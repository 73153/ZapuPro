//
//  UIImage+gifAnime.m
//  photobug
//
//   on 02/07/16.
//  Copyright © Photobug. All rights reserved.
//

#import "UIImage+gifAnime.h"

@implementation UIImage (gifAnime)

@end
