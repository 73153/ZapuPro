//
//  UIImage+gifAnime.h
//  photobug
//
//   on 02/07/16.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (gifAnime)

@end
