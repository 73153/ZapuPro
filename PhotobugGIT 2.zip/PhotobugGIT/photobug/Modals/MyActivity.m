 
//
//  MyActivity.m
//  photobug
//
//   on 20/11/15.
//  Copyright © Photobug. All rights reserved.
//

#import "MyActivity.h"
#import "APICall.h"
#import "Constant.h"
#import "ApplicationData.h"
@implementation MyActivity
@synthesize currentCredit,awards, totalEarning,currentContest,aryCreditHostory,profileid,key,email,firstname,lastname,following,follower,totalMileston,username,arytotalEarningHostry,profileDescription,profileImage,totalCredits,userid,aryAlbumImageList,aryContest,aryMileStone,pasttransaction,credits_history_descStr,past_transactions_descStr,isPastTransaction,isCreditTransaction,aryNoOfMileStone;
// initialize all property of activity class
-(instancetype)init
{
    self = [super init];
    if(self) {
        currentCredit=[[NSMutableString alloc]init];
        awards=[[NSMutableString alloc]init];
        totalEarning=[[NSMutableString alloc]init];
        currentContest=[[NSMutableString alloc]init];
        profileid=[[NSMutableString alloc]init];
        key=[[NSMutableString alloc]init];
        email = [[NSMutableString alloc]init];
        username = [[NSMutableString alloc]init];
        firstname = [[NSMutableString alloc]init];
        lastname = [[NSMutableString alloc]init];
        following = [[NSMutableString alloc]init];
        follower = [[NSMutableString alloc]init];
        totalEarning = [[NSMutableString alloc]init];
        profileDescription=[[NSMutableString alloc]init];
        profileImage=[[NSMutableString alloc]init];
        totalCredits=[[NSMutableString alloc]init];
        userid=[[NSMutableString alloc]init];
        aryAlbumImageList = [[NSMutableArray alloc]init];
        aryCreditHostory=[[NSMutableArray alloc]init];
        arytotalEarningHostry = [[NSMutableArray alloc] init];
        aryMileStone = [[NSMutableArray alloc]init];
        aryNoOfMileStone = [[NSMutableArray alloc] init];
        pasttransaction=[[NSMutableArray alloc]init];
        past_transactions_descStr=[[NSMutableString alloc]init];
         credits_history_descStr=[[NSMutableString alloc]init];
        
    }
    return self;
}
// get my activity detail like  credit ,credit history, no of contest , post transaction
-(void)getMyActivity:(activity_completion_block)completion {
    @try {
    NSString *url_String = [NSString stringWithFormat:@"%@",API_MYACTIVITY ];
    NSDictionary *parameters = @{@"key":self.key,@"profile_id":appDelegate.profilid_AppStr};
    
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* activity, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(activity,@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[activity valueForKey:@"error"]integerValue]==0)
                {
                    self.aryAlbumImageList = [[activity valueForKey:@"data"] valueForKey:@"album_image_list"];
                    self.awards = [[activity valueForKey:@"data"] valueForKey:@"awards"];
                    NSArray *contentArray;
                    
                    
                    if ([[[activity valueForKey:@"data"] valueForKey:@"credit_history"] isKindOfClass:[NSArray class]]) {
                    if ([[[activity valueForKey:@"data"] valueForKey:@"credit_history"] count])
                    {
                        self.aryCreditHostory = [[activity valueForKey:@"data"] valueForKey:@"credit_history"];
                        contentArray= [[activity valueForKey:@"data"] valueForKey:@"content"];
                    }
                    else
                        self.aryCreditHostory = [[NSMutableArray alloc]init];
                    }
                    else
                        self.aryCreditHostory = [[NSMutableArray alloc]init];
                    
                    self.currentContest = [[activity valueForKey:@"data"] valueForKey:@"current_contests"];
                    self.email = [[activity valueForKey:@"data"] valueForKey:@"email"];
                    self.firstname = [[activity valueForKey:@"data"] valueForKey:@"fname"];
                    self.username = [[activity valueForKey:@"data"] valueForKey:@"username"];
                    self.following = [[activity valueForKey:@"data"] valueForKey:@"followedby"];
                    self.follower = [[activity valueForKey:@"data"] valueForKey:@"followers"];
                    self.lastname = [[activity valueForKey:@"data"] valueForKey:@"lname"];
                    self.aryMileStone = [[activity valueForKey:@"data"] valueForKey:@"milesstone"];
                    self.aryNoOfMileStone = [[activity valueForKey:@"data"] valueForKey:@"milestone"];
                    self.pasttransaction= [[activity valueForKey:@"data"] valueForKey:@"pasttransaction"];
                    
                    self.profileDescription = [[activity valueForKey:@"data"] valueForKey:@"profile_description"];
                    self.profileImage = [[activity valueForKey:@"data"] valueForKey:@"profile_photo"];
                    self.totalCredits = [[activity valueForKey:@"data"] valueForKey:@"total_credits"];
                    self.totalEarning = [[activity valueForKey:@"data"] valueForKey:@"total_earning"];
                    self.arytotalEarningHostry = [[activity valueForKey:@"data"] valueForKey:@"total_earning_history"];
                    self.totalMileston = [[activity valueForKey:@"data"] valueForKey:@"total_milestone"];
                    self.userid= [[activity valueForKey:@"data"] valueForKey:@"user_id"];
                    self.profileid= [[activity valueForKey:@"data"] valueForKey:@"profile_id"];
                    
                    self.credits_history_descStr= [contentArray valueForKey:@"credits_history_desc"];
                    self.past_transactions_descStr= [contentArray valueForKey:@"past_transactions_desc"];
                    
                    appDelegate.profilid_AppStr= [[activity valueForKey:@"data"] valueForKey:@"profile_id"];
                   // APPDATA.activity.aryCreditHostory = [[activity valueForKey:@"data"] valueForKey:@"credit_history"];
                    completion(activity,@"Login success",1);
                }
                else if ([[activity valueForKey:@"error"]integerValue]==1)
                {
                    completion(activity,[activity valueForKey:@"message"],-1);
                }
            }
        }
    }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}




@end
