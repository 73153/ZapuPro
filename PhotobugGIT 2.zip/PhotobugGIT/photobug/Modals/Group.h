//
//  Group.h
//  photobug
//
//   on 18/12/15.
//  Copyright © Photobug. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Group : NSObject
typedef void(^group_completion_block)(NSDictionary *result,NSString *, int status);
@property NSMutableString *key,*page,*profileid,*groupId,*imageId,*comment,*postImage,*message,*feedType,*postId,* groupName, *postedBy, *groupDescription, *groupImg,  *rowID;
@property int lastPage;
@property BOOL isGroupCommentAdd,isGroupLeave,isGroupJoin,isDeleteGroup, AddCommentsuccess,isGroupPost,FeedFlagpost;
@property NSMutableArray *arrgroupList,*arrGroupFeed,*arrMyGroupList;
-(void)getGroupList:(group_completion_block)completion;
-(void)getMyGroupList:(group_completion_block)completion;
-(void)getGroupFeed:(group_completion_block)completion;
-(void)joinGroup:(group_completion_block)completion;
-(void)verifyGroupMember:(group_completion_block)completion;
-(void)addGroup:(group_completion_block)completion;
-(void)deleteGroup:(group_completion_block)completion;

-(void)addPostInGroup:(group_completion_block)completion;
-(void)sendCommentInGroup:(group_completion_block)completion;
-(void)deleteGroupPost:(group_completion_block)completion;
-(void)deleteAdminGroupPost:(group_completion_block)completion;
-(void)flagGroupPost:(group_completion_block)completion;
-(void)deleteGroupCommentPost:(group_completion_block)completion;
-(void)flagGroupComment:(group_completion_block)completion;

@end
