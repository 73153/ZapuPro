//
//  AddComment.h
//  photobug
//
//   on 11/20/15.
//  Copyright © Photobug. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Feed : NSObject
//typedef void(^Comment_completion_block)(NSDictionary *result,NSString *, int status);
//@property NSMutableString  *key,*,*message,*data, *session,*appStatus,*requestTime;
////@property NSMutableArray *aryCreditHostory,*arytotalEarningHostry,*aryMileStone,*aryAlbumImageList,*aryContest;
//-(void)getAddComment:(Comment_completion_block)completion;
@end
