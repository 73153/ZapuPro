//
//  DashBoard.m
//  photobug
//
//   on 11/6/15.
//  Copyright © Photobug. All rights reserved.
//

#import "DashBoard.h"
#import "Constant.h"
#import "APICall.h"

@implementation DashBoard
@synthesize bannerBottomImage,bannerTopImage,SplashImage1,SplashImage2,SplashImage3,SplashImage4,SplashImage5,bannerMaintitle;

// initialize all the dashboard property
-(instancetype)init
{
    self = [super init];
    if(self) {
        bannerTopImage=[[NSMutableString alloc]init];
        bannerBottomImage=[[NSMutableString alloc]init];
        SplashImage1=[[NSMutableString alloc]init];
        SplashImage2=[[NSMutableString alloc]init];
        SplashImage3=[[NSMutableString alloc]init];
        SplashImage4=[[NSMutableString alloc]init];
        SplashImage5=[[NSMutableString alloc]init];
        bannerMaintitle=[[NSMutableString alloc]init];
    }
    return self;
}
// get dashboard image
-(void)getDashBoardImage:(dashboard_completion_block)completion {
    @try {
    NSString *url_String = [NSString stringWithFormat:@"%@", API_DASHBOARD];
    [APICall callGetWebService:url_String andDictionary:nil completion:^(NSMutableDictionary *user, NSError *error, long code){
        if(error)
        {
            if(completion)
            {
                completion(nil,@"OOPS Seems like something is wrong with server",-1);
            }
        }
        else{
            if(completion)
            {
                if([[user valueForKey:@"error"]integerValue]==0)
                {
                    completion(user,@"User account registered successfully ",1);
                }
                else if([[user valueForKey:@"error"]integerValue]==1){
                    completion(user,@"Email id is already registered ",0);
                }
                else{
                    completion(user,@"Error From server ",0);
                }
            }
        }

    }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
// get landing page images 
-(void)getLandingPageImage:(dashboard_completion_block)completion
{
    @try {
    NSString *url_String = [NSString stringWithFormat:@"%@", API_LANDINGPAGE];
    [APICall callGetWebService:url_String andDictionary:nil completion:^(NSMutableDictionary *user, NSError *error, long code){
        if(error)
        {
            if(completion)
            {
                completion(nil,@"OOPS Seems like something is wrong with server",-1);
            }
        }
        else{
            if(completion)
            {
                if([[user valueForKey:@"error"]integerValue]==0)
                {
                    completion(user,@"User account registered successfully ",1);
                }
                else if([[user valueForKey:@"error"]integerValue]==1){
                    completion(user,@"Email id is already registered ",0);
                }
                else{
                    completion(user,@"Error From server ",0);
                }
            }
        }
        
    }];
    
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
@end
