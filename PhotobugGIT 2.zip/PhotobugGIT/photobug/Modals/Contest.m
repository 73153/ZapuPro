         //
//  Contest.m
//  photobug
//
//   on 03/12/15.
//  Copyright © Photobug. All rights reserved.
//

#import "Contest.h"
#import "Constant.h"
#import "ApplicationData.h"
#import "APICall.h"

@implementation Contest
@synthesize key,page,profileid,tagid,tagName,arr,dictImageDetail,arrTagDetail,nextPageUrl,lastPage,arrContestList,contestid,arrVoteImageList,aryContestInfo,cont_id,selectTagArray,selectTagNameArray;

// initialize property of contest class
-(instancetype)init
{
    self = [super init];
    if(self) {
    key = [[NSMutableString alloc]init];
    page = [[NSMutableString alloc]init];
    tagid = [[NSMutableString alloc] init];
    tagName = [[NSMutableString alloc] init];
    nextPageUrl = [[NSMutableString alloc] init];
    lastPage = [[NSMutableString alloc] init];
    contestid = [[NSMutableString alloc] init];
    arr = [[NSMutableArray alloc] init];
    arrTagDetail = [[NSMutableArray alloc] init];
    dictImageDetail = [[NSMutableDictionary alloc] init];
    arrContestList = [[NSMutableArray alloc] init];
    arrVoteImageList = [[NSMutableArray alloc] init];
    aryContestInfo = [[NSMutableArray alloc] init];
    selectTagArray=[[NSMutableArray alloc]init];
        
        selectTagNameArray=[[NSMutableArray alloc]init];
        
        cont_id = 0;
    }
    return self;
}

// get contest category
-(void)getContestCategory:(contest_completion_block)completion{
    
    @try {
        
    
    NSString *url_String = [NSString stringWithFormat:@"%@", API_CONTEST_TAG];
        
    NSDictionary *parameters = @{@"key":self.key,@"profile_id":APPDATA.user.profileid};
    
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* contest, NSError*error, long code){ 
        if(error)
        {
            if(completion)
            {
                completion(contest,@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[contest valueForKey:@"error"]integerValue]==0)
                {
                    APPDATA.contest.arrTagDetail=[[NSMutableArray alloc]init];
                    
                    
                    NSMutableArray *arrTagData = [[contest valueForKey:@"data"]objectForKey:@"data"];
                    
                    [arrTagData enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                        
                    [APPDATA.contest.arrTagDetail addObject:obj];
                        
                    }];
                   
                    APPDATA.contest.nextPageUrl = [[contest valueForKey:@"data"] valueForKey:@"next_page_url"];
                    //self.lastPage = [[[contest valueForKey:@"data"] valueForKey:@"last_page"] intValue];
                    
                  
                    
                    completion(contest,@"Login success",1);
                }
                else{
                    completion(contest,[contest valueForKey:@"message"],-1);
                }
            }
        }
    }];
    }
    @catch (NSException *exception) {
        
        
        
    }
    @finally {
        
    }
    
}
// get contest list
-(void)getContestList:(contest_completion_block)completion{
    @try {
    
        
         NSString *url_String = [NSString stringWithFormat:@"%@", API_ALL_CONTESTS];
    
      NSDictionary *parameters = @{@"key":self.key,@"sort":@"All"};
    
        
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* contest, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(contest,@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[contest valueForKey:@"error"]integerValue]==0)
                {
                    APPDATA.contest.arrContestList = [[NSMutableArray alloc] init];
                    
                    NSMutableArray *arrProfileData = [[[contest valueForKey:@"data"] valueForKey:@"tag_image_data"] valueForKey:@"data"];
                    [arrProfileData enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                        [APPDATA.contest.arrContestList addObject:obj];
                    }];
                    
                    APPDATA.user.lastPage = [[[[contest valueForKey:@"data"] valueForKey:@"tag_image_data"] valueForKey:@"last_page"] intValue];
                    
                    
                    completion(contest,@"Login success",1);
                }
                else{
                    completion(contest,[contest valueForKey:@"message"],-1);
                }
            }
        }
    }];
    }
    @catch (NSException *exception) {
         [APPDATA hideLoader];
    }
    @finally {
        
    }
}
// get image of selected contest
-(void)getContestImageList:(contest_completion_block)completion {
    @try {
    NSString *url_String = [NSString stringWithFormat:@"%@", API_CONTEST_IMAGE_LIST];
    
        NSString *Strprofileid;
        
        if (APPDATA.isUserLogin==YES )
        {
            Strprofileid=[NSString stringWithFormat:@"%@",APPDATA.user.profileid];
        }else{
            Strprofileid=@" ";
        }
        
    
        NSDictionary *parameters = @{@"key":self.key,@"profile_id":Strprofileid,@"contest_id":self.contestid};
        
        
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* contest, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(contest,@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[contest valueForKey:@"error"]integerValue]==0)
                {
                    APPDATA.contest.arrVoteImageList=[[NSMutableArray alloc]init];
                    
                    NSMutableArray *arrTagData = [[contest valueForKey:@"data"]objectForKey:@"data"];
                    [arrTagData enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                        
                        if (idx<2)
                        {
                              [APPDATA.contest.arrVoteImageList addObject:obj];
                        }
                        
                      
                        
                    }];
                    
                    
                    APPDATA.contest.nextPageUrl = [[contest valueForKey:@"data"] valueForKey:@"next_page_url"];
                    
                    
                    
                    
                    
                    completion(contest,@"Login success",1);
                }
                else{
                    completion(contest,[contest valueForKey:@"message"],-1);
                }
            }
        }
    }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
// get contest info
-(void)getContestinfo:(contest_completion_block)completion{
    @try {
    NSString *url_String = [NSString stringWithFormat:@"%@", API_CONTEST_INFO];
    NSDictionary *parameters = @{@"key":self.key,@"contest_id":self.contestid};
    
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* recent, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(recent,@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[recent valueForKey:@"error"]integerValue]==0)
                {

                    
                    completion(recent,@"Login success",1);
                }
                else{
                    completion(recent,[recent valueForKey:@"message"],-1);
                }
            }
        }
    }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

@end
