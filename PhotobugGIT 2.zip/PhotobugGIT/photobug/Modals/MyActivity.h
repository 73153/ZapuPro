//
//  MyActivity.h
//  photobug
//
//   on 20/11/15.
//  Copyright © Photobug. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyActivity : NSObject
typedef void(^activity_completion_block)(NSDictionary *result,NSString *, int status);
@property NSMutableString  *profileid,*key,*currentCredit,*awards, *totalEarning,*currentContest,*email,*firstname,*lastname,*following,*follower,*totalMileston,*username,*profileDescription,*profileImage,*totalCredits,*userid,*credits_history_descStr,*past_transactions_descStr;



@property BOOL isPastTransaction,isCreditTransaction;
@property NSMutableArray *aryCreditHostory,*arytotalEarningHostry,*aryMileStone,*aryAlbumImageList,*aryContest,*pasttransaction,*aryNoOfMileStone;
-(void)getMyActivity:(activity_completion_block)completion;
@end
