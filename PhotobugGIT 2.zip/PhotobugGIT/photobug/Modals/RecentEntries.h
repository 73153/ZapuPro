//
//  RecentEntries.h
//  photobug
//
//   on 11/20/15.
//  Copyright © Photobug. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RecentEntries : NSObject
typedef void(^recentEntries_completion_block)(NSDictionary *result,NSString *, int status);
@property int lastPage;
@property NSMutableString  *profileid,*key,*filter_by,*page,*imageId,*flaggedbyId;
@property NSMutableArray *aryRecentImage,*aryPhotoId,*AryRecentphotoId;
@property NSMutableArray *aryMyphotoImage,*aryMyPhotoId,*aryMyphotoTintEye,*aryMyphotoTag,*DictMyPhotodata,*aryMyphotocaption,*arymyphotouser;

@property NSMutableArray *arycontestsMyPhotosImage,*aryContestsTag,*aryConteid,*aryContestsComment,*aryConstentUser,*aryAddShop,*aryConstentCmnt,*aryRecentid,*aryRecentTag,*aryRecentComment,*aryRecentUser,*aryRecentAddShop,*aryRecentCmnt, *DictContenstData,*aryRecentTintEye;
-(void)getRecentEntriesImage:(recentEntries_completion_block)completion;
-(void)getContestsMyPhotosImage:(recentEntries_completion_block)completion;
-(void)deleteImageFromDashboard:(recentEntries_completion_block)completion;
-(void)flageImage:(recentEntries_completion_block)completion;
-(void)MyPhotoImage:(recentEntries_completion_block)completion;


@end
