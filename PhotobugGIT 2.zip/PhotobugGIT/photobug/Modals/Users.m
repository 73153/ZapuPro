//
//  Users.m
//  Rover
//
//  Created by Aadil Keshwani on 3/17/15.
//  Copyright (c) 2015 Aadil Keshwani. All rights reserved.
//

#import "Users.h"
#import "APICall.h"
#import "Constant.h"
#import "ApplicationData.h"

@implementation Users
@synthesize username,password,userid,accountid,firstname,lastname,pin,key,page,profileid,aryMyProfileImage,nextPageUrl,gId,otherProfileid,postid,comment,followedby,aryAddCommentPost,aryProfileAddFollowers,lastPage,InviteUrl,rowID,strOtherId,loginusername,isProfilePublish;
@synthesize strTextfildStreet,StrTextViewDescription,strtxtfildCity,strStateId,strStateName,strtxtFildCurrntpwd,strTxtFildRetypNewPwd,strtxtFildStreet2,strtxtfildZip,strTxtFildNewPwd,strTxtfildPhonenom,strSMS,strAccPrivate,isFacebookLogin,strtxtfildUserName;
// initialize user class property
-(instancetype)init
{
    self = [super init];
    if(self) {
        self.username=[[NSMutableString alloc]init];
        self.loginusername=[[NSMutableString alloc]init];
        self.email=[[NSMutableString alloc]init];
        self.password=[[NSMutableString alloc]init];
        self.currentPassword=[[NSMutableString alloc]init];
        self.firstname=[[NSMutableString alloc]init];
        self.lastname=[[NSMutableString alloc]init];
        self.imgPath=[[NSMutableString alloc] init];
        self.deviceToken=[[NSString alloc] init];
        self.accountid=0;
        self.userid= [[NSMutableString alloc] init];
        self.pin=0;
        self.fbid=[[NSMutableString alloc]init];
    	 self.gId=[[NSMutableString alloc]init];
        lastPage = 0;
        self.profileid=[[NSMutableString alloc]init];
        self.nextPageUrl = [[NSMutableString alloc]init];
        profileid=[[NSMutableString alloc]init];
        key=[[NSMutableString alloc]init];
        comment=[[NSMutableString alloc]init];
        postid=[[NSMutableString alloc]init];
        aryMyProfileImage=[[NSMutableArray alloc]init];
        aryAddCommentPost=[[NSMutableArray alloc]init];
        followedby=[[NSMutableString alloc]init];
        aryProfileAddFollowers=[[NSMutableArray alloc]init];
        //      
         self.InviteUrl = [[NSMutableString alloc]init];
        strtxtfildZip=[[NSMutableString alloc]init];
        strtxtFildStreet2=[[NSMutableString alloc]init];
       strTxtFildRetypNewPwd=[[NSMutableString alloc]init];
       strtxtFildCurrntpwd=[[NSMutableString alloc]init];
        strTextfildStreet=[[NSMutableString alloc]init];
        StrTextViewDescription=[[NSMutableString alloc]init];
       strtxtfildCity =[[NSMutableString alloc] init];
        strTxtFildNewPwd=[[NSMutableString alloc] init];
        strtxtfildUserName=[[NSMutableString alloc]init];
        strTxtfildPhonenom=[[NSMutableString alloc] init];

        rowID=[[NSMutableString alloc] init];
         strOtherId=[[NSMutableString alloc] init];
    }
    return self;
}
// request for register user
-(void)registerUser:(user_completion_block)completion{
    @try {
       
        if ([self.deviceToken length]<1)
        {
            self.deviceToken=@" ";
        }
   
    NSDictionary *parameters = @{@"email":self.email,@"fname": self.firstname,@"lname":self.lastname, @"password":self.password,@"sDeviceToken":self.deviceToken,@"username":self.username,@"status":@"0"};
    NSString *url_String = [NSString stringWithFormat:@"%@", API_USER];
    
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(@"OOPS Seems like something is wrong with server",-1);
            }
            [[[error userInfo] objectForKey:AFNetworkingOperationFailingURLResponseErrorKey] statusCode];
        }
        else{
            if(completion)
            {
                
                if([[user valueForKey:@"error"]integerValue]==0)
                {
                    APPDATA.user.userid = [[user valueForKey: @"data"] valueForKey:@"user_id"];
                    APPDATA.user.profileid = [[user valueForKey: @"data"] valueForKey:@"profile_id"];
                    APPDATA.user.username = [[user valueForKey:@"data"] valueForKey:@"username"];
                    APPDATA.user.InviteUrl = [[user valueForKey:@"data"] valueForKey:@"invite_url"];
                    appDelegate.profilid_AppStr=[NSString stringWithFormat:@"%@",[[user valueForKey: @"data"] valueForKey:@"profile_id"]];
                    APPDATA.user.isProfilePublish = [[[user valueForKey:@"data"] valueForKey:@"status"] boolValue];
                    completion(SUCCESS_SIGNUP,1);
                    
                }
                else if([[user valueForKey:@"error"]integerValue]==1)
                {
                    completion(@"User name already exists",0);
                }
                else
                {
                    completion(@"Error From server ",0);
                }
            }
        }
    }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
// request for registration by facebook
-(void)socialRegistrUser:(user_completion_block)completion
{
   // username,email,social_id,social_site,fname,lname,password
    @try
    {

    if(!self.email)
    {
        self.email=[@"newemail@gmail.com" mutableCopy];
    }
        
    NSDictionary *parameters = @{@"username":self.username,@"email":self.email,@"fname": self.firstname,@"lname":self.lastname, @"password":@"123456",@"social_id":self.fbid,@"social_site":self.socialType,@"sDeviceToken":self.deviceToken};
    NSString *url_String = [NSString stringWithFormat:@"%@", API_SOCIAL_LOGIN_NEW];
        
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code)
        {
        if(error)
        {
            NSLog(@"%ld",code);
            
            if(completion)
            {
                completion(@"OOPS Seems like something is wrong with server",-1);
            }
            
            [[[error userInfo] objectForKey:AFNetworkingOperationFailingURLResponseErrorKey] statusCode];
        }
        else
        {
            if(completion)
            {
                if([[user valueForKey:@"error"]intValue]==0)
                {
                    APPDATA.user.userid = [[user valueForKey: @"data"] valueForKey:@"user_id"];
                    APPDATA.user.profileid = [[user valueForKey: @"data"] valueForKey:@"profile_id"];
                    APPDATA.user.username = [[user valueForKey:@"data"] valueForKey:@"username"];
                    APPDATA.user.InviteUrl = [[user valueForKey:@"data"] valueForKey:@"invite_url"];
                    appDelegate.profilid_AppStr=[NSString stringWithFormat:@"%@",[[user valueForKey: @"data"] valueForKey:@"profile_id"]];
                    APPDATA.user.isProfilePublish = [[[user valueForKey:@"data"] valueForKey:@"status"] boolValue];
                    completion(@"User account registered successfully ",1);
                }
                else if([[user valueForKey:@"error"]intValue]==1)
                {
                    completion([user valueForKey:@"message"],0);
                    
                }
            }
        }
    }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

// verify user is already exist or not
-(void)verifyUser{
    @try {
    NSString *url_String = [NSString stringWithFormat:@"%@/%@/verify?pin=%i", API_USER,self.userid,self.pin];
    [APICall callPostWebService:url_String andDictionary:nil completion:^(NSDictionary* user, NSError*error, long code){
        if(error)
        {
            //NSLog(@"Error");
        }
        else{
           // NSLog(@"Success");
        }
    }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
// request for login in app
-(void)loginUser:(user_completion_block)completion{
    @try {
    NSString *url_String = [NSString stringWithFormat:@"%@", API_USER_LOGIN];
    
    NSDictionary *parameters = @{@"email":self.email,@"password":self.password,@"sDeviceToken":self.deviceToken
                                 };
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[user valueForKey:@"error"]integerValue]==0)
                {
                    self.userid  =[[[user objectForKey:@"data"] objectAtIndex:0] objectForKey:@"id"];
                    
                    self.InviteUrl=[[[user objectForKey:@"data"] objectAtIndex:0] objectForKey:@"invite_url"];
                    [[NSUserDefaults standardUserDefaults]setObject:self.InviteUrl forKey:@"invite_url"];
                    self.username=[[[user objectForKey:@"data"] objectAtIndex:0] objectForKey:@"username"];
                    self.firstname=[[[user objectForKey:@"data"] objectAtIndex:0] objectForKey:@"username"];
                    self.profileid=[[[user objectForKey:@"data"] objectAtIndex:0] objectForKey:@"profile_id"];
                    
                    appDelegate.profilid_AppStr=[NSString stringWithFormat:@"%@",[[[user objectForKey:@"data"] objectAtIndex:0] objectForKey:@"profile_id"]];
                    
                    self.isProfilePublish = [[[[user valueForKey:@"data"] objectAtIndex:0] valueForKey:@"status"] boolValue];
//                    NSArray *arrTemp=[user valueForKey:@"data"];
//                    NSDictionary *dicTemp=[arrTemp objectAtIndex:0];
//                    int pub=[[dicTemp valueForKey:@"status"]intValue];
//                    if (pub==0) {
//                        self.isProfilePublish=NO;
//                    }
//                    else
//                    {
//                        self.isProfilePublish=YES;
//                    }
                    
                     UDSetObject(self.userid, @"id");
                    
                    
                    completion(@"Login success",1);
                }
                else{
                    completion([user valueForKey:@"message"],-1);
                }
            }
        }
    }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
// check email id is alredy exitst or not
-(void)checkEmail:(user_completion_block)completion {
    @try {
    NSString *url_String = [NSString stringWithFormat:@"%@", API_CHECKEMAIL];
    NSDictionary *parameters = @{@"email":self.email,@"sDeviceToken":self.deviceToken};
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[user valueForKey:@"error"]integerValue]==0)
                {
                    
                    completion(@"success",1);
                }
                else{
                    completion([user valueForKey:@"message"],-1);
                }
            }
        }
    }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
// check social id is alredy exist or not
-(void)checkSocialId:(user_completion_block)completion {
    @try {
    NSString *url_String = [NSString stringWithFormat:@"%@", API_CHECK_SOCIAL_ID];
    NSDictionary *parameters = @{@"email":self.email,@"key":API_KEY};
    [APICall callGetWebService:url_String andDictionary:parameters completion:^(NSMutableDictionary *user, NSError *error, long code){
    if(error)
     {
         if(completion)
         {
             completion(@"There was some error, please try again later",-1);
         }
     }
     else{
         if(completion)
         {
             if([[user valueForKey:@"error"] intValue ] == 0)
             {
                 completion(@"success",1);
             }
             else if([[user  objectForKey:@"code"]valueForKey:@"email"] ){
                 completion(@"success",0);
             }
             else{
                 completion([user valueForKey:@"message"],-1);
             }
         }
     }
     }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
// check email is alredy exist or not

-(void)CheakExistingEmail:(user_completion_block)completion {
    @try {
 NSString *url_String = [NSString stringWithFormat:@"%@", API_CHECKEMAILEXISTING];
        // NSDictionary *parameters = @{@"social_id":self.userid,@"sDeviceToken":self.deviceToken};
        NSDictionary *parameters = @{@"email":self.emailCheak};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[user valueForKey:@"error"]integerValue]==0)
                    {
                        
                        
                        completion(@"success",1);
                    }
                    else{
                        completion([user valueForKey:@"message"],0);
                    }
                }
            }
        }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

// profile update
-(void)profileUpdate:(NSMutableDictionary *)dictParam forcompl:(user_completion_block)completion{
    @try {
        
    NSString *url_String = [NSString stringWithFormat:@"%@", API_PROFILE_UPDATE];
    
   
    [APICall callPostWebService:url_String andDictionary:dictParam completion:^(NSDictionary* user, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[user valueForKey:@"error"]integerValue]==0)
                {
                   
                    
                    completion(@"Login success",1);
                }
                else{
                    completion([user valueForKey:@"message"],-1);
                }
            }
        }
    }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}


+ (void)updateProfile:(NSDictionary *)dictParam successed:(void (^)(id responseObject_))success_ failure:(void (^)(NSError* error_))failure_
{
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    [dict addEntriesFromDictionary:dictParam];
    
}
// get logedin user profile image
-(void)getmyprofileImage:(user_completion_block)completion{

    @try {
    NSString *url_String = [NSString stringWithFormat:@"%@", API_PROFILELIST];
    
    NSDictionary *parameters = @{@"key":self.key,@"page":self.page,@"profile_id":APPDATA.user.profileid};
    
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* profile, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[profile valueForKey:@"error"]integerValue]==0)
                {
                    
                    NSMutableArray *arrProfileData = [[profile valueForKey:@"data"]objectForKey:@"data"];
                    [arrProfileData enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                        [APPDATA.user.aryMyProfileImage addObject:obj];
                    }];
                     //APPDATA.user.aryMyProfileImage= [[profile valueForKey:@"data"]objectForKey:@"data"];
                     APPDATA.user.nextPageUrl = [[profile valueForKey:@"data"] valueForKey:@"next_page_url"];
                    APPDATA.user.lastPage = [[[profile valueForKey:@"data"] valueForKey:@"last_page"] intValue];
                    
                    completion(@"Login success",1);
                }
                else{
                    completion([profile valueForKey:@"message"],-1);
                }
            }
        }
    }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
     
}
// add comment in post
-(void)ADDCommentOnPost:(user_completion_block)completion{
    @try {
    NSString *url_String = [NSString stringWithFormat:@"%@", API_ADDCOMMENTONPOST];
    
    NSDictionary *parameters =[[NSDictionary alloc]initWithObjectsAndKeys:self.key,@"key",appDelegate.profilid_AppStr,@"profile_id",self.comment,@"comment",self.postid,@"post_id",nil];
    
    
    //    @{@"key":self.key,@"profile_id":self.profileid,@"comment":self.comment,@"postid":self.postid};
    
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary *result, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[result valueForKey:@"error"]integerValue]==0)
                {
                    APPDATA.user.aryAddCommentPost= [[result valueForKey:@"data"]objectForKey:@"data"];
                    APPDATA.user.nextPageUrl = [[result valueForKey:@"data"] valueForKey:@"next_page_url"];
                    APPDATA.user.profileid=[[result valueForKey:@"data"] valueForKey:@"profile_id"];
                                                          
                    completion(@"Login success",1);
                }
                else{
                    completion([result valueForKey:@"message"],-1);
                }
            }
        }
    }];
    
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

// send request for follow selected user
-(void)addFollow:(user_completion_block)completion{
    @try {
     NSString *url_String = [NSString stringWithFormat:@"%@", API_ADDFOLLOWERS];
    NSDictionary *parameters = @{@"key":self.key,@"profile_id":APPDATA.user.profileid,@"followed_by":self.profileid};
    
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* profile, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[profile valueForKey:@"error"]integerValue]==0)
                {
  
                    
                   completion([profile valueForKey:@"data"],1);
                }
                else{
                    completion([profile valueForKey:@"message"],-1);
                }
            }
        }
    }];
    
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}

// verify user is follow or not
-(void)checkfollowedornot:(user_completion_block)completion{
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_USER_FOLLOWING_NOT];
        NSDictionary *parameters = @{@"key":self.key,@"profile_id":self.profileid,@"followed_by":self.followedby};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* profile, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[profile valueForKey:@"error"]integerValue]==0)
                    {
                        completion([[profile valueForKey:@"data"] valueForKey:@"following"],1);
                    }
                    else{
                        completion([profile valueForKey:@"message"],-1);
                    }
                }
            }
        }];
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
// submit user detail for edit user detail
-(void)getSubmitProfile:(user_completion_block)completion
{
    
    @try {
        
        NSString *url_String = [NSString stringWithFormat:@"%@", API_SUBMIT];
        NSDictionary *parameters = @{@"key":API_KEY,@"profile_id": APPDATA.user.profileid,@"contact":[APPDATA isNullOrEmpty: APPDATA.user.strTxtfildPhonenom],@"address1":[APPDATA isNullOrEmpty: APPDATA.user.strTextfildStreet],@"address2":[APPDATA isNullOrEmpty:APPDATA.user.strtxtFildStreet2],@"city":[APPDATA isNullOrEmpty:APPDATA.user.strtxtfildCity],@"state_id":[APPDATA isNullOrEmpty:[NSString stringWithFormat:@"%@",APPDATA.user.strStateId]],@"zip":[APPDATA isNullOrEmpty:APPDATA.user.strtxtfildZip],@"enable_sms":@(APPDATA.user.strSMS),@"isPrivate":@(APPDATA.user.strAccPrivate),@"current_password":[APPDATA isNullOrEmpty:APPDATA.user.strtxtFildCurrntpwd],@"password":[APPDATA isNullOrEmpty:APPDATA.user.strTxtFildNewPwd],@"confirm_password":[APPDATA isNullOrEmpty:APPDATA.user.strTxtFildRetypNewPwd],@"profile_description":APPDATA.user.StrTextViewDescription,@"user_name":strtxtfildUserName};
        
        
        NSLog(@"%@",parameters);
        
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* recent, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(@"There was some error, please try again later",-1);
                }
                
                
            }
            else{
                if(completion)
                {
                    if([[recent valueForKey:@"error"]integerValue]==0)
                    {
                        
                        completion(@"Login success",1);
                    }
                    else{
                        completion([recent valueForKey:@"message"],-1);
                    }
                }
            }
         }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
// delete user prfile/account from app
-(void)getDeleteProfile:(user_completion_block)completion{
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_DELETE];
        
        NSDictionary *parameters = @{@"key":API_KEY,@"profile_id":APPDATA.user.profileid,};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[user valueForKey:@"error"]integerValue]==0)
                    {
                        APPDATA.user = [[Users alloc]init];
                        appDelegate.profilid_AppStr =@"";
                        UDSetObject(APPDATA.user.username, @"");
                        UDSetObject(APPDATA.user.profileid, @"");
                        UDSetObject(APPDATA.user.firstname, @"");
                        UDSetObject(APPDATA.user.userid, @"");
                        UDSetObject(APPDATA.user.InviteUrl,@"");
                        NSLog(@"%@",APPDATA.user.InviteUrl);
                         completion([user valueForKey:@"message"],1);
                    }
                    else{
                        completion([user valueForKey:@"message"],-1);
                    }
                }
            }
        }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
// edit profile
-(void)EditProfile:(user_completion_block)completion
{
    
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_EDIT_PROFILE];
        NSDictionary *parameters = @{@"key":API_KEY,@"profile_id":APPDATA.user.profileid};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* profile, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[profile valueForKey:@"error"]integerValue]==0)
                    {
                        APPDATA.user.strTextfildStreet=[[APPDATA isNullOrEmpty:[[[profile objectForKey:@"data"] objectAtIndex:0]valueForKey:@"address1"]] mutableCopy];
                        APPDATA.user.strtxtFildStreet2=[[APPDATA isNullOrEmpty:[[[profile objectForKey:@"data"] objectAtIndex:0] valueForKey:@"address2"]] mutableCopy];
                        APPDATA.user.strtxtfildCity =[[APPDATA isNullOrEmpty:[[[profile objectForKey:@"data"] objectAtIndex:0]valueForKey:@"city"]] mutableCopy];
                        APPDATA.user.strTxtfildPhonenom=[[APPDATA isNullOrEmpty:[NSString stringWithFormat:@"%@",[[[profile objectForKey:@"data"] objectAtIndex:0] valueForKey:@"contact"]]] mutableCopy];
                        APPDATA.user.strSMS=[[[[profile objectForKey:@"data"] objectAtIndex:0] valueForKey:@"enable_sms"] boolValue];
                        APPDATA.user.strAccPrivate= [[[[profile objectForKey:@"data"] objectAtIndex:0] valueForKey:@"isPrivate"] boolValue];
                        APPDATA.user.StrTextViewDescription =[[APPDATA isNullOrEmpty:[[[profile objectForKey:@"data"] objectAtIndex:0] valueForKey:@"profile_description"]] mutableCopy];
                        APPDATA.user.strtxtfildUserName =[[APPDATA isNullOrEmpty:[[[profile objectForKey:@"data"] objectAtIndex:0] valueForKey:@"username"]] mutableCopy];
                        APPDATA.user.strStateName=[[APPDATA isNullOrEmpty:[[[profile objectForKey:@"data"] objectAtIndex:0] valueForKey:@"statename"]] mutableCopy];
                        APPDATA.user.strtxtfildZip=[[APPDATA isNullOrEmpty:[NSString stringWithFormat:@"%@",[[[profile objectForKey:@"data"] objectAtIndex:0]valueForKey:@"zip"]]] mutableCopy];
                        APPDATA.user.isFacebookLogin=[[[[profile objectForKey:@"data"] objectAtIndex:0] valueForKey:@"isFacebookLogin"] boolValue];
                        completion(@"Login success",1);
                    }
                    else{
                        completion([profile valueForKey:@"message"],-1);
                    }
                }
            }
            
        }];
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
// delete dashboard post service....

-(void)deleteDashboardPost:(user_completion_block)completion{
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_DELETE_DASHBOARD_POST];

        NSDictionary *parameters=[[NSDictionary alloc]init];
        parameters = @{@"key":API_KEY,@"rowid":self.rowID};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code){
                if(error)
                {
                    if(completion)
                    {
                        completion(@"There was some error, please try again later",-1);
                    }
                }
                else{
                    if(completion)
                    {
                        if([[user valueForKey:@"error"]integerValue]==0)
                        {
                            
                            completion([user valueForKey:@"message"],1);
                        }
                        else{
                            completion([user valueForKey:@"message"],-1);
                        }
                    }
                }

        }];
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

// flag dashboard post

-(void)flagDashboardPost:(user_completion_block)completion{
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_FLAG_DASHBOARD_POST];
        
        NSDictionary *parameters=[[NSDictionary alloc]init];
        parameters = @{@"key":API_KEY,@"rowid":self.rowID,@"flagged_by":APPDATA.user.profileid,@"user_id":self.userid};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[user valueForKey:@"error"]integerValue]==0)
                    {
                        
                        completion([user valueForKey:@"message"],1);
                    }
                    else{
                        completion([user valueForKey:@"message"],-1);
                    }
                }
            }
            
        }];
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

// delete feed commment of selected post
-(void)deleteFeedCommentPost:(user_completion_block)completion {
    
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_DELETE_DASHBOARD_COMMENT];
        
        NSDictionary *parameters = @{@"key":API_KEY,@"rowid":self.rowID};
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[user valueForKey:@"error"]integerValue]==0)
                    {
                        completion(@"Delete success",1);
                    }
                    else{
                        completion([user valueForKey:@"message"],-1);
                    }
                }
            }
        }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
// flag dashboad comment
-(void)flagDashboardComment:(user_completion_block)completion{
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_FLAG_DASHBOARD_COMMENT];
        
        NSDictionary *parameters=[[NSDictionary alloc]init];
        parameters = @{@"key":API_KEY,@"rowid":self.rowID,@"flagged_by":APPDATA.user.profileid,@"user_id":self.userid};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[user valueForKey:@"error"]integerValue]==0)
                    {
                        
                        completion([user valueForKey:@"message"],1);
                    }
                    else{
                        completion([user valueForKey:@"message"],-1);
                    }
                }
            }
            
        }];
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

// if user is first time register then should be publish his profile otherwise they cant do any thing
- (void)publishProfile:(user_completion_block)completion{
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_PUBLISH_PROFILE];
        
        NSDictionary *parameters=[[NSDictionary alloc]init];
        parameters = @{@"key":API_KEY,@"profile_id":APPDATA.user.profileid,@"status":@"1"};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[user valueForKey:@"error"]integerValue]==0)
                    {
                        if ([[user valueForKey:@"message"] isKindOfClass:[NSArray class]]) {
                            completion([[user valueForKey:@"message"] objectAtIndex:0],1);
                        }
                        else
                            completion([user valueForKey:@"message"],1);
                    }
                    else{
                        if ([[user valueForKey:@"message"] isKindOfClass:[NSArray class]]) {                        completion( [user valueForKey:@"message"],-1);
                        }
                    }
                }
            }
            
        }];
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}


@end
