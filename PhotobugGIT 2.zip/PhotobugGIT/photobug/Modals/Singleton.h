//
//  Singleton.h
//  photobug
//
//   on 29/06/16.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Singleton : UIViewController
@property NSMutableString *StrTextViewDescription,*strTxtfildPhonenom,*strTextfildStreet,*strtxtFildStreet2,*strtxtfildCity,*strtxtfildZip,*strtxtFildCurrntpwd,*strTxtFildRetypNewPwd,*strTxtFildNewPwd,*strSMS,*strAccPrivate;

@end
