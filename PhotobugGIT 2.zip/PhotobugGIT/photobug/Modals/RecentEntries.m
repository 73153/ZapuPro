//
//  RecentEntries.m
//  photobug
//
//   on 11/20/15.
//  Copyright © Photobug. All rights reserved.
//

#import "RecentEntries.h"
#import "Constant.h"
#import "ApplicationData.h"
#import "APICall.h"


@implementation RecentEntries
@synthesize profileid,key,aryRecentImage,arycontestsMyPhotosImage,aryConteid,aryContestsTag,aryContestsComment,aryConstentUser,aryConstentCmnt,aryAddShop,aryRecentid,aryRecentTag,aryRecentComment,aryRecentUser,aryRecentCmnt,aryRecentAddShop,DictContenstData,filter_by,page,aryPhotoId,AryRecentphotoId,flaggedbyId,aryRecentTintEye,aryMyPhotoId,aryMyphotoImage,aryMyphotoTag,aryMyphotoTintEye,DictMyPhotodata,aryMyphotocaption,arymyphotouser;
// initialize all property of recent entries class 
-(instancetype)init
{
    self = [super init];
    if(self) {
        
        profileid=[[NSMutableString alloc]init];
        flaggedbyId=[[NSMutableString alloc]init];
        key=[[NSMutableString alloc]init];
        aryPhotoId=[[NSMutableArray alloc]init];
        aryRecentImage=[[NSMutableArray alloc]init];
        arycontestsMyPhotosImage=[[NSMutableArray alloc]init];
        aryContestsTag=[[NSMutableArray alloc]init];
        aryContestsComment=[[NSMutableArray alloc]init];
        aryConstentUser=[[NSMutableArray alloc]init];
        aryConteid=[[NSMutableArray alloc]init];
        aryConstentCmnt=[[NSMutableArray alloc]init];
        aryAddShop=[[NSMutableArray alloc]init];
        aryRecentid=  [[NSMutableArray alloc] init];
        aryRecentTag = [[NSMutableArray alloc] init];
        aryRecentComment=  [[NSMutableArray alloc] init];
        aryRecentUser=[[NSMutableArray alloc]init];
        aryRecentAddShop=  [[NSMutableArray alloc] init];
        aryRecentCmnt=[[NSMutableArray alloc]init];
        DictContenstData=[[NSMutableArray alloc]init];
        filter_by=[[NSMutableString alloc]init];
        AryRecentphotoId=[[NSMutableArray alloc]init];
        page = [[NSMutableString alloc]init];
        aryRecentTintEye=[[NSMutableArray alloc]init];
        DictMyPhotodata=[[NSMutableArray alloc]init];
        aryMyphotoTintEye=[[NSMutableArray alloc]init];
        aryMyPhotoId=[[NSMutableArray alloc]init];
        aryMyphotoImage = [[NSMutableArray alloc]init];
        aryMyphotoTag=[[NSMutableArray alloc]init];
        aryMyphotocaption=[[NSMutableArray alloc]init];
        arymyphotouser=[[NSMutableArray alloc]init];


    }
    return self;
}
// get my photo/ recent entries photo images
-(void)MyPhotoImage:(recentEntries_completion_block)completion
{
    @try {
        
        
        NSString *url_String = [NSString stringWithFormat:@"%@", API_PROFILE_ALBUM_LIST2];
        
        NSDictionary *parameters = @{@"key":API_KEY,@"profile_id":APPDATA.user.profileid,@" filter_by":@"0"};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* recent, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(recent,@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[recent valueForKey:@"error"]integerValue]==0)
                    {
                        APPDATA.recent.aryMyphotocaption = [[NSMutableArray alloc] init];
                        APPDATA.recent.aryMyPhotoId=  [[NSMutableArray alloc] init];
                        APPDATA.recent.aryMyphotoTintEye = [[NSMutableArray alloc] init];
                        APPDATA.recent.aryMyphotoTag=  [[NSMutableArray alloc] init];
                        APPDATA.recent.arymyphotouser=[[NSMutableArray alloc]init];
                        APPDATA.recent.aryMyphotoImage=[[NSMutableArray alloc]init];

                        [[recent valueForKey:@"data"] enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                            [APPDATA.recent.aryMyphotoImage addObject:[obj valueForKey:@"url"]];
                            //[APPDATA.recent.aryRecentCmnt addObject:[obj valueForKey:@"comments"]];
                            [APPDATA.recent.arymyphotouser addObject:[obj valueForKey:@"username"]];
                            [APPDATA.recent.aryMyphotoTag addObject:[obj objectForKey:@"image_tags"]];
                            [APPDATA.recent.aryMyPhotoId addObject:[obj valueForKey:@"id"]];
                            [APPDATA.recent.aryMyphotocaption addObject:[obj valueForKey:@"title"]];
                            [APPDATA.recent.aryMyphotoTintEye addObject:[obj valueForKey:@"tineye_id"]];
                        }];
                        
                        completion(recent,@"Login success",1);
                    }
                    else{
                        completion(recent,[recent valueForKey:@"message"],-1);
                    }
                }
            }
        }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
 
}



// get recent entrie images
-(void) getRecentEntriesImage:(recentEntries_completion_block)completion{
    @try {
        
        
    NSString *url_String = [NSString stringWithFormat:@"%@", API_PROFILE_ALBUM_LIST];
        
    NSDictionary *parameters = @{@"key":API_KEY,@"profile_id":self.profileid,@" filter_by":filter_by};
    
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* recent, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(recent,@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[recent valueForKey:@"error"]integerValue]==0)
                {
                    APPDATA.recent.aryRecentImage = [[NSMutableArray alloc] init];
                    APPDATA.recent.aryRecentid=  [[NSMutableArray alloc] init];
                    APPDATA.recent.aryRecentTag = [[NSMutableArray alloc] init];
                    APPDATA.recent.aryRecentComment=  [[NSMutableArray alloc] init];
                   APPDATA.recent.aryRecentUser=[[NSMutableArray alloc]init];
                    APPDATA.recent.aryRecentAddShop=  [[NSMutableArray alloc] init];
                    APPDATA.recent.aryRecentCmnt=[[NSMutableArray alloc]init];
                    APPDATA.recent.AryRecentphotoId=[[NSMutableArray alloc]init];
                    APPDATA.recent.aryRecentTintEye=[[NSMutableArray alloc]init];
                [[recent valueForKey:@"data"] enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    [APPDATA.recent.aryRecentImage addObject:[obj valueForKey:@"url"]];
                    [APPDATA.recent.aryRecentCmnt addObject:[obj valueForKey:@"comments"]];
                    [APPDATA.recent.aryRecentAddShop addObject:[obj valueForKey:@"for_sale"]];
                    [APPDATA.recent.aryRecentUser addObject:[obj valueForKey:@"username"]];
                    [APPDATA.recent.aryRecentTag addObject:[obj valueForKey:@"image_tags"]];
                    [APPDATA.recent.AryRecentphotoId addObject:[obj valueForKey:@"id"]];
                    [APPDATA.recent.aryRecentComment addObject:[obj valueForKey:@"title"]];
                    [APPDATA.recent.aryRecentid addObject:[obj valueForKey:@"for_sale"]];
                    [APPDATA.recent.aryRecentTintEye addObject:[obj valueForKey:@"tineye_id"]];
                }];
           
                completion(recent,@"Login success",1);
            }
                else{
                    completion(recent,[recent valueForKey:@"message"],-1);
                }
            }
        }
    }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
// get my photo images
-(void)getContestsMyPhotosImage:(recentEntries_completion_block)completion
{
    @try {
    NSString *url_String = [NSString stringWithFormat:@"%@", API_PROFILE_LIST];
        
    NSDictionary *parameters = @{@"key":API_KEY,@"profile_id":APPDATA.user.profileid};
    
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* recent, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(recent,@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[recent valueForKey:@"error"]integerValue]==0)
                {
                    NSMutableArray *arr = [recent valueForKey:@"data"];
                   // arr= [recent valueForKey:@"data"];
                    arycontestsMyPhotosImage = [[NSMutableArray alloc] init];
                    aryConteid=  [[NSMutableArray alloc] init];
                    aryContestsTag = [[NSMutableArray alloc] init];
                    aryContestsComment=  [[NSMutableArray alloc] init];
                    aryConstentUser=[[NSMutableArray alloc]init];
                    aryAddShop=  [[NSMutableArray alloc] init];
                    aryConstentCmnt=[[NSMutableArray alloc]init];
                    DictContenstData=[[NSMutableArray alloc]init];
                  //  NSArray *ary=[[NSArray alloc]init];
                    
                    for (NSDictionary *dict in arr)
                    {
                        [DictContenstData addObject:dict];
                      // [aryConstentCmnt addObject:[dict valueForKey:@"comments"]];
                        //[aryAddShop addObject:[dict valueForKey:@"for_sale"]];
                      // [aryConstentUser addObject:[dict valueForKey:@"username"]];
                        //[aryContestsTag addObject:[dict valueForKey:@"tag_name"]];
                       // NSString *str=[[NSString alloc]init];
                      
                        [aryContestsTag addObject:[dict valueForKey:@"tag_name"]];
                       // [aryContestsTag addObject:[str componentsSeparatedByString:@","]];
//                          aryContestsTag=[str componentsSeparatedByString:@","];
                        [aryPhotoId addObject:[dict valueForKey:@"id"]];
                        [aryContestsComment addObject:[dict valueForKey:@"title"]];
                        [arycontestsMyPhotosImage addObject:[dict valueForKey:@"url"]];
                        [aryConteid addObject:[dict valueForKey:@"tineye_id"]];
                    }
                    completion(recent,@"Login success",1);
                }
                else{
                    completion(recent,[recent valueForKey:@"message"],-1);
                }
            }
        }
    }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
// delete photo from dashboard
-(void)deleteImageFromDashboard:(recentEntries_completion_block)completion {
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_DELETE_DASHBOARD_IMAGE];
        
        NSDictionary *parameters = @{@"key":API_KEY,@"image_id":self.imageId};
        
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* group, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(group,@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[group valueForKey:@"error"]integerValue]==0)
                    {
                        
                        
                        completion(group,@"",1);
                    }
                    else{
                        completion(group,[[group valueForKey:@"message"] objectAtIndex:0],-1);
                    }
                }
            }
        }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
    }
}
// flage photo images

-(void)flageImage:(recentEntries_completion_block)completion{
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_FLAGGED_IMAGE];
        
        NSDictionary *parameters = @{@"key":API_KEY,@"image_id":self.imageId,@"profile_id":self.profileid,@"flagged_by":self.flaggedbyId};
        
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* group, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(group,@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[group valueForKey:@"error"]integerValue]==0)
                    {
                        

                        completion(group,[group valueForKey:@"message"],1);
                    }
                    else
                    {
                    
                        completion(group,[group valueForKey:@"message"],-1);
                    }
                }
            }
        }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
    }
}

@end
