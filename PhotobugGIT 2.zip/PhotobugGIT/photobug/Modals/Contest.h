//
//  Contest.h
//  photobug
//
//   on 03/12/15.
//  Copyright © Photobug. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Contest : NSObject
typedef void(^contest_completion_block)(NSDictionary *result,NSString *, int status);
@property NSMutableString *key,*page,*profileid,*tagName,*tagid,*nextPageUrl,*lastPage,*contestid;
@property NSMutableArray *arr,*arrTagDetail,*arrContestList,*aryContestInfo,*selectTagArray,*selectTagNameArray,
*arrVoteImageList;
@property NSInteger *cont_id;
@property NSMutableDictionary *dictImageDetail;
-(void)getContestCategory:(contest_completion_block)completion;
-(void)getContestList:(contest_completion_block)completion;
-(void)getContestImageList:(contest_completion_block)completion;
-(void)getContestinfo:(contest_completion_block)completion;

@end
