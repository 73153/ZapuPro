//
//  Group.m
//  photobug
//
//   on 18/12/15.
//  Copyright © Photobug. All rights reserved.
//

#import "Group.h"
#import "ApplicationData.h"
#import "Constant.h"
#import "APICall.h"
#import "AppDelegate.h"

@implementation Group
@synthesize key,profileid,page,lastPage,arrgroupList,groupId,arrGroupFeed,imageId,comment,message,postImage,feedType,arrMyGroupList,postId,rowID,AddCommentsuccess,FeedFlagpost;
// initialize prorpery which are use in group class
-(instancetype)init
{
    self = [super init];
    if(self) {
        key = [[NSMutableString alloc]init];
        page = [[NSMutableString alloc]init];
        profileid = [[NSMutableString alloc]init];
        groupId = [[NSMutableString alloc] init];
        imageId = [[NSMutableString alloc] init];
        postId = [[NSMutableString alloc] init];
        comment = [[NSMutableString alloc] init];
        message = [[NSMutableString alloc] init];
        postImage = [[NSMutableString alloc] init];
        feedType = [[NSMutableString alloc] init];
        lastPage = 0;
        arrgroupList = [[NSMutableArray alloc] init];
        arrGroupFeed = [[NSMutableArray alloc] init];
        arrMyGroupList = [[NSMutableArray alloc] init];
        rowID = [[NSMutableString alloc] init];
            }
    return self;
}

// get all group list
-(void)getGroupList:(group_completion_block)completion {
    @try {
       
        NSString *url_String = [NSString stringWithFormat:@"%@", API_GROUP_LIST];
        NSDictionary *parameters = @{@"key":self.key,@"sort_id":@"3",@"page":self.page};
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* group, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(group,@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[group valueForKey:@"error"]integerValue]==0)
                    {
                        
                        [[[group valueForKey:@"data"] valueForKey:@"data"] enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                            [APPDATA.group.arrgroupList addObject:obj];
                        }];
                        NSSortDescriptor *sort = [[NSSortDescriptor alloc] initWithKey:@"group_name"
                                                                             ascending:YES selector:@selector(caseInsensitiveCompare:)];
                        NSArray *arr =[[NSArray alloc] initWithArray:APPDATA.group.arrgroupList];
                        [APPDATA.group.arrgroupList removeAllObjects];
                        [APPDATA.group.arrgroupList addObjectsFromArray:[arr sortedArrayUsingDescriptors:@[sort]]];
                        
                        APPDATA.group.lastPage = [[[group valueForKey:@"data"] valueForKey:@"last_page"] intValue];
                        
                        completion(group,@"get group list success",1);
                    }
                    else{
                        completion(group,[group valueForKey:@"message"],-1);
                    }
                }
            }
        }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
    }
}
// get group feed based on selected group
-(void)getGroupGalleryFeed:(group_completion_block)completion {
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_MY_GALLERY_GROUP];
        NSDictionary *parameters = @{@"key":self.key,@"profile_id":appDelegate.profilid_AppStr};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* group, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(group,@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[group valueForKey:@"error"]integerValue]==0)
                    {
                        APPDATA.group.arrgroupList=[[NSMutableArray alloc]init];
                        
                        
                        APPDATA.group.arrgroupList= [group valueForKey:@"data"];
                        
                        completion(group,@"get group list success",1);
                    }
                    else{
                        completion(group,[group valueForKey:@"message"],-1);
                    }
                }
            }
        }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
    }
}

-(void)GroupProfilePyblish:(group_completion_block)completion {
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_SEND_PROFILE_PUBLISH];
        NSDictionary *parameters = @{@"key":self.key,@"profile_id":appDelegate.profilid_AppStr};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* group, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(group,@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[group valueForKey:@"error"]integerValue]==0)
                    {
                        APPDATA.group.arrgroupList=[[NSMutableArray alloc]init];
                        
                        //  [[group valueForKey:@"data"] enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                        //    [APPDATA.group.arrgroupList addObject:obj];
                        //   }];
                        
                        APPDATA.group.arrgroupList= [group valueForKey:@"data"];
                        
                        // APPDATA.user.nextPageUrl = [[profile valueForKey:@"data"] valueForKey:@"next_page_url"];
                        
                        // APPDATA.group.lastPage = [[[group valueForKey:@"data"] valueForKey:@"last_page"] intValue];
                        
                        completion(group,@"get group list success",1);
                    }
                    else{
                        completion(group,[group valueForKey:@"message"],-1);
                    }
                }
            }
        }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
    }
}

// send request for add member in to group
-(void)addGroupMember:(group_completion_block)completion{
    
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_ADD_MEMBER_TO_GROUP];
        
        NSDictionary *parameters = @{@"key":self.key,@"group_id":self.groupId,@"profile_id":self.profileid};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* group, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(group,@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[group valueForKey:@"error"]integerValue]==0)
                    {
                        APPDATA.group.arrGroupFeed = [[NSMutableArray alloc] init];
                        
                        [[[group valueForKey:@"data"] valueForKey:@"feed_data"]enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                            [APPDATA.group.arrGroupFeed addObject:obj];
                        }];
                        
                        
                        completion(group,@"Feed Get success",1);
                    }
                    else{
                        completion(group,[group valueForKey:@"message"],-1);
                    }
                }
            }
        }];
    } @catch (NSException *exception) {
        
    }
    @finally {
    }
    
    
    
}
// request for delete group
-(void)deleteGroup:(group_completion_block)completion{
    
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_DELETE_GROUP];
        
        NSDictionary *parameters = @{@"key":self.key,@"group_id":self.groupId,@"profile_id":self.profileid};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* group, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(group,@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[group valueForKey:@"error"]integerValue]==0)
                    {
           
                        
                        completion(group,@"Feed Get success",1);
                    }
                    else{
                        completion(group,[group valueForKey:@"message"],-1);
                    }
                }
            }
        }];
    } @catch (NSException *exception) {
        
    }
    @finally {
    }
    
    
    
}

// add new group in app
-(void)addGroup:(group_completion_block)completion{
    
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_ADD_EDIT_GROUP];
    
        NSDictionary *parameters = @{@"group_name":self.groupName,@"posted_by":self.postedBy,@"description":self.groupDescription,@"group_image":self.groupImg,@"key":API_KEY};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* group, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(group,@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[group valueForKey:@"error"]integerValue]==0)
                    {
                        APPDATA.group.arrGroupFeed = [[NSMutableArray alloc] init];
                        
                        [[[group valueForKey:@"data"] valueForKey:@"feed_data"]enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                            [APPDATA.group.arrGroupFeed addObject:obj];
                        }];
    
                        
                        completion([group valueForKey:@"data"],@"Feed Get success",1);
                    }
                    else{
                        completion(group,[group valueForKey:@"message"],-1);
                    }
                }
            }
        }];
    } @catch (NSException *exception) {
        
    }
    @finally {
    }

    
    
}
    
 // get group list of login user
-(void)getMyGroupList:(group_completion_block)completion {
    @try {

        NSString *url_String = [NSString stringWithFormat:@"%@", API_MY_GROUP_LIST];
        
        NSDictionary *parameters = @{@"key":self.key,@"profile_id":APPDATA.user.profileid};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* group, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(group,@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[group valueForKey:@"error"]integerValue]==0)
                    {
                        APPDATA.group.arrMyGroupList = [[NSMutableArray alloc] init];
                        
                        [[group valueForKey:@"data"]  enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                            [APPDATA.group.arrMyGroupList addObject:obj];
                        }];
                        //    APPDATA.user.aryMyProfileImage= [[group valueForKey:@"data"]objectForKey:@"data"];
                        //                        APPDATA.user.nextPageUrl = [[profile valueForKey:@"data"] valueForKey:@"next_page_url"];
                        //                        APPDATA.user.lastPage = [[[profile valueForKey:@"data"] valueForKey:@"last_page"] intValue];
                        
                        completion(group,@"get my group list success",1);
                    }
                    else{
                        completion(group,[group valueForKey:@"message"],-1);
                    }
                }
            }
        }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
    }
}
//get group feed
-(void)getGroupFeed:(group_completion_block)completion {
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_GROUP_FEED];
        
        NSDictionary *parameters = @{@"key":self.key,@"group_id":self.groupId,@"profile_id":self.profileid};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* group, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(group,@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[group valueForKey:@"error"]integerValue]==0)
                    {
                        APPDATA.group.arrGroupFeed = [[NSMutableArray alloc] init];
                        
                        [[[group valueForKey:@"data"] valueForKey:@"feed_data"]enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                            [APPDATA.group.arrGroupFeed addObject:obj];
                        }];
                        //    APPDATA.user.aryMyProfileImage= [[group valueForKey:@"data"]objectForKey:@"data"];
                        //                        APPDATA.user.nextPageUrl = [[profile valueForKey:@"data"] valueForKey:@"next_page_url"];
                        //                        APPDATA.user.lastPage = [[[profile valueForKey:@"data"] valueForKey:@"last_page"] intValue];
                        
                        completion(group,@"Feed Get success",1);
                    }
                    else{
                        completion(group,[group valueForKey:@"message"],-1);
                    }
                }
            }
        }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }}
// send request for jin group by logedin user
-(void)joinGroup:(group_completion_block)completion{
@try {
            NSString *url_String = [NSString stringWithFormat:@"%@", API_GROUP_JOIN];
            
            NSDictionary *parameters = @{@"key":self.key,@"group_id":self.groupId,@"profile_id":self.profileid};
            
            [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* group, NSError*error, long code){
                if(error)
                {
                    if(completion)
                    {
                        completion(group,@"There was some error, please try again later",-1);
                    }
                }
                else{
                    if(completion)
                    {
                        if([[group valueForKey:@"error"]integerValue]==0)
                        {

                            
                            completion(group,@"Join success",1);
                        }
                        else{
                            completion(group,[group valueForKey:@"message"],-1);
                        }
                    }
                }
            }];
        }
        @catch (NSException *exception) {
            
        }
        @finally
    {
    }
}
// check is logedin user is memeber of selected group
-(void)verifyGroupMember:(group_completion_block)completion
{
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_GROUP_MEMBER_VERIFY];
        
        NSDictionary *parameters = @{@"key":self.key,@"group_id":self.groupId,@"profile_id":self.profileid};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* group, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(group,@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[group valueForKey:@"error"]integerValue]==0)
                    {
                        
                        
                        completion(group,@"Join success",1);
                    }
                    else{
                        completion(group,[group valueForKey:@"message"],-1);
                    }
                }
            }
        }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
    }
}
// send post in group
-(void)addPostInGroup:(group_completion_block)completion {
    @try {
        

        NSString *url_String = [NSString stringWithFormat:@"%@", API_ADD_POST_GROUP];
        
        NSDictionary *parameters = @{@"key":self.key,@"group_id":self.groupId,@"profile_id":self.profileid,@"message":message,@"post_image":postImage,@"feed_type":feedType};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* group, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(group,@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[group valueForKey:@"error"]integerValue]==0)
                    {
                        
                        
                        completion(group,@"add post success",1);
                    }
                    else{
                        completion(group,[group valueForKey:@"message"],-1);
                    }
                }
            }
        }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
    }
}

// add commnet into perticular feed in to selected group
-(void)sendCommentInGroup:(group_completion_block)completion {
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_COMMENT_GROUP];
        
        NSDictionary *parameters = @{@"key":self.key,@"group_id":self.groupId,@"profile_id":self.profileid,@"post_id":postId,@"comment":comment};
    

        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* group, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(group,@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[group valueForKey:@"error"]integerValue]==0)
                    {
                        
                        
                        completion(group,@"group comment success",1);
                    }
                    else{
                        completion(group,[group valueForKey:@"message"],-1);
                    }
                }
            }
        }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
    }
}


// Group Delete Post


-(void)deleteGroupPost:(group_completion_block)completion {
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_DELETE_GROUP_POST];
        
        NSDictionary *parameters = @{@"key":self.key,@"group_id":self.groupId,@"rowid":self.rowID};
        
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* group, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(group,@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[group valueForKey:@"error"]integerValue]==0)
                    {
                        
                        
                        completion(group,@"group comment success",1);
                    }
                    else{
                        completion(group,[group valueForKey:@"message"],-1);
                    }
                }
            }
        }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
    }
}

// delete group post
-(void)deleteAdminGroupPost:(group_completion_block)completion {
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_ADMIN_DELETE_GROUP_POST];
        
        NSDictionary *parameters = @{@"key":self.key,@"group_id":self.groupId,@"rowid":self.rowID};
        
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* group, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(group,@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[group valueForKey:@"error"]integerValue]==0)
                    {
                        
                        
                        completion(group,@"group comment success",1);
                    }
                    else{
                        completion(group,[group valueForKey:@"message"],-1);
                    }
                }
            }
        }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
    }
}
// flag group post
-(void)flagGroupPost:(group_completion_block)completion{
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_FLAG_GROUP_POST];
        
        NSDictionary *parameters = @{@"key":self.key,@"group_id":self.groupId,@"rowid":self.rowID,@"flagged_by":APPDATA.user.profileid};
        
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* group, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(group,@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[group valueForKey:@"error"]integerValue]==0)
                    {
                        
                        
                        completion(group,@"group comment success",1);
                    }
                    else{
                        completion(group,[group valueForKey:@"message"],-1);
                    }
                }
            }
        }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
    }
}
// delete group comment post
-(void)deleteGroupCommentPost:(group_completion_block)completion {
    
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_DELETE_GROUP_COMMENT];
        
        NSDictionary *parameters = @{@"key":API_KEY,@"rowid":self.rowID,@"group_id":self.groupId};
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* group, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(group,@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[group valueForKey:@"error"]integerValue]==0)
                    {
                        
                        
                        completion(group,@"group comment success",1);
                    }
                    else{
                        completion(group,[group valueForKey:@"message"],-1);
                    }
                }
            }
        }];
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
}
//  flag group comment 
-(void)flagGroupComment:(group_completion_block)completion{
    @try {
        NSString *url_String = [NSString stringWithFormat:@"%@", API_FLAG_GROUP_COMMENT];
        
        NSDictionary *parameters=[[NSDictionary alloc]init];
        parameters = @{@"key":API_KEY,@"rowid":self.rowID,@"flagged_by":APPDATA.user.profileid,@"group_id":self.groupId};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* group, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(group,@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[group valueForKey:@"error"]integerValue]==0)
                    {
                        
                        
                        completion(group,@"group comment success",1);
                    }
                    else{
                        completion(group,[group valueForKey:@"message"],-1);
                    }
                }
            }
        }];
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}



@end
