//
//  Singleton.m
//  photobug
//
//   on 29/06/16.
//  Copyright © Photobug. All rights reserved.
//

#import "Singleton.h"

@interface Singleton ()

@end

@implementation Singleton
@synthesize strTextfildStreet,StrTextViewDescription,strtxtfildCity,strtxtFildCurrntpwd,strTxtFildRetypNewPwd,strtxtFildStreet2,strtxtfildZip,strTxtFildNewPwd,strTxtfildPhonenom,strSMS,strAccPrivate;


+ (id)sharedManager {
    static Singleton *sharedMyManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedMyManager = [[self alloc] init];
    });
    return sharedMyManager;
}

- (id)init {
    if (self = [super init]) {
        strtxtfildZip=[[NSMutableString alloc]init];
        strtxtFildStreet2=[[NSMutableString alloc]init];
        strTxtFildRetypNewPwd=[[NSMutableString alloc]init];
        strtxtFildCurrntpwd=[[NSMutableString alloc]init];
        strTextfildStreet=[[NSMutableString alloc]init];
        StrTextViewDescription=[[NSMutableString alloc]init];
        strtxtfildCity =[[NSMutableString alloc] init];
        strTxtFildNewPwd=[[NSMutableString alloc] init];
        strTxtfildPhonenom=[[NSMutableString alloc] init];
        strSMS=[[NSMutableString alloc] init];
        strAccPrivate=[[NSMutableString alloc] init];
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
