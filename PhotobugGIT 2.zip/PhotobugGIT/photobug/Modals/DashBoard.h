//
//  DashBoard.h
//  photobug
//
//   on 11/6/15.
//  Copyright © Photobug. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DashBoard : NSObject
typedef void(^dashboard_completion_block)(NSDictionary *result,NSString *, int status);
@property NSMutableString  *SplashImage1,*SplashImage2, *SplashImage3, *SplashImage4, *SplashImage5,*bannerMaintitle;
@property NSMutableString *bannerTopImage,*bannerBottomImage;
-(void)getDashBoardImage:(dashboard_completion_block)completion;
-(void)getLandingPageImage:(dashboard_completion_block)completion;

@end
