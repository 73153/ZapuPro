//
//  JImage.h
//  photobug
//
//   on 30/05/16.
//  Copyright © Photobug. All rights reserved.
//
//JImage.h

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface JImage : UIImageView {
    
    NSURLConnection *connection;
    
    NSMutableData* data;
    
    UIActivityIndicatorView *ai;
}

-(void)initWithImageAtURL:(NSURL*)url;

@property (nonatomic, retain) NSURLConnection *connection;

@property (nonatomic, retain) NSMutableData* data;

@property (nonatomic, retain) UIActivityIndicatorView *ai;

@end
