//
//  Constant.h
//  Challenge Me

#import "Validations.h"
#import "DashBoard.h"
#import "AppDelegate.h"
#import "AsyncImageView.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import <QuartzCore/QuartzCore.h>

//#import "PopupViewController.h"

//#import <CoreLocation/CoreLocation.h>
//#import <GoogleMaps/GoogleMaps.h>
#ifndef ChallengeMe_Constant_h
#define ChallengeMe_Constant_h

#define appDelegate ((AppDelegate*)[[UIApplication sharedApplication] delegate])

#define kFontName @"OpenSans-SemiBold"


#define BASE_URL        @"http://216.55.169.45/~apiphotobug/v1/"


//#define BASE_URL @"http://192.168.15.163/~apiphotobug/v1/"

#define API_KEY         @"B9C010d9Kg7oFihEF3vV383uD39ugjair"

#define API_USER          (BASE_URL@"profile"@"?key=B9C010d9Kg7oFihEF3vV383uD39ugjair")
#define API_USER_LOGIN    (BASE_URL@"login"@"?key=B9C010d9Kg7oFihEF3vV383uD39ugjair")
#define API_DASHBOARD     (BASE_URL@"home"@"?key=B9C010d9Kg7oFihEF3vV383uD39ugjair")
#define API_CHECKEMAIL    (BASE_URL@"checkemail"@"?key=B9C010d9Kg7oFihEF3vV383uD39ugjair")
//
#define API_CHECKEMAILEXISTING   (BASE_URL@"checkemail")
#define API_CHECKSOCIALID (BASE_URL@"checksocialid"@"?key=B9C010d9Kg7oFihEF3vV383uD39ugjair")
// 0 -> Social Login 1 -> Dashboard
#define API_SOCIAL_LOGIN  (BASE_URL@"sociallogin"@"?key=B9C010d9Kg7oFihEF3vV383uD39ugjair")
#define API_LANDINGPAGE   (BASE_URL@"landingPage"@"?key=B9C010d9Kg7oFihEF3vV383uD39ugjair")
#define API_SOCIAL_LOGIN_NEW  (BASE_URL@"social-login-new"@"?key=B9C010d9Kg7oFihEF3vV383uD39ugjair")

#define API_PROFILE_UPDATE (BASE_URL@"profile-update")

#define API_PROFILE_FEED (BASE_URL@"my-profile-feed")

#define API_ADD_POST           (BASE_URL@"add-post")
#define API_MYACTIVITY         (BASE_URL@"my-profile-activity")
#define API_COMMENT            (BASE_URL@"add-post")
#define API_RECENTENTRIES      (BASE_URL@"recent-entries")
#define API_PROFILELIST        (BASE_URL@"user-list-profiles")
#define API_ADDFOLLOWERS       (BASE_URL@"profile-add-follow")
#define API_EDIT_PROFILE        (BASE_URL@"edit-profile-popup")
#define API_ADDCOMMENTONPOST   (BASE_URL@"add-comment-on-post")
#define API_CONTEST_TAG        (BASE_URL@"contest-tags")
#define API_CONTEST_LIST       (BASE_URL@"contests")
#define API_CONTEST_IMAGE_LIST (BASE_URL@"contest-image-list")
#define API_CONTEST_INFO (BASE_URL@"contest-info")
#define UPDATE_PROFILE @"Profile updated successfully."

#define API_PROFILE_ALBUM_ADD_UPDATE (BASE_URL@"profile-album-add-update")
#define API_PROFILE_ALBUM_LIST2 (BASE_URL@"profile-album-image-list-with-data")
#define API_CONTEST_IMAGE_UPLOAD (BASE_URL@"contest-image-upload")
#define API_PROFILE_ALBUM_LIST (BASE_URL@"profile-album-image-list-with-data")
#define API_PROFILE_LIST (BASE_URL@"my-contest-gallery")
#define API_CONTEST_VOTE (BASE_URL@"contest-vote")


#define API_SUBMIT (BASE_URL@"save-edit-profile")
#define API_DELETE (BASE_URL@"delete-user-profile")

#define API_GROUP_LIST (BASE_URL@"group")
#define API_MY_GROUP_LIST (BASE_URL@"show-user-groups")
#define API_GROUP_FEED (BASE_URL@"my-gallery-feed")
#define API_GROUP_JOIN (BASE_URL@"add-member-to-group")
#define API_ADD_POST_GROUP (BASE_URL@"add-group-post")
#define API_COMMENT_GROUP (BASE_URL@"add-comment-on-group-post")
#define API_GROUP_MEMBER_VERIFY (BASE_URL@"verify-group-member")
#define API_USER_INVITE (BASE_URL@"user-invite")

#define API_PROFILE_TOTAL_CREDITS (BASE_URL@"profile-total-credits")
#define API_USER_FOLLOWING_OR_NOT (BASE_URL@"user-following-or-not")

#define API_PROFILE_DELETE_FOLLOW (BASE_URL@"profile-delete-follow")

#define API_CREDIT_HISTORY (BASE_URL@"profile-credit-history")

#define API_LEAVE_FROM_GROUP (BASE_URL@"leave-from-group")

#define API_FORGOT_PASSWORD (BASE_URL@"forgot-password")

#define API_ALL_CONTESTS (BASE_URL@"all-contests")
#define API_CONTEST_NEW_TAGS (BASE_URL@"contest-new-tags")

#define API_SEND_REQUEST_CHECK_MAIL (BASE_URL@"send-request-check-mail")
#define API_ADD_EDIT_GROUP (BASE_URL@"add-edit-group")
#define API_ADD_MEMBER_TO_GROUP (BASE_URL@"add-member-to-group")
#define API_DELETE_GROUP (BASE_URL@"delete-group")
#define API_MY_GALLERY_GROUP (BASE_URL@"my-gallery-feed")
#define API_SEND_PROFILE_PUBLISH (BASE_URL@"profile-publish")
#define API_PICKERLIST          (BASE_URL@"state-list")
#define API_DELETE_POST (BASE_URL@"delete-dashboard-post")
#define API_DELETE_DASHBOARD_POST (BASE_URL@"delete-dashboard-post")
#define API_FLAG_DASHBOARD_POST (BASE_URL@"flag-dashboard-post")
#define API_FLAG_GROUP_POST (BASE_URL@"flag-group-post")
#define API_DELETE_GROUP_POST (BASE_URL@"delete-group-post-user")
#define API_ADMIN_DELETE_GROUP_POST (BASE_URL@"delete-group-post")
#define API_DELETE_DASHBOARD_COMMENT (BASE_URL@"delete-dashboard-comment")
#define API_DELETE_DASHBOARD_IMAGE (BASE_URL@"delete-image-from-dashboard")
#define API_FLAGGED_IMAGE (BASE_URL@"image-flagged")
#define API_USER_FOLLOWING_NOT (BASE_URL@"user-following-or-not")
#define API_DELETE_GROUP_COMMENT (BASE_URL@"delete-group-post-comment")
#define API_FLAG_DASHBOARD_COMMENT (BASE_URL@"flag-dashboard-post-comment")
#define API_FLAG_GROUP_COMMENT (BASE_URL@"flag-group-post-comment")
#define API_PUBLISH_PROFILE (BASE_URL@"profile-publish")
#define API_CHECK_SOCIAL_ID (BASE_URL@"check-social-login")

#endif
#define CommentCellFont  [UIFont fontWithName:@"AvenirNextCondensed-Regular" size:14]

#define IS_IPHONE4 (([[UIScreen mainScreen] bounds].size.height-480)?NO:YES)
#define IS_IPHONE5 (([[UIScreen mainScreen] bounds].size.height-568)?NO:YES)

#define IS_IPHONE6 (([[UIScreen mainScreen] bounds].size.height-667)?NO:YES)
#define IS_IPHONE6plus (([[UIScreen mainScreen] bounds].size.height-736)?NO:YES)



#define IS_OS_5_OR_LATER    ([[[UIDevice currentDevice] systemVersion] floatValue] >= 5.0)
#define IS_OS_6_OR_LATER    ([[[UIDevice currentDevice] systemVersion] floatValue] >= 6.0)
#define IS_OS_7_OR_LATER    ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)
#define IS_OS_8_OR_LATER    ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
#define DEVICE_FRAME [[ UIScreen mainScreen ] bounds ]

#define DEVICE_HEIGHT [[ UIScreen mainScreen ] bounds ].size.height
#define DEVICE_WIDTH [[ UIScreen mainScreen ] bounds ].size.width

#define RGB(r,g,b)    [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1]
#define RGBA(r,g,b,a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]
#define BG_COLOR        RGB(33,60,136)
#define LightGray_COLOR [UIColor colorWithRed:(246.0/255.0) green:(246.0/255.0) blue:(249.0/255.0) alpha:1];
#define LightBlue_COLOR [UIColor colorWithRed:(45.0/255.0) green:(186.0/255.0) blue:(241.0/255.0) alpha:1];
#define DarkBlue_COLOR [UIColor colorWithRed:(28.0/255.0) green:(48.0/255.0) blue:(84.0/255.0) alpha:1];

#define RECT(x,y,w,h)  CGRectMake(x, y, w, h)
#define POINT(x,y)     CGPointMake(x, y)
#define SIZE(w,h)      CGSizeMake(w, h)
#define RANGE(loc,len) NSMakeRange(loc, len)

#define UDSetObject(value, key) [[NSUserDefaults standardUserDefaults] setObject:value forKey:(key)];[[NSUserDefaults standardUserDefaults] synchronize]
#define UDSetValue(value, key) [[NSUserDefaults standardUserDefaults] setValue:value forKey:(key)];[[NSUserDefaults standardUserDefaults] synchronize]
#define UDSetBool(value, key) [[NSUserDefaults standardUserDefaults] setInteger:value forKey:(key)];[[NSUserDefaults standardUserDefaults] synchronize]
#define UDSetInt(value, key) [[NSUserDefaults standardUserDefaults] setFloat:value forKey:(key)];[[NSUserDefaults standardUserDefaults] synchronize]
#define UDSetFloat(value, key) [[NSUserDefaults standardUserDefaults] setBool:value forKey:(key)];[[NSUserDefaults standardUserDefaults] synchronize]

#define UDGetObject(key) [[NSUserDefaults standardUserDefaults] objectForKey:(key)]
#define UDGetValue(key) [[NSUserDefaults standardUserDefaults] valueForKey:(key)]
#define UDGetInt(key) [[NSUserDefaults standardUserDefaults] integerForKey:(key)]
#define UDGetFloat(key) [[NSUserDefaults standardUserDefaults] floatForKey:(key)]
#define UDGetBool(key) [[NSUserDefaults standardUserDefaults] boolForKey:(key)]

#define UDRemoveObject(key) [[NSUserDefaults standardUserDefaults] removeObjectForKey:(key)]

#define topDelegate ((AppDelegate *)[[UIApplication sharedApplication] delegate])

#define dt_time_formatter @"yyyy-MM-dd HH:mm:ss"
#define dt_formatter @"yyyy-MM-dd"
#define time_formatter @"HH:mm:ss"
#define dt_time_formatter1 @"yyyy-MM-dd HH:mm:ss"

//Social Media ID
#define FBAPPID @"1669690943263069"
#define FBSECRETID @"204dda339b1d2143e0343d6f85cb4886"


#define INSTA_CLIENT_ID @"4d91b39699434aa2abe0154ec1505585"
#define INSTA_CLIENT_SECRET 	@"a761acdaa2eb4de4ba35c6cd0e36a9c6"

// For Validation Messages
#define ERROR_NAME @"Please enter Valid Name."
#define kMethod @"method"

#define ERROR_UNAME @"Please enter username."
#define ERROR_COMPANY @"Please enter Valid Company Name."
#define ERROR_WEBSITE @"Please enter Valid Website"
#define ERROR_PASSWORD @"Please enter your email and password."
#define kError @"error"
//KARISHMA

//sign in and signup
#define WRONG_EMAIL_PASSWORD @"Email and/or password is invalid."
#define ERROR_LOGIN @"Please log in to Photobug."
#define ERROR_EMAIL @"Please enter your email and password."
#define ERROR_ALREADY_EMAIL @"Please enter your email and password."
#define ERROR_USERNAME @"Please enter your email and password."
#define ERROR_MINLENGTH_PASSWORD @"Password must be at least 6 characters."
#define ERROR_MAXLENGTH_USERNAME @"User name should not exceed 20 characters."
#define SUCCESS_SIGNUP @"Thanks for signing up to Photobug."
#define ERROR_FNAME @"First name is required."
#define ERROR_LNAME @"Last name is required."
#define ERROR_EMAIL_SIGNUP @"Email is required."
#define ERROR_FORGOT_EMAIL @"Please enter your email address."
#define ERROR_PWD @"Password is required."
#define ERROR_FACEBOOK_CONNECTION @"Unable to connect to Facebook."
#define ERROR_SIGNUP @"An account with that email already exists."
#define ERROR_SOCIAL_SIGNUP @"An account with that email already exists."
#define ERROR_EMAIL_EXISTS @"Email already exists."
#define FORGOT_CLICK @"Instructions on resetting your password have been sent to your email."
#define FORGOT_EMAIL @"Please enter your email address."
#define SUCCESS_SIGNUP @"Thanks for signing up to Photobug."
//dashboard ,comment,group

#define ERROR_COMMENT @"Please add a comment."
#define POST_SUBMIT @"Post submitted."
#define IMAGE_UPLOAD @"Image uploaded."
#define ERROR_IMAGE_UPLOAD @"Upload error. Please try again."
#define DELETE_COMMENT @"Are you sure you want to delete this comment?"
#define DELETE_IMAGE @"Are you sure you want to delete this image?"
#define ERROR_OLD_PASSWORD @"Please enter your old password."
#define ERROR_NEW_PASSWORD @"Please confirm your new password."
#define ERROR_ADD_PASSWORD @"Please enter your new password."
#define ERROR_ADD_RePASSWORD @"Please enter re-type password.."
#define SUCCESS_PASSWORD_CHANGE @"Your password has been changed."
#define DELETE_PROFILE @"Are you sure you want to delete your profile? This is irreversible and will permanently delete all content, points and earnings."
#define SUCCESS_UPDATE_PROFILE @"Profile updated successfully."
#define FLAG_COMMENT @"Are you sure you want to flag this comment?"
#define SUCCESS_JOIN_GROUP @"You have joined this group."
#define SUCCESS_LEFT_GROUP @"You have left this group."
#define DELETE_GROUP @"Are you sure you want to delete this group?"
#define SUCEES_DELETE_GROUP @"Group deleted."
#define ERROR_JOIN_COMMENT @"You must join this group to begin commenting."
#define ERROR_GROUP_NAME @"Please enter a group name."
#define SUCCES_FOLLOW @"Followed profile."
#define SUCCES_UNFOLLOW @"Unfollowed profile."
#define ERROR_SECONDTIME_FOLLOW @"You already followed this profile."
#define SUCCES_COMMENT @"Comment added."
#define FLAG_IMAGE @"Are you sure you want to flag this image?"
#define ERROR_UNPUBLISH_POST @"You must publish your profile to begin posting."
//contest

#define SUCCESG_ENTER_CONTEST @"Entry submitted."
#define TINY_FLAG_IMAGE @"This image has been flagged for copyright infringement."
#define ERROR_CAPTION @"Please add a caption to your photo."
#define ERROR_TAG @"Please add a minimum of one tag to your entry."
#define ERROR_UNPUBLISH_ENTER_CONTEST @"You must publish your profile to enter contests."
#define ERROR_ALREDY_VOTE_IMAGE @"You have already voted on this image."
#define ERROR_UNPUBLISH_VOTING @"You must publish your profile to begin voting."








#define kPlaceHolderImage [UIImage imageNamed:@"right-slant"]

#define APPDATA [ApplicationData sharedInstance] 
#define isLogin @"isLogin"
