//
//  JImage.m
//  photobug
//
//   on 30/05/16.
//  Copyright © Photobug. All rights reserved.
//
#import "JImage.h"

@implementation JImage
@synthesize ai,connection, data;

-(void)initWithImageAtURL:(NSURL*)url {
    
    
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    
    [self setContentMode:UIViewContentModeScaleToFill];
    
    if (!ai){
        
        [self setAi:[[UIActivityIndicatorView alloc]   initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge]];
        
        [ai startAnimating];
        
        [ai setFrame:CGRectMake(27.5, 27.5, 20, 20)];
        
        [ai setColor:[UIColor blackColor]];
        
        [self addSubview:ai];
    }
    NSURLRequest* request = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:60];
    
    connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
}


- (void)connection:(NSURLConnection *)theConnection didReceiveData:(NSData *)incrementalData {
    
    if (data==nil) data = [[NSMutableData alloc] initWithCapacity:5000];
    
    [data appendData:incrementalData];
    
    NSNumber *resourceLength = [NSNumber numberWithUnsignedInteger:[data length]];
    
    NSLog(@"resourceData length: %d", [resourceLength intValue]);
    
}
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"Connection error...");
    
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    
    [ai removeFromSuperview];
    
}
- (void)connectionDidFinishLoading:(NSURLConnection*)theConnection
{
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    
    [self setImage:[UIImage imageWithData: data]];
    
    [ai removeFromSuperview];   
}
@end
