//
//  DashBoardCell.h
//  photobug
//
//   on 11/6/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DashboardViewController.h"

@interface DashBoardCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgDashboard;
@property (weak, nonatomic) IBOutlet UIImageView *imgDashboard2;

@end
