//
//  DashboardViewController.h
//  photobug
//
//   on 11/3/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlideNavigationController.h"
#import "RightMenuViewController.h"
#import "Constant.h"
#import "DashBoardCell.h"
#import <FPPicker/FPPicker.h>
@interface DashboardViewController : UIViewController<SlideNavigationControllerDelegate,UIScrollViewDelegate>//,UITableViewDataSource,UITableViewDelegate>
{
    IBOutlet UIImageView *imgTop2;
    IBOutlet UIImageView *imgTop;
    IBOutlet UIImageView *imgBottom;
    IBOutlet UIScrollView *scrllView;
}
@property (strong,nonatomic)IBOutlet UITableView *tableviewDashboard;
@property (strong, nonatomic) IBOutlet UIButton *menuButton;
//@property (weak, nonatomic) IBOutlet UIImageView *imgDashboard2;
@property (weak, nonatomic) IBOutlet UIButton *btnCenterLogo;

-(void)dashboardMethod;
-(void)imageSetMethod;
@end
