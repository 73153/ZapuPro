//
//  DashboardViewController.m
//  photobug
//
//   on 11/3/15.
//  Copyright © Photobug. All rights reserved.
//
#import "DashboardViewController.h"
#import "ApplicationData.h"
#import "DashBoardCell.h"
#import "AsyncImageView.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "LoginViewController.h"
#import "ContestLandingViewController.h"
#import "MyPhotosViewController.h"
#import "SubmitAnEntryViewController.h"
#import "PhotoPickerViewController.h"
#import "ContestCategoryViewController.h"
#import "MyDashboardViewController.h"
#import <UIActivityIndicator-for-SDWebImage/UIImageView+UIActivityIndicatorForSDWebImage.h>
#import "APICall.h"

@interface DashboardViewController ()
{
    NSMutableData *responseData;
}
@end

@implementation DashboardViewController
{
    __block NSMutableArray *aryDashBoardImage;
    CGRect imgTopViewFrame;
    CGRect imgBottomViewFrame;
    UIImageView *cellImg;
}

@synthesize btnCenterLogo;
- (void)viewDidLoad
{
    [super viewDidLoad];
    [SlideNavigationController sharedInstance].enableSwipeGesture = YES;
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    aryDashBoardImage = [[NSMutableArray alloc]init];
    [_menuButton addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleRightMenu) forControlEvents:UIControlEventTouchUpInside];
    // API call at view load time
      [self dashboardMethod];
}
// get Iamges for dashboard
-(void)dashboardMethod
{
    [APPDATA showLoader];
    APPDATA.recent = [[RecentEntries alloc] init];
    APPDATA.dashboard=[[DashBoard alloc] init];
    aryDashBoardImage = [[NSMutableArray alloc]init];
    [APPDATA.dashboard getDashBoardImage:^(id result,NSString *str, int status){
        [APPDATA hideLoader];
        if(status==1)
        {
            [aryDashBoardImage addObject:[[result valueForKey:@"data"] valueForKey:@"banner_left_image"]];
            [aryDashBoardImage addObject:[[result valueForKey:@"data"] valueForKey:@"banner_right_image"]];
            
            APPDATA.dashboard.bannerMaintitle=[[result valueForKey:@"data"]valueForKey:@"banner_main_title"];
            [btnCenterLogo.titleLabel setFont:[UIFont fontWithName:@"OpenSans-ExtraBold" size:24.0]];
            [btnCenterLogo setTitle:[[result valueForKey:@"data"]valueForKey:@"banner_main_title"] forState:UIControlStateNormal];
            [self imageSetMethod];
            if (APPDATA.isUserLogin == YES)
            {
                APPDATA.islogout=false;
            }
            else
            {
                if (APPDATA.islogout==false) {
                    LoginViewController *objviewController =(LoginViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"LoginViewController"];
                    [APPDATA pushNewViewController:objviewController];
                    APPDATA.islogout=true;
                    
                }
            }
        }
        else{
            [APPDATA hideLoader];
        }
    }];
}
// slide menu when open
-(BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return YES;
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}
// manage User interface of the top and bottom image
-(void)setAsyncImgData
{
    imgTop.frame = CGRectMake(imgTop.frame.origin.x,imgTop.frame.origin.y, self.view.frame.size.width+4,(284* self.view.frame.size.height )/568);
    imgBottom.hidden= TRUE;
    imgBottom.frame = CGRectMake(imgBottom.frame.origin.x,imgTop.frame.size.height-50, self.view.frame.size.width,(284* self.view.frame.size.height )/568+50);
    AsyncImageView *imageView = [[AsyncImageView alloc] initWithFrame:CGRectMake(0, 0,self.view.frame.size.width,(284* self.view.frame.size.height )/568)];
    [[AsyncImageLoader sharedLoader] cancelLoadingImagesForTarget:imageView];
    NSString *strImg;
    strImg=@"banner_left";
    UIImage *temp=[UIImage imageNamed:strImg];
    NSURL *urlStr=[NSURL URLWithString:[NSString stringWithFormat:@"%@",[aryDashBoardImage objectAtIndex:0]]];
    [imgTop setImageWithURL:urlStr placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    imgTop.contentMode = UIViewContentModeScaleAspectFill;
    [imgTop2 setImageWithURL:urlStr placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    imgTop2.contentMode = UIViewContentModeScaleAspectFill;
    imageView = [[AsyncImageView alloc] initWithFrame:CGRectMake(0, 0,self.view.frame.size.width,(284* self.view.frame.size.height )/568)];
    [[AsyncImageLoader sharedLoader] cancelLoadingImagesForTarget:imageView];
    strImg=@"banner_right";
    temp=[UIImage imageNamed:strImg];
    urlStr=[NSURL URLWithString:[NSString stringWithFormat:@"%@",[aryDashBoardImage objectAtIndex:1]]];
    [imgBottom setImageWithURL:urlStr placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    imgBottom.contentMode = UIViewContentModeScaleAspectFill;
    [scrllView setDelegate:self];
    [scrllView setBackgroundColor:[UIColor clearColor]];
    [scrllView setContentSize:CGSizeMake(self.view.frame.size.width,self.view.frame.size.height+150)];
    UIBezierPath *aPath;
    aPath = [UIBezierPath bezierPath];
    imgTop.frame=CGRectMake(imgTop.origin.x, imgTop.origin.y, self.view.bounds.size.width+4, self.view.bounds.size.height/2+52);
    [aPath moveToPoint:CGPointMake(0.0, 0.0)];
    [aPath addLineToPoint:CGPointMake(self.view.bounds.size.width, 0.0)];
    [aPath addLineToPoint:CGPointMake(self.view.bounds.size.width,self.view.frame.size.height/2)];
    [aPath addLineToPoint:CGPointMake(0.0, self.view.frame.size.height/2+43)];
    aPath.lineWidth = 3.0;
    [[UIColor redColor] setStroke];
    [aPath stroke];
    [self setClippingPath:aPath:imgTop];
    [aPath closePath];
    [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(shoImage) userInfo:nil repeats:TRUE];
}

-(void)shoImage
{
    imgBottom.hidden= FALSE;
}

- (void) setClippingPath:(UIBezierPath *)clippingPath : (UIImageView *)imgView
{
    if (![[imgView layer] mask])
        [[imgView layer] setMask:[CAShapeLayer layer]];
    [(CAShapeLayer*) [[imgView layer] mask] setPath:[clippingPath CGPath]];
}
// iamge motion effect.
-(void)setMotionEffect
{
    UIInterpolatingMotionEffect *verticalMotionEffect = [[UIInterpolatingMotionEffect alloc] initWithKeyPath:@"center.y"
                                                                                                        type:UIInterpolatingMotionEffectTypeTiltAlongVerticalAxis];
    verticalMotionEffect.minimumRelativeValue = @(-20);
    verticalMotionEffect.maximumRelativeValue = @(20);
    // Create group to combine both
    UIMotionEffectGroup *group = [UIMotionEffectGroup new];
    group.motionEffects = @[verticalMotionEffect];
    // Add both effects to your view
    [imgTop addMotionEffect:group];
    imgTopViewFrame = imgTop.frame;
    UIInterpolatingMotionEffect *verticalMotionEffect1 = [[UIInterpolatingMotionEffect alloc] initWithKeyPath:@"center.y"
                                                                                                         type:UIInterpolatingMotionEffectTypeTiltAlongVerticalAxis];
    verticalMotionEffect.minimumRelativeValue = @(20);
    verticalMotionEffect.maximumRelativeValue = @(-20);
    // Create group to combine both
    UIMotionEffectGroup *group1 = [UIMotionEffectGroup new];
    group1.motionEffects = @[verticalMotionEffect1];
    // Add both effects to your view
    [imgBottom addMotionEffect:group1];
    imgBottomViewFrame = imgBottom.frame;
}
#pragma mark - scroll view delegate

CGPoint translation;
// when image scroll down or up .
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat scrollOffset = scrollView.contentOffset.y;
    //-- that is image view where we want to show effect
    translation = [scrollView.panGestureRecognizer translationInView:scrollView.superview];
    if(translation.y > 0)
    {
        imgTop2.hidden=NO;
        imgTop2.frame = [self parallaxFrame:imgTopViewFrame
                                scrollFrame:scrollView.frame
                          withParallaxValue:scrollOffset];
    }
    else
    {
        imgBottom.frame = [self parallaxFrame:imgBottomViewFrame
                                  scrollFrame:scrollView.frame
                            withParallaxValue:scrollOffset];
    }
}

- (BOOL)scrollViewShouldScrollToTop:(UIScrollView *)scrollView
{
    return FALSE;
}

- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset
{
    [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(resetScrollContent) userInfo:nil repeats:FALSE];
}

-(void)resetScrollContent
{
    [UIView animateWithDuration:0.3f
                     animations:^{
                         imgTop.frame = CGRectMake(imgTop.frame.origin.x,imgTop.frame.origin.y, self.view.frame.size.width+4,imgTop.frame.size.height);
                         imgBottom.frame = CGRectMake(imgBottom.frame.origin.x,imgBottom.frame.origin.y, self.view.frame.size.width,(284* self.view.frame.size.height+50 )/568);
                         [scrllView setContentOffset:CGPointMake(0, scrllView.frame.origin.y) animated:FALSE];
                         imgTop2.hidden=YES;
                         [self setAsyncImgData];
                     } ];
}
// set image parallax effect
#pragma mark - parallax effect logic
- (CGRect)parallaxFrame:(CGRect)frame
            scrollFrame:(CGRect)scrollFrame
      withParallaxValue:(CGFloat)val
{
    NSInteger factor = 4;
    if(translation.y > 0)
    {
        if (val > 0) {
            return CGRectMake(frame.origin.x, frame.origin.y - val/factor, frame.size.width, frame.size.height);
        }
        return CGRectMake(frame.origin.x + val, frame.origin.y + val, frame.size.width - val*factor, frame.size.height - val*factor);
    } else
    {
        factor = 2;
        if (val > 0) {
            return CGRectMake(frame.origin.x - val, frame.origin.y - val, frame.size.width + val*factor, frame.size.height + val*factor);
        }
        return CGRectMake(frame.origin.x, frame.origin.y - val/factor, frame.size.width, frame.size.height);
    }
    return CGRectMake(frame.origin.x + val, frame.origin.y + val, frame.size.width - val*factor, frame.size.height - val*factor);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark Tab button action...
// Go to Contest screen
- (IBAction)btnContestPressed:(id)sender
{
    if (APPDATA.isUserLogin==YES)
    {
        ContestLandingViewController *viewController =(ContestLandingViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"ContestLandingViewController"];
        [APPDATA pushNewViewController:viewController];
    }else
    {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_LOGIN];
    }
}
// Go to My photo Screen
- (IBAction)btnMyphotosPressed:(id)sender{
    [APPDATA btnMyphotoPressedTab];
}
// Go to upload screen
- (IBAction)btnuploadPressed:(id)sender
{
    [APPDATA btnuploadPressedTab];
}
// API call for get Activivty Detail and set on model class
- (void) getMyActivityData
{
    appDelegate.profilid_AppStr = APPDATA.user.profileid ;
    APPDATA.activity.key = [API_KEY mutableCopy];
    [APPDATA.activity getMyActivity:^(NSDictionary *result, NSString *str, int status) {
        [APPDATA hideLoader];
        if (status == 1) {
            MyDashboardViewController *objviewController =(MyDashboardViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"MyDashboardViewController"];
            objviewController.usertype = Loginuser;
            [APPDATA pushNewViewController:objviewController];
        }
        else
        {
        }
    }];
}

// set image 
-(void)imageSetMethod{
    UIBezierPath *aPath;
    aPath = [UIBezierPath bezierPath];
    imgTop.frame=CGRectMake(imgTop.origin.x, imgTop.origin.y, self.view.bounds.size.width+4, self.view.bounds.size.height/2+50);
    imgTop.layer.masksToBounds = YES;
    imgTop.userInteractionEnabled = YES;
    if (aryDashBoardImage.count>0)
    {
        NSString *profileimageStr;
        if (aryDashBoardImage.count>1)
        {
            profileimageStr=[NSString stringWithFormat:@"%@",[aryDashBoardImage objectAtIndex:0]];
        }
        profileimageStr = [NSString stringWithFormat:@"%@",profileimageStr] ;
        
        [imgTop setImageWithURL:[NSURL URLWithString:profileimageStr] placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        imgTop.contentMode = UIViewContentModeScaleAspectFill;
        [aPath moveToPoint:CGPointMake(0.0, 0.0)];
        [aPath addLineToPoint:CGPointMake(self.view.bounds.size.width, 1.0)];
        [aPath addLineToPoint:CGPointMake(self.view.bounds.size.width,self.view.frame.size.height/2)];
        [aPath addLineToPoint:CGPointMake(0.-10, self.view.frame.size.height/2+45)];
        [self setClippingPath:aPath:imgTop];
        imgBottom.frame=CGRectMake(imgBottom.origin.x, imgBottom.origin.y, self.view.bounds.size.width+4, imgBottom.size.height);
        imgBottom.layer.masksToBounds = YES;
        imgBottom.userInteractionEnabled = YES;
        NSString *profileimageStr1=[NSString stringWithFormat:@"%@",[aryDashBoardImage objectAtIndex:1]];
        profileimageStr1 = [NSString stringWithFormat:@"%@",profileimageStr1] ;
        
        [imgBottom setImageWithURL:[NSURL URLWithString:profileimageStr1] placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        imgBottom.contentMode = UIViewContentModeScaleAspectFill;
        [self.view sendSubviewToBack: imgBottom];
        [aPath closePath];
        CGRect contentRect = CGRectZero;
        for (UIView *view in scrllView.subviews) {
            contentRect = CGRectUnion(contentRect, view.frame);
        }
        scrllView.contentSize = contentRect.size;
    }
}
@end
