//
//  LoginViewController.m
//  photobug
//
//   on 04/11/15.
//  Copyright © Photobug. All rights reserved.
//

#import "LoginViewController.h"
#import "Users.h"
#import <MBProgressHUD.h>
#import "DashboardViewController.h"
#import "ImportPhotosViewController.h"
#import "ApplicationData.h"
#import "APICall.h"
#import "UIImage+animatedGIF.h"
#import "MyDashboardViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController
- (void)viewDidLoad
{
    [super viewDidLoad];
    // set the UI in Iphone4 or 4s
    if (IS_IPHONE4)
       {
        for (int i = 1 ; i <= 6; i ++) {
        CGRect frame = [self.view viewWithTag:i].frame;
        frame.origin.y = [self.view viewWithTag:i].frame.origin.y - 20;
        [self.view viewWithTag:i].frame = frame;
        }

        CGRect frame = self.btnLogin.frame;
       frame.origin.y = self.btnLogin.frame.origin.y - 35;
        self.btnLogin.frame = frame;
        frame = self.btnSignUp.frame;
        frame.origin.y = self.btnSignUp.frame.origin.y - 80;
        self.btnSignUp.frame = frame;
        }
    [self.viewUsername setHidden:YES];
    self.app=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    [_txtEmail setBorderStyle:UITextBorderStyleNone];
    [_txtPassword setBorderStyle:UITextBorderStyleNone];
    [SlideNavigationController sharedInstance].enableSwipeGesture = YES;
    // add target to Slide Menu
    [_menuButton addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleRightMenu) forControlEvents:UIControlEventTouchUpInside];
    _btnForgotPassword.hidden = NO;
    // add target to Forgot button
    UITapGestureRecognizer *singleTap =  [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapping)];
    [singleTap setNumberOfTapsRequired:1];
    
    [_forgotPasswordView addGestureRecognizer:singleTap];
   
    _forgotPasswordView.hidden=YES;
}
// call when forgot button click from Forgot View
- (void) singleTapping
{
    _forgotPasswordView.hidden=YES;
}
// call when slide menu open
-(BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return YES;
}
// get and set email id,password from local.
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    if([UDGetObject(@"emailid") length] > 0)
    {
        _btnStayLogin.selected=YES;
        
        self.txtEmail.text= UDGetObject(@"emailid");
        self.txtPassword.text= UDGetObject(@"password");
    }
    else
    {
        _btnStayLogin.selected=NO;
        self.txtEmail.text=@"";
        self.txtPassword.text=@"";
    }
   
}
//stay login or not
- (IBAction)btnStayLoginPressed:(id)sender
{
    _btnStayLogin.selected=!_btnStayLogin.selected;
}
// go to back
- (IBAction)btnBackPressed:(id)sender
{
    DashboardViewController *objDashboardViewController =(DashboardViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"DashboardViewController"];
    [APPDATA pushNewViewController:objDashboardViewController];
}
#pragma mark Forgot Submit Action ........
// chekc emailid and password are valid and call forgot password API
- (IBAction)btnForgotSubmitAction:(id)sender
{
    if(![APPDATA validateEmail:self.txtforgotEmailid.text])
    {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_FORGOT_EMAIL];
        
    }
    else if([self.txtforgotEmailid.text length]<1)
    {
          [APPDATA ShowAlertWithTitle:@"" Message:ERROR_FORGOT_EMAIL];
    }
    else
    {
        [self forgotPassMethod];
    }
}
// show Forgot Password View
- (IBAction)btnForgotpassAction:(id)sender
{
     _forgotPasswordView.hidden=NO;
}


#pragma mark Login method......

-(IBAction)btnLoginPressed:(id)sender
{
    [APPDATA showLoader];
    BOOL isValid=true;
    // check email id and Password are valid or not
    if(![APPDATA validateEmail:self.txtEmail.text])
    {
        _btnForgotUsername.hidden = YES;
        isValid=false;
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_EMAIL];
        [APPDATA hideLoader];
    }
    else if(![Validations checkMinLength:self.txtPassword.text withLimit:6 ])
    {
        _btnForgotPassword.hidden = NO;
        isValid=false;
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_PASSWORD];
        
        [APPDATA hideLoader];
    }
    if (isValid == TRUE)
    {
        // call Login API for Authentication and if success then store user detail and move to Dash board view
        APPDATA.user.email = [self.txtEmail.text mutableCopy];
    
        APPDATA.user.password = [self.txtPassword.text mutableCopy];
        [APPDATA.user loginUser:^(NSString *str, int status) {
            if (status == 1)
            {
                APPDATA.isUserLogin = YES;
                if(self.btnStayLogin.isSelected)
                {
                    UDSetObject(self.txtEmail.text, @"emailid");
                    UDSetObject(self.txtPassword.text, @"password");
                     UDSetObject(self.txtPassword.text, @"PASSWORD");
                    UDSetObject(APPDATA.user.username, @"username");
                    UDSetObject(APPDATA.user.profileid, @"profile_id");
                    UDSetObject(APPDATA.user.firstname, @"firstname");
                    UDSetObject(APPDATA.user.userid, @"user_id");
                    UDSetObject(APPDATA.user.InviteUrl,@"invite_url");
                    UDSetBool(APPDATA.user.isProfilePublish, @"isPublishProfile");
                    NSLog(@"%@",APPDATA.user.InviteUrl);
                    UDSetBool(APPDATA.isUserLogin, @"isuserlogin");
                    appDelegate.profilid_AppStr=[NSString stringWithFormat:@"%@",APPDATA.user.profileid];
                }
                else
                {
                    UDSetObject(APPDATA.user.InviteUrl,@"invite_url");
                    UDSetBool(APPDATA.user.isProfilePublish, @"isPublishProfile");
                    UDSetObject(@"", @"emailid");
                    UDSetObject(@"", @"password");
                    UDSetObject(self.txtPassword.text, @"PASSWORD");
                }
                
                [APPDATA hideLoader];
                MyDashboardViewController *objDashboardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyDashboardViewController"];
                [APPDATA pushNewViewController:objDashboardViewController];
            }
            else
            {// show alert view
                [APPDATA ShowAlertWithTitle:@"" Message:WRONG_EMAIL_PASSWORD];
                [APPDATA hideLoader];
            }
        }];
    }
}
#pragma mark Facebook facebook login.........
// login with facebook if success then store user detail
-(IBAction)facebookLogin:(id)sender
{
         [APPDATA hideLoader];
        self.app.social=[[SocialLogin alloc] initWithSocialType:socialTypeFaceBook];
        if(self.app.social.socialType == socialTypeFaceBook)
        {
                self.app.social.strFBAppId=[FBAPPID mutableCopy];
                self.app.social.strFBSecretKey=[FBSECRETID mutableCopy];
                [self.app.social logoutFacebook];
                [self.app.social loginWithFacebookWithViewController:self :^(id result, NSError *error, NSString *msg, int status)
                 {
                            if(status==1)
                        {
                            [APPDATA showLoader];
                            APPDATA.user.fbid= [result valueForKey:@"id"];
                            APPDATA.isUserLogin = YES;
                            APPDATA.user.firstname = [result valueForKey:@"first_name"];
                            APPDATA.user.lastname = [result valueForKey:@"last_name"];
                            APPDATA.user.username = [[NSString stringWithFormat:@"%@ %@",[result valueForKey:@"first_name"],[result valueForKey:@"last_name"]] mutableCopy];
                            APPDATA.user.email = [result valueForKey:@"email"];
                            APPDATA.user.socialType = [@"Facebook" mutableCopy];
                            
                            //[self checkSocialId];
                            // is user login first time then first register user.
                            [self socialMediaRegistration];
                        }
                            else
                        {
                            [APPDATA hideLoader];
                            [self.viewUsername setHidden:YES];
                            [APPDATA ShowAlertWithTitle:@"" Message:msg];
                        }
                        }];
        }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
// check social id is already in database or not if already store then give it back full detail of that user and store in local other wise go to ahead for enter Unique user name screen
- (void)checkSocialId
{
    {
        void (^successed)(id responseObject) = ^(id responseObject)
        {
            NSDictionary *dictResponce = responseObject;
            if ([[dictResponce valueForKey:@"error"]boolValue] == YES) {
                ImportPhotosViewController *objImportPhotoVC = [self.storyboard instantiateViewControllerWithIdentifier:@"ImportPhotosViewController"];
                
                objImportPhotoVC.user = [[Users alloc] init];
                objImportPhotoVC.user.firstname = APPDATA.user.firstname;
                objImportPhotoVC.user.lastname = APPDATA.user.lastname;
                objImportPhotoVC.user.email = APPDATA.user.email;
                objImportPhotoVC.user.password = [@"123456" mutableCopy];
                objImportPhotoVC.user.socialType = APPDATA.user.socialType;
                objImportPhotoVC.user.fbid = APPDATA.user.fbid;
                [APPDATA pushNewViewController:objImportPhotoVC];
            }
            else {
                NSDictionary *user = [responseObject valueForKey:@"data"];
                APPDATA.user.userid = [user valueForKey:@"user_id"];
                APPDATA.user.profileid = [user  valueForKey:@"profile_id"];
                APPDATA.user.username = [user  valueForKey:@"username"];
                APPDATA.user.InviteUrl = [user  valueForKey:@"invite_url"];
                appDelegate.profilid_AppStr=[NSString stringWithFormat:@"%@",[user  valueForKey:@"profile_id"]];
                APPDATA.user.isProfilePublish = [[user valueForKey:@"status"] boolValue];
                UDSetObject( APPDATA.user.fbid, @"id");
                UDSetObject( APPDATA.user.firstname, @"first_name");
                UDSetObject( APPDATA.user.lastname, @"last_name");
                UDSetObject( APPDATA.user.email, @"email");
                UDSetObject( APPDATA.user.username, @"username");
                UDSetObject( APPDATA.user.socialType, @"Facebook");
                UDSetObject(APPDATA.user.userid, @"user_id");
                UDSetObject(APPDATA.user.profileid, @"profile_id");
                UDSetObject(APPDATA.user.username, @"username");
                UDSetObject(APPDATA.user.InviteUrl,@"invite_url");
                UDSetBool( APPDATA.isUserLogin, @"isuserFBlogin");
                UDSetBool(APPDATA.user.isProfilePublish, @"isPublishProfile");
                MyDashboardViewController *objDashboardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyDashboardViewController"];
                [APPDATA pushNewViewController:objDashboardViewController];
                [APPDATA hideLoader];
            }
        };
        void (^failure)(NSError * error) = ^(NSError *error) {
        };
        [APPDATA showLoader];
        Users *objSignin=[[Users alloc] init];
            objSignin.fbid=APPDATA.user.fbid;
            objSignin.email = APPDATA.user.email;
        
        NSDictionary *dict = @{@"key":API_KEY,@"email":objSignin.email,@"method":API_CHECK_SOCIAL_ID};
        [APICall sendToService:dict success:successed failure:failure];
    }
}

#pragma mark Registration Social....
// call when register thrugh facebook and register first time and store detail in local
- (void) socialMediaRegistration
{
    Users *objSignin=APPDATA.user;
    objSignin.firstname = APPDATA.user.firstname;
    objSignin.lastname = APPDATA.user.lastname;
    objSignin.email = APPDATA.user.email;
    objSignin.username = APPDATA.user.username;
    objSignin.socialType = APPDATA.user.socialType;
    
    [objSignin socialRegistrUser:^(NSString *str, int status)
    {
        NSLog(@"%d",status);
        
        if(status==1)
        {
            APPDATA.isUserLogin = YES;
            
            UDSetObject( APPDATA.user.fbid, @"id");
            UDSetObject( APPDATA.user.firstname, @"first_name");
            UDSetObject( APPDATA.user.lastname, @"last_name");
            UDSetObject( APPDATA.user.email, @"email");
            UDSetObject( APPDATA.user.username, @"username");
            UDSetObject( APPDATA.user.socialType, @"Facebook");
            UDSetObject(APPDATA.user.userid, @"user_id");
            UDSetObject(APPDATA.user.profileid, @"profile_id");
            UDSetObject(APPDATA.user.username, @"username");
            UDSetObject(APPDATA.user.InviteUrl,@"invite_url");
            UDSetBool( APPDATA.isUserLogin, @"isuserFBlogin");
            UDSetBool(APPDATA.user.isProfilePublish, @"isPublishProfile");
            MyDashboardViewController *objDashboardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyDashboardViewController"];
            [APPDATA pushNewViewController:objDashboardViewController];
            [APPDATA hideLoader];
        }
        else
        {
            [APPDATA ShowAlertWithTitle:@"" Message:str];
            [APPDATA hideLoader];
            return ;
        }
    }];
}
// back to previous screen then clean data
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.txtEmail.text=@"";
    self.txtPassword.text=@"";
    self.txtUsername.text=@"";
    self.txtInstaEmail.text=@"";
    [self.viewUsername setHidden:YES];
}
#pragma mark google + login....
// login with google and store data
-(IBAction)googleLogin:(id)sender{
    
    self.app.social=[[SocialLogin alloc] initWithSocialType:socialTypeGoogle];
    
    if(self.app.social.socialType == socialTypeGoogle)
        {
            self.app.social.strGoogleId=[@"810590258442-liiba31iben4932pmdknm1eb0ko757uh.apps.googleusercontent.com"mutableCopy];
                [self.app.social logoutGoogle];
                [self.app.social loginWithGoogle:^(id result, NSError *error, NSString *msg, int status)
                 {
                     APPDATA.isUserLogin = YES;
                     APPDATA.user.email = [[[result valueForKey:@"emails"] valueForKey:@"value"] firstObject];
                     APPDATA.user.firstname = [[result valueForKey:@"name"] valueForKey:@"givenName"];
                     APPDATA.user.lastname = [[result valueForKey:@"name"] valueForKey:@"familyName"];
                       APPDATA.user.socialType = [@"Google" mutableCopy];
                     APPDATA.user.fbid= [[result JSON] valueForKey:@"id"];
                     
                        [self.app.social postToGooglePlus];
                 }];
        }
}
#pragma mark Tab button action...
// Go to Contest List
- (IBAction)btnContestPressedTab:(id)sender
{
    [APPDATA btnContestsPressedTab];
}
// Go to MyPhoto screen
- (IBAction)btnMyphotosPressedTab:(id)sender
{
    [APPDATA btnMyphotoPressedTab];
}
// Go to Upload Photo Screen
- (IBAction)btnuploadPressedTab:(id)sender
{
    [APPDATA btnuploadPressedTab];
}
#pragma mark UITextField Delegate ...
//
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == self.txtEmail)
    {
        [self.txtPassword becomeFirstResponder];
    }
    else
        [textField resignFirstResponder];
        return YES;
}

#pragma mark forgot main method...
-(void)forgotPassMethod
{
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        
        [APPDATA hideLoader];
       _txtforgotEmailid.text=@"";
        NSString *error=[NSString stringWithFormat:@"%@",[responseObject objectForKey:@"error"]];
        
        if ([error isEqualToString:@"0"])
        {
            _forgotPasswordView.hidden=YES;
            
            [APPDATA ShowAlertWithTitle:@"" Message:FORGOT_CLICK];
        }
        else
        {
        
            [APPDATA ShowAlertWithTitle:@"" Message:[[responseObject valueForKey:@"message"]objectAtIndex:0]];
        }
    };
    
    void (^failure)(NSError * error) = ^(NSError *error)
    {
         _forgotPasswordView.hidden=NO;
         [APPDATA ShowAlertWithTitle:@"" Message:error.description];
        [APPDATA hideLoader];
    };
    
    [APPDATA showLoader];
    NSDictionary *dict = @{@"key":API_KEY,@"email":_txtforgotEmailid.text,@"method":API_FORGOT_PASSWORD
        };
    [APICall sendToService:dict success:successed failure:failure];
    
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if([string isEqualToString:@" "])
    {
       // self.txtPassword.tag=1;
        return NO;
    }
    else
    {
        return YES;
    }
    
    
}
@end
