//
//  LoginViewController.h
//  photobug
//
//   on 04/11/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
@interface LoginViewController : UIViewController<SlideNavigationControllerDelegate,UITextFieldDelegate>
@property (strong,nonatomic) AppDelegate *app;
@property (strong, nonatomic) IBOutlet UIButton *menuButton;
@property (nonatomic,strong) IBOutlet UITextField *txtEmail;
@property (nonatomic,strong) IBOutlet UITextField *txtPassword;
@property (nonatomic,strong) IBOutlet UITextField *txtUsername;
@property (nonatomic,strong) IBOutlet UITextField *txtInstaEmail;

@property (nonatomic,strong) IBOutlet UIButton *btnLogin;
@property (nonatomic,strong) IBOutlet UIButton *btnSignUp;
@property (nonatomic,strong) IBOutlet UIButton *btnBack;
@property (nonatomic,strong) IBOutlet UIButton *btnStayLogin;
@property (nonatomic,strong) IBOutlet UIButton *btnCancel;
@property (nonatomic,strong) IBOutlet UIButton *btnOK;
@property (nonatomic,strong) IBOutlet UIView *viewUsername;
@property(nonatomic,strong) IBOutlet UIButton *btnForgotUsername;
@property(nonatomic,strong) IBOutlet UIButton *btnForgotPassword;

@property (nonatomic,strong) IBOutlet UILabel *lblRO;
@property (nonatomic,strong) IBOutlet UILabel *lblSignIn;
@property (nonatomic,strong) IBOutlet UIButton *btnFacebookSignin;

@property (nonatomic,strong) IBOutlet UIView *viewEmail;
@property (nonatomic,strong) IBOutlet UIView *viewPassword;

@property (strong, nonatomic) IBOutlet UITextField *txtforgotEmailid;
@property (strong, nonatomic) IBOutlet UIView *forgotPasswordView;

- (IBAction)btnForgotSubmitAction:(id)sender;
-(void)forgotPassMethod;

- (IBAction)btnForgotpassAction:(id)sender;

-(IBAction)btnLoginPressed:(id)sender;
-(IBAction)btnBackPressed:(id)sender;
- (void) socialMediaRegistration;

- (IBAction)btnContestPressedTab:(id)sender;
- (IBAction)btnMyphotosPressedTab:(id)sender;
- (IBAction)btnuploadPressedTab:(id)sender;
@end
