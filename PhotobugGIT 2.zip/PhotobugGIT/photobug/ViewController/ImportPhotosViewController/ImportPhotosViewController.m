//
//  ImportPhotosViewController.m
//  photobug
//
//   on 11/7/15.
//  Copyright © Photobug. All rights reserved.
//
#import <FPPicker/FPPicker.h>
#import "ImportPhotosViewController.h"
#import "DashboardViewController.h"
#import "ApplicationData.h"
#import "Constant.h"
#import "MyDashboardViewController.h"
@interface ImportPhotosViewController ()<FPPickerControllerDelegate,
FPSaveControllerDelegate>
{
    NSString *Imageurl;
}
@property (nonatomic, strong) FPSaveController *fpSave;
@property (nonatomic, strong) UIPopoverController *myPopoverController;
@property (nonatomic, strong) NSMutableArray<UIImage *> *displayedImages;
@property (nonatomic, strong) FPTheme *theme;
@end

@implementation ImportPhotosViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    [SlideNavigationController sharedInstance].enableSwipeGesture = YES;
    [_menuButton addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleRightMenu) forControlEvents:UIControlEventTouchUpInside];
    [APPDATA hideLoader];
}
-(BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return YES;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btnBackPressed:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Accessors

- (FPTheme *)theme
{
    if (!_theme)
    {
        FPTheme *theme = [FPTheme new];
        CGFloat hue = 0.5616;
        theme.navigationBarStyle = UIBarStyleBlack;
        theme.navigationBarBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.12 alpha:1.0];
        theme.navigationBarTintColor = [UIColor colorWithHue:hue saturation:0.1 brightness:0.98 alpha:1.0];
        theme.headerFooterViewTintColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.28 alpha:1.0];
        theme.headerFooterViewTextColor = [UIColor whiteColor];
        theme.tableViewBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.49 alpha:1.0];
        theme.tableViewSeparatorColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.38 alpha:1.0];
        theme.tableViewCellBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.49 alpha:1.0];
        theme.tableViewCellTextColor = [UIColor colorWithHue:hue saturation:0.1 brightness:1.0 alpha:1.0];
        theme.tableViewCellTintColor = [UIColor colorWithHue:hue saturation:0.3 brightness:0.7 alpha:1.0];
        theme.tableViewCellSelectedBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.18 alpha:1.0];
        theme.tableViewCellSelectedTextColor = [UIColor whiteColor];
        theme.uploadButtonBackgroundColor = [UIColor blackColor];
        theme.uploadButtonHappyTextColor = [UIColor yellowColor];
        theme.uploadButtonAngryTextColor = [UIColor redColor];
        _theme = theme;
    }
    return _theme;
}

- (NSMutableArray <UIImage *>*)displayedImages
{
    if (!_displayedImages)
    {
        _displayedImages = [NSMutableArray array];
    }
    return _displayedImages;
}

#pragma mark - Actions
- (IBAction)pickerAction:(id)sender
{
    /*
     * Create the object
     */
    FPPickerController *fpController = [FPPickerController new];
    /*
     * Set the delegate
     */
    fpController.fpdelegate = self;
    /*
     * Apply theme
     */
    fpController.theme = self.theme;
    /*
     * Ask for specific data types. (Optional) Default is all files.
     */
    fpController.dataTypes = @[@"image/*"];
    /*
     * Select and order the sources (Optional) Default is all sources
     */
    //fpController.sourceNames = [[NSArray alloc] initWithObjects: FPSourceImagesearch, nil];
    /*
     * Enable multselect (Optional) Default is single select
     */
    fpController.selectMultiple = YES;
    /*
     * Specify the maximum number of files (Optional) Default is 0, no limit
     */
    fpController.maxFiles = 5;
    /*
     * Optionally disable the front camera mirroring (experimental)
     */
    fpController.disableFrontCameraLivePreviewMirroring = NO;
    /*
     * Display it.
     */
    UIPopoverController *popoverController = [[UIPopoverController alloc] initWithContentViewController:fpController];
    self.myPopoverController = popoverController;
    self.myPopoverController.popoverContentSize = CGSizeMake(320, 520);
    [self.myPopoverController presentPopoverFromRect:[sender frame]
                                              inView:self.view
                            permittedArrowDirections:UIPopoverArrowDirectionAny
                                            animated:YES];
}

- (void)pickerModalAction:(NSString *)sender
{
    /*
     * Create the object
     */
    FPPickerController *fpController = [FPPickerController new];
    /*
     * Set the delegate
     */
    fpController.fpdelegate = self;
    /*
     * Apply theme
     */
    fpController.theme = self.theme;
    /*
     * Ask for specific data types. (Optional) Default is all files.
     */
    fpController.dataTypes = @[@"image/*", @"video/*"];
    /*
     * Select and order the sources (Optional) Default is all sources
     */
    //fpController.sourceNames = @[FPSourceImagesearch];
    /*
     * Enable multselect (Optional) Default is single select
     */
    fpController.selectMultiple = YES;
    /*
     * Specify the maximum number of files (Optional) Default is 0, no limit
     */
    fpController.maxFiles = 10;
    /*
     * Optionally disable the front camera mirroring (experimental)
     */
    fpController.disableFrontCameraLivePreviewMirroring = NO;
    fpController.modalPresentationStyle = UIModalPresentationPopover;
    /*
     * If controller will show in popover set popover size (iPad)
     */
    fpController.preferredContentSize = CGSizeMake(400, 500);
    fpController.typeLogin=sender;
    UIPopoverPresentationController *presentationController = fpController.popoverPresentationController;
    presentationController.permittedArrowDirections = UIPopoverArrowDirectionAny;
    [self presentViewController:fpController
                       animated:YES
                     completion:nil];
}

- (IBAction)savingAction:(id)sender
{
    if (self.displayedImages.count == 0)
    {
        UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Nothing to Save"
                                                          message:@"Select an image first."
                                                         delegate:nil
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
        [message show];
        return;
    }
    UIImage *firstImage = self.displayedImages[0];
    NSData *imgData = UIImagePNGRepresentation(firstImage);
    /*
     * Create the object
     */
    self.fpSave = [FPSaveController new];
    /*
     * Set the delegate
     */
    self.fpSave.fpdelegate = self;
    /*
     * Apply theme
     */
    self.fpSave.theme = self.theme;
    /*
     * Select and order the sources (Optional) Default is all sources
     */
    self.fpSave.sourceNames = @[FPSourceCameraRoll];
    /*
     * Set the data and data type to be saved.
     */
    self.fpSave.data = imgData;
    self.fpSave.dataType = @"image/png";
    self.fpSave.modalPresentationStyle = UIModalPresentationPopover;
    /*
     * If controller will show in popover set popover size (iPad)
     */
    self.fpSave.preferredContentSize = CGSizeMake(400, 500);
    UIPopoverPresentationController *presentationController = self.fpSave.popoverPresentationController;
    presentationController.permittedArrowDirections = UIPopoverArrowDirectionAny;
    presentationController.sourceView = sender;
    presentationController.sourceRect = [sender bounds];
    /*
     * Display it.
     */
    [self presentViewController:self.fpSave
                       animated:YES
                     completion:nil];
}

#pragma mark - FPPickerControllerDelegate Methods

- (void)fpPickerController:(FPPickerController *)pickerController
      didPickMediaWithInfo:(FPMediaInfo *)info
{
}

- (void)  fpPickerController:(FPPickerController *)pickerController
didFinishPickingMediaWithInfo:(FPMediaInfo *)info
{
    // NSLog(@"FILE CHOSEN: %@", info);
    if (info)
    {
        if (info.containsImageAtMediaURL)
        {
            UIImage *image = [UIImage imageWithContentsOfFile:info.mediaURL.path];
            Imageurl=[NSString stringWithFormat:@"%@",info.remoteURL];
            UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil);
            [APPDATA ShowAlertWithTitle:@"" Message:@"Successfully saved in photo gallery"];
            [self.displayedImages removeAllObjects];
            [self.displayedImages addObject:image];
            self.imageView.image = image;
        }
        [self dismissViewControllerAnimated:YES
                                 completion:nil];
    }
    else
    {
        //NSLog(@"Nothing was picked.");
    }
}
- (void)fpPickerController:(FPPickerController *)pickerController
didFinishPickingMultipleMediaWithResults:(NSArray *)results
{
    // NSLog(@"FILES CHOSEN: %@", results);
    if (results.count == 0)
    {
        //NSLog(@"Nothing was picked.");
        return;
    }
    // Making a little carousel effect with the images
    [self.displayedImages removeAllObjects];
    for (FPMediaInfo *info in results)
    {
        // Check if uploaded file is an image to add it to carousel
        if (info.containsImageAtMediaURL)
        {
            UIImage *image = [UIImage imageWithContentsOfFile:info.mediaURL.path];
            Imageurl=[NSString stringWithFormat:@"%@",info.remoteURL];
            UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil);
            [APPDATA ShowAlertWithTitle:@"" Message:@"Successfully saved in photo gallery"];

            [self.displayedImages addObject:image];
        }
    }
    self.imageView.animationImages = self.displayedImages;
    self.imageView.animationRepeatCount = 100.f;
    self.imageView.animationDuration = 2.f * self.displayedImages.count; // 2 seconds per image
    [self dismissViewControllerAnimated:YES
                             completion: ^()
    {
        [self.imageView startAnimating];
    }];
}

- (void)fpPickerControllerDidCancel:(FPPickerController *)pickerController
{
    //NSLog(@"FP Cancelled Open");
    [self dismissViewControllerAnimated:YES
                             completion:nil];
}

#pragma mark - FPSaveControllerDelegate Methods

- (void)fpSaveController:(FPSaveController *)saveController
    didFinishSavingMediaWithInfo:(FPMediaInfo *)info
{
    // NSLog(@"FP finished saving with info %@", info);
    [self.fpSave dismissViewControllerAnimated:YES
                                    completion:nil];
}

- (void)fpSaveControllerDidCancel:(FPSaveController *)saveController
{
    //NSLog(@"FP Cancelled Save");
    [self.fpSave dismissViewControllerAnimated:YES
                                    completion:nil];
}

- (void)fpSaveController:(FPSaveController *)saveController
                didError:(NSError *)error
{
    // NSLog(@"FP Error: %@", error);
}

- (IBAction)facebookButtonAction:(id)sender
{
    [self pickerModalAction:@"fb"];
}

- (IBAction)instaButtinAction:(id)sender
{
    [self pickerModalAction:@"in"];
}

- (IBAction)flickerButtonAction:(id)sender
{
    [self pickerModalAction:@"fl"];
}

- (IBAction)dropboxButtonAction:(id)sender
{
    [self pickerModalAction:@"dr"];
}

- (IBAction)googldriveButtonAction:(id)sender
{
    [self pickerModalAction:@"go"];
}
-(IBAction)btnOK:(id)sender
{
    [APPDATA showLoader];
    NSCharacterSet *set = [NSCharacterSet whitespaceCharacterSet];
    if ([self.txtUsername.text length]<2)
    {
        [APPDATA ShowAlertWithTitle:@"" Message:@"Username is required."];
         [APPDATA hideLoader];
    }
    else if (![Validations checkMaxLength:self.txtUsername.text withLimit:20])
    {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_MAXLENGTH_USERNAME];
         [APPDATA hideLoader];
    }

    else if ([[self.txtUsername.text stringByTrimmingCharactersInSet: set] length] == 0)
    {
        [APPDATA ShowAlertWithTitle:@"" Message:@"Username is required."];
         [APPDATA hideLoader];
    }
    else
    {
        self.user.username = [self.txtUsername.text mutableCopy];
        if ([APPDATA.user.socialType isEqualToString:@"Facebook"]) {
            [self.user socialRegistrUser:^(NSString *str, int status)
             {
                 NSLog(@"%d",status);
                 
                 if(status==1)
                 {
                     APPDATA.isUserLogin = YES;
                     
                     UDSetObject( APPDATA.user.fbid, @"id");
                     UDSetObject( APPDATA.user.firstname, @"first_name");
                     UDSetObject( APPDATA.user.lastname, @"last_name");
                     UDSetObject( APPDATA.user.email, @"email");
                     UDSetObject( APPDATA.user.username, @"username");
                     UDSetObject( APPDATA.user.socialType, @"Facebook");
                     UDSetObject(APPDATA.user.userid, @"user_id");
                     UDSetObject(APPDATA.user.profileid, @"profile_id");
                     UDSetObject(APPDATA.user.username, @"username");
                     UDSetObject(APPDATA.user.InviteUrl,@"invite_url");
                     UDSetBool( APPDATA.isUserLogin, @"isuserFBlogin");
                     UDSetBool(APPDATA.user.isProfilePublish, @"isPublishProfile");
                     MyDashboardViewController *objDashboardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyDashboardViewController"];
                     [APPDATA pushNewViewController:objDashboardViewController];
                     [APPDATA hideLoader];
                 }
                 else
                 {
                     [APPDATA ShowAlertWithTitle:@"" Message:str];
                     [APPDATA hideLoader];
                     return ;
                 }
             }];
        }
        else {
        
        [self.user registerUser:^(NSString *str, int status)
         {
             [APPDATA hideLoader];
             
             
             if(status==1)
             {
                 UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"" message:SUCCESS_SIGNUP delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                 [alert show];

             }
             else
             {
                 [APPDATA ShowAlertWithTitle:@"" Message:str];
                 [APPDATA hideLoader];
             }
         }];
        }
    }
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
      APPDATA.isUserLogin = YES;
    UDSetObject(self.email, @"emailid");
    UDSetObject(self.password, @"password");
    UDSetObject(APPDATA.user.username, @"username");
    UDSetObject(APPDATA.user.profileid, @"profile_id");
    UDSetObject(APPDATA.user.firstname, @"firstname");
    UDSetObject(APPDATA.user.userid, @"user_id");
    UDSetBool(APPDATA.isUserLogin, @"isuserlogin");
    UDSetBool(APPDATA.user.isProfilePublish, @"isPublishProfile");
    appDelegate.profilid_AppStr=[NSString stringWithFormat:@"%@",APPDATA.user.profileid];
    UDSetObject(@"", @"emailid");
    UDSetObject(@"", @"password");
    [APPDATA hideLoader];
    MyDashboardViewController *objDashboardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyDashboardViewController"];
    [APPDATA pushNewViewController:objDashboardViewController];
}
-(void)saveInDevice
{
}

#pragma mark Tab button action...

- (IBAction)btnContestPressedTab:(id)sender
{
    [APPDATA btnContestsPressedTab];
}
- (IBAction)btnMyphotosPressedTab:(id)sender
{
    [APPDATA btnMyphotoPressedTab];
}
- (IBAction)btnuploadPressedTab:(id)sender
{
    [APPDATA btnuploadPressedTab];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if([string isEqualToString:@" "])
    {
      
        return NO;
    }
    else
    {
        return YES;
    }
    
    
}
@end
