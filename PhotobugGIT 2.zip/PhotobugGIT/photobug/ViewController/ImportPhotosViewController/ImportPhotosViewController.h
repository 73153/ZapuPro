//
//  ImportPhotosViewController.h
//  photobug
//
//   on 11/7/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlideNavigationController.h"
#import "RightMenuViewController.h"
#import "AppDelegate.h"
#import "LoginViewController.h"
#import "Users.h"

@interface ImportPhotosViewController : UIViewController<UIPopoverControllerDelegate,SlideNavigationControllerDelegate,UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UIButton *menuButton;
@property (nonatomic, weak) IBOutlet UIImageView *imageView;
@property (nonatomic, weak) LoginViewController *loginvc;
@property (nonatomic,retain) Users *user;
@property (nonatomic,retain) IBOutlet UITextField *txtUsername;
@property (nonatomic,strong) NSString *firstName;
@property (nonatomic,strong) NSString *lastName;
@property (nonatomic,strong) NSString *password;
@property (nonatomic,strong) NSString *email;

- (IBAction)facebookButtonAction:(id)sender;
- (IBAction)instaButtinAction:(id)sender;
- (IBAction)flickerButtonAction:(id)sender;
- (IBAction)dropboxButtonAction:(id)sender;
- (IBAction)googldriveButtonAction:(id)sender;
- (IBAction)btnContestPressedTab:(id)sender;
- (IBAction)btnMyphotosPressedTab:(id)sender;
- (IBAction)btnuploadPressedTab:(id)sender;



@end
