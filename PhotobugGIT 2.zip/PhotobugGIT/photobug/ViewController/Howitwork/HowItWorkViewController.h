//
//  HowItWorkViewController.h
//  photobug
//
//   on 17/12/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HowItWorkViewController : UIViewController <UIWebViewDelegate>
@property (strong, nonatomic) IBOutlet UIButton *menuButton;
@property (weak, nonatomic) IBOutlet UIWebView *webViewHTML;

@property (strong, nonatomic) IBOutlet UIButton *BackBtn;

@end
