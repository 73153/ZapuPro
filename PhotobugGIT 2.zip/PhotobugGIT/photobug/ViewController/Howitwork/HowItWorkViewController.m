//
//  HowItWorkViewController.m
//  photobug
//
//   on 17/12/15.
//  Copyright © Photobug. All rights reserved.
//

#import "HowItWorkViewController.h"
#import "Constant.h"
#import "ApplicationData.h"
#import "ContestCategoryViewController.h"

@interface HowItWorkViewController ()

@end

@implementation HowItWorkViewController
// load Webview
- (void)viewDidLoad {
    [super viewDidLoad];
    _webViewHTML.delegate=self;
    [_menuButton addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleRightMenu) forControlEvents:UIControlEventTouchUpInside];
    _webViewHTML.scrollView.bounces = NO;
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}

// pass url in webview for display on screen..
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    // -----  calling web url //----------------------------
    NSString *urlString = @"http://216.55.169.45/~photobug/how-it-works-app";
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url];
    [_webViewHTML loadRequest:urlRequest];
}


#pragma mark Tab button action...
- (IBAction)btnContestPressed:(id)sender
{
    [APPDATA btnContestsPressedTab];
}
- (IBAction)btnMyphotosPressed:(id)sender
{
    [APPDATA btnMyphotoPressedTab];
}
- (IBAction)btnuploadPressed:(id)sender
{
    [APPDATA btnuploadPressedTab];
}
// pop to the particular last controller..
- (IBAction)btnBackAction:(id)sender
{
    
    [self.navigationController popViewControllerAnimated:YES];
}
// webview load url with request type
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    NSLog(@"%@",request.URL.scheme);
    if ([request.URL.scheme isEqualToString:@"inapp"]) {
        if ([request.URL.host isEqualToString:@"capture"]) {
           
        }
        return NO;
    }
    return YES;
}

-(void)webViewDidStartLoad:(UIWebView *)webView {
 
    [APPDATA showLoader];
    
}
-(void)webViewDidFinishLoad:(UIWebView *)webView {
     [_BackBtn setEnabled:[_webViewHTML canGoBack]];
    [APPDATA hideLoader];
  
}

@end
