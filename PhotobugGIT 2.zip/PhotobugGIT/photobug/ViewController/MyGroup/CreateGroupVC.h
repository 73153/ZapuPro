//
//  CreateGroupVC.h
//  photobug
//
//  Created by bhumit on 30/06/16.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FPPicker/FPPicker.h>
#import "UIPlaceHolderTextView.h"

@interface CreateGroupVC : UIViewController<FPPickerControllerDelegate,
FPSaveControllerDelegate,UIActionSheetDelegate>

@property (nonatomic, strong) FPSaveController *fpSave;
@property (nonatomic, strong) NSMutableArray<UIImage *> *displayedImages;
@property (strong, nonatomic) IBOutlet UIButton *btnSubmitCreate;
@property (strong, nonatomic) IBOutlet UIImageView *addphotoImage;
@property (strong, nonatomic) IBOutlet UITextField *txtGroupTitle;
@property (strong, nonatomic) IBOutlet UITextView *txtfieldDesc;
@property (strong, nonatomic) IBOutlet UIPlaceHolderTextView *txtDesc;
@property (strong, nonatomic) IBOutlet UIButton *btnCancel;
@property (nonatomic, strong) FPTheme *theme;

- (IBAction)btnCancelClose:(id)sender;
- (IBAction)createGroupBtn:(id)sender;
- (IBAction)btnAddphoto:(id)sender;

@end
