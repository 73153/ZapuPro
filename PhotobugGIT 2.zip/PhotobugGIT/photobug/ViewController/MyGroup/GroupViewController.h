//
//  MyGroupViewController.h
//  photobug
//
//   on 12/7/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RightMenuViewController.h"
#import "ScrollViewController.h"

@interface GroupViewController : ScrollViewController
@property (nonatomic,strong) UIRefreshControl *refresh;
@property (strong, nonatomic) IBOutlet UICollectionView *collectionView;
@property (nonatomic,strong) IBOutlet UILabel *lblNoDataFound;
@property (strong, nonatomic) IBOutlet UIButton *menuButton;
@property (nonatomic,strong) IBOutlet UIButton *btnCreateGroup;

- (IBAction)btnCreateGroup:(id)sender;
- (IBAction)btnContestPressedTab:(id)sender;
- (IBAction)btnMyphotosPressedTab:(id)sender;
- (IBAction)btnuploadPressedTab:(id)sender;

@end
