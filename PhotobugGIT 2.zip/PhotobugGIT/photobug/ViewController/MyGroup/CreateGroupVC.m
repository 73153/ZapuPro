//
//  CreateGroupVC.m
//  photobug
//
//  Created by bhumit on 30/06/16.
//  Copyright © Photobug. All rights reserved.
//

#import "CreateGroupVC.h"
#import "Group.h"
#import <FPPicker/FPPicker.h>
#import "ApplicationData.h"
#import "Constant.h"
#import "GroupFeedViewController.h"

@interface CreateGroupVC ()
{
    NSString *postImageurl,*profileimageStr;
     NSString *addpostimageFlage;

}
@end

@implementation CreateGroupVC

- (void)viewDidLoad {
    [super viewDidLoad];
   // _lblHeaderName.font = [UIFont fontWithName:@"OpenSans-SemiBold" size:20];

   [_txtDesc setFont:[UIFont fontWithName:@"OpenSans-SemiBold" size:14]];
   _txtDesc.placeholder=@"Write A Description";
    [[_btnSubmitCreate layer] setBorderWidth:1.0f];
    [[_btnSubmitCreate layer] setCornerRadius:2.0f];
    [[_btnSubmitCreate layer] setBorderColor:[UIColor colorWithRed:50.0/255.0 green:198.0/255.0 blue:244.0/255.0 alpha:1.0].CGColor];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)createGroupBtn:(id)sender {
    
    Group *objMyGroup=[[Group alloc] init];
    objMyGroup.groupName=self.txtGroupTitle.text.mutableCopy;
    objMyGroup.postedBy=APPDATA.user.profileid;
    objMyGroup.groupDescription=self.txtfieldDesc.text.mutableCopy;
    if (postImageurl==nil) {
        objMyGroup.groupImg=[NSMutableString stringWithFormat:@""];
    }
    else
    objMyGroup.groupImg=postImageurl.mutableCopy;
    
    [APPDATA showLoader];
      if ([[APPDATA isNullOrEmpty:objMyGroup.groupName] isEqual:@""])
    {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_GROUP_NAME];
        [APPDATA hideLoader];
        
    }
    else if ([[APPDATA isNullOrEmpty:objMyGroup.groupDescription] isEqual:@""])
    {
        [APPDATA ShowAlertWithTitle:@"" Message:@"Please enter description."];
        [APPDATA hideLoader];
    }
    else
    {
        [objMyGroup addGroup:^(NSDictionary *result, NSString *str, int status) {
            
            if (status == 1) {
                [APPDATA ShowAlertWithTitle:@"" Message:@"Group created succesfully."];
                [self.view removeFromSuperview];
                
                GroupFeedViewController  *objviewController =(GroupFeedViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"GroupFeedViewController"];
                objviewController.isMyGroup = YES;
                NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
                [dict setObject:[result valueForKey:@"id" ] forKey:@"id"];
                [dict setObject:self.txtfieldDesc.text forKey:@"description"];
                [dict setObject:self.txtGroupTitle.text forKey:@"group_name"];
                if (postImageurl!=nil) {
                    [dict setObject:postImageurl forKey:@"group_image"];
                }
                
                objviewController.dictGroupDetail = dict;
                
                [APPDATA pushNewViewController:objviewController];
                [[NSNotificationCenter defaultCenter]postNotificationName:@"CreateGroup" object:nil];
                [APPDATA hideLoader];
            }
            else {
                [APPDATA hideLoader];

                [APPDATA ShowAlertWithTitle:@"" Message:@"The group name field is required."
                 ];
            }
        }];
    }
}

- (IBAction)btnAddphoto:(id)sender
{
    addpostimageFlage=@"0";
     [self pickerModalAction:@"lip"];
}

- (FPTheme *)theme
{
    if (!_theme)
    {
        FPTheme *theme = [FPTheme new];
        CGFloat hue = 0.5616;
        theme.navigationBarStyle = UIBarStyleBlack;
        theme.navigationBarBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.12 alpha:1.0];
        theme.navigationBarTintColor = [UIColor colorWithHue:hue saturation:0.1 brightness:0.98 alpha:1.0];
        theme.headerFooterViewTintColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.28 alpha:1.0];
        theme.headerFooterViewTextColor = [UIColor whiteColor];
        theme.tableViewBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.49 alpha:1.0];
        theme.tableViewSeparatorColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.38 alpha:1.0];
        theme.tableViewCellBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.49 alpha:1.0];
        theme.tableViewCellTextColor = [UIColor colorWithHue:hue saturation:0.1 brightness:1.0 alpha:1.0];
        theme.tableViewCellTintColor = [UIColor colorWithHue:hue saturation:0.3 brightness:0.7 alpha:1.0];
        theme.tableViewCellSelectedBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.18 alpha:1.0];
        theme.tableViewCellSelectedTextColor = [UIColor whiteColor];
        theme.uploadButtonBackgroundColor = [UIColor blackColor];
        theme.uploadButtonHappyTextColor = [UIColor yellowColor];
        theme.uploadButtonAngryTextColor = [UIColor redColor];
        _theme = theme;
    }
    return _theme;
}
- (NSMutableArray <UIImage *>*)displayedImages
{
    if (!_displayedImages)
    {
        _displayedImages = [NSMutableArray array];
    }
    return _displayedImages;
}
- (void)pickerModalAction:(NSString *)sender
{
    /*
     * Create the object
     */
    FPPickerController *fpController = [FPPickerController new];
    /*
     * Set the delegate
     */
    fpController.fpdelegate = self;
    /*
     * Apply theme
     */
    fpController.theme = self.theme;
    /*
     * Ask for specific data types. (Optional) Default is all files.
     */
    fpController.dataTypes = @[@"image/*", @"video/*"];
    /*
     * Select and order the sources (Optional) Default is all sources
     */
    //fpController.sourceNames = @[FPSourceImagesearch];
    /*
     * Enable multselect (Optional) Default is single select
     */
    fpController.selectMultiple = YES;
    /*
     * Specify the maximum number of files (Optional) Default is 0, no limit
     */
    fpController.maxFiles = 10;
    /*
     * Optionally disable the front camera mirroring (experimental)
     */
    fpController.disableFrontCameraLivePreviewMirroring = NO;
    fpController.modalPresentationStyle = UIModalPresentationPopover;
    /*
     * If controller will show in popover set popover size (iPad)
     */
    fpController.preferredContentSize = CGSizeMake(400, 500);
    fpController.typeLogin=sender;
    UIPopoverPresentationController *presentationController = fpController.popoverPresentationController;
    presentationController.permittedArrowDirections = UIPopoverArrowDirectionAny;
    //presentationController.sourceView = sender;
    // presentationController.sourceRect = [sender bounds];
    /*
     * Display it.
     */
    [self presentViewController:fpController
                       animated:YES
                     completion:nil];
}
- (void)fpPickerControllerDidCancel:(FPPickerController *)pickerController
{
    // NSLog(@"FP Cancelled Open");
    [self dismissViewControllerAnimated:YES
                             completion:nil];
}
- (void)fpPickerController:(FPPickerController *)pickerController
      didPickMediaWithInfo:(FPMediaInfo *)info
{
}
- (void)fpPickerController:(FPPickerController *)pickerController
didFinishPickingMediaWithInfo:(FPMediaInfo *)info
{
    //NSLog(@"FILE CHOSEN: %@", info);
    if (info)
    {
        if (info.containsImageAtMediaURL)
        {
            if ([addpostimageFlage isEqualToString:@"0"])
            {
                postImageurl=[NSString stringWithFormat:@"%@",info.remoteURL];
                NSLog(@"%@",info.remoteURL);
                UIImage *image = [UIImage imageWithContentsOfFile:info.mediaURL.path];
                [self.displayedImages addObject:image];
                [self.displayedImages removeAllObjects];
                [self.displayedImages addObject:image];
                self.addphotoImage.contentMode=UIViewContentModeScaleAspectFit;
                self.addphotoImage.image = image;
            }
            else
            {

            }
        }
        [self dismissViewControllerAnimated:YES
                                 completion:nil];
    }
    else
    {
        //NSLog(@"Nothing was picked.");
    }
}

- (IBAction)btnCancelClose:(id)sender {
    [self.view removeFromSuperview];
    [[NSNotificationCenter defaultCenter]postNotificationName:@"CreateGroup" object:nil];
}
@end
