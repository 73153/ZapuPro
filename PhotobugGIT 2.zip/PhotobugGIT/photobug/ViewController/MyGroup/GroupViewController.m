//
//  MyGroupViewController.m
//  photobug
//
//   on 12/7/15.
//  Copyright © Photobug. All rights reserved.
//

#import "GroupViewController.h"
#import "Constant.h"
#import "CreateGroupVC.h"
#import "ApplicationData.h"
#import "MyDashboardViewController.h"
#import "GroupFeedViewController.h"
#import "ScrollViewController.h"
#import <UIActivityIndicator-for-SDWebImage/UIImageView+UIActivityIndicatorForSDWebImage.h>
#import <QuartzCore/QuartzCore.h>

@interface GroupViewController ()<UICollectionViewDataSource,UICollectionViewDelegate>
{
    NSString *addpostimageFlage;
        int pageNo;
}

@end

@implementation GroupViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(backFromCreateGroup) name:@"CreateGroup" object:nil];
    [self.collectionView setBouncesZoom:NO];
    [[_btnCreateGroup layer] setBorderWidth:1.0f];
    [[_btnCreateGroup layer] setCornerRadius:2.0f];
    [[_btnCreateGroup layer] setBorderColor:[UIColor colorWithRed:50.0/255.0 green:198.0/255.0 blue:244.0/255.0 alpha:1.0].CGColor];
    // Do any additional setup after loading the view.
}
- (void) backFromCreateGroup {
    APPDATA.group.arrgroupList  = [[NSMutableArray alloc] init];
    pageNo = 1;
    [self getGroupList];
}

- (void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
     APPDATA.group.arrgroupList = [[NSMutableArray alloc] init];
    [_menuButton addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleRightMenu) forControlEvents:UIControlEventTouchUpInside];
    pageNo = 1;
    [self getGroupList];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)reloadData
{
if (APPDATA.group.lastPage > pageNo)
    {
        pageNo = pageNo+1;
        [self getGroupList];
     }
}
#pragma marrk Get profile info...
- (void) getGroupList
{
    [APPDATA showLoader];
    Group *objGroup = [[Group alloc] init];
    objGroup.key = [API_KEY mutableCopy];
    objGroup.page=[NSString stringWithFormat:@"%d", pageNo ].mutableCopy;
    [objGroup getGroupList:^(NSDictionary *result, NSString *str, int status) {
        
        if (status == 1)
        {
            if(APPDATA.group.arrgroupList.count==0)
            {
                 self.lblNoDataFound.hidden = NO;
                CGRect frame = self.lblNoDataFound.frame;
                frame.origin.y = (self.view.superview.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
                [self.lblNoDataFound setFrame:frame];

            }else
            {
                 self.lblNoDataFound.hidden = YES;
            }
            [self.collectionView reloadData];
        }
        else if(status == 0)
        {
            self.lblNoDataFound.hidden = NO;
            CGRect frame = self.lblNoDataFound.frame;
            frame.origin.y = (self.view.superview.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
            [self.lblNoDataFound setFrame:frame];

            [self.collectionView reloadData];
        }
        else
        {
            self.lblNoDataFound.hidden = NO;
            CGRect frame = self.lblNoDataFound.frame;
            frame.origin.y = (self.view.superview.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
            [self.lblNoDataFound setFrame:frame];

            [self.collectionView reloadData];
            [self getGroupList];
        }
         [APPDATA hideLoader];
    }];
}
#pragma mark collectionView delegate method...

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return APPDATA.group.arrgroupList.count;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"Cell";
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];

    @try {
             UIImageView *recipeImageView = (UIImageView *)[cell viewWithTag:100];
               NSDictionary *dictUserData = [APPDATA.group.arrgroupList objectAtIndex:indexPath.row];
        
        UILabel *userLabel = (UILabel *)[cell viewWithTag:101];
        NSString * nameStr=[dictUserData valueForKey:@"group_name"];
        NSString *lastChar = [nameStr substringFromIndex:[nameStr length] - 1];
        
        if ([lastChar isEqualToString:@"."])
        {
            userLabel.text=[[dictUserData valueForKey:@"group_name"] uppercaseString];
        }
        else
        {
            userLabel.text=[[NSString stringWithFormat:@"%@.",nameStr]uppercaseString];
        }
        userLabel.shadowColor = [UIColor blackColor];
        if (![[dictUserData valueForKey:@"group_image"] isKindOfClass:[NSNull class]] &&
            [[dictUserData valueForKey:@"group_image"] length] > 3)
        {
            NSString *profile_photoStr=[NSString stringWithFormat:@"%@",[dictUserData valueForKey:@"group_image"]];
            NSString *fCharStr =[profile_photoStr substringToIndex:22];
            if ([profile_photoStr rangeOfString:@"convert"].location == NSNotFound && [fCharStr isEqualToString:@"https://www.filepicker"])
            {
                profile_photoStr = [NSString stringWithFormat:@"%@/convert?w=1000&h=1000",profile_photoStr] ;
            }
            else if([fCharStr isEqualToString:@"https://www.filepicker"])
            {
                profile_photoStr = [profile_photoStr substringToIndex:[profile_photoStr length]-20];
                profile_photoStr = [NSString stringWithFormat:@"%@/convert?w=1000&h=1000",profile_photoStr] ;
            }
            
            [recipeImageView setImageWithURL:[NSURL URLWithString:profile_photoStr] placeholderImage:[UIImage imageNamed:@"no_imgV.png"] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            recipeImageView.contentMode = UIViewContentModeScaleAspectFill;
            recipeImageView.clipsToBounds=YES;
            
        }
        else
        {
            [recipeImageView setImage:[UIImage imageNamed:@"no_imgV.png"]];
        }
        
        [APPDATA hideLoader];

    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
    
       return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSArray *arr=APPDATA.group.arrgroupList;
    GroupFeedViewController  *objviewController =(GroupFeedViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"GroupFeedViewController"];
       
    if ([[[arr objectAtIndex:indexPath.row]valueForKey:@"posted_by"]integerValue] == APPDATA.user.profileid.integerValue) {
        objviewController.isMyGroup=YES;
        
    }else{
        objviewController.isMyGroup=NO;
    }
    
   // objviewController.otherProfiletag=[NSString stringWithFormat:@"%ld",(long)indexPath.row];
    objviewController.dictGroupDetail = [APPDATA.group.arrgroupList objectAtIndex:indexPath.row];
     APPDATA.group.groupId = [[APPDATA.group.arrgroupList objectAtIndex:indexPath.row]valueForKey:@"id"];
     APPDATA.group.postedBy = [[APPDATA.group.arrgroupList objectAtIndex:indexPath.row]valueForKey:@"posted_by"];
    
   // objviewController.selectGroupeType = SelectAllGroup;
    
    objviewController.usertype = Guestuser;
    objviewController.selectGroupeType = (groupType*)SelectAllGroup;
    //objviewController.selectType = SelectGroup;
    [APPDATA pushNewViewController:objviewController];
   // [self.navigationController pushViewController:objviewController animated:YES];
    
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    CGSize cgsize ;
    
    
    if( IS_IPHONE6){
        cgsize = CGSizeMake(183, 183);
        
    }else if(IS_IPHONE6plus)
    {
        cgsize = CGSizeMake(202, 202);
        
    }else
    {
        cgsize = CGSizeMake(156, 156);
    }
    return cgsize;
}
- (IBAction)btnBackPressed:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark Tab button action...

- (IBAction)btnCreateGroup:(id)sender {
        CreateGroupVC *controller =(CreateGroupVC *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"CreateGroupVC"];
    
    
        [self.parentViewController addChildViewController:controller];
        [self.parentViewController.view addSubview:controller.view];
        [controller didMoveToParentViewController:self];
        [controller.view setFrame:CGRectMake(0,0,controller.view.frame.size.width,self.view.frame.size.height)];
}

- (IBAction)btnContestPressedTab:(id)sender {
     [APPDATA btnContestsPressedTab];
}
- (IBAction)btnMyphotosPressedTab:(id)sender {
    [APPDATA btnMyphotoPressedTab];
}
- (IBAction)btnuploadPressedTab:(id)sender {
    [APPDATA btnuploadPressedTab];
}

@end
