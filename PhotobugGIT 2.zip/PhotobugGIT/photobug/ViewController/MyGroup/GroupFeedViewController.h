//
//  GroupFeedViewController.h
//  photobug
//
//   on 21/12/15.
//  Copyright © Photobug. All rights reserved.
//
typedef enum {
    SelectMyGroup,
    SelectAllGroup,
} groupType;
#import <UIKit/UIKit.h>
#import "RTLabel.h"
#import "RightMenuViewController.h"
#import "UIPlaceHolderTextView.h"
#import "UCZProgressView.h"
#import <MessageUI/MessageUI.h>

@interface GroupFeedViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UIScrollViewDelegate,MFMailComposeViewControllerDelegate>
{
    NSString *postMessageStr,*feed_typeStr,*postImageStr;
}
@property BOOL isMyGroup;
@property (nonatomic)BOOL usertype;
@property (strong, nonatomic) IBOutlet UITableView *tableviewFeed;
@property (strong, nonatomic) IBOutlet UIButton *menuButton;
@property (nonatomic,strong) IBOutlet UITextField *txtGroupTitle;
@property (nonatomic,strong) IBOutlet UIImageView *imgGroupImage;
@property (weak, nonatomic) IBOutlet UIView *viewNewPost;
@property (weak, nonatomic) IBOutlet UIButton *btnNewPost;
@property (weak, nonatomic) IBOutlet UIButton *btnEmail;
@property (weak, nonatomic) IBOutlet UIButton *btnFackebook;
@property (nonatomic,strong) IBOutlet UILabel *lblNoDataFound;
@property (weak, nonatomic) IBOutlet UIButton *btnMyfeed;
@property (strong, nonatomic) IBOutlet NSString *otherProfiletag;
@property (strong,nonatomic) NSDictionary *dictGroupDetail;
@property (strong, nonatomic) IBOutlet UILabel *lbluserName;
@property (strong, nonatomic) IBOutlet UIImageView *addphotoImage;
@property (strong, nonatomic) IBOutlet UIPlaceHolderTextView *txtpost;
@property (nonatomic, weak) IBOutlet RTLabel *postviewComment;
@property(nonatomic ,retain)NSString *strProfileid;
@property (weak, nonatomic) IBOutlet UIView *ShareView;
@property (weak, nonatomic) IBOutlet UIImageView *imgviewBorder;
@property (nonatomic,strong) IBOutlet UIButton *btnJoinGroup;
@property (strong, nonatomic) IBOutlet UIImageView *profilephoto;
@property (nonatomic) groupType *selectGroupeType;
@property (strong, nonatomic) IBOutlet UIImageView *BigImageView;
@property (strong, nonatomic) IBOutlet UIView *photDisplayView;
@property (nonatomic) IBOutlet UCZProgressView *progressView;
@property (nonatomic) IBOutlet UIScrollView *bigimgScrollView;
@property (nonatomic) NSMutableData *data1;
@property (nonatomic) double expectedBytes;
@property NSString *data;
- (IBAction)btnCloseTapped:(id)sender;
- (IBAction)imgFeedAction:(id)sender;
- (IBAction)btnJoinGroupPressed:(id)sender;
-(void)getSelectedGroupFeed;
-(void)leaveGroup;
 @end
