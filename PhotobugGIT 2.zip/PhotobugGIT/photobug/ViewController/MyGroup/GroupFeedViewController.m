//
//  GroupFeedViewController.m
//  photobug
//
//   on 21/12/15.
//  Copyright © Photobug. All rights reserved.
//
#import "GroupFeedViewController.h"
#import "IQKeyboardManager.h"
#import "IQKeyboardManagerConstants.h"
#import "IQKeyboardReturnKeyHandler.h"
#import "IQUIView+IQKeyboardToolbar.h"
#import "MyDashboardViewController.h"
#import "APICall.h"
#import "FeedCell2TableViewCell.h"
#import "AddCommentViewController.h"
#import "MyGroupsViewController.h"
#import <FPPicker/FPPicker.h>
#import "GroupViewController.h"
#import <UIActivityIndicator-for-SDWebImage/UIImageView+UIActivityIndicatorForSDWebImage.h>

@interface GroupFeedViewController ()<FPPickerControllerDelegate,
FPSaveControllerDelegate>
{

    NSString *strProfileid,*rowId,*strAdmin,*strUserId,*strOtherId;
    NSArray *commentsArray;
    CGSize optimumSize;
    MyDashboardViewController *objMyDashboardViewController;
    UITapGestureRecognizer *singleTap;
    NSMutableArray *aryCellHeight;
    NSString *postImageurl,*addpostimageFlage,*imagestr;
    IQKeyboardReturnKeyHandler *returnKeyHandler;
    FBSDKShareButton *shareButton;
    FBSDKShareLinkContent *content;
    NSString *commentStr,*postidStr,*strGroupId,*profileimageStr,*JOINStr;
    BOOL _wasKeyboardManagerEnabled;
     NSInteger indexToDeletePost;
    NSDictionary *dicGroup;
}
@property (nonatomic, strong) FPSaveController *fpSave;
@property (nonatomic, strong) UIPopoverController *myPopoverController;
@property (nonatomic, strong) NSMutableArray<UIImage *> *displayedImages;
@property (nonatomic, strong) FPTheme *theme;
@end

@implementation GroupFeedViewController
@synthesize usertype,strProfileid;

// to hide big image and  custom keyboard
- (void)viewDidLoad {
    [super viewDidLoad];
    APPDATA.group.arrGroupFeed=nil;
    [_menuButton addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleRightMenu) forControlEvents:UIControlEventTouchUpInside];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(hideShareView) name:@"hideShareView" object:nil];
    [[IQKeyboardManager sharedManager] setEnable:YES];
    [[IQKeyboardManager sharedManager] setEnableAutoToolbar:YES];
    returnKeyHandler = [[IQKeyboardReturnKeyHandler alloc] initWithViewController:self];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapShareView)];
    [self.view addGestureRecognizer:tap];
    
    _BigImageView.userInteractionEnabled = YES;
    _photDisplayView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSingleTapGesture:)];
 
    [_photDisplayView addGestureRecognizer:tapGestureRecognizer];
    
    self.bigimgScrollView.delegate = self;
    self.bigimgScrollView.contentSize = self.BigImageView.size;
    self.bigimgScrollView.delegate = self;
    self.bigimgScrollView.maximumZoomScale = 100.0;
    [_txtpost setFont:[UIFont fontWithName:@"OpenSans" size:12]];
    _txtpost.placeholder=@"Write a Post";

    [_ShareView setHidden:YES];
    
}

// call get groupfeed and veryfygroupMember APIS and set new create group details.
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getSelectedGroupFeed) name:@"reloadGroup" object:nil];
    
       _photDisplayView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSingleTapGesture:)];
    [_photDisplayView addGestureRecognizer:tapGestureRecognizer];
   
    self.txtGroupTitle.text = [NSString stringWithFormat:@"%@.",[[self.dictGroupDetail valueForKey:@"group_name"] uppercaseString]];
    
    NSString *imgStr=[APPDATA isNullOrEmpty:[NSString stringWithFormat:@"%@",[self.dictGroupDetail valueForKey:@"group_image"]]];
    
    if ([imgStr length]>2)
    {
        [self.imgGroupImage  setImageWithURL:[NSURL URLWithString:[self.dictGroupDetail valueForKey:@"group_image"]] placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    }
    else
    {
        [self.imgGroupImage setImage:[UIImage imageNamed:@"no_imgV.png"]];
    }
    self.imgGroupImage .contentMode = UIViewContentModeScaleAspectFill;
    self.imgGroupImage.clipsToBounds=YES;
    [self verifyGroupMember];
    [self getSelectedGroupFeed];
    
    if (self.isMyGroup) {
        [_btnJoinGroup setTitle: @"Delete" forState: UIControlStateNormal];
    }
}

// hide detail (big) image
-(void)handleSingleTapGesture:(UITapGestureRecognizer *)tapGestureRecognizer{
    _photDisplayView.hidden=YES;
    _BigImageView.hidden=YES;
}

- (IBAction)btnCloseTapped:(id)sender {
}

// for get the image string
- (IBAction)imgFeedAction:(id)sender

{
    imagestr= [[APPDATA.group.arrGroupFeed objectAtIndex:[sender tag]]valueForKey:@"post_image"];
    [self loadImage:imagestr];
}

// convert the image size and set in Bigimageview
- (void)loadImage:(NSString *)imgstr {
    [_BigImageView setHidden:NO];
    self.BigImageView.image=[UIImage imageNamed:@""];
    _photDisplayView.hidden=NO;
    imgstr = [NSString stringWithFormat:@"%@/convert?w=1200&h=1200",imgstr];
    _BigImageView.contentMode = UIViewContentModeCenter;
    _BigImageView.contentMode = UIViewContentModeScaleAspectFit;
    NSURL *url = [NSURL URLWithString:imgstr];
    [NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:url] delegate:self];
}


// convert image size and set with progress view methods..
#pragma mark -
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    self.expectedBytes = response.expectedContentLength;
    self.data1 = [NSMutableData dataWithCapacity:self.expectedBytes];
    self.progressView.progress = 0.0;
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [self.data1 appendData:data];
    double receivedBytes = self.data.length;
    self.progressView.progress = receivedBytes / self.expectedBytes;
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    self.BigImageView.image = [UIImage imageWithData:self.data1];
    self.progressView.progress = 1.0;
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    self.progressView.progress = 1.0;
}

#pragma mark verifyGroupMember Method...
- (void) verifyGroupMember
{
    if (APPDATA.isUserLogin == YES)
    {
        [APPDATA showLoader];
        Group *objGroup = [[Group alloc] init];
        objGroup.key = [API_KEY mutableCopy];
        objGroup.profileid = APPDATA.user.profileid;
        objGroup.groupId = [self.dictGroupDetail valueForKey:@"id"];
        [objGroup verifyGroupMember:^(NSDictionary *result, NSString *str, int status)
         {
             if (status == 1)
             {
                 JOINStr=[NSString stringWithFormat:@"%@",[result valueForKey:@"data"]];
                 if ([JOINStr isEqualToString:@"1"])
                 {
                     
                     [_btnJoinGroup setTitle: @"LEAVE" forState: UIControlStateNormal];
                    
                     self.btnJoinGroup.hidden = NO;
                     self.btnNewPost.hidden = NO;
                 }
                 else
                 {
                    [_btnJoinGroup setTitle: @"JOIN" forState: UIControlStateNormal];
                     self.btnJoinGroup.hidden = NO;
                     self.btnNewPost.hidden = YES;
                 }
                 if (self.isMyGroup) {
                      [_btnJoinGroup setTitle: @"Delete" forState: UIControlStateNormal];
                 }
             }
             else
             {
                 [APPDATA hideLoader];
             }
         }];
    }
    else
    {
        self.btnJoinGroup.hidden = NO;
        self.btnNewPost.hidden = YES;
        return;
    }
}

// for going to back comtroller check by condtions
- (IBAction)btnBackPressed:(id)sender
{
    if (self.selectGroupeType == SelectMyGroup)
    {
        MyDashboardViewController *controller =(MyDashboardViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"MyDashboardViewController"];
        [APPDATA turnBackToAnOldViewController:controller];
    }
    else
    {
        GroupViewController *controller =(GroupViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"GroupViewController"];
        [APPDATA turnBackToAnOldViewController:controller];
    }
}

#pragma mark Feed Geeting Method ....
- (void) getSelectedGroupFeed
{
    [APPDATA showLoader];
    Group *objGroup = [[Group alloc] init];
    objGroup.key = [API_KEY mutableCopy];
    //objGroup.profileid = [" mutableCopy];
    objGroup.groupId = [self.dictGroupDetail valueForKey:@"id"];
    objGroup.profileid = APPDATA.user.profileid;
    [objGroup getGroupFeed:^(NSDictionary *result, NSString *str, int status)
     {
         if (status == 1)
         {
             
             NSDictionary *datadic=[result objectForKey:@"data"];
             dicGroup=[datadic objectForKey:@"feed_data"];
             
              if (dicGroup.count == 0)
              {
                  if ([JOINStr isEqualToString:@"1"]) {
                      
                      _lblNoDataFound.text=@"Click the Post button to begin sharing images and posting comments to your group.";
                  }

                else
                {
                   _lblNoDataFound.text=@"Click the join button to begin sharing images and posting comments to your group.";
               }

              }
             
             if (APPDATA.group.arrGroupFeed.count == 0)
             {
                 [self.tableviewFeed reloadData];
                 self.lblNoDataFound.hidden = NO;
                 CGRect frame = self.lblNoDataFound.frame;
                 frame.origin.y = (self.view.superview.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
                 [self.lblNoDataFound setFrame:frame];

             }
             else
             {
                 [self.tableviewFeed reloadData];
                 self.lblNoDataFound.hidden = YES;
             }
               [APPDATA hideLoader];
             
             if (APPDATA.group.isGroupCommentAdd==YES) {
                 
                  [APPDATA ShowAlertWithTitle:@"" Message:SUCCES_COMMENT];
                 APPDATA.group.isGroupCommentAdd=NO;
             }
            else if (APPDATA.group.isGroupLeave==YES) {
                 
                 [APPDATA ShowAlertWithTitle:@"" Message:SUCCESS_LEFT_GROUP];
                 APPDATA.group.isGroupLeave=NO;
             }
           else if (APPDATA.group.isGroupJoin==YES) {
                 
                 [APPDATA ShowAlertWithTitle:@"" Message:SUCCESS_JOIN_GROUP];
                 APPDATA.group.isGroupJoin=NO;
             }
            else if (APPDATA.group.isGroupPost==YES)
             {
              [APPDATA ShowAlertWithTitle:@"" Message:@"Message successfully posted."];
                APPDATA.group.isGroupPost=NO;
             }
         }
         else
         {
             [self.tableviewFeed reloadData];
             self.lblNoDataFound.hidden = NO;
             CGRect frame = self.lblNoDataFound.frame;
             frame.origin.y = (self.view.superview.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
             [self.lblNoDataFound setFrame:frame];

             [APPDATA hideLoader];
         }
     }];
}

#pragma mark TableView Delegate..............
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    return [APPDATA.group.arrGroupFeed count];
}

// set the data like image ,comments ,times and checking the joingroup and delete post actions.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *imagestrChek = [NSString stringWithFormat:@"%@",[[APPDATA.group.arrGroupFeed objectAtIndex:indexPath.row] objectForKey:@"post_image"]] ;
    if ([imagestrChek length]>3)
    {
        static NSString *CellIdentifier = @"FeedCell";
        FeedCell  *cell = (FeedCell *)[self.tableviewFeed dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
          cell.selectionStyle = UITableViewCellSelectionStyleNone;
        NSString * userNameStr;
        if (![[[APPDATA.group.arrGroupFeed objectAtIndex:indexPath.row] objectForKey:@"other_username"] isKindOfClass:[NSNull class]] &&
            [[[APPDATA.group.arrGroupFeed objectAtIndex:indexPath.row] objectForKey:@"other_username"] length] > 3)
        {
            userNameStr=[[NSString stringWithFormat:@"%@",[[APPDATA.group.arrGroupFeed objectAtIndex:indexPath.row] objectForKey:@"other_username"]] uppercaseString];
        }
        else
        {
            userNameStr=[[NSString stringWithFormat:@"%@",[[APPDATA.group.arrGroupFeed objectAtIndex:indexPath.row] objectForKey:@"username"]] uppercaseString];
        }
        cell.txtmeassage.textContainerInset = UIEdgeInsetsMake(10, -5.0, 0.0, 0.0);
        cell.txtmeassage.text=[NSString stringWithFormat:@"%@",[[APPDATA.group.arrGroupFeed objectAtIndex:indexPath.row] objectForKey:@"message"]];
        NSString *getTimeStr=[NSString stringWithFormat:@"%@",[appDelegate LocalToday:[[APPDATA.group.arrGroupFeed objectAtIndex:indexPath.row] objectForKey:@"created_at"]]];
       
        cell.lblUserName.text=userNameStr;
        cell.lblTime.text=getTimeStr;
              // cell.lblUserName.attributedText=AddStr;
        commentsArray=[[APPDATA.group.arrGroupFeed objectAtIndex:indexPath.row] objectForKey:@"comments"];
        cell.lblCommentcount.text=[NSString stringWithFormat:@"( %lu )",(unsigned long)[commentsArray count]];
        
        if ([JOINStr isEqualToString:@"1"])
        {
            cell.btnDeletePostImg.hidden=NO;
        }
        else if ([JOINStr isEqualToString:@"0"])
        {
            cell.btnDeletePostImg.hidden=YES;
        }
        
        cell.btnDeletePostImg.tag=indexPath.row;
        [cell.btnDeletePostImg addTarget:self
                                  action:@selector(btnDeletePressed:) forControlEvents:UIControlEventTouchUpInside];
        
        cell.btnShare.tag=indexPath.row;
       cell.imgbtnFeed.tag=indexPath.row;
        [cell.btnShare addTarget:self
                          action:@selector(shareDispalyMethod:)
                forControlEvents:UIControlEventTouchUpInside];
        cell.btnComment.tag=indexPath.row;
        [cell.btnComment addTarget:self
                            action:@selector(commentDispalyMethod:)
                  forControlEvents:UIControlEventTouchUpInside];
        if (![[[APPDATA.group.arrGroupFeed objectAtIndex:indexPath.row] objectForKey:@"post_image"] isKindOfClass:[NSNull class]] &&
            [[[APPDATA.group.arrGroupFeed objectAtIndex:indexPath.row] objectForKey:@"post_image"] length] > 3) {
            imagestr = [NSString stringWithFormat:@"%@",[[APPDATA.group.arrGroupFeed objectAtIndex:indexPath.row] objectForKey:@"post_image"]] ;
            NSString *fCharStr =[imagestr substringToIndex:22];
            if ([imagestr rangeOfString:@"convert"].location == NSNotFound && [fCharStr isEqualToString:@"https://www.filepicker"])
            {
            }
            else if([fCharStr isEqualToString:@"https://www.filepicker"])
            {
                imagestr = [imagestr substringToIndex:[imagestr length]-20];
            }
            if ([imagestr length]>2)
            {
                [cell.imgFeed setContentMode:UIViewContentModeScaleAspectFit];
                [cell.imgFeed setImageWithURL:[NSURL URLWithString:imagestr] placeholderImage:[UIImage imageNamed:@"no_imgV.png"] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            }
            else
            {
                [cell.imgFeed setImage:[UIImage imageNamed:@"no_imgV.png"]];
            }
            cell.imgFeed.contentMode = UIViewContentModeScaleAspectFill;
            cell.imgFeed.clipsToBounds = YES;
        }else
        {
            [cell.imgFeed setImage:[UIImage imageNamed:@"no_imgV.png"]];
        }
        cell.btnShare.hidden=YES;
        cell.txtComment.tag=indexPath.row;
        cell.txtComment.text=@"";
        [cell.txtComment addCancelDoneOnKeyboardWithTarget:self cancelAction:@selector(cancelAction:) doneAction:@selector(doneAction:)];
        return cell;
    }
    else
    {
        static NSString *CellIdentifier = @"FeedCell2TableViewCell";
        FeedCell2TableViewCell  *cell = (FeedCell2TableViewCell *)[self.tableviewFeed dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
          cell.selectionStyle = UITableViewCellSelectionStyleNone;
        NSString *userNameStr;
        if (![[[APPDATA.group.arrGroupFeed objectAtIndex:indexPath.row] objectForKey:@"other_username"] isKindOfClass:[NSNull class]] &&
            [[[APPDATA.group.arrGroupFeed objectAtIndex:indexPath.row] objectForKey:@"other_username"] length] > 3)
        {
            userNameStr=[[NSString stringWithFormat:@"%@",[[APPDATA.group.arrGroupFeed objectAtIndex:indexPath.row] objectForKey:@"other_username"]] uppercaseString];
        }
        else
        {
            userNameStr=[[NSString stringWithFormat:@"%@",[[APPDATA.group.arrGroupFeed objectAtIndex:indexPath.row] objectForKey:@"username"]] uppercaseString];
        }
        cell.txtmeassage.textContainerInset = UIEdgeInsetsMake(10, -5.0, 0.0, 0.0);

        cell.txtmeassage.text=[NSString stringWithFormat:@"%@",[[APPDATA.group.arrGroupFeed objectAtIndex:indexPath.row] objectForKey:@"message"]];
        NSString *getTimeStr=[NSString stringWithFormat:@"%@",[appDelegate LocalToday:[[APPDATA.group.arrGroupFeed objectAtIndex:indexPath.row] objectForKey:@"created_at"]]];
        
        NSMutableAttributedString *AddStr;
          AddStr=[appDelegate opensSemiBold:[NSString stringWithFormat:@"%@",[[APPDATA isNullOrEmpty:userNameStr] mutableCopy]]:getTimeStr];
               cell.lblUserName.attributedText=AddStr;
        commentsArray=[[APPDATA.group.arrGroupFeed objectAtIndex:indexPath.row] objectForKey:@"comments"];
        cell.lblCommentCount.text=[NSString stringWithFormat:@"( %lu )",(unsigned long)[commentsArray count]];
        
        if ([JOINStr isEqualToString:@"1"])
        {
            cell.btnDeletePost.hidden=NO;
        }
        else if ([JOINStr isEqualToString:@"0"])
        {
            cell.btnDeletePost.hidden=YES;
        }
        else
        {
             cell.btnDeletePost.hidden=YES;
        }
        cell.btnDeletePost.tag=indexPath.row;
        [cell.btnDeletePost addTarget:self
                               action:@selector(btnDeletePressed:) forControlEvents:UIControlEventTouchUpInside];
        

        
        cell.btnShare.tag=indexPath.row;
        [cell.btnShare addTarget:self action:@selector(shareDispalyMethod:)
                forControlEvents:UIControlEventTouchUpInside];
        cell.btnComment.tag=indexPath.row;
        [cell.btnComment addTarget:self action:@selector(commentDispalyMethod:)
                  forControlEvents:UIControlEventTouchUpInside];
        cell.txtComment.tag=indexPath.row;
        cell.txtComment.text=@"";
        [cell.txtComment addCancelDoneOnKeyboardWithTarget:self cancelAction:@selector(cancelAction:) doneAction:@selector(doneAction:)];
        cell.btnShare.hidden=YES;
        return cell;
    }
    return nil;
}

// for hide share view popup
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [_ShareView setHidden:YES];
}

-(void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView
{
    [_ShareView setHidden:YES];
}

#pragma mark Share view hidden...
-(void)hideShareView
{
    [_ShareView setHidden:YES];
}

-(void)tapShareView
{
    [_ShareView setHidden:YES];
}

//set share view frame
#pragma mark Sharing Main Btn action...
- (IBAction)shareDispalyMethod:(UIButton *)sender {
    UIButton *senderButton = (UIButton *)sender;
    NSIndexPath *path = [NSIndexPath indexPathForRow:senderButton.tag inSection:0];
    CGRect rectOfCellInTableView = [_tableviewFeed rectForRowAtIndexPath: path ];
    CGRect rectOfCellInSuperview = [_tableviewFeed convertRect: rectOfCellInTableView toView:self.view.superview];
    content = [[FBSDKShareLinkContent alloc] init];
    content.contentTitle =  [[APPDATA.group.arrGroupFeed objectAtIndex:[sender tag]] valueForKey:@"username"];
    content.contentDescription =  [[APPDATA.group.arrGroupFeed objectAtIndex:[sender tag]] valueForKey:@"message"];
    if (![[[APPDATA.group.arrGroupFeed objectAtIndex:[sender tag]] valueForKey:@"post_image"] isKindOfClass:[NSNull class]] &&
        [[[APPDATA.group.arrGroupFeed objectAtIndex:[sender tag]] valueForKey:@"post_image"] length] > 3) {
        postImageStr = [NSString stringWithFormat:@"%@",[[APPDATA.group.arrGroupFeed objectAtIndex:[sender tag]] valueForKey:@"post_image"]] ;
    }
    else
    {
        postImageStr=@"";
    }
    feed_typeStr=[[APPDATA.group.arrGroupFeed objectAtIndex:[sender tag]] objectForKey:@"feed_type"];
    postMessageStr=[[APPDATA.group.arrGroupFeed objectAtIndex:[sender tag]] valueForKey:@"message"];
    content.imageURL = [NSURL URLWithString:postImageStr];
    if (sender.frame.origin.x < 160)
    {
        if (usertype==0)
        {
            if (sender.tag == APPDATA.group.arrGroupFeed.count-1)
            {
                [_ShareView setFrame:CGRectMake(sender.frame.origin.x, rectOfCellInSuperview.origin.y+40, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                [_ShareView setHidden:NO];
            }
            else
            {
                CGRect frame = _ShareView.frame;
                CGRect frame1 =_imgviewBorder.frame;
                frame.size.height = 86;
                _ShareView.frame = frame;
                frame1.size.height = 86;
                _imgviewBorder.frame = frame1;
                [_btnMyfeed setHidden:YES];
                [_ShareView setFrame:CGRectMake(sender.frame.origin.x, rectOfCellInSuperview.origin.y+136, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                [_ShareView setHidden:NO];
            }
        }
        else
        {
            if (sender.tag == APPDATA.group.arrGroupFeed.count-1)
            {
                if (APPDATA.group.arrGroupFeed.count<=2)
                {
                    [_ShareView setFrame:CGRectMake(sender.frame.origin.x-40, rectOfCellInSuperview.origin.y+126, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                    [_ShareView setHidden:NO];
                }
                else
                {
                    [_ShareView setFrame:CGRectMake(sender.frame.origin.x-40, rectOfCellInSuperview.origin.y+40, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                    [_ShareView setHidden:NO];
                }
                [_ShareView setFrame:CGRectMake(sender.frame.origin.x, rectOfCellInSuperview.origin.y, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                [_ShareView setHidden:NO];
            }
            else
            {
                [_ShareView setFrame:CGRectMake(sender.frame.origin.x, rectOfCellInSuperview.origin.y+126, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                [_ShareView setHidden:NO];
            }
        }
    }
    else
    {
        if (usertype==0)
        {
            if (sender.tag == APPDATA.group.arrGroupFeed.count-1)
            {
                [_ShareView setFrame:CGRectMake(sender.frame.origin.x, rectOfCellInSuperview.origin.y, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                [_ShareView setHidden:NO];
            }
            else
            {
                CGRect frame = _ShareView.frame;
                CGRect frame1 =_imgviewBorder.frame;
                frame.size.height = 86;
                _ShareView.frame = frame;
                frame1.size.height = 86;
                _imgviewBorder.frame = frame1;
                [_btnMyfeed setHidden:YES];
                if (IS_IPHONE6plus)
                {
                    [_ShareView setFrame:CGRectMake(sender.frame.origin.x-40, rectOfCellInSuperview.origin.y+132, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                    [_ShareView setHidden:NO];
                }
                else
                {
                    [_ShareView setFrame:CGRectMake(sender.frame.origin.x-40, rectOfCellInSuperview.origin.y+126, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                    [_ShareView setHidden:NO];
                }
            }
        }
        else
        {
            if (IS_IPHONE6plus) {
                if (sender.tag == APPDATA.group.arrGroupFeed.count-1)
                {
                    if (APPDATA.group.arrGroupFeed.count<=2)
                    {
                        [_ShareView setFrame:CGRectMake(sender.frame.origin.x-10, rectOfCellInSuperview.origin.y+130, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                        [_ShareView setHidden:NO];
                    }
                    else
                    {
                        [_ShareView setFrame:CGRectMake(sender.frame.origin.x-10, rectOfCellInSuperview.origin.y-10, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                        [_ShareView setHidden:NO];                    }
                }
                else
                {
                    [_ShareView setFrame:CGRectMake(sender.frame.origin.x-10, rectOfCellInSuperview.origin.y+130, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                    [_ShareView setHidden:NO];
                }
            }
            else
            {
                if (sender.tag == APPDATA.group.arrGroupFeed.count-1)
                {
                    if (APPDATA.group.arrGroupFeed.count<=2)
                    {
                        [_ShareView setFrame:CGRectMake(sender.frame.origin.x-10, rectOfCellInSuperview.origin.y+130, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                        [_ShareView setHidden:NO];
                    }
                    else
                    {
                        [_ShareView setFrame:CGRectMake(sender.frame.origin.x-10, rectOfCellInSuperview.origin.y-10, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                        [_ShareView setHidden:NO];
                    }
                }
                else{
                    [_ShareView setFrame:CGRectMake(sender.frame.origin.x-10, rectOfCellInSuperview.origin.y+140, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                    [_ShareView setHidden:NO];
                }
            }
        }
    }
    [_ShareView setHidden:NO];
}

#pragma mark MFMailComposeViewController Delegate ...
- (void) mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    switch (result)
    {
        case MFMailComposeResultCancelled:
            //  NSLog(@"Mail cancelled");
            break;
        case MFMailComposeResultSaved:
            //  NSLog(@"Mail saved");
            break;
        case MFMailComposeResultSent:
           
            [APPDATA ShowAlertWithTitle:@"" Message:@"Post successfully share"];
            break;
        case MFMailComposeResultFailed:
            
            break;
        default:
            break;
    }
    [self dismissViewControllerAnimated:YES completion:NULL];
}

#pragma mark Sharing Btn Method....
- (IBAction)btnEmailTapped:(id)sender
{
    [_ShareView setHidden:YES];
    if ([feed_typeStr isEqualToString:@"post"])
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"Are you sure email,this post ?"
                                                       delegate:self cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:@"OK",nil];
        alert.tag=201;
        [alert show];
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"Are you sure email,this post ?" delegate:self cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:@"OK",nil];
        alert.tag=201;
        [alert show];
    }
}

// sharing facebook post methods..
- (IBAction)btnFacebookTapped:(id)sender
{
    [_ShareView setHidden:YES];
    if ([feed_typeStr isEqualToString:@"post"])
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"Are you sure share,this post ?"
                                                       delegate:self
                                              cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:@"OK",nil];
        alert.tag=301;
        [alert show];
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"Are you sure share,this post ?"
                                                       delegate:self
                                              cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:@"OK",nil];
        alert.tag=301;
        [alert show];
    }
}

#pragma mark feed Method...........
- (IBAction)btnMyfeedTapped:(id)sender
{
    [_ShareView setHidden:YES];
    if ([feed_typeStr isEqualToString:@"post"])
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"Are you sure share,this post ?"
                                                       delegate:self
                                              cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:@"OK",nil];
        alert.tag=101;
        [alert show];
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"Are you sure share,this post ?"
                                                       delegate:self cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:@"OK",nil];
        alert.tag=102;
        [alert show];
    }
}

#pragma mark Alertview Delegate
- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    // the user clicked OK
    if (alertView.tag==101)
    {
        //post
        if (buttonIndex == 1)
        {
            [self addmessageMethd];
        }
    }
    if (alertView.tag==102)
    {
        //message
        if (buttonIndex == 1)
        {
            [self addmessageMethd];
        }
    }
    if (alertView.tag==201)
    {
        //post email
        if (buttonIndex == 1)
        {
            [APPDATA showLoader];
            MFMailComposeViewController *mc=[[MFMailComposeViewController alloc]init];
            UIImage *pic = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:postImageStr]]];
            NSData *exportData = UIImageJPEGRepresentation(pic ,1.0);
            [mc addAttachmentData:exportData mimeType:@"image/jpeg" fileName:@"Picture.jpeg"];
            mc.mailComposeDelegate=self;
            [mc setMessageBody:postMessageStr isHTML:NO];
            [self presentViewController:mc animated:YES completion:NULL];
            [_ShareView setHidden:YES];
            [APPDATA hideLoader];
        }
    }
    if (alertView.tag==202)
    {
        //message email
        if (buttonIndex == 1)
        {
            [APPDATA showLoader];
            MFMailComposeViewController *mc=[[MFMailComposeViewController alloc]init];
            mc.mailComposeDelegate=self;
            [mc setMessageBody:postMessageStr isHTML:NO];
            [self presentViewController:mc animated:YES completion:NULL];
            [_ShareView setHidden:YES];
            [APPDATA hideLoader];
        }
    }
    if (alertView.tag==301)
    {
        if (buttonIndex == 1)
        {
            [APPDATA showLoader];
            content = [[FBSDKShareLinkContent alloc] init];
            content.contentURL = [NSURL URLWithString:postImageStr];
            NSURL *imageURL =
            [NSURL URLWithString:postImageStr];
            content.contentDescription=[NSString stringWithFormat:@"User Details ;%@",postMessageStr];
            content.contentTitle=@"Photo Bug";
            content.imageURL=imageURL;
            [FBSDKShareDialog showFromViewController:self withContent:content delegate:nil];
            [APPDATA hideLoader];
        }
    }
    if (alertView.tag==302)
    {
        if (buttonIndex == 1)
        {
            [APPDATA showLoader];
            content = [[FBSDKShareLinkContent alloc] init];
            content.contentURL = [NSURL URLWithString:@"http://www.zaptechsolutions.com"];
            NSURL *imageURL = [NSURL URLWithString:@""];
            content.contentDescription=[NSString stringWithFormat:@"User Details ;%@",postMessageStr];
            content.contentTitle=@"Photo Bug";
            content.imageURL=imageURL;
            [FBSDKShareDialog showFromViewController:self withContent:content delegate:nil];
            [APPDATA hideLoader];
        }
    }
}

#pragma mark Tab button action...
- (IBAction)btnContestPressedTab:(id)sender
{
    [APPDATA btnContestsPressedTab];
}

- (IBAction)btnMyphotosPressedTab:(id)sender
{
    [APPDATA btnMyphotoPressedTab];
}

- (IBAction)btnuploadPressedTab:(id)sender
{
    [APPDATA btnuploadPressedTab];
}


// call API for join and delete group
- (IBAction)btnJoinGroupPressed:(id)sender
{
    if (APPDATA.isUserLogin == YES)
    {
        if (self.isMyGroup) {
            [APPDATA showLoader];
            Group *objGroup = [[Group alloc] init];
            objGroup.profileid = APPDATA.user.profileid;
            objGroup.key = [API_KEY mutableCopy];

            objGroup.groupId = [self.dictGroupDetail valueForKey:@"id"];
            //  objGroup.profileid = APPDATA.user.profileid;
            [objGroup deleteGroup:^(NSDictionary *result, NSString *str, int status)
             {
                 if (status == 1)
                 {
                    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Delete Group" message:DELETE_GROUP delegate:self          cancelButtonTitle:@"Yes"
                              
                                             otherButtonTitles:@"No",nil];
                     [alert show];
                     alert.tag=507;
                    // [APPDATA hideLoader];
                 }
                 else
                 {
                     // NSLog(@"Failed");
                     [APPDATA hideLoader];
                 }
             }];
        }
        else{
        if ([_btnJoinGroup.titleLabel.text isEqualToString:@"JOIN"])
        {
            [APPDATA showLoader];
            Group *objGroup = [[Group alloc] init];
            objGroup.key = [API_KEY mutableCopy];
            objGroup.profileid = APPDATA.user.profileid;
            objGroup.groupId = [self.dictGroupDetail valueForKey:@"id"];
            //  objGroup.profileid = APPDATA.user.profileid;
            [objGroup joinGroup:^(NSDictionary *result, NSString *str, int status)
             {
                 if (status == 1)
                 {
                     APPDATA.group.isGroupJoin=YES;
                     [_btnJoinGroup setTitle: @"LEAVE" forState: UIControlStateNormal];
                     [self verifyGroupMember];
                     dispatch_async (dispatch_get_main_queue(), ^{
                
                         [self getSelectedGroupFeed];
                         [self.tableviewFeed reloadData];
                     });
                     self.btnJoinGroup.hidden = NO;
                     self.btnNewPost.hidden = NO;
                   //  [APPDATA hideLoader];
                  //  [APPDATA ShowAlertWithTitle:@"" Message:SUCCESS_JOIN_GROUP];
                 }
                 else
                 {
                     // NSLog(@"Failed");
                     [APPDATA hideLoader];
                 }
             }];
        }
        else
        {
            [self leaveGroup];
        }
        }
    }
    else
    {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_LOGIN];
        return;
    }
}

#pragma mark Comment Dispaly Method ....
-(IBAction)commentDispalyMethod:(id)sender
{
    // NSLog(@"%@",sender);
    if (APPDATA.isUserLogin==YES)
    {
        NSArray *commentsArray2=[[APPDATA.group.arrGroupFeed objectAtIndex:[sender tag]] objectForKey:@"comments"];
        NSUInteger comInt=commentsArray2.count;
        if (comInt==0)
        {
            [APPDATA ShowAlertWithTitle:@"" Message:@"No comment found."];
        }
        else
        {
            AddCommentViewController *controller =(AddCommentViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"AddCommentViewController"];
            controller.tagStr=[NSString stringWithFormat:@"%ld",(long)[sender tag]];
            controller.otherProfileid=[NSString stringWithFormat:@"%@",strProfileid];
            controller.gropCommentStr=[NSString stringWithFormat:@"%@",[[APPDATA.group.arrGroupFeed objectAtIndex:[sender tag]] objectForKey:@"post_image"]];
            controller.isFromGroup=YES;
            controller.strjoin=JOINStr;
            controller.usertype=usertype;
            controller.groupStrCommentFlag=@"1";
            controller.selectType = SelectGroup;
            [self.parentViewController addChildViewController:controller];
            [self.parentViewController.view addSubview:controller.view];
            [controller didMoveToParentViewController:self];
            [controller.view setFrame:CGRectMake(0,0,controller.view.frame.size.width,self.view.frame.size.height)];
        }
    }
    else
    {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_LOGIN];
    }
}

#pragma Mark Key Board Done Button Action...-------------------------------------------------
-(void)doneAction:(UIBarButtonItem*)barButton
{
    if (APPDATA.isUserLogin==YES)
    {
        NSCharacterSet *set = [NSCharacterSet whitespaceCharacterSet];
        if ([commentStr length]<1)
        {
          if (![JOINStr isEqualToString:@"1"])
            {
                [self.view endEditing:YES];
                [APPDATA ShowAlertWithTitle:@"" Message:ERROR_JOIN_COMMENT];
                
            }
            else
            {
                [self.view endEditing:YES];
                [APPDATA ShowAlertWithTitle:@"" Message:ERROR_COMMENT];
            }
        }
        else if ([[commentStr stringByTrimmingCharactersInSet: set] length] == 0)
        {
            if (![JOINStr isEqualToString:@"1"])
            {
                [self.view endEditing:YES];
                [APPDATA ShowAlertWithTitle:@"" Message:ERROR_JOIN_COMMENT];
                
            }
            else

            [APPDATA ShowAlertWithTitle:@"" Message:ERROR_COMMENT];
        }
        else
        {
            [self addComment];
        }
    }else
    {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_LOGIN];
    }
}

-(void)cancelAction:(UIBarButtonItem*)barButton
{
    //cancelAction
    [self.tableviewFeed reloadData];
}

#pragma Add Comment Method ...
-(void)addComment
{
    [APPDATA showLoader];
    Group *objGroup = [[Group alloc] init];
    objGroup.key = [API_KEY mutableCopy];
    objGroup.profileid = APPDATA.user.profileid;
    objGroup.comment = [commentStr mutableCopy];
    objGroup.postId = [postidStr mutableCopy];
    objGroup.groupId = [strGroupId mutableCopy];
    [objGroup sendCommentInGroup:^(NSDictionary *result, NSString *str, int status) {
        if (status == 1)
        {
            APPDATA.group.isGroupCommentAdd=YES;
            [self getSelectedGroupFeed];
            [self.tableviewFeed reloadData];
            self.lblNoDataFound.hidden = YES;
            commentStr=nil;
            // [APPDATA hideLoader];
             // [APPDATA ShowAlertWithTitle:@"" Message:SUCCES_COMMENT];
        }
        else
        {
            //[APPDATA ShowAlertWithTitle:@"" Message:@"Please enter comments !"];
            self.lblNoDataFound.hidden = NO;
            CGRect frame = self.lblNoDataFound.frame;
            frame.origin.y = (self.view.superview.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
            [self.lblNoDataFound setFrame:frame];

            [self.tableviewFeed reloadData];
            [APPDATA hideLoader];
        }
    }];
}

// for checking group is join or not
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string;
{
    if (APPDATA.isUserLogin == YES)
    {
        if (![JOINStr isEqualToString:@"1"])
        {
            [self.view endEditing:YES];
            [APPDATA ShowAlertWithTitle:@"" Message:ERROR_JOIN_COMMENT];
            
            return NO;
        }
        else
        {
            postidStr=[NSString stringWithFormat:@"%@",[[APPDATA.group.arrGroupFeed objectAtIndex:[textField tag]] objectForKey:@"id"]];
            strGroupId = [NSString stringWithFormat:@"%@",[[APPDATA.group.arrGroupFeed objectAtIndex:[textField tag]] objectForKey:@"group_id"]];
            commentStr = [textField.text stringByReplacingCharactersInRange:range withString:string];
            return YES;
        }
    }
    else
    {
        [self.view endEditing:YES];
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_LOGIN];
        return NO;
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

#pragma mark add Post Image Button Action....
- (IBAction)btnaddimage:(id)sender
{
    addpostimageFlage=@"1";
    [self pickerModalAction:@"lip"];

}
// new post button action..
- (IBAction)btnNewPostTapped:(id)sender
{
    NSString *textStr11= [[NSString stringWithFormat:@"YOU (%@) ",APPDATA.user.username] uppercaseString];
    UIFont *font1 = [UIFont fontWithName:@"OpenSans-Bold" size:10];
    NSDictionary *arialDict = [NSDictionary dictionaryWithObject: font1 forKey:NSFontAttributeName];
    NSMutableAttributedString *aAttrString1 = [[NSMutableAttributedString alloc] initWithString:textStr11 attributes: arialDict];
    UIFont *font2 = [UIFont fontWithName:@"OpenSans" size:9];
    NSDictionary *arialDict2 = [NSDictionary dictionaryWithObject: font2 forKey:NSFontAttributeName];
    NSMutableAttributedString *aAttrString2 = [[NSMutableAttributedString alloc] initWithString:@"NOW" attributes: arialDict2];
    NSUInteger length1 = [aAttrString1 length];
    NSUInteger length2 = [aAttrString2 length];
    [aAttrString1 addAttribute:NSForegroundColorAttributeName value:[UIColor grayColor] range:NSMakeRange(0,length1)];
    [aAttrString2 addAttribute:NSForegroundColorAttributeName value:[UIColor lightGrayColor] range:NSMakeRange(0,length2)];
    [aAttrString1 appendAttributedString:aAttrString2];
    _lbluserName.attributedText=aAttrString1;
    [_viewNewPost setHidden:NO];
    [self.view bringSubviewToFront:_viewNewPost];
    [_addphotoImage setImage:[UIImage imageNamed:@"addphoto-bg"]];
    self.addphotoImage.contentMode=UIViewContentModeScaleAspectFit;
    [[IQKeyboardManager sharedManager] setEnable:YES];
    [[IQKeyboardManager sharedManager] setEnableAutoToolbar:YES];
}

- (IBAction)addPhotoCloseButtonAction:(id)sender
{
    addpostimageFlage=@"";
    postImageurl=@"";
    [[IQKeyboardManager sharedManager] setEnable:NO];
    [[IQKeyboardManager sharedManager] setEnableAutoToolbar:NO];
    _viewNewPost.hidden=YES;
}

#pragma Mark Add Post Action... -------------------------------------------------
- (IBAction)addpostAction:(id)sender
{
    if ([_txtpost.text length]<1 || [_txtpost.text isEqualToString:@"Write a Post"])
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:ERROR_COMMENT delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
    }
    else
    {
        [self addPostMethd];
    }
}

// call API for add post in group
-(void)addPostMethd
{
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        postImageurl=@"";
        APPDATA.group.isGroupPost=YES;
        [self getSelectedGroupFeed];
        [self.view endEditing:YES];
       

        _viewNewPost.hidden=YES;
    };
    void (^failure)(NSError * error) = ^(NSError *error)
    {
    };
    if ([_txtpost.text length]<1 || [_txtpost.text isEqualToString:@"Write a Post"])
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:ERROR_COMMENT
                                                       delegate:self cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
    }
    else
    {
        if ([postImageurl length]<1)
        {
            postImageurl=@"";
        }
        NSDictionary *dict = @{@"key":API_KEY,@"feed_type":@"group_post",@"message":_txtpost.text,@"profile_id":APPDATA.user.profileid,@"group_id":[self.dictGroupDetail valueForKey:@"id"],@"method":API_ADD_POST_GROUP,@"post_image":postImageurl};
        [APICall sendToService:dict success:successed failure:failure];
        _txtpost.text = @"";
    }
}

#pragma mark Add Message method ..
-(void)addmessageMethd
{
    [APPDATA showLoader];
    void (^successed)(id responseObject) = ^(id responseObject)
    {
       
        [APPDATA hideLoader];
         [APPDATA ShowAlertWithTitle:@"" Message:@"MyFeed post successfully share"];
    };
    void (^failure)(NSError * error) = ^(NSError *error)
    {
    };
    //1 log
    NSString  *strDeviceToken=[[NSUserDefaults standardUserDefaults] objectForKey:@"strDeviceToken"];
    if ([strDeviceToken isKindOfClass:[NSNull class]] || strDeviceToken == nil || [strDeviceToken isEqualToString:@""])
    {
        strDeviceToken=nil;
    }
    NSDictionary *dict = @{@"key":API_KEY,@"post_image":postImageStr,@"feed_type":@"post",@"message":content.contentDescription,@"profile_id":appDelegate.profilid_AppStr,@"method":API_ADD_POST};
    [APICall sendToService:dict success:successed failure:failure];
}

#pragma mark - ActionSheet delegates -------------------------------------------------

- (void)pickerModalAction:(NSString *)sender
{
    /*
     * Create the object
     */
    FPPickerController *fpController = [FPPickerController new];
    /*
     * Set the delegate
     */
    fpController.fpdelegate = self;
    /*
     * Apply theme
     */
    fpController.theme = self.theme;
    /*
     * Ask for specific data types. (Optional) Default is all files.
     */
    fpController.dataTypes = @[@"image/*", @"video/*"];
    fpController.selectMultiple = YES;
    /*
     * Specify the maximum number of files (Optional) Default is 0, no limit
     */
    fpController.maxFiles = 10;
    /*
     * Optionally disable the front camera mirroring (experimental)
     */
    fpController.disableFrontCameraLivePreviewMirroring = NO;
    fpController.modalPresentationStyle = UIModalPresentationPopover;
    /*
     * If controller will show in popover set popover size (iPad)
     */
    fpController.preferredContentSize = CGSizeMake(400, 500);
    fpController.typeLogin=sender;
    UIPopoverPresentationController *presentationController = fpController.popoverPresentationController;
    presentationController.permittedArrowDirections = UIPopoverArrowDirectionAny;

    [self presentViewController:fpController
                       animated:YES
                     completion:nil];
}
// file picker saving image actions
- (IBAction)savingAction:(id)sender
{
    if (self.displayedImages.count == 0)
    {
        UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Nothing to Save"
                                                          message:@"Select an image first."
                                                         delegate:nil
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
        [message show];
        return;
    }
    UIImage *firstImage = self.displayedImages[0];
    NSData *imgData = UIImagePNGRepresentation(firstImage);
    /*
     * Create the object
     */
    self.fpSave = [FPSaveController new];
    /*
     * Set the delegate
     */
    self.fpSave.fpdelegate = self;
    /*
     * Apply theme
     */
    self.fpSave.theme = self.theme;
    self.fpSave.data = imgData;
    self.fpSave.dataType = @"image/png";
    self.fpSave.modalPresentationStyle = UIModalPresentationPopover;
    /*
     * If controller will show in popover set popover size (iPad)
     */
    self.fpSave.preferredContentSize = CGSizeMake(400, 500);
    UIPopoverPresentationController *presentationController = self.fpSave.popoverPresentationController;
    presentationController.permittedArrowDirections = UIPopoverArrowDirectionAny;
    presentationController.sourceView = sender;
    presentationController.sourceRect = [sender bounds];
    /*
     * Display it.
     */
    [self presentViewController:self.fpSave
                       animated:YES
                     completion:nil];
}
#pragma mark - FPPickerControllerDelegate Methods
- (void)fpPickerController:(FPPickerController *)pickerController
      didPickMediaWithInfo:(FPMediaInfo *)info
{
}

- (void)fpPickerController:(FPPickerController *)pickerController
didFinishPickingMediaWithInfo:(FPMediaInfo *)info
{
    // NSLog(@"FILE CHOSEN: %@", info);
    if (info)
    {
        if (info.containsImageAtMediaURL)
        {
            if ([addpostimageFlage isEqualToString:@"1"])
            {
                postImageurl=[NSString stringWithFormat:@"%@",info.remoteURL];
                UIImage *image = [UIImage imageWithContentsOfFile:info.mediaURL.path];
                [self.displayedImages addObject:image];
                [self.displayedImages removeAllObjects];
                [self.displayedImages addObject:image];
                self.addphotoImage.image = image;
            }
            else
            {
                profileimageStr=[NSString stringWithFormat:@"%@",info.remoteURL];
                UIImage *image = [UIImage imageWithContentsOfFile:info.mediaURL.path];
                [self.displayedImages addObject:image];
                [self.displayedImages removeAllObjects];
                [self.displayedImages addObject:image];
                // [self profileUpdateMethod];
                self.profilephoto.image = image;
            }
        }
        [self dismissViewControllerAnimated:YES
                                 completion:nil];
    }
    else
    {
        //NSLog(@"Nothing was picked.");
    }
}

- (void)fpPickerController:(FPPickerController *)pickerController
didFinishPickingMultipleMediaWithResults:(NSArray *)results
{
    //NSLog(@"FILES CHOSEN: %@", results);
    if (results.count == 0)
    {
        //NSLog(@"Nothing was picked.");
        return;
    }
    // Making a little carousel effect with the images
    [self.displayedImages removeAllObjects];
    for (FPMediaInfo *info in results)
    {
        // Check if uploaded file is an image to add it to carousel
        if (info.containsImageAtMediaURL)
        {
            if ([addpostimageFlage isEqualToString:@"1"])
            {
                postImageurl=[NSString stringWithFormat:@"%@",info.remoteURL];
                UIImage *image = [UIImage imageWithContentsOfFile:info.mediaURL.path];
                [self.displayedImages addObject:image];
                [self.displayedImages removeAllObjects];
                [self.displayedImages addObject:image];
                self.addphotoImage.image = image;
            }
            else
            {
                profileimageStr=[NSString stringWithFormat:@"%@",info.remoteURL];
                // [self profileUpdateMethod];
                if ([profileimageStr length]>2)
                {
                    [_profilephoto setImageWithURL:[NSURL URLWithString:profileimageStr] placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                }
                else
                {
                    [_profilephoto setImage:[UIImage imageNamed:@"no_imgV.png"]];
                }
             _profilephoto.contentMode = UIViewContentModeScaleAspectFill;
                _profilephoto.clipsToBounds = YES;
            }
        }
    }
}

- (void)fpPickerControllerDidCancel:(FPPickerController *)pickerController
{
    [self dismissViewControllerAnimated:YES
                             completion:nil];
}

#pragma mark - FPSaveControllerDelegate Methods
- (void)fpSaveController:(FPSaveController *)saveController
didFinishSavingMediaWithInfo:(FPMediaInfo *)info
{
    //NSLog(@"FP finished saving with info %@", info);
    [self.fpSave dismissViewControllerAnimated:YES
                                    completion:nil];
}

- (void)fpSaveControllerDidCancel:(FPSaveController *)saveController
{
    //NSLog(@"FP Cancelled Save");
    [self.fpSave dismissViewControllerAnimated:YES
                                    completion:nil];
}

- (void)fpSaveController:(FPSaveController *)saveController
                didError:(NSError *)error
{
    // NSLog(@"FP Error: %@", error);
}

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
   
    addpostimageFlage=@"";
    postImageurl=@"";
    _viewNewPost.hidden=YES;
}

-(void)leaveGroup
{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Leave Group" message:@"Are you sure you want to leave this group?" delegate:self          cancelButtonTitle:@"Yes"
                     
                                         otherButtonTitles:@"No",nil];
    
    [alert show];
    alert.tag=505;
    
    
}

// image zoom and move code

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}


- (void)scrollViewDidZoom:(UIScrollView *)sv
{
    UIView* zoomView = [sv.delegate viewForZoomingInScrollView:sv];
    CGRect zvf = zoomView.frame;
    if(zvf.size.width < sv.bounds.size.width)
    {
        zvf.origin.x = (sv.bounds.size.width - zvf.size.width) / 2.0;
    }
    else
    {
        zvf.origin.x = 0.0;
    }
    if(zvf.size.height < sv.bounds.size.height)
    {
        zvf.origin.y = (sv.bounds.size.height - zvf.size.height) / 2.0;
    }
    else
    {
        zvf.origin.y = 0.0;
    }
    zoomView.frame = zvf;
}



- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    CGPoint centerPoint = CGPointMake(CGRectGetMidX(self.bigimgScrollView.bounds),
                                      CGRectGetMidY(self.bigimgScrollView.bounds));
    [self view:self.BigImageView setCenter:centerPoint];
}
- (void)view:(UIView*)view setCenter:(CGPoint)centerPoint
{
    CGRect vf = view.frame;
    CGPoint co = self.bigimgScrollView.contentOffset;
    
    CGFloat x = centerPoint.x - vf.size.width / 2.0;
    CGFloat y = centerPoint.y - vf.size.height / 2.0;
    
    if(x < 0)
    {
        co.x = -x;
        vf.origin.x = 0.0;
    }
    else
    {
        vf.origin.x = x;
    }
    if(y < 0)
    {
        co.y = -y;
        vf.origin.y = 0.0;
    }
    else
    {
        vf.origin.y = y;
    }
    
    view.frame = vf;
    self.bigimgScrollView.contentOffset = co;
}
- (UIView*)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return  self.BigImageView;
}


//  alert view delete post actions
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (alertView.tag==501) {
   
    if (buttonIndex == 0)
    {
        
        
        if ([strUserId isEqualToString:strAdmin])
            
        {
            
            [self groupAdminDeletePostAction:rowId index:indexToDeletePost];
            
        }
        else if ([strUserId isEqualToString:strOtherId])
        {
            
            [self groupDeletePostAction:rowId index:indexToDeletePost];
        }
        
        else
            
        {
            [self  flagGroupPostAction:rowId index:indexToDeletePost];
            
            
        }
        
    }
    else{
        [APPDATA hideLoader];
        }
    }
    else if (alertView.tag==505)
    {
        if (buttonIndex == 0)
        {
            {
            [APPDATA showLoader];
            void (^successed)(id responseObject) = ^(id responseObject)
            {
                [_btnJoinGroup setTitle: @"JOIN" forState: UIControlStateNormal];
                APPDATA.group.isGroupLeave=YES;
                self.btnNewPost.hidden = YES;
              //  [APPDATA ShowAlertWithTitle:@"" Message:SUCCESS_LEFT_GROUP];
                [self verifyGroupMember];
                dispatch_async (dispatch_get_main_queue(), ^{
                    
                    [self getSelectedGroupFeed];
                });
               // [APPDATA hideLoader];
            };
            void (^failure)(NSError * error) = ^(NSError *error)
            {
                [APPDATA hideLoader];
            };
            NSDictionary *dict = @{@"key":API_KEY,@"method":API_LEAVE_FROM_GROUP,@"profile_id":appDelegate.profilid_AppStr,@"group_id":[self.dictGroupDetail valueForKey:@"id"]};
            [APICall sendToService:dict success:successed failure:failure];
            }
        }
        else{
            [APPDATA hideLoader];
        }
    }
    else if (alertView.tag==507)
    {
        if (buttonIndex == 0)
        {

        [_btnJoinGroup setTitle: @"LEAVE" forState: UIControlStateNormal];
        //                      [self verifyGroupMember];
        self.btnJoinGroup.hidden = NO;
        self.btnNewPost.hidden = NO;
        [APPDATA hideLoader];
         [APPDATA ShowAlertWithTitle:@"" Message:SUCEES_DELETE_GROUP];
        GroupViewController *controller =(GroupViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"GroupViewController"];
        [APPDATA turnBackToAnOldViewController:controller];
        
        }

    }
    else
    {
        [APPDATA hideLoader];
    }
    
}
// get the details for delete API call Required IDs..
-(void)btnDeletePressed:(id)sender

{
    @try{
        
        UIButton *btnTapped = (UIButton*)sender;
        
        NSInteger btnTag = btnTapped.tag;
        
        indexToDeletePost = btnTag;
        
        if (![[[APPDATA.group.arrGroupFeed objectAtIndex:[sender tag]] valueForKey:@"id"] isKindOfClass:[NSNull class]])
            
        {
            
            rowId = [NSString stringWithFormat:@"%@",[[APPDATA.group.arrGroupFeed objectAtIndex:[sender tag]] valueForKey:@"id"]] ;
            
        }else{
            
            rowId=@"";
            
        }
        
        if (![[[APPDATA.group.arrGroupFeed objectAtIndex:[sender tag]] valueForKey:@"group_id"] isKindOfClass:[NSNull class]])
            
        {

          strGroupId = [NSString stringWithFormat:@"%@",[[APPDATA.group.arrGroupFeed objectAtIndex:[sender tag]] valueForKey:@"group_id"]] ;
        }
        
        if (![[[APPDATA.group.arrGroupFeed objectAtIndex:[sender tag]] valueForKey:@"posted_by"] isKindOfClass:[NSNull class]])
            
        {
            
            strAdmin = [NSString stringWithFormat:@"%@",[[APPDATA.group.arrGroupFeed objectAtIndex:[sender tag]] valueForKey:@"posted_by"]] ;
        }

        if (![[[APPDATA.group.arrGroupFeed objectAtIndex:[sender tag]] valueForKey:@"profile_id"] isKindOfClass:[NSNull class]])
            
        {
            
            strOtherId = [NSString stringWithFormat:@"%@",[[APPDATA.group.arrGroupFeed objectAtIndex:[sender tag]] valueForKey:@"profile_id"]] ;
        }
        
        
      strUserId = [NSString stringWithFormat:@"%@",APPDATA.user.profileid];
        
        
        
       if ([strUserId isEqualToString:strAdmin] || [strUserId isEqualToString:strOtherId])
            
        {
            
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Delete Post" message:@"Are you sure you want to delete this post?" delegate:self          cancelButtonTitle:@"Yes"
                                  
                                                 otherButtonTitles:@"No",nil];
            
            [alert show];
            alert.tag=501;

        }
        
        else
            
        {
            
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Flag Post" message:@"Are you sure you want to flag this post?" delegate:self          cancelButtonTitle:@"Yes"
                                  
                                                 otherButtonTitles:@"No",nil];
            
            [alert show];
             alert.tag=501;

        }
        

        return;
        
        
        
    } @catch (NSException *exception) {
        
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
        
    }
    

    
}


// Call API for Admin delete posts methods..
-(void)groupAdminDeletePostAction:(NSString*)strFlag index:(NSInteger)index
{
    @try{
        [APPDATA showLoader];
        Group *objGroupDelete = [[Group alloc] init];
         objGroupDelete.rowID=[NSMutableString stringWithFormat:@"%@",rowId];
        objGroupDelete.key = [API_KEY mutableCopy];
        objGroupDelete.profileid = APPDATA.user.profileid;
        objGroupDelete.groupId = [NSMutableString stringWithFormat:@"%@",strGroupId];
        [objGroupDelete deleteAdminGroupPost:^(NSDictionary *result, NSString *str, int status)
         {
             if (status == 1){

                 dispatch_async (dispatch_get_main_queue(), ^{
                     
                     [self getSelectedGroupFeed];
                 });
                 [self.tableviewFeed reloadData];
                 
                 [APPDATA hideLoader];
 
                 
                 NSLog(@"success");
                 
             }
             
             else {
                    NSLog(@"Failed");
                 
                 [APPDATA hideLoader];
                 
             }
             
         }];
        
        
        
    } @catch (NSException *exception) {
        
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
        
    }
    
}

// Call API for Group delete posts methods..
-(void)groupDeletePostAction:(NSString*)strFlag index:(NSInteger)index
{
    @try{
        [APPDATA showLoader];
        Group *objGroupDelete = [[Group alloc] init];
        objGroupDelete.rowID=[NSMutableString stringWithFormat:@"%@",rowId];
        objGroupDelete.key = [API_KEY mutableCopy];
        objGroupDelete.profileid = APPDATA.user.profileid;
        objGroupDelete.groupId = [NSMutableString stringWithFormat:@"%@",strGroupId];
        [objGroupDelete deleteGroupPost:^(NSDictionary *result, NSString *str, int status)
         {
             if (status == 1){
        
                // [APPDATA ShowAlertWithTitle:@"" Message:@"Post deleted Successfully."];
                 
                 dispatch_async (dispatch_get_main_queue(), ^{
                     
                     [self getSelectedGroupFeed];
                 });
                 
                 [self.tableviewFeed reloadData];
                 
                 [APPDATA hideLoader];
                 
                 
                 NSLog(@"success");
                 
             }
             
             else {
           
                 NSLog(@"Failed");
                 
                 [APPDATA hideLoader];
                 
             }
             
         }];

    } @catch (NSException *exception) {
        
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
        
    }
    
}

// Call API for Flag Group posts methods..
-(void)flagGroupPostAction:(NSString*)strFlag index:(NSInteger)index

{
    @try{
        [APPDATA showLoader];
        Group *objGroupDelete = [[Group alloc] init];
         objGroupDelete.rowID=[NSMutableString stringWithFormat:@"%@",rowId];
        objGroupDelete.key = [API_KEY mutableCopy];
        objGroupDelete.profileid = APPDATA.user.profileid;
        objGroupDelete.groupId = [NSMutableString stringWithFormat:@"%@",strGroupId];
        [objGroupDelete flagGroupPost:^(NSDictionary *result, NSString *str, int status)
         {
             if (status == 1){
                 
                [APPDATA ShowAlertWithTitle:@"" Message:@"Comment Flagged Successfully."];
                 [self.tableviewFeed reloadData];
                 
                 [APPDATA hideLoader];
                 
                
                 NSLog(@"success");
                }
             
             else {
     
                 NSLog(@"Failed");
            
                    NSString *strmsg=[APPDATA isValueNullOrEmpty:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]]];
                    [APPDATA ShowAlertWithTitle:@"" Message:strmsg];

                 [APPDATA hideLoader];
             }
             
         }];

        
    } @catch (NSException *exception) {
        
        
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
        
    }
    
}

@end
