  //
//  AppDelegate.m
//  photobug
//
//   on 11/2/15.
//  Copyright © Photobug. All rights reserved.
//

#import "AppDelegate.h"
#import "LoadingpageViewController.h"
#import "FPPicker.h"
#import "DTTimePeriod.h"
#import "NSDate+DateTools.h"
#import "Group.h"
#import "Users.h"
#import "Constant.h"
#import "ApplicationData.h"
#import "ContestLandingViewController.h"
#import "APICall.h"
#import <Fabric/Fabric.h>
#import <Crashlytics/Crashlytics.h>

@interface AppDelegate (){
    NSInteger currentTab;
    BOOL isOpenFromRemoteNote;
    BOOL isOpenFromRemoteNoteOffer;
    BOOL isOpenFromRemoteNoteFriend;
    BOOL isOpenFromRemoteNotePostDetail;
    BOOL isOpenFromRemoteNoteTicketList;
    NSInteger tabViewControllerCount;
    NSTimer *timer;
}

@end

@implementation AppDelegate
@synthesize pickerInStr,tagNameAppStr,contest_idAppStr,image_idAppStr,captionAppStr,tabDisplayAppFlag,profilid_AppStr,followedby_AppStr,followers_AppStr,tagFormygroup,ArrowNum1,ArrowNum2,ArrowNum3,pageChangeNo,hideFooter;

+ (void)initialize
{
    //! Filepicker.io configuration (required)
    
    //[FPConfig sharedInstance].APIKey = @"AWJoMvu1fTgWi1Xqib2h7z";
    
    [FPConfig sharedInstance].APIKey = @"AZD57D5HSHCXx65ZXfUM8z";
    
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    [Fabric with:@[[Crashlytics class]]];
    
    APPDATA.user = [[Users alloc] init];
    APPDATA.activity = [[MyActivity alloc] init];
    APPDATA.contest = [[Contest alloc] init];
    APPDATA.group = [[Group alloc] init];
    NSSetUncaughtExceptionHandler(&myExceptionHandler);

    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    
    
    
    RightMenuViewController *rightMenu = (RightMenuViewController*)[mainStoryboard
                                                                    instantiateViewControllerWithIdentifier: @"RightMenuViewController"];
    
    
    
    
    LoadingpageViewController *load= (LoadingpageViewController *)[mainStoryboard instantiateViewControllerWithIdentifier:@"LoadingpageViewController"];
    
    
    SlideNavigationController *nav=[[SlideNavigationController alloc] initWithRootViewController:load];
    [nav setNavigationBarHidden:YES];
    
    
    
    if( IS_IPHONE6 ){
        [SlideNavigationController sharedInstance].portraitSlideOffset=220;
        
    }else if(IS_IPHONE6plus)
    {
       [SlideNavigationController sharedInstance].portraitSlideOffset=240;
        
    }else
    {
        [SlideNavigationController sharedInstance].portraitSlideOffset=180;
    }
    
    [SlideNavigationController sharedInstance].rightMenu = rightMenu;
   
    [SlideNavigationController sharedInstance].menuRevealAnimationDuration = .18;
    
    // Creating a custom bar button for right menu
    UIButton *button  = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    
    [button setImage:[UIImage imageNamed:@"gear"] forState:UIControlStateNormal];
    
    [button addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleRightMenu) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
    [SlideNavigationController sharedInstance].rightBarButtonItem = rightBarButtonItem;
    
    
    self.window.rootViewController = nav;
    
      return [[FBSDKApplicationDelegate sharedInstance] application:application
      didFinishLaunchingWithOptions:launchOptions];

}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
   
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings {
    
    [application registerForRemoteNotifications];
    
}





-(void)applicationDidBecomeActive:(UIApplication *)application {
    [FBSDKAppEvents activateApp];
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    
    
    _isUserLoginget= UDGetBool(@"isuserlogin");
    _isUserLoginFBget= UDGetBool(@"isuserFBlogin");
    
    if (_isUserLoginget==YES) {
        APPDATA.user.email=UDGetObject(@"emailid");
        APPDATA.user.password =UDGetObject(@"password");
        APPDATA.user.username =UDGetObject(@"username");
        APPDATA.user.profileid=UDGetObject(@"profile_id");
        APPDATA.user.firstname=UDGetObject(@"firstname");
        APPDATA.user.userid=UDGetObject(@"user_id");
        APPDATA.isUserLogin = _isUserLoginget;
        
        profilid_AppStr=UDGetObject(@"profile_id");
    }
    else if(_isUserLoginFBget==YES)
    {
        APPDATA.user.userid=UDGetObject(@"user_id");
        APPDATA.user.firstname=UDGetObject(@"first_name");
        APPDATA.user.fbid=UDGetObject(@"id");
        APPDATA.user.email=UDGetObject(@"email");
        APPDATA.user.username=UDGetObject(@"username");
        APPDATA.user.lastname=UDGetObject(@"last_name");
        APPDATA.user.socialType=UDGetObject(@"Facebook");
        APPDATA.user.profileid = UDGetObject(@"profile_id");
        
        // APPDATA.isUserLogin=UDGetObject(@"isuserFBlogin");
        APPDATA.isUserLogin = _isUserLoginFBget;
    }
    else
    {
        
    }
    
}
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation {

    if(self.social.socialType==socialTypeFaceBook)
        {
            [APPDATA hideLoader];
            return [[FBSDKApplicationDelegate sharedInstance] application:application openURL:url sourceApplication:sourceApplication
                  annotation:annotation];
    }
    else if (self.social.socialType==socialTypeGoogle)
    {
        return [GPPURLHandler handleURL:url sourceApplication:sourceApplication annotation:annotation];
    }
    else
    {
       return [GPPURLHandler handleURL:url sourceApplication:sourceApplication annotation:annotation];
    }
    
}


- (NSString *)LocalToday:(NSString *)time
{
    NSString *strReturnTime;
    
    NSDate *endDate;
    
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    
    NSDate *dateFromString = [dateFormatter dateFromString:time];
    
    NSDate* serDate = [NSDate dateWithTimeInterval:[[NSTimeZone systemTimeZone] secondsFromGMT] sinceDate:dateFromString];
    
    
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init] ;
    NSString *currentDatestr=[dateFormatter stringFromDate:[NSDate date]];
    
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    
   // serDate = [formatter dateFromString:dateRepresentation];
    
    endDate = [formatter dateFromString:currentDatestr];
    
    NSTimeInterval timeDifference = [endDate timeIntervalSinceDate:serDate];
    
    //double minutes = timeDifference / 60;
    
//    double hours = minutes / 60;
    
    double seconds = timeDifference;
    
//    double days = minutes / 1440;
    


//    strReturnTime =
        NSDate *timeAgoDate = [NSDate dateWithTimeIntervalSinceNow:-seconds];
        strReturnTime=[NSString stringWithFormat:@"%@",timeAgoDate.timeAgoSinceNow];

    
    return strReturnTime;
  
}
void myExceptionHandler(NSException *exception)
{
//    NSArray *stack = [exception callStackReturnAddresses];
   // NSLog(@"Stack trace: %@", stack);
}

-(NSMutableAttributedString *)opensSemiBold:(NSString *)textStr11 :(NSString *)textStr9
{
    
    textStr11=[NSString stringWithFormat:@"%@  ",textStr11];
    
    UIFont *font1 = [UIFont fontWithName:@"OpenSans-Bold" size:13];
    NSDictionary *arialDict = [NSDictionary dictionaryWithObject: font1 forKey:NSFontAttributeName];
    NSMutableAttributedString *aAttrString1 = [[NSMutableAttributedString alloc] initWithString:textStr11 attributes: arialDict];
    
    UIFont *font2 = [UIFont fontWithName:@"OpenSans-SemiBold" size:11];
    
    NSDictionary *arialDict2 = [NSDictionary dictionaryWithObject: font2 forKey:NSFontAttributeName];
    NSMutableAttributedString *aAttrString2 = [[NSMutableAttributedString alloc] initWithString:textStr9 attributes: arialDict2];
    
   
    
    NSUInteger length1 = [aAttrString1 length];
    
    NSUInteger length2 = [aAttrString2 length];
    
    
    
    [aAttrString1 addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithRed:27.0/255.0 green:48.0/255.0 blue:84.0/255.0 alpha:1] range:NSMakeRange(0,length1)];
    
    [aAttrString2 addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithRed:191.0/255.0 green:191.0/255.0 blue:191.0/255.0 alpha:1] range:NSMakeRange(0,length2)];
    
    
    [aAttrString1 appendAttributedString:aAttrString2];
    
    return aAttrString1;
}


@end
