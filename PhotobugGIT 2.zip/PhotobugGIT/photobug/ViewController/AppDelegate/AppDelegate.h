//
//  AppDelegate.h
//  photobug
//
//   on 11/2/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SocialLogin.h"
#import "SlideNavigationController.h"
#import "RightMenuViewController.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate,UIPopoverControllerDelegate>
@property (strong,nonatomic) SocialLogin *social;
@property (strong, nonatomic) UIWindow *window;
@property(strong,nonatomic)NSString *pickerInStr;
@property (nonatomic) BOOL isUserLoginget;
@property (nonatomic) BOOL isUserLoginFBget;
@property (nonatomic) int ArrowNum1;
@property (nonatomic) int ArrowNum2;
@property (nonatomic) int ArrowNum3;
@property (nonatomic) int pageChangeNo;
- (NSString *)LocalToday:(NSString *)time;

@property(nonatomic,retain)NSString *tagNameAppStr;
@property(strong ,nonatomic)NSString *contest_idAppStr;
@property(strong ,nonatomic)NSString *image_idAppStr;
@property(strong ,nonatomic)NSString *captionAppStr;
@property(strong ,nonatomic)NSString *tabDisplayAppFlag;

@property(strong ,nonatomic)NSString *profilid_AppStr;

@property(strong ,nonatomic)NSString *followedby_AppStr;

@property(strong ,nonatomic)NSString *followers_AppStr;
@property(strong,nonatomic)NSString *strDeviceToken;

@property(strong,nonatomic)NSString *tagFormygroup;

@property (nonatomic) BOOL hideFooter;
-(NSMutableAttributedString *)opensSemiBold:(NSString *)textStr11 :(NSString *)textStr9;

@end


