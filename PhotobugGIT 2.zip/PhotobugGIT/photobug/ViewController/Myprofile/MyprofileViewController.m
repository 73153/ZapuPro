//
//  MyprofileViewController.m
//  photobug
//
//   on 11/17/15.
//  Copyright © Photobug. All rights reserved.
//

#import "MyprofileViewController.h"
#import "MyDashboardViewController.h"
#import "Constant.h"
#import "Users.h"
#import "ApplicationData.h"
#import "ScrollViewController.h"
#import "LoginViewController.h"
#import <UIActivityIndicator-for-SDWebImage/UIImageView+UIActivityIndicatorForSDWebImage.h>
#import <QuartzCore/QuartzCore.h>

@interface MyprofileViewController ()
{
    NSArray *recipeImages;
    int pageNo;
    NSMutableArray *imgArray;
    
}
 @end
 
@implementation MyprofileViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [_menuButton addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleRightMenu) forControlEvents:UIControlEventTouchUpInside];
     APPDATA.user.aryMyProfileImage=[[NSMutableArray alloc]init];
        pageNo = 1;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// API call for getting myprofile image when load more profile
- (void)reloadData
{
    if (APPDATA.user.lastPage > pageNo)
    {
        pageNo = pageNo+1;
        [self getMyprofileImage];
    }
}

// Get my Profile API call and set Page is 1
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
     APPDATA.user.aryMyProfileImage = [[NSMutableArray alloc] init];
     pageNo=1;
     [self getMyprofileImage];
}

#pragma marrk Get profile info...
- (void) getMyprofileImage
{
      [APPDATA showLoader];
        Users *objUser = [[Users alloc] init];
       objUser.key = [API_KEY mutableCopy];
       objUser.page = [[NSString stringWithFormat:@"%d",pageNo] mutableCopy];
     [objUser getmyprofileImage:^(NSString *result, int status)
        {
            NSLog(@"%@",result);
            if (status == 1)
            {
                if (APPDATA.user.aryMyProfileImage.count==0)
                {
                     self.lblNoDataFound.hidden = NO;
                    CGRect frame = self.lblNoDataFound.frame;
                    frame.origin.y = (self.view.superview.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
                    [self.lblNoDataFound setFrame:frame];

                }
                else
                {
                    self.lblNoDataFound.hidden = YES;
                    [self.collectionView reloadData];
                }
             }
             else
             {
                 [self getMyprofileImage];
                 [self.collectionView reloadData];
             }
            
            [APPDATA hideLoader];
        }];
}

#pragma mark collectionView delegate method...

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return APPDATA.user.aryMyProfileImage.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"Cell";
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    UIImageView *recipeImageView = (UIImageView *)[cell viewWithTag:100];
    NSDictionary *dictUserData = [APPDATA.user.aryMyProfileImage objectAtIndex:indexPath.row];
    if (![[dictUserData valueForKey:@"profile_photo"] isKindOfClass:[NSNull class]] &&
        [[dictUserData valueForKey:@"profile_photo"] length] > 3) {
        NSString *profile_photoStr=[NSString stringWithFormat:@"%@",[dictUserData valueForKey:@"profile_photo"]];
        NSString *fCharStr =[profile_photoStr substringToIndex:22];
        if ([profile_photoStr rangeOfString:@"convert"].location == NSNotFound && [fCharStr isEqualToString:@"https://www.filepicker"])
        {
        }
        else if([fCharStr isEqualToString:@"https://www.filepicker"])
        {
            profile_photoStr = [profile_photoStr substringToIndex:[profile_photoStr length]-20];
        }
        if ([profile_photoStr length]>2)
        {
             [recipeImageView setImageWithURL:[NSURL URLWithString:profile_photoStr] placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                recipeImageView.contentMode = UIViewContentModeScaleAspectFill;
                recipeImageView.clipsToBounds=YES;
        }
        else
        {
            [recipeImageView setImage:[UIImage imageNamed:@"no_imgV.png"]];
        }
        
    }
    else
    {
        [recipeImageView setImage:[UIImage imageNamed:@"no_imgV.png"]];
    }
    UILabel *userLabel = (UILabel *)[cell viewWithTag:101];
    NSString * nameStr=[dictUserData valueForKey:@"username"];
    NSString *lastChar = [nameStr substringFromIndex:[nameStr length] - 1];
    if ([lastChar isEqualToString:@"."])
    {
         userLabel.text=[nameStr uppercaseString];
    }
    else
    {
         userLabel.text=[[NSString stringWithFormat:@"%@.",nameStr] uppercaseString];
    }
    userLabel.shadowColor = [UIColor blackColor];
    NSLog(@"%@",[dictUserData valueForKey:@"username"]);
    [APPDATA hideLoader];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    MyDashboardViewController *objviewController =(MyDashboardViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"MyDashboardViewController"];
      objviewController.usertype = 1;
      objviewController.otherProfiletag=[NSString stringWithFormat:@"%ld",(long)indexPath.row];
    objviewController.isNewProfile=YES;
      objviewController.dictUserDetail = [APPDATA.user.aryMyProfileImage objectAtIndex:indexPath.row];
        APPDATA.user.strOtherId = [[APPDATA.user.aryMyProfileImage objectAtIndex:indexPath.row] valueForKey:@"profile_id"];
    
    [self.navigationController pushViewController:objviewController animated:YES];
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {

    CGSize cgsize ;
    if( IS_IPHONE6)
    {
        cgsize = CGSizeMake(183, 183);
    }
    else if(IS_IPHONE6plus)
    {
        cgsize = CGSizeMake(202, 202);
    }
    else
    {
         cgsize = CGSizeMake(156, 156);
    }
        return cgsize;
}
#pragma mark Tab button action...
- (IBAction)btnContestPressedTab:(id)sender
{
    [APPDATA btnContestsPressedTab];
}
- (IBAction)btnMyphotosPressedTab:(id)sender
{
    [APPDATA btnMyphotoPressedTab];
}
- (IBAction)btnuploadPressedTab:(id)sender
{
    [APPDATA btnuploadPressedTab];
}

@end
