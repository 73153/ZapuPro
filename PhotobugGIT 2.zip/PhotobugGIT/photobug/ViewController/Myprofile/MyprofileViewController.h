//
//  MyprofileViewController.h
//  photobug
//
//   on 11/17/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RightMenuViewController.h"
#import "ScrollViewController.h"

@interface MyprofileViewController : ScrollViewController

@property (nonatomic,strong) UIRefreshControl *refresh;
@property (strong, nonatomic) IBOutlet UICollectionView *collectionView;
@property (nonatomic) BOOL isMoreData;
@property (nonatomic,strong) IBOutlet UILabel *lblNoDataFound;
@property (strong, nonatomic) IBOutlet UIButton *menuButton;
@property (strong, nonatomic) IBOutlet UIImageView *BigImageView;

- (IBAction)btnContestPressedTab:(id)sender;
- (IBAction)btnMyphotosPressedTab:(id)sender;
- (IBAction)btnuploadPressedTab:(id)sender;

@end

