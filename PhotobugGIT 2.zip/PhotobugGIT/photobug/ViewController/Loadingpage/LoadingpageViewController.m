//
//  LoadingpageViewController.m
//  photobug
//
//   on 11/3/15.
//  Copyright © Photobug. All rights reserved.
//
#import "LoadingpageViewController.h"
#import "ApplicationData.h"
#import "Constant.h"
#import <AVKit/AVKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVFoundation.h>
#import "MyDashboardViewController.h"
#import "LoginViewController.h"


@interface LoadingpageViewController ()
@property (nonatomic, retain) MPMoviePlayerController *moviePlayer;
@end

@implementation LoadingpageViewController
@synthesize imgSplash1,imgSplash2,imgSplash3,imgSplash4,imgSplash5,imgSplash6,imgCenter,imglogo;

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString*thePath=[[NSBundle mainBundle] pathForResource:@"pb_load" ofType:@"mp4"];
    NSURL*theurl=[NSURL fileURLWithPath:thePath];
    self.moviePlayer=[[MPMoviePlayerController alloc] initWithContentURL:theurl];
    [self.moviePlayer.view setFrame:CGRectMake(self.view.frame.origin.x, self.view.frame.origin.y, self.view.frame.size.width, self.view.frame.size.height)];
    [self.moviePlayer prepareToPlay];
    [self.moviePlayer setShouldAutoplay:YES]; // And other options you can look through the documentation.
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryAmbient error:nil];
    [self.moviePlayer setControlStyle:MPMovieControlStyleNone];
    [self.moviePlayer setFullscreen:YES];
    [self.view addSubview:self.moviePlayer.view];
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self performSelector:@selector(navigationToDashboad) withObject:self afterDelay:4.7 ];
    APPDATA.dashboard=[[DashBoard alloc] init];
}

-(void)navigationToDashboad
{
    
    BOOL isUserLoginget= UDGetBool(@"isuserlogin");
    BOOL isUserLoginFBget= UDGetBool(@"isuserFBlogin");
    
    if (isUserLoginget==YES)
    {
        
        APPDATA.user.profileid=UDGetObject(@"profile_id");
        APPDATA.isUserLogin = isUserLoginget;
        appDelegate.profilid_AppStr=[NSString stringWithFormat:@"%@",UDGetObject(@"profile_id")];
        MyDashboardViewController *objDashboardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyDashboardViewController"];
        [APPDATA pushNewViewController:objDashboardViewController];
    }
    else if(isUserLoginFBget==YES)
    {
        
        APPDATA.user.profileid = UDGetObject(@"profile_id");
        appDelegate.profilid_AppStr=[NSString stringWithFormat:@"%@",UDGetObject(@"profile_id")];
        APPDATA.isUserLogin = isUserLoginFBget;
        MyDashboardViewController *objDashboardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyDashboardViewController"];
        [APPDATA pushNewViewController:objDashboardViewController];
        
    }else
    {
            LoginViewController *objLoginViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"LoginViewController"];
            [APPDATA pushNewViewController:objLoginViewController];
             }
}

@end
