//
//  LoadingpageViewController.h
//  photobug
//
//   on 11/3/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DashboardViewController.h"
@interface LoadingpageViewController : UIViewController
@property (nonatomic,strong) IBOutlet UIImageView *imgSplash1;
@property (nonatomic,strong) IBOutlet UIImageView *imgSplash2;
@property (nonatomic,strong) IBOutlet UIImageView *imgSplash3;
@property (nonatomic,strong) IBOutlet UIImageView *imgSplash4;
@property (nonatomic,strong) IBOutlet UIImageView *imgSplash5;
@property (nonatomic,strong) IBOutlet UIImageView *imgSplash6;
@property (nonatomic,strong) IBOutlet UIImageView *imgCenter;
@property (nonatomic,strong) IBOutlet UIImageView *imglogo;

-(void)navigationToDashboad;

@end
