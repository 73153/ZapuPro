//
//  RightMenuViewController.h
//  SlideMenu
//
//  Created by Aryan Gh on 4/26/14.
//  Copyright (c) 2014 Aryan Ghassemi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SlideNavigationController.h>
#import "Users.h"
#import "EditProfileViewController.h"
#import "AppDelegate.h"

@interface RightMenuViewController : UIViewController <SignInSignUp>
@property (nonatomic, strong) IBOutlet UITableView *tableView;
@property (nonatomic, assign) BOOL slideOutAnimationEnabled;
@property (nonatomic,strong) IBOutlet UILabel *lblUserName;
@property (nonatomic,strong) IBOutlet UILabel *lblCredits;
@property (nonatomic,strong) IBOutlet UIButton *btnMyDashboard;
@property (nonatomic,strong) IBOutlet UILabel *lblLifiTimeCredits;
@property (nonatomic,strong) IBOutlet UIButton *btnLoginLogout;
@property (nonatomic,strong) IBOutlet UIButton *btnSignUp;
@property (nonatomic,strong)IBOutlet UIButton *btnInviteOthers;
@property (nonatomic,strong)IBOutlet UIButton *btnGroup;
@property (nonatomic,strong)IBOutlet UIButton *btnProfile;
@property (nonatomic) Users *user;
@property (strong, nonatomic) IBOutlet UIView *CreditView;

- (IBAction)profileButtonActions:(id)sender;
-(IBAction)myDashboardMethod:(id)sender;
-(IBAction)inviteOtherMethod:(id)sender;


@end
