//
//  RightMenuViewController.m
//  SlideMenu
//
//  Created by Aryan Gh on 4/26/14.
//  Copyright (c) 2014 Aryan Ghassemi. All rights reserved.
//
#import "RightMenuViewController.h"
#import "LoginViewController.h"
#import "Constant.h"
#import "ApplicationData.h"
#import "Users.h"
#import "ImportPhotosViewController.h"
#import "RegistrationViewController.h"
#import "MyprofileViewController.h"
#import "MyDashboardViewController.h"
#import "DashboardViewController.h"
#import "inviteothersViewController.h"
#import "HowItWorkViewController.h"
#import "GroupViewController.h"
#import "SlideNavigationController.h"
#import "APICall.h"
#import "CreditHistoryViewController.h"

@implementation RightMenuViewController
{
    NSNumberFormatter *numberFormatter;
    AppDelegate *app;
}
#pragma mark - UIViewController Methods -

- (void)viewDidLoad
{
    [super viewDidLoad];
    EditProfileViewController *objedit=[[EditProfileViewController alloc]init];
    objedit.delegate=self;
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(userLogin)
    name:@"SlideNavigationControllerDidOpen" object:nil];
    app=(AppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (void) userLogin
{
    if (APPDATA.isUserLogin == YES)
    {
        CGRect frame = self.btnInviteOthers.frame;
        frame.origin.y = self.btnGroup.frame.origin.y + self.btnGroup.frame.size.height;
        _CreditView.hidden=NO;
        self.btnInviteOthers.frame = frame;
        self.btnGroup.hidden = NO;
        self.btnInviteOthers.hidden = NO;
        self.btnMyDashboard.hidden = NO;
        [self.btnSignUp setHidden:YES];
        [self getMyActivityData];
        [self.btnLoginLogout setTitle:@"LOG OUT" forState:UIControlStateNormal];
    }
    else
    {
        CGRect frame = self.btnInviteOthers.frame;
        frame.origin.y = self.btnProfile.frame.origin.y + self.btnGroup.frame.size.height;
        self.btnInviteOthers.frame = frame;
        self.btnMyDashboard.hidden = YES;
        self.lblCredits.text = @"0";
        self.lblLifiTimeCredits.text = @"0";
        _CreditView.hidden=YES;
        self.lblUserName.text = @"";
        self.btnGroup.hidden = YES;
        [self.btnSignUp setHidden:NO];
        [self.btnLoginLogout setTitle:@"SIGN IN" forState:UIControlStateNormal];
        [self.btnSignUp setTitle:@"SIGN UP /" forState:UIControlStateNormal];
    }
    if (APPDATA.isUserLogin==YES)
    {
        [self criditMethod];
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void) getMyActivityData
{
    appDelegate.profilid_AppStr = APPDATA.user.profileid ;
    APPDATA.activity.key = [API_KEY mutableCopy];
    numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setGroupingSeparator:@","];
    [numberFormatter setGroupingSize:3];
    [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];

    [APPDATA.activity getMyActivity:^(NSDictionary *result, NSString *str, int status) {
        [APPDATA hideLoader];
        if (status == 1)
        {
            self.lblUserName.text = [APPDATA.activity.username uppercaseString];
        }
        else
        {
        }
    }];
}

#pragma mark - UITableView Delegate & Datasrouce -
- (IBAction)btnSignUpPressed:(id)sender
{
    APPDATA.isUserLogin = NO;
    [[SlideNavigationController sharedInstance] toggleRightMenu];
    RegistrationViewController *viewController =(RegistrationViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"SignUpViewController"];
    [APPDATA pushNewViewController:viewController];
}

- (IBAction)btnSignInPressed:(id)sender
{
    if (APPDATA.isUserLogin == YES)
    {
        [app.social logoutFacebook];
        APPDATA.isUserLogin = NO;
        UDSetBool(APPDATA.isUserLogin, @"isuserlogin");
        UDSetBool(APPDATA.isUserLogin, @"isuserFBlogin");
        UDSetBool(APPDATA.isUserLogin, @"isPublishProfile");
        APPDATA.user = [[Users alloc]init];
        appDelegate.profilid_AppStr =@"";
        
        self.lblUserName.text = @"";
         self.btnMyDashboard.hidden = YES;
        [self.btnLoginLogout setTitle:@"SIGN IN" forState:UIControlStateNormal];
        [self.btnSignUp setHidden:NO];
        [self.btnSignUp setTitle:@"SIGN UP /" forState:UIControlStateNormal];
        [[SlideNavigationController sharedInstance] toggleRightMenu];
        LoginViewController *viewController =(LoginViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"LoginViewController"];
        [APPDATA pushNewViewController:viewController];
    }
    else
    {
        LoginViewController *viewController =(LoginViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"LoginViewController"];
        [APPDATA pushNewViewController:viewController];
    }
}
-(void)Buttonhidden
{  UDSetBool(APPDATA.isUserLogin, @"isuserlogin");
    UDSetBool(APPDATA.isUserLogin, @"isuserFBlogin");
    APPDATA.user = [[Users alloc]init];
    appDelegate.profilid_AppStr =@"";
    UDSetBool(APPDATA.isUserLogin, @"isuserFBlogin");
    APPDATA.user = [[Users alloc]init];
    appDelegate.profilid_AppStr =@"";
    self.btnMyDashboard.hidden = YES;
    [self.btnLoginLogout setTitle:@"SIGN IN" forState:UIControlStateNormal];
    [self.btnSignUp setHidden:NO];
    [self.btnSignUp setTitle:@"SIGN UP /" forState:UIControlStateNormal];
    [[SlideNavigationController sharedInstance] toggleRightMenu];

}
- (IBAction)profileButtonActions:(id)sender
{
    MyprofileViewController *objviewController =(MyprofileViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"MyprofileViewController"];
    [APPDATA pushNewViewController:objviewController];
}

-(IBAction)myDashboardMethod:(id)sender
{
    MyDashboardViewController *objviewController =(MyDashboardViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"MyDashboardViewController"];
    objviewController.usertype = Loginuser;
    objviewController.backStr=@"1";
    [APPDATA pushNewViewController:objviewController];
}

-(IBAction)inviteOtherMethod:(id)sender
{
    if (APPDATA.isUserLogin == YES)
    {
        UIViewController *viewContrlls=[[[SlideNavigationController sharedInstance] viewControllers] lastObject];
        inviteothersViewController *objviewController =(inviteothersViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"inviteothersViewController"];
        [APPDATA pushNewViewController:viewContrlls];
        [viewContrlls addChildViewController:objviewController];
        [viewContrlls.view addSubview:objviewController.view];
    }
    else
    {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_LOGIN];
    }
}

-(IBAction)btnHowItWorkPressed:(id)sender
{
    HowItWorkViewController *objviewController =(HowItWorkViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"HowItWorkViewController"];
    [APPDATA pushNewViewController:objviewController];
}

-(IBAction)btnGroupPressed:(id)sender
{
     if (APPDATA.isUserLogin == NO)
     {
         [APPDATA ShowAlertWithTitle:@"" Message:ERROR_LOGIN];

     }
    else
    {
    GroupViewController *objviewController =(GroupViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"GroupViewController"];
    [APPDATA pushNewViewController:objviewController];
    }
}

- (IBAction)btnCreditHistoryPressed:(id)sender
{

}

-(void)criditMethod
{
    @try {
        void (^successed)(id responseObject) = ^(id responseObject)
        {
            NSDictionary *datadic=[responseObject objectForKey:@"data"];
             numberFormatter = [[NSNumberFormatter alloc] init];
            [numberFormatter setGroupingSeparator:@","];
            [numberFormatter setGroupingSize:3];
            [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
           
            @try {
                if (!(datadic.count==0))
                {
                    _lblCredits.text=[numberFormatter stringFromNumber:[NSNumber numberWithInteger:[[datadic objectForKey:@"total_credits"] integerValue]]];
                    _lblLifiTimeCredits.text=[numberFormatter stringFromNumber:[NSNumber numberWithInteger:[[datadic objectForKey:@"credit_total"] integerValue]]];
                }

            }
            @catch (NSException *exception) {
                
            }
            @finally {
                
                
            }                   };
        void (^failure)(NSError * error) = ^(NSError *error)
        {
            [APPDATA hideLoader];
        };
        NSDictionary  *dict = @{@"key":API_KEY,@"profile_id":APPDATA.user.profileid,@"method":API_PROFILE_TOTAL_CREDITS
                                };
        [APICall sendToService:dict success:successed failure:failure];

    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
   }
@end
