//
//  RegistrationViewController.m
//  photobug
//
//   on 04/11/15.
//  Copyright © Photobug. All rights reserved.
//
#import "RegistrationViewController.h"
#import "Users.h"
#import "ApplicationData.h"
#import "Constant.h"
#import "LoginViewController.h"
#import "ImportPhotosViewController.h"

@interface RegistrationViewController ()
@end

@implementation RegistrationViewController
{
    Users *objSignin;
}
- (void)viewDidLoad
{   // set textfield border style
    [super viewDidLoad];
    [_txtEmailid setBorderStyle:UITextBorderStyleNone];
    [_txtFirstName setBorderStyle:UITextBorderStyleNone];
    [_txtLastName setBorderStyle:UITextBorderStyleNone];
    [_txtPassword setBorderStyle:UITextBorderStyleNone];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]
                                   initWithTarget:self
                                   action:@selector(dismissk)];
    [self.scrollView addGestureRecognizer:tap];
    [self.scrollView setContentSize:CGSizeMake(self.scrollView.frame.size.width, self.view1.frame.size.height)];
    [SlideNavigationController sharedInstance].enableSwipeGesture = YES;
    // open slide menu
    [_menuButton addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleRightMenu) forControlEvents:UIControlEventTouchUpInside];
}
// slide menu is opened
-(BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return YES;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}
// back to previous view
- (IBAction)btnBackPressed:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
// check user detail is valid or not , if user detail is valid then check user email is already exist in database or not if already exist then give it back error otherwise move on unique user name screen.
- (IBAction)btnSignUpPressed:(id)sender
{
    BOOL isValid=true;
    if (![Validations checkMinLength:self.txtFirstName.text withLimit:1 ]) {
        isValid=false;
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_FNAME];
    }
    else if (![Validations checkMaxLength:self.txtFirstName.text withLimit:20])
    {
        isValid=false;
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_MAXLENGTH_USERNAME];

    }
    else if (![Validations checkMinLength:self.txtLastName.text withLimit:1]) {
        isValid=false;
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_LNAME];
    }
    else if(![APPDATA validateEmail:self.txtEmailid.text])
    {
        isValid=false;
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_EMAIL];
    }
    else if([Validations checkMaxLength:self.txtPassword.text withLimit:0 ])
    {
        isValid=false;
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_EMAIL];
    }

    else if(![Validations checkMinLength:self.txtPassword.text withLimit:6 ])
    {
        isValid=false;
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_MINLENGTH_PASSWORD];
    }
    if (isValid == TRUE){
       objSignin=[[Users alloc] init];
        objSignin.emailCheak=[_txtEmailid.text mutableCopy];
        [APPDATA showLoader];
        [objSignin CheakExistingEmail:^(NSString *cheakEmail, int status) {
        [APPDATA hideLoader];
            if (status == 0)
            {
                [APPDATA ShowAlertWithTitle:@"" Message:cheakEmail];
            }
            else
            {
                objSignin.email=[_txtEmailid.text mutableCopy];
                objSignin.firstname=[_txtFirstName.text mutableCopy];
                objSignin.lastname=[_txtLastName.text mutableCopy];
                objSignin.password=[_txtPassword.text mutableCopy];
                UDSetObject(_txtPassword.text, @"PASSWORD");
                
                ImportPhotosViewController *objImportPhotoVC = [self.storyboard instantiateViewControllerWithIdentifier:@"ImportPhotosViewController"];
                objImportPhotoVC.firstName=[_txtFirstName.text mutableCopy];
                objImportPhotoVC.lastName=[_txtLastName.text mutableCopy];
                objImportPhotoVC.email=[_txtEmailid.text mutableCopy];
                objImportPhotoVC.password=[_txtPassword.text mutableCopy];
                objImportPhotoVC.user=objSignin;
                [APPDATA pushNewViewController:objImportPhotoVC];
                [APPDATA showLoader];
      }
        }];
    }
}

- (void) dismissk
{
    [self.txtFirstName resignFirstResponder];
    [self.txtLastName resignFirstResponder];
    [self.txtEmailid resignFirstResponder];
    [self.txtPassword resignFirstResponder];
}
// back to previous screen then clear data
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.txtFirstName.text=@"";
    self.txtLastName.text=@"";
    self.txtPassword.text=@"";
    self.txtEmailid.text=@"";
}

#pragma mark Tab button action...
// Go to Contest List
- (IBAction)btnContestPressedTab:(id)sender
{
    [APPDATA btnContestsPressedTab];
}
// Go to MyPhoto Screen
- (IBAction)btnMyphotosPressedTab:(id)sender
{
    [APPDATA btnMyphotoPressedTab];
}
// Go To Upload Photo Screen 
- (IBAction)btnuploadPressedTab:(id)sender
{
    [APPDATA btnuploadPressedTab];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    NSInteger nextTag = textField.tag + 1;
    // Try to find next responder
    UIResponder* nextResponder = [textField.superview viewWithTag:nextTag];
    if (nextResponder) {
        // Found next responder, so set it.
        [nextResponder becomeFirstResponder];
    } else {
        // Not found, so remove keyboard.
        [textField resignFirstResponder];
    }
    return NO;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if([string isEqualToString:@" "])
    {
        return NO;
    }
    else
    {
        return YES;
    }
}

@end
