//
//  RegistrationViewController.h
//  photobug
//
//   on 04/11/15.
//  Copyright © Photobug. All rights reserved.
//
typedef enum {
    RegistrationTypeFaceook,
    RegistrationTypeInstagram,
    RegistrationTypeEmail
} RegistrationType;
#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "SlideNavigationController.h"
#import "RightMenuViewController.h"

@interface RegistrationViewController : UIViewController<UITextFieldDelegate,SlideNavigationControllerDelegate>

@property (strong,nonatomic) AppDelegate *app;
@property (nonatomic) RegistrationType *regType;
@property (strong, nonatomic) IBOutlet UIButton *menuButton;
@property (nonatomic,strong) IBOutlet UITextField *txtFirstName;
@property (nonatomic,strong) IBOutlet UITextField *txtLastName;
@property (nonatomic,strong) IBOutlet UITextField *txtUserName;
@property (nonatomic,strong) IBOutlet UITextField *txtEmailid;
@property (nonatomic,strong) IBOutlet UITextField *txtPassword;
@property (nonatomic,strong) IBOutlet UIButton *btnSignUp;
@property (weak, nonatomic) IBOutlet UIView *view1;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

- (IBAction)btnSignUpPressed:(id)sender;
- (IBAction)btnContestPressedTab:(id)sender;
- (IBAction)btnMyphotosPressedTab:(id)sender;
- (IBAction)btnuploadPressedTab:(id)sender;



@end
