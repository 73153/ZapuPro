//
//  SignUpViewController.m
//  photobug
//
//   on 04/11/15.
//  Copyright © Photobug. All rights reserved.
//
#import "SignUpViewController.h"
#import "Users.h"
#import "ApplicationData.h"
#import "Constant.h"
#import "SocialLogin.h"
#import "RegistrationViewController.h"
#import "AppDelegate.h"
#import "MyDashboardViewController.h"
#import "APICall.h"

@interface SignUpViewController ()
@end

@implementation SignUpViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.app=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    [self.viewEmail setHidden: YES];
    [SlideNavigationController sharedInstance].enableSwipeGesture = YES;
    //open  side menu
    [_menuButton addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleRightMenu) forControlEvents:UIControlEventTouchUpInside];
}
// side menu
-(BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}
// check social id is exitst is not
- (void)checkSocialId
{
    {
        void (^successed)(id responseObject) = ^(id responseObject)
        {
            NSDictionary *dictResponce = responseObject;
            if ([[dictResponce valueForKey:@"error"]boolValue] == YES) {
                ImportPhotosViewController *objImportPhotoVC = [self.storyboard instantiateViewControllerWithIdentifier:@"ImportPhotosViewController"];
                
                objImportPhotoVC.user = [[Users alloc] init];
                objImportPhotoVC.user.firstname = APPDATA.user.firstname;
                objImportPhotoVC.user.lastname = APPDATA.user.lastname;
                objImportPhotoVC.user.email = APPDATA.user.email;
                objImportPhotoVC.user.password = [@"123456" mutableCopy];
                objImportPhotoVC.user.socialType = APPDATA.user.socialType;
                objImportPhotoVC.user.fbid = APPDATA.user.fbid;
                [APPDATA pushNewViewController:objImportPhotoVC];
            }
            else {
                NSDictionary *user = [responseObject valueForKey:@"data"];
                APPDATA.user.userid = [user valueForKey:@"user_id"];
                APPDATA.user.profileid = [user  valueForKey:@"profile_id"];
                APPDATA.user.username = [user  valueForKey:@"username"];
                APPDATA.user.InviteUrl = [user  valueForKey:@"invite_url"];
                appDelegate.profilid_AppStr=[NSString stringWithFormat:@"%@",[user  valueForKey:@"profile_id"]];
                APPDATA.user.isProfilePublish = [[user valueForKey:@"status"] boolValue];
                UDSetObject( APPDATA.user.fbid, @"id");
                UDSetObject( APPDATA.user.firstname, @"first_name");
                UDSetObject( APPDATA.user.lastname, @"last_name");
                UDSetObject( APPDATA.user.email, @"email");
                UDSetObject( APPDATA.user.username, @"username");
                UDSetObject( APPDATA.user.socialType, @"Facebook");
                UDSetObject(APPDATA.user.userid, @"user_id");
                UDSetObject(APPDATA.user.profileid, @"profile_id");
                UDSetObject(APPDATA.user.username, @"username");
                UDSetObject(APPDATA.user.InviteUrl,@"invite_url");
                UDSetBool( APPDATA.isUserLogin, @"isuserFBlogin");
                UDSetBool(APPDATA.user.isProfilePublish, @"isPublishProfile");
                MyDashboardViewController *objDashboardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyDashboardViewController"];
                [APPDATA pushNewViewController:objDashboardViewController];
                [APPDATA hideLoader];
            }
        };
        void (^failure)(NSError * error) = ^(NSError *error) {
        };
        [APPDATA showLoader];
        //1 log
        Users *objSignin=[[Users alloc] init];
        objSignin.fbid=APPDATA.user.fbid;
        objSignin.email = APPDATA.user.email;
        
        NSDictionary *dict = @{@"key":API_KEY,@"email":objSignin.email,@"method":API_CHECK_SOCIAL_ID};
        [APICall sendToService:dict success:successed failure:failure];
    }
}
// click on sign in button
- (IBAction)btnSignInPressedTab:(id)sender;
{
    SignUpViewController *viewController =(SignUpViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"LoginViewController"];
    [APPDATA pushNewViewController:viewController];
}
// click on back button
- (IBAction)btnBackPressed:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
//click on cancel button
- (IBAction)btnCancel:(id)sender
{
    [self.viewEmail setHidden:YES];
}
// registration with facebook if user is already exist then move to dashboard screen otherwise ask for unique name of the user.
- (IBAction)btnRegistrationWithFacebook:(id)sender
{
    self.app.social=[[SocialLogin alloc] initWithSocialType:socialTypeFaceBook];
    if(self.app.social.socialType == socialTypeFaceBook)
    {
        self.app.social.strFBAppId=[FBAPPID mutableCopy];
        self.app.social.strFBSecretKey=[FBSECRETID mutableCopy];
        [self.app.social logoutFacebook];
        [self.app.social loginWithFacebookWithViewController:self :^(id result, NSError *error, NSString *msg, int status)
         {
             if(status==1)
             {
                 [APPDATA showLoader];
                 APPDATA.user.fbid= [result valueForKey:@"id"];
                 APPDATA.isUserLogin = YES;
                 APPDATA.user.firstname = [result valueForKey:@"first_name"];
                 APPDATA.user.lastname = [result valueForKey:@"last_name"];
                 APPDATA.user.username = [[NSString stringWithFormat:@"%@ %@",[result valueForKey:@"first_name"],[result valueForKey:@"last_name"]] mutableCopy];
                 APPDATA.user.email = [result valueForKey:@"email"];
                 APPDATA.user.socialType = [@"Facebook" mutableCopy];
                 //[self checkSocialId];
                 [self socialMediaRegistration];
                 
             }
             else if (status==-1)
             {
                 [APPDATA ShowAlertWithTitle:@"" Message:msg];
             }
             else{
                 [APPDATA ShowAlertWithTitle:@"" Message:msg];
             }
         }];
    }
}
// call API for registration using facebook and store at out server side
- (void) socialMediaRegistration
{
    Users *objSignin=APPDATA.user;
    objSignin.firstname = APPDATA.user.firstname;
    objSignin.lastname = APPDATA.user.lastname;
    objSignin.email = APPDATA.user.email;
    objSignin.username = APPDATA.user.username;
    objSignin.socialType = APPDATA.user.socialType;
    [objSignin socialRegistrUser:^(NSString *str, int status)
     {
         NSLog(@"%d",status);
         
         if(status==1)
         {
             APPDATA.isUserLogin = YES;
             UDSetObject( APPDATA.user.fbid, @"id");
             UDSetObject( APPDATA.user.firstname, @"first_name");
             UDSetObject( APPDATA.user.lastname, @"last_name");
             UDSetObject( APPDATA.user.email, @"email");
             UDSetObject( APPDATA.user.username, @"username");
             UDSetObject( APPDATA.user.socialType, @"Facebook");
             UDSetBool( APPDATA.isUserLogin, @"isuserFBlogin");
             UDSetObject(APPDATA.user.userid, @"user_id");
             UDSetObject(APPDATA.user.profileid, @"profile_id");
             UDSetObject(APPDATA.user.username, @"username");
             UDSetObject(APPDATA.user.InviteUrl,@"invite_url");
             UDSetBool(APPDATA.user.isProfilePublish, @"isPublishProfile");
             
             
             MyDashboardViewController *objDashboardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyDashboardViewController"];
             [APPDATA pushNewViewController:objDashboardViewController];
             [APPDATA hideLoader];
         }
         else
         {
             [APPDATA ShowAlertWithTitle:@"" Message:str];
             [APPDATA hideLoader];
             return ;
         }
     }];
}
#pragma mark Tab button action...
// go ot contest list
- (IBAction)btnContestPressedTab:(id)sender
{
    [APPDATA btnContestsPressedTab];
}
// go to my photo
- (IBAction)btnMyphotosPressedTab:(id)sender
{
    [APPDATA btnMyphotoPressedTab];
}
// go to upload photo
- (IBAction)btnuploadPressedTab:(id)sender
{
    [APPDATA btnuploadPressedTab];
}

@end
