//
//  SignUpViewController.h
//  photobug
//
//   on 04/11/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "LoginViewController.h"
#import "DashboardViewController.h"
#import "ImportPhotosViewController.h"
@interface SignUpViewController : UIViewController<SlideNavigationControllerDelegate>
@property (strong,nonatomic) AppDelegate *app;
@property (strong, nonatomic) IBOutlet UIButton *menuButton;
@property (nonatomic,strong) IBOutlet UIButton *btnInstagram;
@property (nonatomic,strong) IBOutlet UIButton *btnFacebook;
@property (nonatomic,strong) IBOutlet UIView *viewEmail;
@property (nonatomic,strong) IBOutlet UITextField *txtEmail;

- (IBAction)btnRegistrationWithFacebook:(id)sender;
- (IBAction)btnCancel:(id)sender;
- (IBAction)btnSignInPressedTab:(id)sender;
- (IBAction)btnContestPressedTab:(id)sender;
- (IBAction)btnMyphotosPressedTab:(id)sender;
- (IBAction)btnuploadPressedTab:(id)sender;

@end
