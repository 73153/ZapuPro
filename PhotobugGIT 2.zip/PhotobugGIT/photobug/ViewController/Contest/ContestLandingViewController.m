//
//  ContestLandingViewController.m
//  photobug
//
//   on 12/2/15.
//  Copyright © Photobug. All rights reserved.
//
#import "ContestLandingViewController.h"
#import "ApplicationData.h"
#import <FPPicker/FPPicker.h>
#import "APICall.h"
#import "Constant.h"
#import "SubmitAnEntryViewController.h"
#import "PhotoPickerViewController.h"
#import "VoteImageViewController.h"
#define IMAGE_VIEW_TAG 999
#import <SDWebImage/UIImageView+WebCache.h>
#import "ContestLoadingTableViewCell.h"
#import <UIActivityIndicator-for-SDWebImage/UIImageView+UIActivityIndicatorForSDWebImage.h>
#import "MyDashboardViewController.h"

@interface ContestLandingViewController ()<UITableViewDataSource,UITableViewDelegate,FPSimpleAPIDelegate,FPPickerControllerDelegate,FPSaveControllerDelegate>
{
    NSString *postImageurl;
    NSArray *conArray;

}
@property (nonatomic, strong) FPSaveController *fpSave;
@property (nonatomic, strong) NSMutableArray *items;
@property (nonatomic) NSOperationQueue *downloadQueue;
@property (nonatomic, strong) NSMutableArray<UIImage *> *displayedImages;
@property (nonatomic, strong) FPTheme *theme;

@end

@implementation ContestLandingViewController
@synthesize tagName;

-(void)viewDidLoad
{
    [super viewDidLoad];
    [_btnMenu addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleRightMenu) forControlEvents:UIControlEventTouchUpInside];
    self.downloadQueue = [[NSOperationQueue alloc] init];
    self.downloadQueue.maxConcurrentOperationCount = 2;
    [self getContestList];
    [self.tblContest setBounces:NO];
    [self.tblContest setBouncesZoom:NO];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    if (APPDATA.user.isSubmitTheContest==YES) {
          [self getContestList];
        APPDATA.user.isSubmitTheContest=NO;
    }
    
    if (APPDATA.isUserLogin == YES)
    {
        _btnBack.hidden=NO;
        
    }else
    {
        _btnBack.hidden=YES;
    }

}
//Call method for contest images
- (void) getContestList
{
    [APPDATA showLoader];
    Contest *objContest = [[Contest alloc] init];
    objContest.key = [API_KEY mutableCopy];
    // objContest.page = [[NSString stringWithFormat:@"%d",pageNo] mutableCopy];
    // objContest.profileid = APPDATA.user.profileid;
    objContest.tagid = [[NSString stringWithFormat:@"%@",[self.dictTagDetail valueForKey:@"tag_id"]] mutableCopy];
    [objContest getContestList:^(NSDictionary *result, NSString *str, int status) {
        [APPDATA hideLoader];
        if (status == 1) {
            if (APPDATA.contest.arrContestList.count > 0)
            {
                conArray=[APPDATA.contest.arrContestList copy];
                
                self.lblNoDataFound.hidden = YES;
                [_tblContest reloadData];
            }
            else{
                [self getContestList];
                self.lblNoDataFound.hidden = NO;
                CGRect frame = self.lblNoDataFound.frame;
                frame.origin.y = (self.view.superview.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
                [self.lblNoDataFound setFrame:frame];

            }
        }
        else
        {
            self.lblNoDataFound.hidden = NO;
            CGRect frame = self.lblNoDataFound.frame;
            frame.origin.y = (self.view.superview.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
            [self.lblNoDataFound setFrame:frame];

        }
    }];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)awakeFromNib
{
    
    [super awakeFromNib];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}
#pragma mark -
#pragma mark iCarousel methods
//Tab button of contest perform action to viewcontroller and if user not logged in than display alertview or if logged in than directly display collectionview
-(IBAction)btnEnterContest:(id)sender
{
    if (APPDATA.isUserLogin == YES)
    {
        if (UDGetBool(@"isPublishProfile") == YES) {
        PhotoPickerViewController *objviewController =(PhotoPickerViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"PhotoPickerViewController"];
        appDelegate.tabDisplayAppFlag=@"1";
        appDelegate.contest_idAppStr=[NSString stringWithFormat:@"%@",[[APPDATA.contest.arrContestList objectAtIndex:[sender tag]-100]valueForKey:@"contest_id"]];
        appDelegate.image_idAppStr=[NSString stringWithFormat:@"%@",[[APPDATA.contest.arrContestList objectAtIndex:[sender tag]-100]valueForKey:@"image_id"]];
        appDelegate.captionAppStr=[NSString stringWithFormat:@"%@",[[APPDATA.contest.arrContestList objectAtIndex:[sender tag]-100]valueForKey:@"caption"]];
        
        objviewController.FlagForContest=YES;
        [APPDATA pushNewViewController:objviewController];
        }
        else{
            [APPDATA ShowAlertWithTitle:@"" Message:ERROR_UNPUBLISH_ENTER_CONTEST];
        }
        
    }
    else
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_LOGIN];
}
- (void)simpleAPI:(FPSimpleAPI *)simpleAPI requiresAuthenticationForSource:(FPSource *)source
{
    FPAuthController *authController = [[FPAuthController alloc] initWithSource:source];
    if (authController)
    {
        [self.navigationController pushViewController:authController animated:YES];
    }
    else
    {
        // NSLog(@"FPAuthController could not be instantiated.");
    }
}
//filepicker delegate method for displasy images
- (FPTheme *)theme
{
    if (!_theme)
    {
        FPTheme *theme = [FPTheme new];
        CGFloat hue = 0.5616;
        theme.navigationBarStyle = UIBarStyleBlack;
        theme.navigationBarBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.12 alpha:1.0];
        theme.navigationBarTintColor = [UIColor colorWithHue:hue saturation:0.1 brightness:0.98 alpha:1.0];
        theme.headerFooterViewTintColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.28 alpha:1.0];
        theme.headerFooterViewTextColor = [UIColor whiteColor];
        theme.tableViewBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.49 alpha:1.0];
        theme.tableViewSeparatorColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.38 alpha:1.0];
        theme.tableViewCellBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.49 alpha:1.0];
        theme.tableViewCellTextColor = [UIColor colorWithHue:hue saturation:0.1 brightness:1.0 alpha:1.0];
        theme.tableViewCellTintColor = [UIColor colorWithHue:hue saturation:0.3 brightness:0.7 alpha:1.0];
        theme.tableViewCellSelectedBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.18 alpha:1.0];
        theme.tableViewCellSelectedTextColor = [UIColor whiteColor];
        theme.uploadButtonBackgroundColor = [UIColor blackColor];
        theme.uploadButtonHappyTextColor = [UIColor yellowColor];
        theme.uploadButtonAngryTextColor = [UIColor redColor];
        _theme = theme;
    }
    return _theme;
}

- (NSMutableArray <UIImage *>*)displayedImages
{
    if (!_displayedImages)
    {
        _displayedImages = [NSMutableArray array];
    }
    return _displayedImages;
}
#pragma mark - Actions -------------------------------------------------
- (void)pickerModalAction:(NSString *)sender
{
    /*
     * Create the object
     */
    FPPickerController *fpController = [FPPickerController new];
    /*
     * Set the delegate
     */
    fpController.fpdelegate = self;
    /*
     * Apply theme
     */
    fpController.theme = self.theme;
    /*
     * Ask for specific data types. (Optional) Default is all files.
     */
    fpController.dataTypes = @[@"image/*", @"video/*"];
    /*
     * Select and order the sources (Optional) Default is all sources
     */
    //fpController.sourceNames = @[FPSourceImagesearch];
    /*
     * Enable multselect (Optional) Default is single select
     */
    fpController.selectMultiple = YES;
    /*
     * Specify the maximum number of files (Optional) Default is 0, no limit
     */
    fpController.maxFiles = 10;
    /*
     * Optionally disable the front camera mirroring (experimental)
     */
    fpController.disableFrontCameraLivePreviewMirroring = NO;
    fpController.modalPresentationStyle = UIModalPresentationPopover;
    /*
     * If controller will show in popover set popover size (iPad)
     */
    fpController.preferredContentSize = CGSizeMake(400, 500);
    fpController.typeLogin=sender;
    UIPopoverPresentationController *presentationController = fpController.popoverPresentationController;
    presentationController.permittedArrowDirections = UIPopoverArrowDirectionAny;
    
    [self presentViewController:fpController
                       animated:NO
                     completion:nil];
}

- (IBAction)btnAlbumAction:(id)sender
{
    
}

- (IBAction)savingAction:(id)sender
{
    if (self.displayedImages.count == 0)
    {
        UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Nothing to Save"
                                                          message:@"Select an image first."
                                                         delegate:nil
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
        [message show];
        return;
    }
    UIImage *firstImage = self.displayedImages[0];
    NSData *imgData = UIImagePNGRepresentation(firstImage);
    /*
     * Create the object
     */
    self.fpSave = [FPSaveController new];
    /*
     * Set the delegate
     */
    self.fpSave.fpdelegate = self;
    /*
     * Apply theme
     */
    self.fpSave.theme = self.theme;
    /*
     * Select and order the sources (Optional) Default is all sources
     */
    //self.fpSave.sourceNames = @[FPSourceDropbox, FPSourceFacebook, FPSourceBox];
    /*
     * Set the data and data type to be saved.
     */
    self.fpSave.data = imgData;
    self.fpSave.dataType = @"image/png";
    self.fpSave.modalPresentationStyle = UIModalPresentationPopover;
    /*
     * If controller will show in popover set popover size (iPad)
     */
    self.fpSave.preferredContentSize = CGSizeMake(400, 500);
    UIPopoverPresentationController *presentationController = self.fpSave.popoverPresentationController;
    presentationController.permittedArrowDirections = UIPopoverArrowDirectionAny;
    presentationController.sourceView = sender;
    presentationController.sourceRect = [sender bounds];
    /*
     * Display it.
     */
    [self presentViewController:self.fpSave
                       animated:YES
                     completion:nil];
}

#pragma mark - FPPickerControllerDelegate Methods
- (void)fpPickerController:(FPPickerController *)pickerController
      didPickMediaWithInfo:(FPMediaInfo *)info
{
}
- (void)fpPickerController:(FPPickerController *)pickerController
didFinishPickingMediaWithInfo:(FPMediaInfo *)info
{
    // NSLog(@"FILE CHOSEN: %@", info);
    if (info)
    {
        if (info.containsImageAtMediaURL)
        {
            postImageurl=[NSString stringWithFormat:@"%@",info.remoteURL];
            [self.displayedImages removeAllObjects];
            if ([appDelegate.tabDisplayAppFlag isEqualToString:@"1"])
            {
                SubmitAnEntryViewController *viewController =(SubmitAnEntryViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"SubmitAnEntryViewController"];
                viewController.postImageurl=postImageurl;
                [APPDATA pushNewViewControllerFromContest:viewController];
                appDelegate.tabDisplayAppFlag=@"";
            }else{
                [self imgUpload:postImageurl];
            }
        }
        [self dismissViewControllerAnimated:YES
                                 completion:nil];
    }
    else
    {
    }
}
- (void)fpPickerController:(FPPickerController *)pickerController
didFinishPickingMultipleMediaWithResults:(NSArray *)results
{
    // NSLog(@"FILES CHOSEN: %@", results);
    if (results.count == 0)
    {
        //NSLog(@"Nothing was picked.");
        return;
    }
    // Making a little carousel effect with the images
    [self.displayedImages removeAllObjects];
    for (FPMediaInfo *info in results)
    {
        // Check if uploaded file is an image to add it to carousel
        if (info.containsImageAtMediaURL)
        {
            postImageurl=[NSString stringWithFormat:@"%@",info.remoteURL];
            [self.displayedImages removeAllObjects];
            if ([appDelegate.tabDisplayAppFlag isEqualToString:@"1"])
            {
                [self imgUpload:postImageurl];
                
            }else{
                SubmitAnEntryViewController *viewController =(SubmitAnEntryViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"SubmitAnEntryViewController"];
                viewController.postImageurl=postImageurl;
                [APPDATA pushNewViewController:viewController];
                appDelegate.tabDisplayAppFlag=@"";
                
            }
        }
    }
    [self dismissViewControllerAnimated:YES
                             completion:nil];
}

- (void)fpPickerControllerDidCancel:(FPPickerController *)pickerController
{
    // NSLog(@"FP Cancelled Open");
    [self dismissViewControllerAnimated:YES
                             completion:nil];
}

#pragma mark - FPSaveControllerDelegate Methods
- (void)fpSaveController:(FPSaveController *)saveController
didFinishSavingMediaWithInfo:(FPMediaInfo *)info
{
    //NSLog(@"FP finished saving with info %@", info);
    [self.fpSave dismissViewControllerAnimated:YES
                                    completion:nil];
}

- (void)fpSaveControllerDidCancel:(FPSaveController *)saveController
{
    //NSLog(@"FP Cancelled Save");
    [self.fpSave dismissViewControllerAnimated:YES
                                    completion:nil];
}

- (void)fpSaveController:(FPSaveController *)saveController
                didError:(NSError *)error
{
    //NSLog(@"FP Error: %@", error);
}
-(void)imgUpload:(NSString *)imgStr
{
    [APPDATA showLoader];
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        int check=[[responseObject objectForKey:@"error"]intValue];
        if (check==1)
        {
            [APPDATA ShowAlertWithTitle:@"" Message:ERROR_IMAGE_UPLOAD];
            [self pickerModalAction:@"lip"];
        }else{
            [APPDATA ShowAlertWithTitle:@"" Message:IMAGE_UPLOAD];
        }
        [APPDATA hideLoader];
    };
    void (^failure)(NSError * error) = ^(NSError *error) {
        [APPDATA hideLoader];
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_IMAGE_UPLOAD];
        [self pickerModalAction:@"lip"];
    };
    NSDictionary *dict = @{@"key":API_KEY,@"method":API_PROFILE_ALBUM_ADD_UPDATE,@"profile_id":appDelegate.profilid_AppStr,@"url":imgStr
                           };
    [APICall sendToService:dict success:successed failure:failure];
}
//button for voting action
- (IBAction)btnBeginVotingPressed :(UIButton *)sender {
    if (APPDATA.isUserLogin == YES)
    {
        VoteImageViewController *objviewController =(VoteImageViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"VoteImageViewController"];
        objviewController.strIndex = [NSString stringWithFormat:@"%ld",(long)sender.tag];
        NSInteger tagValue=[sender tag]-900;
        appDelegate.contest_idAppStr=[NSString stringWithFormat:@"%@",[[conArray objectAtIndex:tagValue]valueForKey:@"contest_id"]];
        [APPDATA pushNewViewController:objviewController];
    }
else
    {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_LOGIN];
    }
}
//On the tapgesture on tab on vote&Earn button
- (void)handleTap:(UITapGestureRecognizer *)tapRecognizer
{
    UIView *view = tapRecognizer.view;
    if (APPDATA.isUserLogin == YES)
    {
        VoteImageViewController *objviewController =(VoteImageViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"VoteImageViewController"];
        objviewController.strIndex = [NSString stringWithFormat:@"%ld",(long)view.tag];
        
         NSInteger tagValue=(long)view.tag-900;
        
         objviewController.contestidStrN=[[APPDATA.contest.arrContestList objectAtIndex:tagValue] objectForKey:@"contest_id"];
        [APPDATA pushNewViewController:objviewController];
    }else
    {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_LOGIN];
    }
}
//On tap on back button and perform action to pop
- (IBAction)btnBackACtion:(id)sender {
    APPDATA.contest.arrContestList = nil;
    MyDashboardViewController *objDashboardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyDashboardViewController"];
    [APPDATA turnBackToAnOldViewController:objDashboardViewController];
}
//on tap on contest button
- (IBAction)btnContestPressedTab:(id)sender {
    [APPDATA btnContestsPressedTab];
}
//on tap on myphotos
- (IBAction)btnMyphotosPressedTab:(id)sender {
    [APPDATA btnMyphotoPressedTab];
}
//on event of upload button if user logged in than it disply file picker library and if not logged in than display error massage
- (IBAction)btnuploadPressedTab:(id)sender {
    if (APPDATA.isUserLogin==YES)
    {
         [self pickerModalAction:@"lip"];
    }else{
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_LOGIN];
    }

   
}

#pragma mark TableView Delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 200;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex {
    return APPDATA.contest.arrContestList.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"ContestLoadingTableViewCell";
    ContestLoadingTableViewCell  *cell = (ContestLoadingTableViewCell *)[self.tblContest dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    cell.lblCountEnters.hidden = YES;
    NSString *imagestr;
    imagestr = [NSString stringWithFormat:@"%@",[[APPDATA.contest.arrContestList objectAtIndex:indexPath.row] objectForKey:@"default_contestphoto_url"]] ;
    
    
    if ([imagestr length]>3)
    {
        NSString *fCharStr =[imagestr substringToIndex:22];
        if ([imagestr rangeOfString:@"convert"].location == NSNotFound && [fCharStr isEqualToString:@"https://www.filepicker"])
        {
            imagestr = [NSString stringWithFormat:@"%@/convert?w=400&h=400",imagestr] ;
        }else if([fCharStr isEqualToString:@"https://www.filepicker"])
        {
            imagestr = [imagestr substringToIndex:[imagestr length]-20];
            imagestr = [NSString stringWithFormat:@"%@/convert?w=400&h=400",imagestr] ;
        }
     
        NSLog(@"Con-->%@",imagestr);
     
        __block UIActivityIndicatorView *activityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        activityIndicator.center = cell.imgContest.center;
        activityIndicator.hidesWhenStopped = YES;

        [cell.imgContest sd_setImageWithURL:[NSURL URLWithString:imagestr] placeholderImage:nil options:SDWebImageCacheMemoryOnly progress:^(NSInteger receivedSize, NSInteger expectedSize) {
            
        } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
            if (error) {
                [activityIndicator removeFromSuperview];
                cell.lblCountEnters.hidden = NO;
                [cell.imgContest setImage:[UIImage imageNamed:@"no_imgV.png"]];
            }
            else {
                cell.lblCountEnters.hidden = NO;
                [activityIndicator removeFromSuperview];
            }
        }];
        if (cell.imgContest.image == nil) {
        [cell.imgContest addSubview:activityIndicator];
        [activityIndicator startAnimating];
        }
        
        
    }else{
        [cell.imgContest setImage:[UIImage imageNamed:@"no_imgV.png"]];
    }
    cell.imgContest.contentMode = UIViewContentModeScaleAspectFill;
    cell.lblContestLabel.text = [NSString stringWithFormat:@"%@",[[APPDATA.contest.arrContestList objectAtIndex:indexPath.row] objectForKey:@"name"]] ;
   
    
    cell.btnCridit.titleLabel.numberOfLines = 3;
    NSString *sponsor_nameStr= [[NSString stringWithFormat:@"%@",[[APPDATA.contest.arrContestList objectAtIndex:indexPath.row] objectForKey:@"sponsor_name"]]uppercaseString];
    NSString *totalentriesStr= [NSString stringWithFormat:@"%@",[[APPDATA.contest.arrContestList objectAtIndex:indexPath.row] objectForKey:@"totalentries"]];
    NSString *strdate = [NSString stringWithFormat:@"%@",[[APPDATA.contest.arrContestList objectAtIndex:indexPath.row] objectForKey:@"ends"]];
    NSDate *endday = [APPDATA getFormattedDateFrom:strdate formatter:dt_time_formatter1];
    NSString *str = [APPDATA getFormattedStringFrom:endday formatter:dt_formatter];
    NSDate *endd = [APPDATA getFormattedDateFrom:str formatter:dt_formatter];
    
    NSString *strDate = [APPDATA getFormattedStringFrom:[NSDate date] formatter:dt_formatter];
    NSDate *date = [APPDATA getFormattedDateFrom:strDate formatter:dt_formatter];
    if (endday == nil) {
         totalentriesStr=[NSString stringWithFormat:@"%@  ENTRIES | SPONSORED BY ",totalentriesStr];
    }
    else {
    NSInteger day = [APPDATA daysBetweenDate:date andDate:endd];
    
    totalentriesStr=[NSString stringWithFormat:@"%@  ENTRIES | %@ DAYS REMAINING | SPONSORED BY ",totalentriesStr,[NSString stringWithFormat:@"%ld",(long)day]];
    }
    NSMutableAttributedString *AddStr=[self opensSemiBold:totalentriesStr :sponsor_nameStr];
    
    cell.btnEnterContest.tag=indexPath.row+100;
    [cell.btnEnterContest addTarget:self action:@selector(btnEnterContest:) forControlEvents:UIControlEventTouchUpInside];
    [cell.btnCridit addTarget:self action:@selector(btnBeginVotingPressed:) forControlEvents:UIControlEventTouchUpInside];
    cell.btnCridit.tag=indexPath.row+900;
    cell.lblCountEnters.attributedText=AddStr;
    cell.lblCountEnters.font = [UIFont systemFontOfSize:9];
    return cell;
}
//call method when display font in bold
-(NSMutableAttributedString *)opensSemiBold:(NSString *)textStr11 :(NSString *)textStr9
{
    textStr11=[NSString stringWithFormat:@"%@  ",textStr11];
    UIFont *font1 = [UIFont fontWithName:@"OpenSans" size:13];
    NSDictionary *arialDict = [NSDictionary dictionaryWithObject: font1 forKey:NSFontAttributeName];
    NSMutableAttributedString *aAttrString1 = [[NSMutableAttributedString alloc] initWithString:textStr11 attributes: arialDict];
    UIFont *font2 = [UIFont fontWithName:@"OpenSans" size:13];
    NSDictionary *arialDict2 = [NSDictionary dictionaryWithObject: font2 forKey:NSFontAttributeName];
    NSMutableAttributedString *aAttrString2 = [[NSMutableAttributedString alloc] initWithString:textStr9 attributes: arialDict2];
    NSUInteger length1 = [aAttrString1 length];
    NSUInteger length2 = [aAttrString2 length];
    [aAttrString1 addAttribute:NSForegroundColorAttributeName value:[UIColor whiteColor] range:NSMakeRange(0,length1)];
    [aAttrString2 addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(0,length2)];
    [aAttrString1 appendAttributedString:aAttrString2];
    return aAttrString1;
}

@end
