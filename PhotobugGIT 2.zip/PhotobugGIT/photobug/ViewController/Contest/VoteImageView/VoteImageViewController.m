//
//  VoteImageViewController.m
//  photobug
//
//   on 08/12/15.
//  Copyright © Photobug. All rights reserved.
//
#import "VoteImageViewController.h"
#import "AsyncImageView.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "Contest.h"
#define IMAGE_VIEW_TAG 999
#import "APICall.h"
#import "ContestCategoryViewController.h"
#import "CreditHistoryViewController.h"
#define IS_IPHONE4 (([[UIScreen mainScreen] bounds].size.height-480)?NO:YES)
#define IS_IPHONE5 (([[UIScreen mainScreen] bounds].size.height-568)?NO:YES)
#define IS_IPHONE6 (([[UIScreen mainScreen] bounds].size.height-667)?NO:YES)
#define IS_IPHONE6plus (([[UIScreen mainScreen] bounds].size.height-736)?NO:YES)
#import <UIActivityIndicator-for-SDWebImage/UIImageView+UIActivityIndicatorForSDWebImage.h>
#import "ActiveMoreViewController.h"

@implementation VoteImageViewController
{
    UIImageView *tempImg;
     UIImageView *tempImg1;
    NSMutableArray *aryDashBoardImage;
    CGRect imgTopViewFrame;
    CGRect imgBottomViewFrame;
    UIImageView *cellImg;
    NSMutableArray *ImgArray;
    NSString *contestId;
    UIPanGestureRecognizer *tap;
    CGRect frameBottonImage;
    CGRect frameTopImage;
    CGRect framebtnBottom;
    BOOL ImgSetFlage;
    int current_pageStr;
    
}
@synthesize contestidStrN;

- (void)viewDidLoad
{
    [super viewDidLoad];
    tempImg=[UIImageView new];
     tempImg1=[UIImageView new];
    tempImg.frame=self.imageBt.frame;
     tempImg1.frame=self.imageTp.frame;
    ImgSetFlage=YES;
    ImgArray=[[NSMutableArray alloc]init];
    aryDashBoardImage = [[NSMutableArray alloc]init];
    [_menuButton addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleRightMenu) forControlEvents:UIControlEventTouchUpInside];
    [self.viewSelected1 setHidden:NO];
    [self.viewSelected2 setHidden:YES];
    [self.viewSelected3 setHidden:YES];
    [self.view setUserInteractionEnabled:YES];
    
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(oneTapTop:)];
    [imgTop addGestureRecognizer:singleTap];
    
    UITapGestureRecognizer *singleTap1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(oneTap1Bottom:)];
    [imgBottom addGestureRecognizer:singleTap1];
    
    UITapGestureRecognizer *bgTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(bgTapAction:)];
    [_bigView addGestureRecognizer:bgTap];
    [self.view bringSubviewToFront:_viewHeader];
    _viewHeader.layer.zPosition = 10000;
    self.imageTp.userInteractionEnabled = YES;
    self.bigimgScrollView.delegate = self;
    self.bigimgScrollView.delegate = self;
    self.bigimgScrollView.maximumZoomScale = 100.0;
    _btnbottomlike.hidden=YES;
    _btntoplikeL.hidden=YES;
     _btnbgLike.enabled = YES;

}
// Method for display slider rightmenu
-(BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return YES;
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.imageTp.userInteractionEnabled = YES;
    self.bigimgScrollView.delegate = self;
    self.bigimgScrollView.maximumZoomScale = 100.0;
    self.imageBt.userInteractionEnabled = YES;
    current_pageStr=1;
    [self getContestImageListMainMethod];
    [scrllView setContentSize:CGSizeMake(self.view.frame.size.width, 3000)];
     [self.view bringSubviewToFront:_viewHeader];
}


// Call when get ContestListImages and that method fetch code, Currentpage index, next page url
-(void)getContestImageListMainMethod
{
    [APPDATA showLoader];
    void (^successed)(id responseObject) = ^(id responseObject)
    {    [APPDATA hideLoader];
        _btnliketops.enabled = YES;
        _btnbottomlike.enabled = YES;
        _btnbgLike.enabled = YES;
        
        NSString *codeStr=[NSString stringWithFormat:@"%@",[responseObject valueForKey:@"code"]];
        
        if ([codeStr isEqualToString:@"100"])
        {
            
        NSArray *arrTagData = [[responseObject valueForKey:@"data"]objectForKey:@"data"];
        
        NSString *curr=[NSString stringWithFormat:@"%@",[[responseObject valueForKey:@"data"]objectForKey:@"current_page"]];
        
         NSString *NextPageUrl=[NSString stringWithFormat:@"%@",[[responseObject valueForKey:@"data"]objectForKey:@"next_page_url"]];
        
        current_pageStr=[curr intValue];
       
        if ([NextPageUrl isEqualToString:@"<null>"])
        {
            self.viewDiveder.hidden=YES;
            self.lblNoDataFound.hidden = NO;
            _tapHistoryview.hidden=YES;
            _imgTop2.hidden=YES;
            imgTop.hidden=YES;
            imgBottom.hidden=YES;
            _btnbottomlike.hidden=YES;
            _btntoplikeL.hidden=YES;
            _btnliketops.hidden=YES;
            [self.view bringSubviewToFront:_viewHeader];
        }else if (arrTagData.count > 1)
        {
            if (arrTagData.count >1)
            {
                aryDashBoardImage = [[NSMutableArray alloc]init];
                ImgArray=[[NSMutableArray alloc]init];
                self.viewDiveder.hidden=NO;
                self.lblNoDataFound.hidden = YES;
                for (int i=0; i<arrTagData.count; i++)
                {
                    [aryDashBoardImage addObject:[[arrTagData objectAtIndex:i] objectForKey:@"url"]];
                    [ImgArray addObject:[[arrTagData objectAtIndex:i] objectForKey:@"image_id"]];
                }
                
                _imgTop2.hidden=YES;
                imgTop.hidden=NO;
                imgBottom.hidden=NO;
                _btntoplikeL.hidden=YES;
                [self setScrollView];
                [self.view bringSubviewToFront:_viewHeader];
                [self.view bringSubviewToFront:self.btnliketops];
                }
            else{
                self.viewDiveder.hidden=YES;
                self.lblNoDataFound.hidden = NO;
                _tapHistoryview.hidden=YES;
                _imgTop2.hidden=YES;
                imgTop.hidden=YES;
                imgBottom.hidden=YES;
                _btnbottomlike.hidden=YES;
                _btntoplikeL.hidden=YES;
                _btnliketops.hidden=YES;
                [self.view bringSubviewToFront:_viewHeader];
            }
        }
        else
        {
            [APPDATA hideLoader];
            self.viewDiveder.hidden=YES;
            self.lblNoDataFound.hidden  =NO;
            _imgTop2.hidden=YES;
            imgTop.hidden=YES;
            imgBottom.hidden=YES;
            _btnbottomlike.hidden=YES;
            _btntoplikeL.hidden=YES;
            _btnliketops.hidden=YES;
            _tapHistoryview.hidden=YES;
            [self.view bringSubviewToFront:_viewHeader];
        }
    }
        else
        {
            [APPDATA hideLoader];
            self.viewDiveder.hidden=YES;
            self.lblNoDataFound.hidden  =NO;
            _imgTop2.hidden=YES;
            imgTop.hidden=YES;
            imgBottom.hidden=YES;
            _btnbottomlike.hidden=YES;
            _btntoplikeL.hidden=YES;
            _btnliketops.hidden=YES;
            _tapHistoryview.hidden=YES;
            [self.view bringSubviewToFront:_viewHeader];
        }
    };
    void (^failure)(NSError * error) = ^(NSError *error) {
        [APPDATA hideLoader];
         self.viewDiveder.hidden=YES;
        self.lblNoDataFound.hidden  =NO;
        _imgTop2.hidden=YES;
        imgTop.hidden=YES;
        imgBottom.hidden=YES;
        _btnbottomlike.hidden=YES;
        _btntoplikeL.hidden=YES;
        _btnliketops.hidden=YES;
          _tapHistoryview.hidden=YES;
        [self.view bringSubviewToFront:_viewHeader];
    };
    
    Contest *contest = [[Contest alloc] init];
    contest.profileid = APPDATA.user.profileid;
    contest.contestid = [[APPDATA.contest.arrContestList objectAtIndex:[_strIndex intValue]-900] valueForKey:@"contest_id"];
    
    
    NSDictionary *dict = @{@"key":API_KEY,@"contest_id":appDelegate.contest_idAppStr,@"profile_id":appDelegate.profilid_AppStr,@"method":API_CONTEST_IMAGE_LIST,@"page":@"1"
                           };
    [APICall sendToService:dict success:successed failure:failure];
    
    SDImageCache *imageCache = [SDImageCache sharedImageCache];
    [imageCache clearMemory];
    [imageCache clearDisk];
}

//Call when set scrollview For images and changes images for voting
-(void)setScrollView
{
    [APPDATA showLoader];
    _bigView.hidden=YES;
    if (ImgSetFlage==YES)
    {
       frameTopImage=CGRectMake(imgTop.origin.x, imgTop.origin.y, self.view.bounds.size.width, self.view.bounds.size.height/2+50);
        frameBottonImage=CGRectMake(imgBottom.origin.x, imgBottom.origin.y, self.view.bounds.size.width, imgBottom.size.height);
        ImgSetFlage=NO;
    }
    imgTop.userInteractionEnabled = YES;
    _imgTop2.userInteractionEnabled = YES;
    if (aryDashBoardImage.count>1)
    {
        NSString *profileimageStr;
        if (aryDashBoardImage.count>1)
        {
            profileimageStr=[NSString stringWithFormat:@"%@",[aryDashBoardImage objectAtIndex:1]];
        }
        profileimageStr = [NSString stringWithFormat:@"%@",profileimageStr] ;
        //chnage
        NSString *fCharStr =[profileimageStr substringToIndex:22];
        if ([profileimageStr rangeOfString:@"convert"].location == NSNotFound && [fCharStr isEqualToString:@"https://www.filepicker"])
        {
        }else if([fCharStr isEqualToString:@"https://www.filepicker"])
        {
            profileimageStr = [profileimageStr substringToIndex:[profileimageStr length]-20];
        }
        if ([profileimageStr length]>2)
        {
            imgTop.contentMode=UIViewContentModeScaleAspectFill;
            imgTop.clipsToBounds=YES;
            [imgTop sd_setImageWithURL:[NSURL URLWithString:profileimageStr] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                [APPDATA hideLoader];
                _btnliketops.hidden=NO;
            }];
         
            _btnliketops.hidden=YES;
            [_imageTp setImageWithURL:[NSURL URLWithString:profileimageStr] placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        }else{
            [_imageTp setImage:[UIImage imageNamed:@""]];
            [imgTop setImage:[UIImage imageNamed:@""]];
        }
        [self.view addSubview:imgTop];
        imgBottom.frame=CGRectMake(imgBottom.origin.x, imgBottom.origin.y, self.view.bounds.size.width, imgBottom.size.height);
        imgBottom.userInteractionEnabled = YES;
        NSString *profileimageStr1=[NSString stringWithFormat:@"%@",[aryDashBoardImage objectAtIndex:0]];
        profileimageStr1 = [NSString stringWithFormat:@"%@",profileimageStr1] ;
        NSString *fCharStr1 =[profileimageStr1 substringToIndex:22];
        if ([profileimageStr1 rangeOfString:@"convert"].location == NSNotFound && [fCharStr1 isEqualToString:@"https://www.filepicker"])
        {
        }else if([fCharStr1 isEqualToString:@"https://www.filepicker"])
        {
           
        }
        if ([profileimageStr1 length]>2)
        {
            imgBottom.contentMode=UIViewContentModeScaleAspectFill;
            imgBottom.clipsToBounds=YES;
            [imgBottom sd_setImageWithURL:[NSURL URLWithString:profileimageStr1] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                [APPDATA hideLoader];
                _btnbottomlike.hidden=NO;
            }];
            _btnbottomlike.hidden=YES;
            [_imageBt setImageWithURL:[NSURL URLWithString:profileimageStr1] placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        }else{
            [imgBottom setImage:[UIImage imageNamed:@""]];
            [_imageBt setImage:[UIImage imageNamed:@""]];
        }
        [self.view sendSubviewToBack: imgBottom];
        [self.view bringSubviewToFront:_tapHistoryview];
    }
    else
    {
         self.viewDiveder.hidden=YES;
        self.lblNoDataFound.hidden = NO;
        _imgTop2.hidden=YES;
        imgTop.hidden=YES;
        imgBottom.hidden=YES;
        _btnbottomlike.hidden=YES;
        _btntoplikeL.hidden=YES;
        _btnliketops.hidden=YES;
          _tapHistoryview.hidden=YES;
        [self.view bringSubviewToFront:_viewHeader];

    }
}
float contentPos = 0.0;

//Call when reset scrollview set a new frame for images.
-(void)resetScrollFrame:(int)imageTag
{
    int nPostContetn = 0;
    for (int i=(int)aryDashBoardImage.count-1; i>=0; i--) {
      UIBezierPath *aPath;
        aPath = [UIBezierPath bezierPath];
        UIImageView *imgContent = (UIImageView *)[scrllView viewWithTag:i+1000];
        UIButton *btnTag = (UIButton *)[scrllView viewWithTag:i];
        if (imageTag>0) {
            btnTag.center = self.view.center;
            btnTag.frame = CGRectMake(imgContent.frame.size.width/2-30, imgContent.frame.size.height/2-30, 60, 60);
            [imgContent setFrame:CGRectMake(0, i*self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height)];
           [aPath moveToPoint:CGPointMake(0.0, 0.0)];
          [aPath addLineToPoint:CGPointMake(self.view.bounds.size.width, 0.0)];
           [aPath addLineToPoint:CGPointMake(self.view.bounds.size.width,self.view.frame.size.height)];
            [aPath addLineToPoint:CGPointMake(0.0, self.view.frame.size.height)];
        }
        else
        {
            [imgContent setFrame:CGRectMake(0, i*self.view.frame.size.height/2, self.view.frame.size.width, self.view.frame.size.height/2+50)];
            btnTag.frame = CGRectMake(imgContent.frame.size.width/2-30, imgContent.frame.size.height/2-30, 60, 60);
           [aPath moveToPoint:CGPointMake(0.0, 0.0)];
          [aPath addLineToPoint:CGPointMake(self.view.bounds.size.width, 0.0)];
           [aPath addLineToPoint:CGPointMake(self.view.bounds.size.width,self.view.frame.size.height/2)];
           [aPath addLineToPoint:CGPointMake(0.0, self.view.frame.size.height/2+50)];
        }
        if (i+1000 == imageTag) {
            contentPos =imgContent.frame.origin.y;
        }
      [self setClippingPath:aPath:imgContent];
    [aPath closePath];
        nPostContetn +=imgContent.frame.size.height;
    }
    scrllView.frame = CGRectMake(0,0,self.view.frame.size.width,self.view.frame.size.height);
    scrllView.contentSize = CGSizeMake(self.view.frame.size.width,nPostContetn-600);
    [scrllView setContentOffset:CGPointMake(0,contentPos)];
}
// Call when scroll image for voting and reset scroll view.
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (isFullImage) {
        isFullImage = FALSE;
        [self resetScrollFrame:-1];
    }
}
// Call when u swipe image for voting and that reset scroll view
- (void)frameTapGesture:(UITapGestureRecognizer*)sender
{
    UIGestureRecognizer *recognizer = (UIGestureRecognizer*)sender;
    UIImageView *imageView = (UIImageView *)recognizer.view;
    [self resetScrollFrame:(int)imageView.tag];
    [UIView animateWithDuration:0.2 delay:0 options:UIViewAnimationOptionBeginFromCurrentState animations:^{
        isFullImage = TRUE;
    } completion:nil];
}

- (void) setClippingPath:(UIBezierPath *)clippingPath : (UIImageView *)imgView
{
    if (![[imgView layer] mask])
        [[imgView layer] setMask:[CAShapeLayer layer]];
    [(CAShapeLayer*) [[imgView layer] mask] setPath:[clippingPath CGPath]];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return [[UIScreen mainScreen]bounds].size.height/2;
}
- (nullable UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView *view=[[UIView alloc]initWithFrame:CGRectZero];
    return view;
}

-(IBAction)likeMethod:(id)sender{
    if (APPDATA.isUserLogin == YES) {
        UIButton *btn=(UIButton *)sender;
        [btn setImage:[UIImage imageNamed:@"like"] forState:UIControlStateNormal];
        [self likeMainMethod:(int)[sender tag]];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Tab button action...
//Call when u tab on contest
- (IBAction)btnContestPressed:(id)sender {
    [APPDATA btnContestsPressedTab];
}
//Call when u tab on Myphotos
- (IBAction)btnMyphotosPressed:(id)sender {
    [APPDATA btnMyphotoPressedTab];
}
//Call when u tab on Upload
- (IBAction)btnuploadPressed:(id)sender {
    [APPDATA btnuploadPressedTab];
}
//Call when u press back button
- (IBAction)btnBackAction:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)likeBtnAction:(id)sender {
}
//Call when tap on top image
- (void) oneTapTop: (id)sender
{
    _bigView.hidden=NO;
    _imageBt.hidden=YES;
    _imageTp.hidden=NO;
    _btnbgLike.tag=0;
    _btnliketops.hidden=YES;
    _btnbottomlike.hidden=YES;
    _imageTp.frame=tempImg.frame;
   self.bigimgScrollView.contentSize = self.imageTp.size;

    [self.view bringSubviewToFront:_viewHeader];
     [[self view] bringSubviewToFront:_bigView];
     [[self view] bringSubviewToFront:_btnbgLike];
}
// Call when tap on bottom image
- (void) oneTap1Bottom: (id)sender
{
    _bigView.hidden=NO;
    _imageBt.hidden=NO;
    _imageTp.hidden=YES;
    _btnbgLike.tag=1;
    _btnbottomlike.hidden=YES;
    _btnliketops.hidden=YES;
    _imageBt.frame=tempImg1.frame;
    self.bigimgScrollView.contentSize = self.imageBt.size;

    [self.view bringSubviewToFront:_viewHeader];
     [[self view] bringSubviewToFront:_bigView];
     [[self view] bringSubviewToFront:_btnbgLike];
}

- (void) bgTapAction: (id)sender
{
    _btnbottomlike.hidden=NO;
    _btnliketops.hidden=NO;
    _imageTp.frame=tempImg.frame;
    _imageTp.frame=tempImg1.frame;
    _bigView.hidden=YES;
}

-(IBAction)handlePanGesture:(UIPanGestureRecognizer *)sender
{
    UIGestureRecognizerState state = [sender state];
    if (state == UIGestureRecognizerStateBegan || state == UIGestureRecognizerStateChanged)
    {
        _imgTop2.hidden=NO;
        [[self view] sendSubviewToBack:_btnbottomlike];
        int hightIncr=0;
        if(IS_IPHONE5)
        {
            hightIncr=465;
        }else if (IS_IPHONE6)
        {
            hightIncr=579;
        }else if(IS_IPHONE6plus)
        {
            hightIncr=642;
        }else{
            hightIncr=395;
        }
        CGRect frame = _imgTop2.frame;
        if (frame.size.height<hightIncr)
        {
            CGRect frame = imgTop.frame;
            frame.size.height += 5.0f;
            imgTop.frame = frame;
            [sender setTranslation:CGPointZero inView:imgTop];
            CGRect frameT = _imgTop2.frame;
            frameT.size.height += 5.0f;
            _imgTop2.frame = frameT;
            [sender setTranslation:CGPointZero inView:_imgTop2];
        }else{
            _btntoplikeL.hidden=NO;
            _btntoplikeL.frame=CGRectMake(self.view.frame.size.width/2- _btntoplikeL.frame.size.width/2, self.view.frame.size.height/2, _btntoplikeL.frame.size.width, _btntoplikeL.frame.size.height);
            [[self view] bringSubviewToFront:_tapHistoryview];
        }
    }
    else{
        int hightIncr=0;
        if(IS_IPHONE5)
        {
            hightIncr=465;
        }else if (IS_IPHONE6)
        {
            hightIncr=579;
        }else if(IS_IPHONE6plus)
        {
            hightIncr=642;
        }else{
            hightIncr=395;
        }
        CGRect frame = _imgTop2.frame;
        if (frame.size.height<hightIncr-1) {
            [UIView animateWithDuration:.4f animations:^{
                CGRect frame = _imgTop2.frame;
                frame.size.height = frameTopImage.size.height;
                _imgTop2.frame = frame;
                _imgTop2.hidden=YES;
                [self performSelector:@selector(setimage) withObject:self afterDelay:1.0 ];
            }];
        }
    }
}

-(IBAction)handlePanGesture2:(UIPanGestureRecognizer *)sender
{
    UIGestureRecognizerState state = [sender state];
    int hightIncr = 0;
    if(IS_IPHONE5)
    {
        hightIncr=520;
    }else if (IS_IPHONE6)
    {
        hightIncr=520;
    }else if(IS_IPHONE6plus)
    {
        hightIncr=684;
    }else{
        hightIncr=445;
    }
    if (state == UIGestureRecognizerStateBegan || state == UIGestureRecognizerStateChanged)
    {
        CGRect framem = imgTop.frame;
        framem.size.height = 250; // This is just for the width, but you can change the origin and the height as well.
        imgTop.frame = framem;
        [self.view bringSubviewToFront:_viewHeader];
        [[self view] bringSubviewToFront:imgBottom];
        [[self view] bringSubviewToFront:_tapview];
        [[self view] bringSubviewToFront:_btnbottomlike];
        CGRect frame = imgBottom.frame;
        if (frame.size.height<hightIncr){
            CGRect frame = imgBottom.frame;
            frame.size.height += 5.0f;
            frame.origin.y-=5.0f;
            imgBottom.frame = frame;
            [sender setTranslation:CGPointZero inView:imgBottom];
        }else{
            _btnbottomlike.frame=CGRectMake(self.view.frame.size.width/2- _btnbottomlike.frame.size.width/2, self.view.frame.size.height/2, _btnbottomlike.frame.size.width, _btnbottomlike.frame.size.height);
            [[self view] bringSubviewToFront:_tapHistoryview];
        }
    }
    else{
        CGRect frame = imgBottom.frame;
        if (frame.size.height<hightIncr-1) {
            [UIView animateWithDuration:.4f animations:^{
                CGRect frame = imgBottom.frame;
                frame.size.height = frameBottonImage.size.height;
                frame.origin.y=frameBottonImage.origin.y;
                imgBottom.frame = frame;
                [self performSelector:@selector(setimage) withObject:self afterDelay:1.0 ];
            }];
        }
    }
}

- (IBAction)btnToplikeLAction:(id)sender {
    if (APPDATA.isUserLogin == YES) {
        UIButton *btn=(UIButton *)sender;
        [btn setImage:[UIImage imageNamed:@"like"] forState:UIControlStateNormal];
        [self likeMainMethod:(int)[sender tag]];
    }
    else
    {[APPDATA ShowAlertWithTitle:@"" Message:ERROR_LOGIN];
    }
}

- (IBAction)btnToplikeSAction:(id)sender {
    if (APPDATA.isUserLogin == YES) {
       if (UDGetBool(@"isPublishProfile") == YES) {
        UIButton *btn=(UIButton *)sender;
        [btn setImage:[UIImage imageNamed:@"like"] forState:UIControlStateNormal];
        [self likeMainMethod:(int)[sender tag]];
        }
        else{
            [APPDATA ShowAlertWithTitle:@"" Message:ERROR_UNPUBLISH_VOTING];
        }
        }
    
    else{
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_LOGIN];
    }
}

- (IBAction)btnbottomlikeAction:(id)sender {
    if (APPDATA.isUserLogin == YES) {
        if (UDGetBool(@"isPublishProfile") == YES) {
        UIButton *btn=(UIButton *)sender;
        [btn setImage:[UIImage imageNamed:@"like"] forState:UIControlStateNormal];
        [self likeMainMethod:(int)[sender tag]];
    }
    else {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_UNPUBLISH_VOTING];
    }
    }
    else{
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_LOGIN];
    }
}

- (IBAction)btnCreditHistoryTapped:(id)sender {
    if (APPDATA.isUserLogin == YES) {
        
        
        APPDATA.activity.isCreditTransaction=YES;
        APPDATA.activity.isPastTransaction=NO;
        ActiveMoreViewController *objActiveMoreViewController =(ActiveMoreViewController *) [[UIStoryboard storyboardWithName:@"Main"bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"ActiveMoreViewController"];
        
        [self addChildViewController:objActiveMoreViewController];
        [self.view addSubview:objActiveMoreViewController.view];
        
        
    }
    else [APPDATA ShowAlertWithTitle:@"" Message:ERROR_LOGIN];
}
//Call when set image for voting
-(void)setimage{
    [self setScrollView];
}
//Call when like any images
-(void)likeMainMethod:(int)senderTag
{
    [self performSelector:@selector(setimage) withObject:self afterDelay:1.0 ];
    
    
    NSString * imgStr=[ImgArray objectAtIndex:senderTag];
    NSString * imgStr2;
    if (ImgArray.count==1)
    {
        imgStr2=[NSString stringWithFormat:@"%@",imgStr];
    }else{
        if (senderTag ==0)
        {
            imgStr2=[ImgArray objectAtIndex:senderTag+1];
        }else{
            imgStr2=[ImgArray objectAtIndex:senderTag-1];
        }
    }
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        int check=[[responseObject objectForKey:@"error"]intValue];
        [APPDATA hideLoader];
        if (check==1)
        {
            NSString *pointstr=@"LUCKY YOU +200";
            _lblLuckuou.text=pointstr;
            _tapHistoryview.hidden=NO;
            _btnliketops.enabled = NO;
            _btnbottomlike.enabled = NO;
            _btnbgLike.enabled = NO;
            [self performSelector:@selector(getContestImageListMainMethod) withObject:self afterDelay:5.0 ];
            current_pageStr= current_pageStr+1;
            _btnliketops.hidden=NO;
            _btnbottomlike.hidden=NO;
           
        }
        else
        {
            NSDictionary *datadic=[responseObject objectForKey:@"data"];
            NSString *pointstr=[NSString stringWithFormat:@"LUCKY YOU +%@",[datadic objectForKey:@"points"]];
            _lblLuckuou.text=pointstr;
            _tapHistoryview.hidden=NO;
            _btnliketops.enabled = NO;
            _btnbottomlike.enabled = NO;
            _btnbgLike.enabled = NO;
            [self performSelector:@selector(getContestImageListMainMethod) withObject:self afterDelay:1.0 ];
            current_pageStr= current_pageStr+1;
         
        }
        [APPDATA hideLoader];
    };
    void (^failure)(NSError * error) = ^(NSError *error) {
        [APPDATA hideLoader];
       
        [self getContestImageListMainMethod];
    };
    
    
    
    [APPDATA showLoader];
    
    
    NSDictionary *dict = @{@"key":API_KEY,@"method":API_CONTEST_VOTE,@"profile_id":appDelegate.profilid_AppStr,@"contest_id":appDelegate.contest_idAppStr,@"image_id":imgStr,@"second_image_id":imgStr2
                           };
    
    [APICall sendToService:dict success:successed failure:failure];
    
    
    
}

// Call when tap on thumb for like
- (IBAction)likeTP:(id)sender
{
    if (APPDATA.isUserLogin == YES) {
        if (UDGetBool(@"isPublishProfile") == YES) {
            NSLog(@"mainLike");
    [self likeMainMethod:(int)[sender tag]];
        }else{
                [APPDATA ShowAlertWithTitle:@"" Message:ERROR_UNPUBLISH_VOTING];
            }
        }
        else{ [APPDATA ShowAlertWithTitle:@"" Message:ERROR_LOGIN];
        }

}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

//Scroll Zooming in image
- (void)scrollViewDidZoom:(UIScrollView *)sv
{
    UIView* zoomView = [sv.delegate viewForZoomingInScrollView:sv];
    CGRect zvf = zoomView.frame;
    if(zvf.size.width < sv.bounds.size.width)
    {
        zvf.origin.x = (sv.bounds.size.width - zvf.size.width) / 2.0;
    }
    else
    {
        zvf.origin.x = 0.0;
    }
    if(zvf.size.height < sv.bounds.size.height)
    {
        zvf.origin.y = (sv.bounds.size.height - zvf.size.height) / 2.0;
    }
    else
    {
        zvf.origin.y = 0.0;
    }
    zoomView.frame = zvf;
}



- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    CGPoint centerPoint = CGPointMake(CGRectGetMidX(self.bigimgScrollView.bounds),
                                      CGRectGetMidY(self.bigimgScrollView.bounds));
   if (self.imageTp.hidden==NO)
  {
        [self view:self.imageTp setCenter:centerPoint];
   }
   else
       [self view:self.imageBt setCenter:centerPoint];
    
}
- (void)view:(UIView*)view setCenter:(CGPoint)centerPoint
{
    CGRect vf = view.frame;
    CGPoint co = self.bigimgScrollView.contentOffset;
    
    CGFloat x = centerPoint.x - vf.size.width / 2.0;
    CGFloat y = centerPoint.y - vf.size.height / 2.0;
    
    if(x < 0)
    {
        co.x = -x;
        vf.origin.x = 0.0;
    }
    else
    {
        vf.origin.x = x;
    }
    if(y < 0)
    {
        co.y = -y;
        vf.origin.y = 0.0;
    }
    else
    {
        vf.origin.y = y;
    }
    
    view.frame = vf;
    self.bigimgScrollView.contentOffset = co;
}
// Call When zoom and scroll in imageview
- (UIView*)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
     if (self.imageTp.hidden==NO)
   {
        return  self.imageTp;
   }
    else
        return  self.imageBt;

}

@end
