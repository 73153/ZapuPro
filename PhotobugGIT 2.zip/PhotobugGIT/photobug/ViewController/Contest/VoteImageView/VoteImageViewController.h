//
//  VoteImageViewController.h
//  photobug
//
//   on 08/12/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlideNavigationController.h"
#import "RightMenuViewController.h"
#import "Constant.h"
#import "ApplicationData.h"

@interface VoteImageViewController : UIViewController<SlideNavigationControllerDelegate,UIScrollViewDelegate,UIScrollViewDelegate>
{
    IBOutlet UIImageView *imgTop;
    IBOutlet UIImageView *imgBottom;
    IBOutlet UIScrollView *scrllView;
    BOOL isFullImage;
    UIButton *buttonlike;
}

@property (strong,nonatomic)IBOutlet UITableView *tableviewDashboard;
@property (nonatomic,strong) NSString *strIndex;
@property (strong, nonatomic) IBOutlet UIButton *btnlike;
@property (strong, nonatomic) IBOutlet UIView *tapHistoryview;
@property (strong, nonatomic) IBOutlet UIButton *menuButton;
@property (strong,nonatomic) IBOutlet UIView *viewSelected1;
@property (strong,nonatomic) IBOutlet UIView *viewSelected2;
@property (strong,nonatomic) IBOutlet UIView *viewSelected3;
@property (nonatomic,strong) IBOutlet UILabel *lblNoDataFound;
@property (strong, nonatomic) IBOutlet UIView *tapview;
@property (strong, nonatomic) IBOutlet UIImageView *imgTop2;
@property (strong, nonatomic) IBOutlet UIButton *btntoplikeL;
@property (strong, nonatomic) IBOutlet UIButton *btnbottomlike;
@property (strong, nonatomic) IBOutlet UIButton *btnliketops;
@property (strong, nonatomic) IBOutlet UIButton *btnCreditHistory;
@property (strong, nonatomic) IBOutlet UILabel *lblLuckuou;
@property (strong, nonatomic) IBOutlet UIButton *btnbgLike;
@property (strong, nonatomic) IBOutlet UIView *bigView;
@property (strong, nonatomic) IBOutlet UIView *viewDiveder;
@property (strong, nonatomic) IBOutlet UIView *viewHeader;
@property (strong, nonatomic) IBOutlet UIImageView *imageTp;
@property (strong, nonatomic) IBOutlet UIImageView *imageBt;
@property (nonatomic) IBOutlet UIScrollView *bigimgScrollView;
@property (nonatomic,retain)NSString *contestidStrN;

- (void) setClippingPath:(UIBezierPath *)clippingPath : (UIImageView *)imgView;
- (IBAction)likeBtnAction:(id)sender;
-(IBAction)handlePanGesture:(UIPanGestureRecognizer *)sender;
-(IBAction)handlePanGesture2:(UIPanGestureRecognizer *)sender;
- (IBAction)btnCreditHistoryTapped:(id)sender;
-(void)likeMainMethod:(int)senderTag;
- (IBAction)btnToplikeLAction:(id)sender;
- (IBAction)btnbottomlikeAction:(id)sender;
- (IBAction)btnToplikeSAction:(id)sender;
- (IBAction)likeTP:(id)sender;
@end
