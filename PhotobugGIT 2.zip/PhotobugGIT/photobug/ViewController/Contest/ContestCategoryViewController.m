//
//  ContestCategoryViewController.m
//  photobug
//
//   on 12/3/15.
//  Copyright © Photobug. All rights reserved.
//
#import "ContestCategoryViewController.h"
#import "SlideNavigationController.h"
#import "ApplicationData.h"
#import "Constant.h"
#import "ContestLandingViewController.h"
#import "Contest.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import <UIActivityIndicator-for-SDWebImage/UIImageView+UIActivityIndicatorForSDWebImage.h>
@interface ContestCategoryViewController ()
{
    NSArray *recipeImages;
    int pageNo;
    NSMutableArray *imgArray;
}
@end

@implementation ContestCategoryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [_menuButton addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleRightMenu) forControlEvents:UIControlEventTouchUpInside];
    APPDATA.user.aryMyProfileImage=[[NSMutableArray alloc]init];
    pageNo = 1;
    [self getContestCaltegory];
    [self.viewSelected1 setHidden:NO];
    [self.viewSelected2 setHidden:YES];
    [self.viewSelected3 setHidden:YES];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//call method to fetch contest category for diplay modules of contest
- (void) getContestCaltegory{
    [APPDATA showLoader];
    Contest *objContest = [[Contest alloc] init];
    objContest.key = [API_KEY mutableCopy];
    objContest.profileid = APPDATA.user.profileid;
    [objContest getContestCategory:^(NSDictionary *result, NSString *str, int status) {
        if (status == 1) {
            [self.collectionView reloadData];
            self.lblNoDataFound.hidden = YES;
        }
        else {
            self.lblNoDataFound.hidden = NO;
            CGRect frame = self.lblNoDataFound.frame;
            frame.origin.y = (self.view.superview.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
            [self.lblNoDataFound setFrame:frame];

            // NSLog(@"Failed");
            [APPDATA hideLoader];
        }
    }];
}

//Collection view delegate method for collectionview of images
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return APPDATA.contest.arrTagDetail.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"CategoryCell";
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    UIImageView *recipeImageView = (UIImageView *)[cell viewWithTag:100];
    NSDictionary *dictUserData = [APPDATA.contest.arrTagDetail objectAtIndex:indexPath.row];
    if (![[[dictUserData valueForKey:@"imagedetail"] valueForKey:@"url"] isKindOfClass:[NSNull class]] &&
        [[[[dictUserData valueForKey:@"imagedetail"] firstObject] valueForKey:@"url"] length] > 3) {
        NSString *imgStr=[NSString stringWithFormat:@"%@/convert?w=200&h=200",[[[dictUserData valueForKey:@"imagedetail"] firstObject] valueForKey:@"url"]];
            [recipeImageView setImageWithURL:[NSURL URLWithString:imgStr] placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        recipeImageView.contentMode = UIViewContentModeScaleAspectFill;
    }
    else
    {
        [recipeImageView setImage:[UIImage imageNamed:@""]];
    }
    UILabel *userLabel = (UILabel *)[cell viewWithTag:101];
    userLabel.text=[[dictUserData valueForKey:@"tag"] uppercaseString];
    [APPDATA hideLoader];
    return cell;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    ContestLandingViewController *objviewController =(ContestLandingViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"ContestLandingViewController"];
    objviewController.dictTagDetail=[APPDATA.contest.arrTagDetail objectAtIndex:indexPath.row];
    [APPDATA pushNewViewController:objviewController];
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    CGSize cgsize ;
    if( IS_IPHONE6){
        cgsize = CGSizeMake(184, 184);
    }else if(IS_IPHONE6plus)
    {
        cgsize = CGSizeMake(203, 203);
    }else
    {
        cgsize = CGSizeMake(157, 157);
    }
    return cgsize;
}
//On back button for back to viewcontroller
- (IBAction)btnBackPressed:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark Tab button action...

- (IBAction)btnContestPressedTab:(id)sender
{
    // [APPDATA btnContestsPressedTab];
}
//on myphotos tab button
- (IBAction)btnMyphotosPressedTab:(id)sender {
    [APPDATA btnMyphotoPressedTab];
}
//on upload photos press tab
- (IBAction)btnuploadPressedTab:(id)sender {
    appDelegate.tabDisplayAppFlag=@"";
    [APPDATA btnuploadPressedTab];
}
@end
