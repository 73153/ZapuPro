//
//  MyPhotosViewController.h
//  PhotoBugContestDemo
//
//   on 12/2/15.
//  Copyright © 2015 karishma. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ScrollViewController.h"
#import "PhotoDetailViewController.h"
#import <FPPicker/FPPicker.h>
#import "APICall.h"

@protocol Delegate <NSObject>
-(void) DictionaryforData:(NSDictionary *) DictData;
@end



@interface MyPhotosViewController : ScrollViewController<FPPickerControllerDelegate,
FPSaveControllerDelegate>
@property (nonatomic, strong) FPSaveController *fpSave;
@property (nonatomic, strong) NSMutableArray<UIImage *> *displayedImages;
@property (nonatomic, strong) FPTheme *theme;
@property (strong, nonatomic) IBOutlet UICollectionView *collectionView;
@property(strong,nonatomic)NSString *profilidStr;
@property (nonatomic,strong) IBOutlet UILabel *lblNoDataFound;
@property (weak,nonatomic) id <Delegate> ProtoDelegate;
@property(nonatomic,strong)NSString *mainViewFl;
@property(nonatomic,strong)NSString *mainViewFl2;
@property (strong, nonatomic) IBOutlet UIView *contest_TabView;
@property (strong, nonatomic) IBOutlet UIView *mainTabview;
@property (strong, nonatomic) IBOutlet UIView *photDisplayview;
@property (strong, nonatomic) IBOutlet UIImageView *bigImageView;
@property (strong,nonatomic) IBOutlet UIView *viewSelected2;
@property (strong,nonatomic) IBOutlet UIView *viewSelected;
@property (strong, nonatomic) IBOutlet UIButton *menuButton;
@property (strong, nonatomic) IBOutlet UILabel *lblnavTit;
@property (strong, nonatomic) IBOutlet UIButton *backButton;
@property (strong, nonatomic) IBOutlet UIImageView *titLogo;
@property (strong, nonatomic) IBOutlet UIButton *tineyeBtnHigh;

-(void)collectionViewReloadMethod;
- (void)pickerModalAction:(NSString *)sender;
- (IBAction)btninfoPressedTab:(id)sender;
- (IBAction)btnMyphotosPressedTab:(id)sender;
- (IBAction)btnuploadPressedTab:(id)sender;
-(void)intdata: (NSInteger)pagechange;
- (IBAction)btnuploadPhotoTab:(id)sender;
- (IBAction)btnContestTab:(id)sender;
- (IBAction)btnphotoCancel:(id)sender;
-(void)reloadCollectionView;
@end
