//
//  SubmitAnEntryViewController.m
//  PhotoBugContestDemo
//
//   on 12/1/15.
//  Copyright © 2015 karishma. All rights reserved.
//
#import "SubmitAnEntryViewController.h"
#import "AsyncImageView.h"
#define IMAGE_VIEW_TAG 999
#import "SlideNavigationController.h"
#import "APICall.h"
#import "Contest.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "ContestCategoryViewController.h"
#import "IQKeyboardManager.h"
#import "IQKeyboardManagerConstants.h"
#import "IQKeyboardReturnKeyHandler.h"
#import "IQUIView+IQKeyboardToolbar.h"
#import "ApplicationData.h"
#import "MyDashboardViewController.h"
#import "ContestLandingViewController.h"
#import "AddTagViewController.h"
#import "AddTagTableViewCell.h"
#import "ZFTokenField.h"
#import <UIActivityIndicator-for-SDWebImage/UIImageView+UIActivityIndicatorForSDWebImage.h>
#import "IQKeyboardManager.h"
#import "IQKeyboardManagerConstants.h"
#import "IQKeyboardReturnKeyHandler.h"
#import "IQUIView+IQKeyboardToolbar.h"
#import "UCZProgressView.h"

@interface SubmitAnEntryViewController ()<ZFTokenFieldDataSource, ZFTokenFieldDelegate,UITextFieldDelegate>
{
    BOOL addtoshopFlag;
    NSString *addtoshopStr;
    NSString *orgStrCat;
    IQKeyboardManager *objKeymanage;
    IQKeyboardReturnKeyHandler *returnKeyHandler;
}

@property (nonatomic) IBOutlet UCZProgressView *progressView;
@property (nonatomic) NSMutableData *data;
@property (nonatomic) double expectedBytes;
@end

@implementation SubmitAnEntryViewController
@synthesize otherProfiletag,imgEnterPhoto,strimgEnterPhoto,postImageurl,contest_idStr,image_idStr,tagName,captionStr,arytag;
@synthesize pastUrls;
@synthesize autocompleteUrls;

- (void)viewDidLoad {
    [super viewDidLoad];
    _tokenField.dataSource=self;
    _tokenField.delegate=self;
    objKeymanage= [IQKeyboardManager sharedManager];
    [_tokenField reloadData];
    arytag=[[NSMutableArray alloc]init];
    self.tokens = [NSMutableArray array];
    self.pastUrls = [[NSMutableArray alloc] init];
    self.autocompleteUrls = [[NSMutableArray alloc] init];
    _tokenField.textField.textColor = [UIColor whiteColor];
    self.viewtag.layer.masksToBounds = YES;
    self.viewtag.layer.cornerRadius = 15;
       self.viewtag.layer.zPosition = 20000;
    self.AddTxtTag.text=NSLineBreakByWordWrapping;
    if (self.strCaption.length!=0) {
        self.txtCreateCaption.text=self.strCaption;
    }
    if (self.strTag.length!=0) {
         _lbltagplaceholder.hidden=YES;
        self.tokenField.dataSource = self;
        self.tokenField.delegate = self;
        _tokens = (NSMutableArray *)[self.strTag componentsSeparatedByString:@","];
        [self.tokenField reloadData];
    }
    else
    {
        _lbltagplaceholder.hidden=NO;
    }
    [_tblviewTag setSeparatorStyle:UITableViewCellSeparatorStyleNone];

    _viewtag.hidden=YES;
    [_tokenField.textField setFont:[UIFont fontWithName:@"OpenSans" size:12]];
    
    UIColor *color = [UIColor colorWithRed:79.0/255.0 green:93.0/255.0 blue:120.0/255.0 alpha:1.0];
    _txtCreateCaption.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"Create a caption..." attributes:@{NSForegroundColorAttributeName: color}];
    UILabel * leftView = [[UILabel alloc] initWithFrame:CGRectMake(28,0,12,26)];
    leftView.backgroundColor = [UIColor clearColor];
    _txtCreateCaption.leftView = leftView;
    _txtCreateCaption.leftViewMode = UITextFieldViewModeAlways;
    [self AllTagMethod];
    addtoshopStr=@"0";
    appDelegate.tabDisplayAppFlag=@"0";
    if ([postImageurl length]<1)
    {
        postImageurl=[NSString stringWithFormat:@"%@",[SlideNavigationController sharedInstance].imageStr];
    }
     orgStrCat=[NSString stringWithFormat:@"%@",postImageurl];
    NSString *fCharStr =[postImageurl substringToIndex:22];
    if ([postImageurl rangeOfString:@"convert"].location == NSNotFound && [fCharStr isEqualToString:@"https://www.filepicker"])
    {
        postImageurl = [NSString stringWithFormat:@"%@/convert?w=1200&h=1200",postImageurl];
    }else if([fCharStr isEqualToString:@"https://www.filepicker"])
    {
        postImageurl = [postImageurl substringToIndex:[postImageurl length]-20];
        postImageurl = [NSString stringWithFormat:@"%@/convert?w=1200&h=1200",postImageurl];
    }
    [self loadImage];
    if ([postImageurl length]>2)
    {
        [_imgExp setImageWithURL:[NSURL URLWithString:postImageurl] placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    }else{
        [_imgExp setImage:[UIImage imageNamed:@"no_imgV.png"]];
    }
    [self.viewSelected1 setHidden:YES];
    [self.viewSelected2 setHidden:YES];
    [self.viewSelected3 setHidden:YES];
    [[IQKeyboardManager sharedManager] setEnable:YES];
    [[IQKeyboardManager sharedManager] setEnableAutoToolbar:YES];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(displayTag) name:@"Message" object:nil];
    returnKeyHandler = [[IQKeyboardReturnKeyHandler alloc] initWithViewController:self];
    [_tokenField.textField addDoneOnKeyboardWithTarget:self action:@selector(doneAction:)];
    addtoshopStr=@"1";
    [_addshopImg setImage:[UIImage imageNamed:@"check.png"]];
    addtoshopFlag=YES;
    tblFrame=_tblviewTag.frame;

}
//text reactangle bounds
- (CGRect)textRectForBounds:(CGRect)bounds {
    return CGRectInset(bounds, 10, 10);
}
#pragma mark - private methods
- (void)loadImage {
    NSURL *url = [NSURL URLWithString:postImageurl];
    [NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:url] delegate:self];
}

//connection delegates for image display in progressview
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    self.expectedBytes = response.expectedContentLength;
    self.data = [NSMutableData dataWithCapacity:self.expectedBytes];
    self.progressView.progress = 0.0;
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [self.data appendData:data];
    double receivedBytes = self.data.length;
    self.progressView.progress = receivedBytes / self.expectedBytes;
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    self.imgEnterPhoto.image = [UIImage imageWithData:self.data];
    self.progressView.progress = 1.0;
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    self.progressView.progress = 1.0;
}

-(void)displayTag
{
    if (APPDATA.contest.selectTagNameArray.count>1)
    {
      
    }
}
//Method for blure effect
- (void) setBlureEffect {
    CIFilter *gaussianBlurFilter = [CIFilter filterWithName:@"CIGaussianBlur"];
    [gaussianBlurFilter setDefaults];
    CIImage *inputImage = [CIImage imageWithCGImage:[self.imgExp.image CGImage]];
    [gaussianBlurFilter setValue:inputImage forKey:kCIInputImageKey];
    [gaussianBlurFilter setValue:@10 forKey:kCIInputRadiusKey];
    CIImage *outputImage = [gaussianBlurFilter outputImage];
    CIContext *context   = [CIContext contextWithOptions:nil];
    CGImageRef cgimg     = [context createCGImage:outputImage fromRect:[inputImage extent]];
    UIImage *image= [UIImage imageWithCGImage:cgimg];
    [self.imgExp setImage:image];
    CGImageRelease(cgimg);
    [APPDATA hideLoader];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
//Button for addtagView
- (IBAction)btnAggAction:(id)sender {
    AddTagViewController *objAddTagViewController =(AddTagViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"AddTagViewController"];
    [self.parentViewController addChildViewController:objAddTagViewController];
    [self.parentViewController.view addSubview:objAddTagViewController.view];
    [objAddTagViewController didMoveToParentViewController:self];
}
//On cross button perform this action or popviewcontroller
- (IBAction)btnCancelEntryTapped:(id)sender {
    appDelegate.tabDisplayAppFlag=@"1";
    [self.navigationController popViewControllerAnimated:YES];
}
//on submit button perform this action
- (IBAction)btnSubmitEntryTapped:(id)sender {
    NSCharacterSet *set = [NSCharacterSet whitespaceCharacterSet];
    APPDATA.contest.selectTagArray = [[NSMutableArray alloc] init];
    APPDATA.contest.selectTagArray = _tokens;
    
    if (APPDATA.contest.selectTagArray.count<1 &&  self.strTag.length==0)
    {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_TAG];
    }else if ([[_txtCreateCaption.text  stringByTrimmingCharactersInSet: set] length] == 0)
    {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_CAPTION];
    }
    else{
        [self sumbitMethod];
    }
}
//For add imgae in shop perform action on this button
- (IBAction)btnAddShopTapped:(id)sender {
    if (addtoshopFlag==NO)
    {
        addtoshopStr=@"1";
        [_addshopImg setImage:[UIImage imageNamed:@"check"]];
               addtoshopFlag=YES;
    }else{
        addtoshopStr=@"0";
        [_addshopImg setImage:[UIImage imageNamed:@"uncheck"]];

        addtoshopFlag=NO;
    }
}

//Tab button press on info
- (IBAction) btninfoPressedTab:(id)sender {
    [APPDATA btninfoPressedTab];
}
// myphotos tab button action
- (IBAction)btnMyphotosPressedTab:(id)sender {
    [APPDATA btnMyphotoPressedTab];
}
//Upload image perform action
- (IBAction)btnuploadPressedTab:(id)sender {
    [APPDATA btnuploadPressedTab];
}
//On action of submit button display exception view and on this view press button of submit button perform this action
- (IBAction)btnExceptAction:(id)sender {
    [APPDATA ShowAlertWithTitle:@"" Message:SUCCESG_ENTER_CONTEST];
    appDelegate.tabDisplayAppFlag=@"0";
    _ExceptView.hidden=YES;
    APPDATA.user.isSubmitTheContest=YES;
    ContestLandingViewController *viewController = [[ContestLandingViewController alloc] init];
    [APPDATA turnBackToAnOldViewController:viewController];
}

- (IBAction)btnFeedAction:(id)sender {
    MyDashboardViewController *objviewController =(MyDashboardViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"MyDashboardViewController"];
    objviewController.usertype = Loginuser;
    objviewController.backStr=@"1";
    [APPDATA pushNewViewController:objviewController];
}
-(void)SendEvent
{
    _viewtag.hidden=YES;


}
//on submitbutton perform this action
-(void)sumbitMethod{
    [APPDATA showLoader];
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        int check=[[responseObject objectForKey:@"error"]intValue];
        if (check==1)
        {
            [APPDATA ShowAlertWithTitle:@"" Message:ERROR_IMAGE_UPLOAD];
        }else{
            //Voting ...
            NSMutableAttributedString *aAttrString2;
            NSString *textStr;
            NSString *TypeValue;
            
            NSString *strType=[NSString stringWithFormat:@"%@",[[responseObject valueForKey:@"data"] valueForKey:@"cm_type"]];
            
            TypeValue=[NSString stringWithFormat:@"%@",[[responseObject valueForKey:@"data"] valueForKey:@"points"]];
            if ([strType isEqualToString:@"Credit"])
            {
                textStr=[NSString stringWithFormat:@"+%@",TypeValue];
            }
            else if ([strType isEqualToString:@"Debit"])
            {
                textStr=[NSString stringWithFormat:@"-%@",TypeValue];
            }

            UIFont *font1 = [UIFont fontWithName:@"OpenSans-ExtraBold" size:16];
            NSDictionary *arialDict = [NSDictionary dictionaryWithObject: font1 forKey:NSFontAttributeName];
            NSMutableAttributedString *aAttrString1 = [[NSMutableAttributedString alloc] initWithString:textStr attributes: arialDict];
            UIFont *font2 = [UIFont fontWithName:@"OpenSans" size:17];
            NSDictionary *arialDict2 = [NSDictionary dictionaryWithObject: font2 forKey:NSFontAttributeName];
            
            aAttrString2 = [[NSMutableAttributedString alloc] initWithString:@"  CREDITS" attributes: arialDict2];
          
            [aAttrString1 appendAttributedString:aAttrString2];
           
            self.lblcredit.attributedText=aAttrString1;
            _ExceptView.hidden=NO;
        }
        [APPDATA hideLoader];
    };
    void (^failure)(NSError * error) = ^(NSError *error) {
        [APPDATA hideLoader];
        NSString *textStr=@"100";
        UIFont *font1 = [UIFont fontWithName:@"OpenSans-ExtraBold" size:16];
        NSDictionary *arialDict = [NSDictionary dictionaryWithObject: font1 forKey:NSFontAttributeName];
        NSMutableAttributedString *aAttrString1 = [[NSMutableAttributedString alloc] initWithString:textStr attributes: arialDict];
        UIFont *font2 = [UIFont fontWithName:@"OpenSans" size:17];
        NSDictionary *arialDict2 = [NSDictionary dictionaryWithObject: font2 forKey:NSFontAttributeName];
        NSMutableAttributedString *aAttrString2 = [[NSMutableAttributedString alloc] initWithString:@"  CREDITS" attributes: arialDict2];
        [aAttrString1 appendAttributedString:aAttrString2];
        self.lblcredit.attributedText=aAttrString1;
        _ExceptView.hidden=NO;
    };
    if ([appDelegate.tagNameAppStr isKindOfClass:[NSNull class]] || appDelegate.tagNameAppStr == nil || [appDelegate.tagNameAppStr isEqualToString:@""])
    {
        appDelegate.tagNameAppStr=@" ";
    }
    if (APPDATA.contest.selectTagArray.count<1)
    {
        [APPDATA.contest.selectTagArray addObject:@" "];
    }
    int conInt=[appDelegate.contest_idAppStr intValue];
    NSString *ConStr=[NSString stringWithFormat:@"%d",conInt];
    [APPDATA.contest.selectTagArray removeObject: @""];
    NSOrderedSet *mySet = [[NSOrderedSet alloc] initWithArray:APPDATA.contest.selectTagArray];
    APPDATA.contest.selectTagArray = [[NSMutableArray alloc] initWithArray:[mySet array]];
    NSLog(@"%@",contest_idStr);
    NSDictionary *dict = [[NSDictionary alloc]init];
    if ([[APPDATA isNullOrEmpty:contest_idStr] length]!= 0)
    {
         dict= @{@"key":API_KEY,@"method":API_CONTEST_IMAGE_UPLOAD,@"profile_id":appDelegate.profilid_AppStr,@"contest_id":ConStr,@"image_id":contest_idStr,@"caption":_txtCreateCaption.text,@"image_url":orgStrCat,@"tags":APPDATA.contest.selectTagArray,@"add_to_shop":addtoshopStr,@"mobile_tags":@"0",@"title":_txtCreateCaption.text};
        
           }
    else
    {
        dict = @{@"key":API_KEY,@"method":API_CONTEST_IMAGE_UPLOAD,@"profile_id":appDelegate.profilid_AppStr,@"contest_id":ConStr,@"image_id":@"0",@"caption":_txtCreateCaption.text,@"image_url":orgStrCat,@"tags":APPDATA.contest.selectTagArray,@"add_to_shop":addtoshopStr,@"mobile_tags":@"0",@"title":_txtCreateCaption.text};
        

    }
    [APICall sendToService:dict success:successed failure:failure];
}

#pragma  mark tableviewdelegate
- (IBAction)goPressed
  {
      [_tokenField.textField becomeFirstResponder];
        _viewtag.hidden=YES;

}
//on tagname array search call this method
- (void)searchAutocompleteEntriesWithSubstring:(NSString *)substring {
    // Put anything that starts with this substring into the autocompleteUrls array
    // The items in this array is what will show up in the table view
    [arytag removeAllObjects];
    [autocompleteUrls removeAllObjects];
    for(NSDictionary *curString in pastUrls) {
        
          NSRange substringRange = [[curString valueForKey:@"tagname"] rangeOfString:substring options:NSCaseInsensitiveSearch];
        
        if (substringRange.location == 0)
        {
            
            [autocompleteUrls addObject:curString];
        }
    }

    NSArray * aArray = [autocompleteUrls valueForKey:@"tagname"];
      autocompleteUrls = [aArray sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)].mutableCopy;
       dispatch_async (dispatch_get_main_queue(), ^{
        
           if (autocompleteUrls.count==0)
            {  [_viewtag setHidden:YES];
                _tblviewTag.hidden=YES;
            }
        
           [_tblviewTag reloadData];
        
        });
}

//Call this uitableviewdelegates method for tag display
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger) section {
    return autocompleteUrls.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *strAddTagTableViewCell=@"AddTagTableViewCell";
    AddTagTableViewCell *cell=(AddTagTableViewCell*)[_tblviewTag dequeueReusableCellWithIdentifier:strAddTagTableViewCell];
    if (cell == nil) {
        cell = [[AddTagTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:strAddTagTableViewCell];
    }
    cell.lblTagName.text = [autocompleteUrls objectAtIndex:indexPath.row];
    
    if (!(autocompleteUrls.count==0))
    {
        [_viewtag setHidden:NO];
        [self setTableViewheightOfTable:_tblviewTag ByArrayName:autocompleteUrls];
        _tblviewTag.hidden=NO;
    }
else
       [_viewtag setHidden:YES];

    return cell;
}
//Set tableview hights according to tagname array
-(void)setTableViewheightOfTable :(UITableView *)tableView ByArrayName:(NSArray *)array
{
    if (autocompleteUrls.count<3)
    {
        _viewtag.backgroundColor=[UIColor clearColor];
        CGFloat height = _tblviewTag.rowHeight;
        height *= autocompleteUrls.count;
        CGRect tableFrame = _tblviewTag.frame;
        tableFrame.size.height = height;
        _tblviewTag.frame = tableFrame;
        _tblviewTag.layer.cornerRadius=9;
    }
    else
    {
    
        _tblviewTag.frame = tblFrame;
    }
}

#pragma mark UITableViewDelegate methods
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([_tokens containsObject:[autocompleteUrls objectAtIndex:indexPath.row]])
    {
    }else
    {
        NSMutableArray *arrToken = [[NSMutableArray alloc] initWithArray:_tokens];
        [arrToken addObject:[autocompleteUrls objectAtIndex:indexPath.row]];
        _tokens = [[NSMutableArray alloc] init];
        
        [_tokens addObjectsFromArray:arrToken];
    }
    
    [_tokenField reloadData];
    [self goPressed];
}

//Call method for all the tag names
-(void)AllTagMethod{
    [APPDATA showLoader];
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        APPDATA.contest.selectTagArray=[[NSMutableArray alloc]init];
        APPDATA.contest.selectTagNameArray=[[NSMutableArray alloc]init];
        self.pastUrls = [responseObject valueForKey:@"data"];
        [_tblviewTag reloadData];
        [APPDATA hideLoader];
    };
    void (^failure)(NSError * error) = ^(NSError *error) {
        [APPDATA hideLoader];
    };
    NSDictionary *dict = @{@"key":API_KEY,@"method":API_CONTEST_NEW_TAGS
                           };
    [APICall sendToService:dict success:successed failure:failure];
}

#pragma mark ZFtokenField
- (CGFloat)lineHeightForTokenInField:(ZFTokenField *)tokenField
{
    return 30;
}

- (NSUInteger)numberOfTokenInField:(ZFTokenField *)tokenField
{
    return self.tokens.count;
}

- (UIView *)tokenField:(ZFTokenField *)tokenField viewForTokenAtIndex:(NSUInteger)index
{
    NSArray *nibContents = [[NSBundle mainBundle] loadNibNamed:@"TokenView" owner:nil options:nil];
    UIView *view = nibContents[0];
    UILabel *label = (UILabel *)[view viewWithTag:2];
    UIButton *button = (UIButton *)[view viewWithTag:3];
    [button addTarget:self action:@selector(tokenDeleteButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
    label.text = [self.tokens objectAtIndex:index];
    if (self.strTag.length!=0)
    {   _lbltagplaceholder.hidden=YES;
        label.text= [self.tokens objectAtIndex:index];
        
    }
    
   
    label.layer.cornerRadius=5;
    label.layer.masksToBounds = YES;
    [APPDATA.contest.selectTagArray addObject:[self.tokens objectAtIndex:index]];
    CGSize stringSize = [label.text sizeWithAttributes:@{NSFontAttributeName: [UIFont systemFontOfSize:12.0f]}];
    view.layer.cornerRadius = 11 ;
    view.frame = CGRectMake(0,0,stringSize.width + button.frame.size.width + 20, 45);
    return view;
}
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    return YES;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    
}
#pragma mark - ZFTokenField Delegat
- (CGFloat)tokenMarginInTokenInField:(ZFTokenField *)tokenField
{
    return 5;
}

- (void)tokenField:(ZFTokenField *)tokenField didReturnWithText:(NSString *)text
{
    NSLog(@"%@",self.tokens);
        
      if ( [_tokens containsObject:text])
      {
          _tokenField.textField.text = @"";
      }
      else{
    [self.tokens addObject:text];
    NSLog(@"%@",APPDATA.contest.selectTagArray );
    NSMutableDictionary *dictext=[[NSMutableDictionary alloc]init];
    [dictext setValue:text forKey:@"tagname"];
    [self.tokens addObject:dictext];
    [tokenField reloadData];
      }
}
//when remove all tags and display placeholder
- (void)tokenField:(ZFTokenField *)tokenField didRemoveTokenAtIndex:(NSUInteger)index
{
    [self.tokens removeObjectAtIndex:index];
    if (index==0) {
        _lbltagplaceholder.hidden=NO;
    }
    else
        _lbltagplaceholder.hidden=YES;
}

- (BOOL)tokenFieldShouldEndEditing:(ZFTokenField *)textField
{
   
    return NO;
   
}
//call this method when text change in tokefield
- (void)tokenField:(ZFTokenField *)tokenField didTextChanged:(NSString *)text
{
    
    text = [text lowercaseString];
    if ([text isEqualToString:@" "])
        text = [text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    CGSize stringSize = [text sizeWithAttributes:@{NSFontAttributeName: [UIFont systemFontOfSize:12.0f]}];
    
    self.tokenField.textField.frame = CGRectMake( self.tokenField.textField.frame.origin.x,  self.tokenField.textField.frame.origin.y, stringSize.width + 40,  self.tokenField.textField.frame.size.height+100) ;
    if ([text length]>0)
    {
         _lbltagplaceholder.hidden=YES;
        _lbladdtag.text=@"";
          _viewtag.hidden=NO;
        
    }
    else
    {
        _viewtag.hidden=YES;
    }
    if (autocompleteUrls.count==0) {
         _viewtag.hidden=YES;
        _tblviewTag.hidden=YES;

    }
    
    NSString *substring1 = [NSString stringWithString:_tokenField.textField.text];
    
    
    [self searchAutocompleteEntriesWithSubstring:substring1];
    if ([text containsString:@" "])
    {
        
        NSString *trimmedString = [text stringByTrimmingCharactersInSet:
                                   [NSCharacterSet whitespaceAndNewlineCharacterSet]];
        for (NSString *str in _tokens) {
            if ([str isEqualToString:trimmedString]) {
                _isAvailable = YES;
            }
        }
        if (_isAvailable == YES) {
            tokenField.textField.text = @"";
            _isAvailable = NO;
        }  else {
        if (![_tokens containsObject:trimmedString]) {
            NSMutableArray *arrtoken  = [[ NSMutableArray alloc] init];
            [arrtoken addObjectsFromArray:_tokens];
            [arrtoken addObject:trimmedString];
            _tokens = [[NSMutableArray alloc] init];
            _tokens = arrtoken;
            [_tokenField reloadData];
            [self goPressed];
        }
            }
    }
}

- (void)dealloctokenFieldDidBeginEditing:(ZFTokenField *)tokenField{
    [self.tokenField.textField becomeFirstResponder];
}

//on the close button of tag view perform this action for delete tag
- (void)tokenDeleteButtonPressed:(UIButton *)tokenButton
{
    NSUInteger index = [self.tokenField indexOfTokenView:tokenButton.superview];
    if (index != NSNotFound) {
        [self.tokens removeObjectAtIndex:index];
        if (index==0) {
             _lbltagplaceholder.hidden=NO;
        }
       
        [self.tokenField reloadData];
    }else{
    }
}
//On done button from bar button perform this action
-(void)doneAction:(UIBarButtonItem*)barButton{
    [APPDATA.contest.selectTagArray addObject:_tokenField.textField.text];
    [self.view endEditing:YES];
    [_tokenField.textField resignFirstResponder];
}
@end
