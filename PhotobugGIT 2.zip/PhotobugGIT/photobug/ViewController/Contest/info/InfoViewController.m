//
//  InfoViewController.m
//  photobug
//
//   on 04/12/15.
//  Copyright © Photobug. All rights reserved.
//
#import "InfoViewController.h"
#import "Constant.h"
#import "ApplicationData.h"
#import "APICall.h"
#import "MyPhotosViewController.h"
#define TRANSFORM_CELL_VALUE CGAffineTransformMakeScale(0.8, 0.8)
#define ANIMATION_SPEED 0.2

@implementation InfoViewController
{
    NSMutableArray *arycontestimg;
    BOOL isfirstTimeTransform;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self getinfoMethod];
    arycontestimg=[[NSMutableArray alloc]init];
    [self performSelector:@selector(collectionViewReloadMethod)  withObject:nil afterDelay:0.3];
    [self.viewSelected1 setHidden:YES];
    [self.viewSelected2 setHidden:YES];
    [self.viewSelected3 setHidden:NO];
    isfirstTimeTransform = YES;
    _scrollView.contentSize = CGSizeMake(_scrollView.frame.size.width,200);
}

-(void)collectionViewReloadMethod{
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.collectionView reloadData];
        
    });
}

- (IBAction)btnBackButtonAction:(id)sender
{
}

- (IBAction)btnMyphotosPressedTab:(id)sender
{
    MyPhotosViewController *viewController =(MyPhotosViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"MyPhotosViewController"];
    viewController.mainViewFl2=@"1";
    [[SlideNavigationController sharedInstance] pushViewController:viewController animated:NO];
}

- (IBAction)btnuploadPressedTab:(id)sender
{
    [APPDATA btnuploadPressedTab];
}

- (IBAction)btnCancelPressed:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)getinfoMethod;
{
    [APPDATA showLoader];
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        [APPDATA hideLoader];
        if(responseObject == NULL)
        {
        }else{
            if ([responseObject count]>1) {
                
                    _lbl1stPlace.text =[APPDATA isNullOrEmpty: [[[responseObject valueForKey:@"data"] firstObject] valueForKey:@"prize1"]];
                    _lbl2ndPlace.text =[APPDATA isNullOrEmpty:[[[responseObject valueForKey:@"data"] firstObject] valueForKey:@"prize2"]];
                    _lbl3rdPlace.text = [APPDATA isNullOrEmpty:[[[responseObject valueForKey:@"data"] firstObject] valueForKey:@"prize3"]];
                
                self.txtDescription.text = [[[responseObject valueForKey:@"data"] firstObject] valueForKey:@"description"];
                
                NSString *img1=[[[responseObject valueForKey:@"data"] firstObject] valueForKey:@"contest-info-img-1"];
                NSString *img2=[[[responseObject valueForKey:@"data"] firstObject] valueForKey:@"contest-info-img-2"];
                NSString *img3=[[[responseObject valueForKey:@"data"] firstObject] valueForKey:@"contest-info-img-3"];
                [arycontestimg addObject:img1];
                [arycontestimg addObject:img2];
                [arycontestimg addObject:img3];
                [_collectionView reloadData];
                self.lblNoDataFound.hidden = YES;
                [self.collectionView reloadData];
            }
            else
            {
                self.lblNoDataFound.hidden = NO;
                CGRect frame = self.lblNoDataFound.frame;
                frame.origin.y = (self.view.superview.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
                [self.lblNoDataFound setFrame:frame];

            }
            [APPDATA hideLoader];
        }
    };
    void (^failure)(NSError * error) = ^(NSError *error)
    {
        [APPDATA hideLoader];
        self.lblNoDataFound.hidden = NO;
        CGRect frame = self.lblNoDataFound.frame;
        frame.origin.y = (self.view.superview.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
        [self.lblNoDataFound setFrame:frame];

    };
    NSDictionary* dict = @{@"key":API_KEY,@"method":API_CONTEST_INFO,@"contest_id":appDelegate.contest_idAppStr
                           };
    [APICall sendToService:dict success:successed failure:failure];
}
#pragma mark - CollectionView Data Source

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return arycontestimg.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    if (indexPath.row == 0 && isfirstTimeTransform) { // make a bool and set YES initially, this check will prevent fist load transform
        isfirstTimeTransform = NO;
    }else{
        cell.transform = TRANSFORM_CELL_VALUE; // the new cell will always be transform and without animation
    }
    UIImageView *recipeImageView = (UIImageView *)[cell viewWithTag:100];
    if (![[arycontestimg objectAtIndex:indexPath.row ] isKindOfClass:[NSNull class]] &&
        [[arycontestimg objectAtIndex:indexPath.row ] length] > 3) {
        recipeImageView.imageURL = [NSURL URLWithString:[arycontestimg objectAtIndex:indexPath.row]];
    }else{
        [recipeImageView setImage:[UIImage imageNamed:@""]];
    }
    recipeImageView.layer.cornerRadius = 25;
    UIImageView *bgimageView = (UIImageView *)[cell viewWithTag:101];
    [bgimageView setImage:[UIImage imageNamed:@"circle"]];
    return cell;
}

-(void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset
{
    float pageWidth =190 +  50; // width + space
    //float pageWidth =self.view.frame.size.width/2; // width + space
    float currentOffset = scrollView.contentOffset.x;
    float targetOffset = targetContentOffset->x;
    float newTargetOffset = 0;
    if (targetOffset > currentOffset)
        newTargetOffset = ceilf(currentOffset / pageWidth) * pageWidth;
    else
        newTargetOffset = floorf(currentOffset / pageWidth) * pageWidth;
    if (newTargetOffset < 0)
        newTargetOffset = 0;
    else if (newTargetOffset > scrollView.contentSize.width)
        newTargetOffset = scrollView.contentSize.width;
    targetContentOffset->x = currentOffset;
    [scrollView setContentOffset:CGPointMake(newTargetOffset, 0) animated:YES];
    int index = newTargetOffset / pageWidth;
    if (index == 0) { // If first index
        UICollectionViewCell *cell = [self.collectionView cellForItemAtIndexPath:[NSIndexPath indexPathForItem:index  inSection:0]];
        [UIView animateWithDuration:ANIMATION_SPEED animations:^{
            cell.transform = CGAffineTransformIdentity;
        }];
        cell = [self.collectionView cellForItemAtIndexPath:[NSIndexPath indexPathForItem:index + 1  inSection:0]];
        [UIView animateWithDuration:ANIMATION_SPEED animations:^{
            cell.transform = TRANSFORM_CELL_VALUE;
        }];
    }else{
        UICollectionViewCell *cell = [self.collectionView cellForItemAtIndexPath:[NSIndexPath indexPathForItem:index inSection:0]];
        [UIView animateWithDuration:ANIMATION_SPEED animations:^{
            cell.transform = CGAffineTransformIdentity;
        }];
        index --; // left
        cell = [self.collectionView cellForItemAtIndexPath:[NSIndexPath indexPathForItem:index inSection:0]];
        [UIView animateWithDuration:ANIMATION_SPEED animations:^{
            cell.transform = TRANSFORM_CELL_VALUE;
        }];
        index ++;
        index ++; // right
        cell = [self.collectionView cellForItemAtIndexPath:[NSIndexPath indexPathForItem:index inSection:0]];
        [UIView animateWithDuration:ANIMATION_SPEED animations:^{
            cell.transform = TRANSFORM_CELL_VALUE;
        }];
    }
}

@end
