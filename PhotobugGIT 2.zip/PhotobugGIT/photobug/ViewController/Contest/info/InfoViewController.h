//
//  InfoViewController.h
//  photobug
//
//   on 04/12/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InfoViewController : UIViewController<UICollectionViewDataSource,UICollectionViewDelegate>

@property (nonatomic,strong) IBOutlet UILabel *lblNoDataFound;
@property (nonatomic,strong) NSMutableDictionary *dictTagDetail;
@property (strong, nonatomic) IBOutlet UICollectionView *collectionView;
@property (nonatomic,strong) IBOutlet UITextView *txtDescription;
@property (nonatomic,strong) IBOutlet UILabel *lblPrize;
@property (nonatomic,strong) IBOutlet UILabel *lblName;
@property (strong,nonatomic) IBOutlet UIView *viewSelected1;
@property (strong,nonatomic) IBOutlet UIView *viewSelected2;
@property (strong,nonatomic) IBOutlet UIView *viewSelected3;
@property (strong, nonatomic) IBOutlet UILabel *lblplace;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;
@property (strong, nonatomic) IBOutlet UILabel *lbl1stPlace;
@property (strong, nonatomic) IBOutlet UILabel *lbl2ndPlace;
@property (strong, nonatomic) IBOutlet UILabel *lbl3rdPlace;
@property (strong, nonatomic) IBOutlet UILabel *lbl1Description;
@property (strong, nonatomic) IBOutlet UILabel *lbl2Description;
@property (strong, nonatomic) IBOutlet UILabel *lbl3Description;

- (IBAction)btnBackButtonAction:(id)sender;
-(IBAction)btnMyphotosPressedTab:(id)sender;
- (IBAction)btnuploadPressedTab:(id)sender;

@end
