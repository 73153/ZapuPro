//
//  MyPhotosViewController.m
//  PhotoBugContestDemo
//
//   on 12/2/15.
//  Copyright © 2015 karishma. All rights reserved.
//
#import "MyPhotosViewController.h"
#import "Constant.h"
#import "Users.h"
#import "ApplicationData.h"
#import "SubmitAnEntryViewController.h"
#import "UCZProgressView.h"
#import <UIActivityIndicator-for-SDWebImage/UIImageView+UIActivityIndicatorForSDWebImage.h>
#import "PhotoDetailViewController.h"
#import "MyPhotosCollectionViewCell.h"

@interface MyPhotosViewController ()<UICollectionViewDataSource,UICollectionViewDelegate>
{
    NSArray *aryContestMyPhotos;
    int pageNo;
     NSString *postImageurl;
    NSMutableArray *imgArray;
    PhotoDetailViewController *objPhotos;

}
@property (nonatomic, strong) UIPopoverController *myPopoverController;
@property (nonatomic) IBOutlet UCZProgressView *progressView;
@property (nonatomic) NSMutableData *data;
@property (nonatomic) double expectedBytes;
@end

@implementation MyPhotosViewController
@synthesize mainViewFl,mainViewFl2,ProtoDelegate;

- (void)viewDidLoad {
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    [super viewDidLoad];
self.collectionView.bounces=NO;
    pageNo = 1;
    if ([mainViewFl2 isEqualToString:@"1"]) {
        [self.viewSelected2 setHidden:NO];
        _mainTabview.hidden=YES;
        _contest_TabView.hidden=NO;
        _titLogo.hidden=YES;
        _menuButton.hidden=YES;
        _backButton.hidden=NO;
        _lblnavTit.hidden=NO;
        [self getContestMyPhotos];

    }
    else if (appDelegate.hideFooter)
    {
        appDelegate.hideFooter=NO;
        _mainTabview.hidden=NO;
        [self.viewSelected setHidden:NO];
        _contest_TabView.hidden=YES;
        _titLogo.hidden=NO;
        _menuButton.hidden=NO;
        _backButton.hidden=YES;
        _lblnavTit.hidden=YES;
        [_menuButton addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleRightMenu) forControlEvents:UIControlEventTouchUpInside];
    }
    else if([mainViewFl isEqualToString:@"1"])
        
    {
        
        _mainTabview.hidden=NO;
        [self.viewSelected setHidden:NO];
        _contest_TabView.hidden=YES;
        _titLogo.hidden=NO;
        _menuButton.hidden=NO;
        _backButton.hidden=YES;
        _lblnavTit.hidden=YES;
        [self getMyPhotosDetail];
        [_menuButton addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleRightMenu) forControlEvents:UIControlEventTouchUpInside];
    }
    [self performSelector:@selector(collectionViewReloadMethod)  withObject:nil afterDelay:10.0];

    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(reloadCollectionView) name:@"reloadCol" object:nil];


}
//Reload CollectionView for images
-(void)reloadCollectionView
{
    [self performSelector:@selector(collectionViewReloadMethod)  withObject:nil afterDelay:1.0];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    APPDATA.user.strOtherId=APPDATA.user.profileid;
    if ([mainViewFl2 isEqualToString:@"1"])
    {
            [self getContestMyPhotos];
    }
    else if([mainViewFl isEqualToString:@"1"])
    {
        [self getMyPhotosDetail];
    }
}

-(void)collectionViewReloadMethod{
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.collectionView reloadData];
    });
}

#pragma mark Reload Data ....
- (void)reloadData {
    if (APPDATA.recent.lastPage > pageNo) {
        pageNo = pageNo+1;
        if ([mainViewFl2 isEqualToString:@"1"])
        {
            [self getContestMyPhotos];
        }
        else if([mainViewFl isEqualToString:@"1"])
        {
            [self getMyPhotosDetail];
        }
    }
    [self.collectionView reloadData];
}
// Get photos from contest and display in collection view
- (void) getContestMyPhotos {
    [APPDATA showLoader];
    
    [APPDATA.recent getContestsMyPhotosImage:^(NSDictionary *result, NSString *str, int status)
     {
         [APPDATA hideLoader];
         if (status == 1)
         {
             if (APPDATA.recent.arycontestsMyPhotosImage.count == 0)
             {
                 self.lblNoDataFound.hidden = NO;
                 CGRect frame = self.lblNoDataFound.frame;
                 frame.origin.y= (self.view.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
                 [self.lblNoDataFound setFrame:frame];
             }
             else
             {
                 self.lblNoDataFound.hidden = YES;
             }
             [self.collectionView reloadData];
         }
         else {
             self.lblNoDataFound.hidden = NO;
             CGRect frame = self.lblNoDataFound.frame;
             frame.origin.y = (self.view.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
             [self.lblNoDataFound setFrame:frame];
         }
     }];
}
//Get my photos which is uploaded by library
- (void) getMyPhotosDetail
{
    [APPDATA showLoader];
   
    [APPDATA.recent MyPhotoImage:^(NSDictionary *result, NSString *str, int status)
     {
         [APPDATA hideLoader];
         if (status == 1) {
             if (APPDATA.recent.aryMyphotoImage.count == 0)
             {
                 self.lblNoDataFound.hidden = NO;
                 CGRect frame = self.lblNoDataFound.frame;
                 frame.origin.y = (self.view.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
                 [self.lblNoDataFound setFrame:frame];
                 
                 
                 
             }
             else
             {
                 self.lblNoDataFound.hidden = YES;
             }
             dispatch_async(dispatch_get_main_queue(), ^ {
                 [self.collectionView reloadData];
                 [self.collectionView layoutIfNeeded];
             });
         }
         else
         {
             self.lblNoDataFound.hidden = NO;
             CGRect frame = self.lblNoDataFound.frame;
             frame.origin.y = (self.view.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
             [self.lblNoDataFound setFrame:frame];
         }
     }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//Collectionview delegate methods.
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    
    if ([mainViewFl2 isEqualToString:@"1"])
    {
        return APPDATA.recent.arycontestsMyPhotosImage.count;
    }
    else if([mainViewFl isEqualToString:@"1"])
    {
        return APPDATA.recent.aryMyphotoImage.count;
    }
    return 0;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"Cell";
    MyPhotosCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    UIImageView *recipeImageView = (UIImageView *)[cell viewWithTag:100];
    
    if ([mainViewFl2 isEqualToString:@"1"])
    {
        
          if (![[APPDATA.recent.arycontestsMyPhotosImage objectAtIndex:indexPath.row ] isKindOfClass:[NSNull class]] &&
            [[APPDATA.recent.arycontestsMyPhotosImage objectAtIndex:indexPath.row ] length] > 3) {
            NSString *imgStr=[NSString stringWithFormat:@"%@",[APPDATA.recent.arycontestsMyPhotosImage objectAtIndex:indexPath.row]];
            
            NSString *fCharStr =[imgStr substringToIndex:22];
            if ([imgStr rangeOfString:@"convert"].location == NSNotFound && [fCharStr isEqualToString:@"https://www.filepicker"])
            {
                imgStr = [NSString stringWithFormat:@"%@/convert?w=300&h=300",imgStr] ;
            }else if([fCharStr isEqualToString:@"https://www.filepicker"])
            {
                imgStr = [imgStr substringToIndex:[imgStr length]-20];
                imgStr = [NSString stringWithFormat:@"%@/convert?w=300&h=300",imgStr] ;
            }
            if ([imgStr length]>2)
            {
                [recipeImageView setImageWithURL:[NSURL URLWithString:imgStr] placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            }else{
                [recipeImageView setImage:[UIImage imageNamed:@"no_imgV.png"]];
            }
            recipeImageView .contentMode = UIViewContentModeScaleAspectFill;
        }else{
            [recipeImageView setImage:[UIImage imageNamed:@""]];
        }
        if ([[APPDATA.recent.aryConteid objectAtIndex:indexPath.row] isEqual:@"1"])
        {
            
            cell.Tineyebtn.hidden=NO;
        }
        else
        {
            cell.Tineyebtn.hidden=YES;
            
        }
        
 
    }
    else if([mainViewFl isEqualToString:@"1"])
        
    {
        
        if (![[APPDATA.recent.aryMyphotoImage objectAtIndex:indexPath.row ] isKindOfClass:[NSNull class]] &&
            [[APPDATA.recent.aryMyphotoImage objectAtIndex:indexPath.row ] length] > 3) {
            NSString *imgStr=[NSString stringWithFormat:@"%@",[APPDATA.recent.aryMyphotoImage objectAtIndex:indexPath.row]];
            
            NSString *fCharStr =[imgStr substringToIndex:22];
            if ([imgStr rangeOfString:@"convert"].location == NSNotFound && [fCharStr isEqualToString:@"https://www.filepicker"])
            {
                imgStr = [NSString stringWithFormat:@"%@/convert?w=300&h=300",imgStr] ;
            }else if([fCharStr isEqualToString:@"https://www.filepicker"])
            {
                imgStr = [imgStr substringToIndex:[imgStr length]-20];
                imgStr = [NSString stringWithFormat:@"%@/convert?w=300&h=300",imgStr] ;
            }
            if ([imgStr length]>2)
            {
                [recipeImageView setImageWithURL:[NSURL URLWithString:imgStr] placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            }else{
                [recipeImageView setImage:[UIImage imageNamed:@"no_imgV.png"]];
            }
            recipeImageView .contentMode = UIViewContentModeScaleAspectFill;
        }else{
            [recipeImageView setImage:[UIImage imageNamed:@""]];
        }
        if ([[APPDATA.recent.aryMyphotoTintEye objectAtIndex:indexPath.row] isEqual:@"1"])
        {
            cell.Tineyebtn.hidden=NO;
        }
        else
        {
            cell.Tineyebtn.hidden=YES;
        }
    }
    
       return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
   
    NSInteger ind = indexPath.row;
    if ([mainViewFl2 isEqualToString:@"1"])
    {
        NSString *forSaleStr=[APPDATA.recent.aryConteid objectAtIndex:indexPath.row];
        int forScale=[forSaleStr intValue];
        if (forScale==1)
        {
            [APPDATA ShowAlertWithTitle:@"" Message:TINY_FLAG_IMAGE];
        }

        else
        {
            SubmitAnEntryViewController *objviewController =(SubmitAnEntryViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"SubmitAnEntryViewController"];
            objviewController.otherProfiletag=[NSString stringWithFormat:@"%ld",(long)indexPath.row];
            objviewController.postImageurl = [APPDATA.recent.arycontestsMyPhotosImage objectAtIndex:indexPath.row];
            NSString *strtag=[[NSString alloc]init];
            strtag=[APPDATA isNullOrEmpty:[APPDATA.recent.aryContestsTag objectAtIndex:indexPath.row]];
             objviewController.strTag = strtag;
            
              NSString *strCap=[APPDATA isNullOrEmpty:[APPDATA.recent.aryContestsComment objectAtIndex:indexPath.row]];
             objviewController.strCaption = strCap;
            objviewController.contest_idStr=[NSString stringWithFormat:@"%@",[APPDATA.recent.aryPhotoId objectAtIndex:indexPath.row]];
            [APPDATA pushNewViewController:objviewController];
        }
    }
    else if([mainViewFl isEqualToString:@"1"])

    {
               NSString *imagestr=[NSString stringWithFormat:@"%@",[APPDATA.recent.aryMyphotoImage objectAtIndex:indexPath.row]];
        
        NSString *fCharStr =[imagestr substringToIndex:22];
        if ([imagestr rangeOfString:@"convert"].location == NSNotFound && [fCharStr isEqualToString:@"https://www.filepicker"])
        {
            imagestr = [NSString stringWithFormat:@"%@/convert?w=700&h=700",imagestr] ;
        }else if([fCharStr isEqualToString:@"https://www.filepicker"])
        {
            imagestr = [imagestr substringToIndex:[imagestr length]-20];
            imagestr = [NSString stringWithFormat:@"%@/convert?w=700&h=700",imagestr] ;
        }
        
        UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
        objPhotos= (PhotoDetailViewController*)[mainStoryboard instantiateViewControllerWithIdentifier:@"PhotoDetailViewController"];
        objPhotos.postImageurl=imagestr;
        objPhotos.DictObjContestData=APPDATA.recent.DictMyPhotodata;
        objPhotos.profileCaptionStr=[APPDATA.recent.aryMyphotocaption objectAtIndex:indexPath.row];
        objPhotos.profileId=ind;
        NSArray *arrTag = [[NSArray alloc]initWithArray:[APPDATA.recent.aryMyphotoTag objectAtIndex:indexPath.row]];
        objPhotos.ProfileAryForTag = [[NSMutableArray alloc] init];
        [objPhotos.ProfileAryForTag addObjectsFromArray:arrTag];
        
        objPhotos.ProfileImageId=[APPDATA.recent.aryMyPhotoId objectAtIndex:indexPath.row];
        
        NSLog(@"%@",appDelegate.contest_idAppStr);
        [[self navigationController] pushViewController:objPhotos animated:NO];
    }
}
//Delegate methods for array of images which is chnge in photodetailviewcontroller on swipe
-(void)intdata:(NSInteger)pagechange
{
    @try {
        if (pagechange < 0 && pagechange > APPDATA.recent.arycontestsMyPhotosImage.count)
        {
            
        }
        else
        {
            NSString *imagestr=[NSString stringWithFormat:@"%@",[APPDATA.recent.aryMyphotoImage objectAtIndex:pagechange]];
            appDelegate.pageChangeNo=(int)pagechange;
            NSDictionary *fix=@{@"imgStr":imagestr,@"caption":[APPDATA.recent.aryMyphotocaption objectAtIndex:pagechange],@"tag":[APPDATA.recent.aryMyphotoTag objectAtIndex:pagechange],
                                @"ID":[APPDATA.recent.aryMyPhotoId objectAtIndex:pagechange]};
            
            
            
            [ProtoDelegate DictionaryforData:fix];
            
        }

    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
        }

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    CGSize cgsize ;
    if( IS_IPHONE6){
        cgsize = CGSizeMake(183, 183);
    }else if(IS_IPHONE6plus)
    {
        cgsize = CGSizeMake(202, 202);
    }else
    {
        cgsize = CGSizeMake(156, 156);
    }
    return cgsize;
}
//Tab button action for info myphots uploadphotos
- (IBAction) btninfoPressedTab:(id)sender {
    [APPDATA btninfoPressedTab];
}

- (IBAction)btnMyphotosPressedTab:(id)sender {
}

- (IBAction)btnuploadPressedTab:(id)sender {
    [APPDATA btnuploadPressedTab];
}

- (IBAction)btnuploadPhotoTab:(id)sender
{
    [self pickerModalAction:@"lip"];
}
//Filepicker delegate methods for images
- (FPTheme *)theme
{
    if (!_theme)
    {
        FPTheme *theme = [FPTheme new];
        CGFloat hue = 0.5616;
        theme.navigationBarStyle = UIBarStyleBlack;
        theme.navigationBarBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.12 alpha:1.0];
        theme.navigationBarTintColor = [UIColor colorWithHue:hue saturation:0.1 brightness:0.98 alpha:1.0];
        theme.headerFooterViewTintColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.28 alpha:1.0];
        theme.headerFooterViewTextColor = [UIColor whiteColor];
        theme.tableViewBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.49 alpha:1.0];
        theme.tableViewSeparatorColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.38 alpha:1.0];
        theme.tableViewCellBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.49 alpha:1.0];
        theme.tableViewCellTextColor = [UIColor colorWithHue:hue saturation:0.1 brightness:1.0 alpha:1.0];
        theme.tableViewCellTintColor = [UIColor colorWithHue:hue saturation:0.3 brightness:0.7 alpha:1.0];
        theme.tableViewCellSelectedBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.18 alpha:1.0];
        theme.tableViewCellSelectedTextColor = [UIColor whiteColor];
        theme.uploadButtonBackgroundColor = [UIColor blackColor];
        theme.uploadButtonHappyTextColor = [UIColor yellowColor];
        theme.uploadButtonAngryTextColor = [UIColor redColor];
        _theme = theme;
    }
    return _theme;
}
- (NSMutableArray <UIImage *>*)displayedImages
{
    if (!_displayedImages)
    {
        _displayedImages = [NSMutableArray array];
    }
    return _displayedImages;
}
#pragma mark - Actions -------------------------------------------------
- (IBAction)pickerAction:(id)sender
{
    /*
     * Create the object
     */
    FPPickerController *fpController = [FPPickerController new];
    /*
     * Set the delegate
     */
    fpController.fpdelegate = self;
    /*
     * Apply theme
     */
    fpController.theme = self.theme;
    /*
     * Ask for specific data types. (Optional) Default is all files.
     */
    fpController.dataTypes = @[@"image/*"];
    /*
     * Select and order the sources (Optional) Default is all sources
     */
    //fpController.sourceNames = [[NSArray alloc] initWithObjects: FPSourceImagesearch, nil];
    /*
     * Enable multselect (Optional) Default is single select
     */
    fpController.selectMultiple = YES;
    /*
     * Specify the maximum number of files (Optional) Default is 0, no limit
     */
    fpController.maxFiles = 5;
    /*
     * Optionally disable the front camera mirroring (experimental)
     */
    fpController.disableFrontCameraLivePreviewMirroring = NO;
    /*
     * Display it.
     */
    UIPopoverController *popoverController = [[UIPopoverController alloc] initWithContentViewController:fpController];
    self.myPopoverController = popoverController;
    self.myPopoverController.popoverContentSize = CGSizeMake(320, 520);
    [self.myPopoverController presentPopoverFromRect:[sender frame]
                                              inView:self.view
                            permittedArrowDirections:UIPopoverArrowDirectionAny
                                            animated:YES];
}
- (void)pickerModalAction:(NSString *)sender
{
    /*
     * Create the object
     */
    FPPickerController *fpController = [FPPickerController new];
    /*
     * Set the delegate
     */
    fpController.fpdelegate = self;
    /*
     * Apply theme
     */
    fpController.theme = self.theme;
    /*
     * Ask for specific data types. (Optional) Default is all files.
     */
    fpController.dataTypes = @[@"image/*", @"video/*"];
    /*
     * Select and order the sources (Optional) Default is all sources
     */
    //fpController.sourceNames = @[FPSourceImagesearch];
    /*
     * Enable multselect (Optional) Default is single select
     */
    fpController.selectMultiple = YES;
    /*
     * Specify the maximum number of files (Optional) Default is 0, no limit
     */
    fpController.maxFiles = 10;
    /*
     * Optionally disable the front camera mirroring (experimental)
     */
    fpController.disableFrontCameraLivePreviewMirroring = NO;
    fpController.modalPresentationStyle = UIModalPresentationPopover;
    /*
     * If controller will show in popover set popover size (iPad)
     */
    fpController.preferredContentSize = CGSizeMake(400, 500);
    fpController.typeLogin=sender;
    UIPopoverPresentationController *presentationController = fpController.popoverPresentationController;
    presentationController.permittedArrowDirections = UIPopoverArrowDirectionAny;
    
    [self presentViewController:fpController
                       animated:YES
                     completion:nil];
}
- (IBAction)savingAction:(id)sender
{
    if (self.displayedImages.count == 0)
    {
        UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Nothing to Save"
                                                          message:@"Select an image first."
                                                         delegate:nil
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
        [message show];
        return;
    }
    UIImage *firstImage = self.displayedImages[0];
    NSData *imgData = UIImagePNGRepresentation(firstImage);
    /*
     * Create the object
     */
    self.fpSave = [FPSaveController new];
    /*
     * Set the delegate
     */
    self.fpSave.fpdelegate = self;
    /*
     * Apply theme
     */
    self.fpSave.theme = self.theme;
    /*
     * Select and order the sources (Optional) Default is all sources
     */
    //self.fpSave.sourceNames = @[FPSourceDropbox, FPSourceFacebook, FPSourceBox];
    /*
     * Set the data and data type to be saved.
     */
    self.fpSave.data = imgData;
    self.fpSave.dataType = @"image/png";
    self.fpSave.modalPresentationStyle = UIModalPresentationPopover;
    /*
     * If controller will show in popover set popover size (iPad)
     */
    self.fpSave.preferredContentSize = CGSizeMake(400, 500);
    UIPopoverPresentationController *presentationController = self.fpSave.popoverPresentationController;
    presentationController.permittedArrowDirections = UIPopoverArrowDirectionAny;
    presentationController.sourceView = sender;
    presentationController.sourceRect = [sender bounds];
    /*
     * Display it.
     */
    [self presentViewController:self.fpSave
                       animated:YES
                     completion:nil];
}


#pragma mark - FPPickerControllerDelegate Methods
- (void)fpPickerController:(FPPickerController *)pickerController
      didPickMediaWithInfo:(FPMediaInfo *)info
{
}

- (void)fpPickerController:(FPPickerController *)pickerController
didFinishPickingMediaWithInfo:(FPMediaInfo *)info
{
    //NSLog(@"FILE CHOSEN: %@", info);
    if (info)
    {
        if (info.containsImageAtMediaURL)
        {
            postImageurl=[NSString stringWithFormat:@"%@",info.remoteURL];
            [self.displayedImages removeAllObjects];
            appDelegate.hideFooter=YES;
            [self imgUpload:postImageurl];
        }
        [self dismissViewControllerAnimated:YES
                                 completion:nil];
    }
    else
    {
    }
}

//After file picker delegates method url display through this method and upload which is display in collectionview
-(void)imgUpload:(NSString *)imgStr
{
    [APPDATA showLoader];
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        int check=[[responseObject objectForKey:@"error"]intValue];
        if (check==1)
        {
            [APPDATA hideLoader];
            
            [APPDATA ShowAlertWithTitle:@"" Message:ERROR_IMAGE_UPLOAD];
            [self pickerModalAction:@"lip"];
        }else{
            [APPDATA ShowAlertWithTitle:@"" Message:IMAGE_UPLOAD];
            [self getMyPhotosDetail];
        }
    };
    void (^failure)(NSError * error) = ^(NSError *error) {
        [APPDATA hideLoader];
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_IMAGE_UPLOAD];
        [self pickerModalAction:@"lip"];
    };
    NSDictionary *dict = @{@"key":API_KEY,@"method":API_PROFILE_ALBUM_ADD_UPDATE,@"profile_id":appDelegate.profilid_AppStr,@"url":imgStr
                           };
    [APICall sendToService:dict success:successed failure:failure];
}


- (void)fpPickerController:(FPPickerController *)pickerController
didFinishPickingMultipleMediaWithResults:(NSArray *)results
{
    //NSLog(@"FILES CHOSEN: %@", results);
    if (results.count == 0)
    {
        //NSLog(@"Nothing was picked.");
        return;
    }
    // Making a little carousel effect with the images
    [self.displayedImages removeAllObjects];
    for (FPMediaInfo *info in results)
    {
        // Check if uploaded file is an image to add it to carousel
        if (info.containsImageAtMediaURL)
        {
            postImageurl=[NSString stringWithFormat:@"%@",info.remoteURL];
            [self.displayedImages removeAllObjects];
            
            
            [self imgUpload:postImageurl];
            [APPDATA hideLoader];
            appDelegate.hideFooter=YES;
        }
        }
}
//Call when cancel button called

- (void)fpPickerControllerDidCancel:(FPPickerController *)pickerController
{
    // NSLog(@"FP Cancelled Open");
    [self dismissViewControllerAnimated:YES
                             completion:nil];
}
#pragma mark - FPSaveControllerDelegate Methods
- (void)        fpSaveController:(FPSaveController *)saveController
    didFinishSavingMediaWithInfo:(FPMediaInfo *)info
{
    //NSLog(@"FP finished saving with info %@", info);
    [self.fpSave dismissViewControllerAnimated:YES
                                    completion:nil];
}
- (void)fpSaveControllerDidCancel:(FPSaveController *)saveController
{
    // NSLog(@"FP Cancelled Save");
    [self.fpSave dismissViewControllerAnimated:YES
                                    completion:nil];
}
- (void)fpSaveController:(FPSaveController *)saveController
                didError:(NSError *)error
{
    // NSLog(@"FP Error: %@", error);
}
//------------------------------------------------------------------------------------------------------
#pragma Mark Post Close Button Action...-------------------------------------------------

//On tab button contestviewcontroller display
- (IBAction)btnContestTab:(id)sender {
    [APPDATA btnContestsPressedTab];
}

- (IBAction)btnphotoCancel:(id)sender {
    _photDisplayview.hidden=YES;
}

- (IBAction)btnCancelPressed:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
   
    _photDisplayview.hidden=YES;
}


@end
