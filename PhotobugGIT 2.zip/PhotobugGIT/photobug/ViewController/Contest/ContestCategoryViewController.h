//
//  ContestCategoryViewController.h
//  photobug
//
//   on 12/3/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ScrollViewController.h"
#import "Contest.h"

@interface ContestCategoryViewController : ScrollViewController
@property (nonatomic,strong) UIRefreshControl *refresh;
@property (strong, nonatomic) IBOutlet UICollectionView *collectionView;
@property (nonatomic,strong) IBOutlet UILabel *lblNoDataFound;
@property (strong, nonatomic) IBOutlet UIButton *menuButton;
@property (strong,nonatomic) IBOutlet UIView *viewSelected1;
@property (strong,nonatomic) IBOutlet UIView *viewSelected2;
@property (strong,nonatomic) IBOutlet UIView *viewSelected3;

- (IBAction)btnContestPressedTab:(id)sender;
- (IBAction)btnMyphotosPressedTab:(id)sender;
- (IBAction)btnuploadPressedTab:(id)sender;

@end
