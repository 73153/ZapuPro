//
//  PhotoPickerViewController.m
//  photobug
//
//   on 12/2/15.
//  Copyright © Photobug. All rights reserved.
//
#import "PhotoPickerViewController.h"
#import <FPPicker/FPPicker.h>
#import "SubmitAnEntryViewController.h"
#import "ApplicationData.h"
#import "APICall.h"
#import "ContestCategoryViewController.h"
#import "MyPhotosViewController.h"

@interface PhotoPickerViewController ()<FPSimpleAPIDelegate,FPPickerControllerDelegate,FPSaveControllerDelegate>
{
    NSString *postImageurl;
}
@property (nonatomic, strong) FPSaveController *fpSave;
@property (nonatomic, strong) UIPopoverController *myPopoverController;
@property (nonatomic, strong) NSMutableArray<UIImage *> *displayedImages;
@property (nonatomic, strong) FPTheme *theme;
@end

@implementation PhotoPickerViewController
@synthesize tabDisplayFlag,contest_idStr,image_idStr,tagName,captionStr;

- (void)viewDidLoad
{
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(sendBack) name:@"sendtoBack" object:nil];
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    if (_FlagForContest==YES)
    {
        _ViewForUploads.hidden=YES;
    }
    else
    {
        _ViewForUploads.hidden=NO;
        [self pickerModalAction:@"lip"];
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(backFromPicker) name:@"FromUpload" object:nil];
    }
    if ([appDelegate.tabDisplayAppFlag isEqualToString:@"1"])
    {
        _tabView.hidden=NO;
    }else{
       _tabView.hidden=YES;
    }
    [self.viewSelected1 setHidden:NO];
    [self.viewSelected2 setHidden:YES];
    [self.viewSelected3 setHidden:YES];
}

- (void)viewWillAppear:(BOOL)animated
{
    
    [super viewWillAppear:animated];
    //initData
}
- (void) backFromPicker {
    [self.navigationController popViewControllerAnimated:NO];
}
- (void)simpleAPI:(FPSimpleAPI *)simpleAPI requiresAuthenticationForSource:(FPSource *)source
{
    FPAuthController *authController = [[FPAuthController alloc] initWithSource:source];
    if (authController)
    {
        [self.navigationController pushViewController:authController animated:YES];
    }
    else
    {
        // NSLog(@"FPAuthController could not be instantiated.");
    }
}
#pragma mark filefilker Delegate...-------------------------------------------------

- (FPTheme *)theme
{
    if (!_theme)
    {
        FPTheme *theme = [FPTheme new];
        CGFloat hue = 0.5616;
        theme.navigationBarStyle = UIBarStyleBlack;
        theme.navigationBarBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.12 alpha:1.0];
        theme.navigationBarTintColor = [UIColor colorWithHue:hue saturation:0.1 brightness:0.98 alpha:1.0];
        theme.headerFooterViewTintColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.28 alpha:1.0];
        theme.headerFooterViewTextColor = [UIColor whiteColor];
        theme.tableViewBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.49 alpha:1.0];
        theme.tableViewSeparatorColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.38 alpha:1.0];
        theme.tableViewCellBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.49 alpha:1.0];
        theme.tableViewCellTextColor = [UIColor colorWithHue:hue saturation:0.1 brightness:1.0 alpha:1.0];
        theme.tableViewCellTintColor = [UIColor colorWithHue:hue saturation:0.3 brightness:0.7 alpha:1.0];
        theme.tableViewCellSelectedBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.18 alpha:1.0];
        theme.tableViewCellSelectedTextColor = [UIColor whiteColor];
        theme.uploadButtonBackgroundColor = [UIColor blackColor];
        theme.uploadButtonHappyTextColor = [UIColor yellowColor];
        theme.uploadButtonAngryTextColor = [UIColor redColor];
        _theme = theme;
    }
    return _theme;
}

- (NSMutableArray <UIImage *>*)displayedImages
{
    if (!_displayedImages)
    {
        _displayedImages = [NSMutableArray array];
    }
    return _displayedImages;
}
#pragma mark - Actions -------------------------------------------------
- (void)pickerModalAction:(NSString *)sender
{
    /*
     * Create the object
     */
    FPPickerController *fpController = [FPPickerController new];
    /*
     * Set the delegate
     */
    fpController.fpdelegate = self;
    /*
     * Apply theme
     */
    fpController.theme = self.theme;
    /*
     * Ask for specific data types. (Optional) Default is all files.
     */
    fpController.dataTypes = @[@"image/*", @"video/*"];
    /*
     * Select and order the sources (Optional) Default is all sources
     */
    //fpController.sourceNames = @[FPSourceImagesearch];
    /*
     * Enable multselect (Optional) Default is single select
     */
    fpController.selectMultiple = YES;
    /*
     * Specify the maximum number of files (Optional) Default is 0, no limit
     */
    fpController.maxFiles = 10;
    /*
     * Optionally disable the front camera mirroring (experimental)
     */
    fpController.disableFrontCameraLivePreviewMirroring = NO;
    fpController.modalPresentationStyle = UIModalPresentationPopover;
    /*
     * If controller will show in popover set popover size (iPad)
     */
    fpController.preferredContentSize = CGSizeMake(400, 500);
    fpController.typeLogin=sender;
    UIPopoverPresentationController *presentationController = fpController.popoverPresentationController;
    presentationController.permittedArrowDirections = UIPopoverArrowDirectionAny;
    //presentationController.sourceView = sender;
    // presentationController.sourceRect = [sender bounds];
    /*
     * Display it.
     */
    [self presentViewController:fpController
                       animated:NO
                     completion:nil];
}

- (IBAction)btnAlbumAction:(id)sender
{
            [self pickerModalAction:@"lip"];
    
}

- (IBAction)savingAction:(id)sender
{
    if (self.displayedImages.count == 0)
    {
        UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Nothing to Save"
                                                          message:@"Select an image first."
                                                         delegate:nil
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
        [message show];
        return;
    }
    UIImage *firstImage = self.displayedImages[0];
    NSData *imgData = UIImagePNGRepresentation(firstImage);
    /*
     * Create the object
     */
    self.fpSave = [FPSaveController new];
    /*
     * Set the delegate
     */
    self.fpSave.fpdelegate = self;
    /*
     * Apply theme
     */
    self.fpSave.theme = self.theme;
    /*
     * Select and order the sources (Optional) Default is all sources
     */
    //self.fpSave.sourceNames = @[FPSourceDropbox, FPSourceFacebook, FPSourceBox];
    /*
     * Set the data and data type to be saved.
     */
    self.fpSave.data = imgData;
    self.fpSave.dataType = @"image/png";
    self.fpSave.modalPresentationStyle = UIModalPresentationPopover;
    /*
     * If controller will show in popover set popover size (iPad)
     */
    self.fpSave.preferredContentSize = CGSizeMake(400, 500);
    UIPopoverPresentationController *presentationController = self.fpSave.popoverPresentationController;
    presentationController.permittedArrowDirections = UIPopoverArrowDirectionAny;
    presentationController.sourceView = sender;
    presentationController.sourceRect = [sender bounds];
    /*
     * Display it.
     */
    [self presentViewController:self.fpSave
                       animated:YES
                     completion:nil];
}

#pragma mark - FPPickerControllerDelegate Methods
- (void)fpPickerController:(FPPickerController *)pickerController
      didPickMediaWithInfo:(FPMediaInfo *)info
{
}
- (void)fpPickerController:(FPPickerController *)pickerController
didFinishPickingMediaWithInfo:(FPMediaInfo *)info
{
    // NSLog(@"FILE CHOSEN: %@", info);
    if (info)
    {
        if (info.containsImageAtMediaURL)
        {
            postImageurl=[NSString stringWithFormat:@"%@",info.remoteURL];
            [self.displayedImages removeAllObjects];
            if ([appDelegate.tabDisplayAppFlag isEqualToString:@"1"])
            {
                SubmitAnEntryViewController *viewController =(SubmitAnEntryViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"SubmitAnEntryViewController"];
                viewController.postImageurl=postImageurl;
                [APPDATA pushNewViewControllerFromContest:viewController];
                appDelegate.tabDisplayAppFlag=@"";
            }else{
                [self imgUpload:postImageurl];
            }
        }
        [self dismissViewControllerAnimated:YES
                                 completion:nil];
    }
    else
    {
    }
}
- (void)fpPickerController:(FPPickerController *)pickerController
didFinishPickingMultipleMediaWithResults:(NSArray *)results
{
    // NSLog(@"FILES CHOSEN: %@", results);
    if (results.count == 0)
    {
        //NSLog(@"Nothing was picked.");
        return;
    }
    // Making a little carousel effect with the images
    [self.displayedImages removeAllObjects];
    for (FPMediaInfo *info in results)
    {
        // Check if uploaded file is an image to add it to carousel
        if (info.containsImageAtMediaURL)
        {
            postImageurl=[NSString stringWithFormat:@"%@",info.remoteURL];
            [self.displayedImages removeAllObjects];
            if ([appDelegate.tabDisplayAppFlag isEqualToString:@"1"])
            {
                [self imgUpload:postImageurl];

                            }else{
                                SubmitAnEntryViewController *viewController =(SubmitAnEntryViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"SubmitAnEntryViewController"];
                                viewController.postImageurl=postImageurl;
                                [APPDATA pushNewViewController:viewController];
                                appDelegate.tabDisplayAppFlag=@"";

            }
        }
    }
    [self dismissViewControllerAnimated:YES
                             completion:nil];
}

- (void)fpPickerControllerDidCancel:(FPPickerController *)pickerController
{
    // NSLog(@"FP Cancelled Open");
    [self dismissViewControllerAnimated:YES
                             completion:nil];
}

#pragma mark - FPSaveControllerDelegate Methods
- (void)fpSaveController:(FPSaveController *)saveController
    didFinishSavingMediaWithInfo:(FPMediaInfo *)info
{
    //NSLog(@"FP finished saving with info %@", info);
    [self.fpSave dismissViewControllerAnimated:YES
                                    completion:nil];
}

- (void)fpSaveControllerDidCancel:(FPSaveController *)saveController
{
    //NSLog(@"FP Cancelled Save");
    [self.fpSave dismissViewControllerAnimated:YES
                                    completion:nil];
}

- (void)fpSaveController:(FPSaveController *)saveController
                didError:(NSError *)error
{
    //NSLog(@"FP Error: %@", error);
}

- (IBAction)cameraButtonACtion:(id)sender
{
    [self pickerModalAction:@"lip"];
}

-(void)sendBack
{
    [[self navigationController]popViewControllerAnimated:NO];
}
- (IBAction)cancelButtonAction:(id)sender
{
    [[self navigationController]popViewControllerAnimated:YES];
}

- (IBAction)myphotoTabbuttonAction:(id)sender
{
    MyPhotosViewController *viewController =(MyPhotosViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"MyPhotosViewController"];
    viewController.mainViewFl2=@"1";
    [[SlideNavigationController sharedInstance] pushViewController:viewController animated:NO];
}
- (IBAction)infoTabButtonAction:(id)sender
{
    [APPDATA btninfoPressedTab];
}
-(void)imgUpload:(NSString *)imgStr
{
    [APPDATA showLoader];
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        int check=[[responseObject objectForKey:@"error"]intValue];
        if (check==1)
        {
            [APPDATA ShowAlertWithTitle:@"" Message:ERROR_IMAGE_UPLOAD];
            [self pickerModalAction:@"lip"];
        }else{
            [APPDATA ShowAlertWithTitle:@"" Message:IMAGE_UPLOAD];
        }
        [APPDATA hideLoader];
    };
    void (^failure)(NSError * error) = ^(NSError *error) {
        [APPDATA hideLoader];
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_IMAGE_UPLOAD];
        [self pickerModalAction:@"lip"];
    };
    NSDictionary *dict = @{@"key":API_KEY,@"method":API_PROFILE_ALBUM_ADD_UPDATE,@"profile_id":appDelegate.profilid_AppStr,@"url":imgStr
                           };
    [APICall sendToService:dict success:successed failure:failure];
}
@end
