//
//  ContestLandingViewController.h
//  photobug
//
//   on 12/2/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "iCarousel.h"


@interface ContestLandingViewController : UIViewController
@property (nonatomic,strong) IBOutlet UIButton *btnBack;
@property (nonatomic,strong) NSMutableDictionary *dictTagDetail;
@property (nonatomic,strong) IBOutlet UIView *viewBottom;
@property (nonatomic,strong) IBOutlet UIButton *btnMenu;
@property (nonatomic,strong) IBOutlet UIImageView *imgLogo;
@property (nonatomic,strong) IBOutlet UIImageView *imgHeader;
@property (nonatomic,strong) IBOutlet UILabel *lblNoDataFound;
@property(nonatomic,strong)NSString *tagName;
@property (strong,nonatomic) IBOutlet UIView *viewSelected1;
@property (strong,nonatomic) IBOutlet UIView *viewSelected2;
@property (strong,nonatomic) IBOutlet UIView *viewSelected3;
@property (strong, nonatomic) IBOutlet UITableView *tblContest;

-(NSMutableAttributedString *)opensSemiBold:(NSString *)textStr11 :(NSString *)textStr9;
- (IBAction)btnBackACtion:(id)sender;
- (void)pickerModalAction:(NSString *)sender;
- (IBAction)btnContestPressedTab:(id)sender;
- (IBAction)btnMyphotosPressedTab:(id)sender;
- (IBAction)btnuploadPressedTab:(id)sender;
 -(IBAction)btnEnterContest:(id)sender;


@end
