//
//  SubmitAnEntryViewController.h
//  PhotoBugContestDemo
//
//   on 12/1/15.
//  Copyright © 2015 karishma. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZFTokenField.h"

@interface SubmitAnEntryViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate,ZFTokenFieldDataSource, ZFTokenFieldDelegate>
{
    NSMutableArray *pastUrls;
    NSMutableArray *autocompleteUrls;
    NSMutableArray *arytag;
    CGRect tblFrame;
 }
- (IBAction)goPressed ;
@property (nonatomic, retain) NSMutableArray *pastUrls;
@property (nonatomic, retain) NSMutableArray *autocompleteUrls;
@property (nonatomic, retain) NSMutableArray *arytag;
@property (nonatomic, strong) NSMutableArray *tokens;
@property (strong, nonatomic) IBOutlet ZFTokenField *tokenField;
@property (weak,nonatomic) IBOutlet UIImageView *imgEnterPhoto;
@property (weak,nonatomic) IBOutlet UITextField *txtAutumGreen;
@property (strong,nonatomic) IBOutlet UITextField *txtCreateCaption;
@property (strong, nonatomic) IBOutlet UITextField *AddTxtTag;
@property (strong, nonatomic) IBOutlet ZFTokenTextField *txtAddTag;
@property (weak,nonatomic) IBOutlet UIButton *btnAddtoShop;
@property (weak,nonatomic) IBOutlet UIButton *btnSubmitEntry;
@property (weak,nonatomic) IBOutlet UIButton *btnCancelEntry;
@property (strong, nonatomic) IBOutlet NSString *otherProfiletag;
@property (strong, nonatomic) IBOutlet UIView *tagView;
@property (strong, nonatomic) IBOutlet UIImageView *imgExp;
@property (strong, nonatomic) IBOutlet UILabel *ExpContEnt;
@property (strong, nonatomic) IBOutlet UILabel *lblcredit;
@property (strong, nonatomic) IBOutlet NSString *postImageurl;
@property (strong, nonatomic) IBOutlet NSString *strTag;
@property (strong, nonatomic) IBOutlet NSString *strCaption;
@property NSString *strimgEnterPhoto;
@property(strong ,nonatomic)NSString *tagName;
@property(strong ,nonatomic)NSString *contest_idStr;
@property(strong ,nonatomic)NSString *image_idStr;
@property(strong ,nonatomic)NSString *captionStr;
@property (strong, nonatomic) IBOutlet UIView *ExceptView;
@property (strong,nonatomic) IBOutlet UIView *viewSelected1;
@property (strong,nonatomic) IBOutlet UIView *viewSelected2;
@property (strong,nonatomic) IBOutlet UIView *viewtag;
@property (strong,nonatomic) IBOutlet UILabel *lbltagplaceholder;
@property (strong,nonatomic) IBOutlet UIView *viewSelected3;
@property (strong, nonatomic) IBOutlet UIImageView *addshopImg;
@property (strong,nonatomic) IBOutlet UIButton *btnMakeUrAcPrivate;
@property (nonatomic) BOOL isAvailable;
@property (strong, nonatomic) IBOutlet UILabel *lbladdtag;
@property (strong, nonatomic) IBOutlet UITableView *tblviewTag;
@property (nonatomic) NSURL *fullResolutionImageURL;

- (IBAction)btnAggAction:(id)sender;
- (void)searchAutocompleteEntriesWithSubstring:(NSString *)substring;
- (IBAction)btnCancelEntryTapped:(id)sender;
- (IBAction)btnSubmitEntryTapped:(id)sender;
- (IBAction)btnAddShopTapped:(id)sender;
- (IBAction) btninfoPressedTab:(id)sender;
- (IBAction)btnMyphotosPressedTab:(id)sender;
- (IBAction)btnuploadPressedTab:(id)sender;
- (IBAction)btnExceptAction:(id)sender;
- (IBAction)btnFeedAction:(id)sender;
-(void)displayTag;

@end
