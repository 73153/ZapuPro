//
//  PhotoDetailViewController.m
//  photobug
//
//   on 10/05/16.
//  Copyright © Photobug. All rights reserved.
//
#define kLabelFont [NSFont fontWithName:@"SourceSansPro-Regular" size:12.0f]
#define maxWidth 1000.0f
#import "PhotoDetailViewController.h"
#import "Constant.h"
#import "Users.h"
#import "ApplicationData.h"
#import "SubmitAnEntryViewController.h"
#import "UCZProgressView.h"
#import <UIActivityIndicator-for-SDWebImage/UIImageView+UIActivityIndicatorForSDWebImage.h>
#import "RecentEntriesViewController.h"
#import "InfoViewController.h"
#import "ANTagsView.h"


@interface PhotoDetailViewController ()<UICollectionViewDataSource,UICollectionViewDelegate,Delegate,UIScrollViewDelegate,protRecentdel>
{
    NSArray *aryContestMyPhotos;
    int pageNo;
    CGRect lblFrame,lblFrame2,lblFrame3,lblFrame4,lblFrame5;
    NSMutableArray *imgArray;
    BOOL first;
    NSInteger newPage;
    RecentEntriesViewController *objRecentVc;
    MyPhotosViewController *ObjPhotosVC;
    __block NSMutableArray *arrstring;
}

@end

@implementation PhotoDetailViewController
@synthesize mainViewFl,ProfileUserTabView;


//Scroll to nextpage  by swipegasture and display new images
-(void)scrollToNextPage
{
    int num=pageNo+1;
    int x=self.scrlOutView.contentOffset.x;
    [self.scrlOutView setContentOffset:CGPointMake(x+self.scrlOutView.frame.size.width, 0) animated:YES];
    
    if (_IsFlagForRecentEntries==YES)
    {
        [objRecentVc intRecentdata:num];
        pageNo++;
    }
    else
    {
        [ObjPhotosVC intdata:num];
        pageNo++;
    }
    [self setDynamicCollectionViewHeight];
    [self setTagList];
}
//Scroll previousPage by swipegasture and display previous images
-(void)scrollToPrevPage
{
    int num=pageNo-1;
    [self.scrlOutView setContentOffset:CGPointMake(num*self.scrlOutView.frame.size.width, 0) animated:YES];
    
    if (_IsFlagForRecentEntries==YES)
    {
        [objRecentVc intRecentdata:num];
        pageNo--;
    }
    else
    {
        [ObjPhotosVC intdata:num];
        pageNo--;
    }
    
    [self setTagList];
    
    
}


//Set tag in collectionview which is submited in submitentryviewcontroller
- (void) setTagList {
    for (ANTagsView *view in _scrollViewTag.subviews) {
        if (view
            ) {
            [view removeFromSuperview];
        }
    }
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    // Do any additional setup after loading the view, typically from a nib.
    __block NSMutableArray *arrTag = [[NSMutableArray alloc] init];
    [_ProfileAryForTag enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [arrTag addObject:[obj valueForKey:@"tagname"]];
    }];
    ANTagsView *tagsView = [[ANTagsView alloc] initWithTags:arrTag frame:CGRectMake(5, -20, screenRect.size.width - 10, 10)];
    [tagsView setTagBackgroundColor:[UIColor colorWithRed:82.0/255.0 green:95.0/255.0 blue:122.0/255.0 alpha:1]];
    [tagsView setTagTextColor: [UIColor colorWithRed:11.0/255.0 green:17.0/255.0 blue:30.0/255.0 alpha:1]];
    
    [tagsView setBackgroundColor:[UIColor clearColor]];
    
    [tagsView setFrameWidth:310];
    [self.scrollViewTag addSubview:tagsView];
    [self.scrollViewTag setContentSize:CGSizeMake(tagsView.frame.size.width,tagsView.frame.size.height-25)];
    if (tagsView.frame.size.height-25 > 45) {
        [self.viewMainTag setFrame:CGRectMake(self.viewMainTag.frame.origin.x, self.viewMainTag.frame.origin.y, self.viewMainTag.frame.size.width, 55)];
        [self.scrollViewTag setFrame:CGRectMake(self.viewMainTag.frame.origin.x, 0, self.viewMainTag.frame.size.width, 55)];
        _ViewBlue.frame=CGRectMake(_LblCaptionStr.frame.origin.x,self.viewMainTag.frame.origin.y+55, _ViewBlue.frame.size.width,_ViewBlue.frame.size.height);
    }
    else{
        [self.viewMainTag setFrame:CGRectMake(self.viewMainTag.frame.origin.x, self.viewMainTag.frame.origin.y, self.viewMainTag.frame.size.width, 34)];
    }
    _txtViewForTab.frame=CGRectMake(_ViewBlue.frame.origin.x, _ViewBlue.frame.origin.y+10, _txtViewForTab.frame.size.width,100);
}
- (void)viewDidLoad
{
    [[self navigationController] setNavigationBarHidden:YES animated:YES];
    [super viewDidLoad];
    
    //Swipegasture for slide images
    _scrlOutView.scrollEnabled = TRUE;
    _scrlOutView.pagingEnabled = TRUE;
    _scrlOutView.userInteractionEnabled=TRUE;
    UISwipeGestureRecognizer* swipe;
    
    swipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(scrollToNextPage)] ;
    swipe.direction = UISwipeGestureRecognizerDirectionLeft;
    [self.ViewForSWipe addGestureRecognizer:swipe];
    
    swipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(scrollToPrevPage)];
    swipe.direction = UISwipeGestureRecognizerDirectionRight; // default
    [self.ViewForSWipe addGestureRecognizer:swipe];
    
    
    pageNo = 1;
    _Dictrecententry = [[NSDictionary alloc]init];
    [self loadImage];
    [self SetFrame];
    if (_IsFlagForRecentEntries==YES)
    {
        _scrlOutView.contentSize = CGSizeMake(self.view.frame.size.width*APPDATA.recent.aryRecentImage.count-1,self.scrlOutView.frame.size.height);
        _scrlOutView.contentOffset= CGPointMake(self.view.frame.size.width*self.profileIdRecent, self.scrlOutView.frame.size.height);
    }
    else
    {
        _scrlOutView.contentSize = CGSizeMake(self.view.bounds.size.width*APPDATA.recent.aryMyphotoImage.count-1,self.scrlOutView.frame.size.height);
        _scrlOutView.contentOffset= CGPointMake(self.view.bounds.size.width*self.profileId, self.scrlOutView.frame.size.height);
    }
    NSLog(@"%@",APPDATA.user.strOtherId);
    int temp=[APPDATA.user.strOtherId intValue];
    if (temp<=0) {
        APPDATA.user.strOtherId=APPDATA.user.profileid;
    }
    if ([[NSString stringWithFormat:@"%@",APPDATA.user.strOtherId] isEqualToString:[NSString stringWithFormat:@"%@",APPDATA.user.profileid]])
    {
        [_DeleteBtn setTitle:@"DELETE IMAGE" forState:UIControlStateNormal];
    }
    else
    {
        [_DeleteBtn setTitle:@"FLAG IMAGE" forState:UIControlStateNormal];
    }
    if (IS_IPHONE6)
    {
        _txtViewForTab.frame=CGRectMake(_txtViewForTab.frame.origin.x ,_txtViewForTab.frame.origin.y ,_txtViewForTab.frame.size.width,120);
        
    }
    [_ProfileUserLbl setText:[[NSString stringWithFormat:@"%@",UDGetObject(@"username")] uppercaseString]];
    _LblCaptionStr.text=[NSString stringWithFormat:@"%@",_profileCaptionStr];
    NSString *codeR = [NSString stringWithFormat:@"%@",_profileAddShopDet];
    if ([codeR isEqualToString:@"1"])
    {
        _BtnAddToShopOutlet.hidden=NO;
        _BtnUnchekOutlet.hidden=NO;
    }
    else
    {
        _BtnAddToShopOutlet.hidden=YES;
        _BtnUnchekOutlet.hidden=YES;
    }
    [self SetCmntdata];
    
    if (_ProfileAryForTag.count==0) {
        if (IS_IPHONE5) {
            _LblCaptionStr.frame=CGRectMake(_ProfileUserLbl.frame.origin.x, _ProfileUserLbl.frame.origin.y+70, _LblCaptionStr.frame.size.width, _LblCaptionStr.frame.size.height);
            
            _ViewBlue.frame=CGRectMake(_LblCaptionStr.frame.origin.x, _LblCaptionStr.frame.origin.y+10, _ViewBlue.frame.size.width,_ViewBlue.frame.size.height);
            _LblTags.hidden=YES;
            _txtViewForTab.frame=CGRectMake(_ViewBlue.frame.origin.x, _ViewBlue.frame.origin.y+10, _txtViewForTab.frame.size.width,100);
            
        }
        else if (IS_IPHONE6)
        {
            _LblCaptionStr.frame=CGRectMake(_ProfileUserLbl.frame.origin.x, _ProfileUserLbl.frame.origin.y+70, _LblCaptionStr.frame.size.width, _LblCaptionStr.frame.size.height);
            
            _ViewBlue.frame=CGRectMake(_LblCaptionStr.frame.origin.x, _LblCaptionStr.frame.origin.y+30, _ViewBlue.frame.size.width,_ViewBlue.frame.size.height);
            _LblTags.hidden=YES;
            _txtViewForTab.frame=CGRectMake(_ViewBlue.frame.origin.x, _ViewBlue.frame.origin.y+20, _txtViewForTab.frame.size.width,120);
            
        }
        
        
    }
    else
    {
        [self GetFrame];
        self.view.autoresizesSubviews = YES;
        
        _LblTags.hidden=NO;
        _CollectionViewTag.delegate=self;
        _CollectionViewTag.dataSource=self;
        _CollectionViewTag.scrollEnabled=YES;
        [self.CollectionViewTag reloadData];
    }
    [_scrollview setContentSize:CGSizeMake(self.view.frame.size.width,500)];
    [_scrollview setScrollEnabled:TRUE];
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
    objRecentVc= (RecentEntriesViewController*)[mainStoryboard instantiateViewControllerWithIdentifier:@"RecentEntriesViewController"];
    objRecentVc.RecentProtoDelegate=self;
    ObjPhotosVC= (MyPhotosViewController*)[mainStoryboard instantiateViewControllerWithIdentifier:@"MyPhotosViewController"];
    ObjPhotosVC.ProtoDelegate=self;
    [self setDynamicCollectionViewHeight];
    [self setTagList];
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    [[SlideNavigationController sharedInstance] setEnableSwipeGesture:NO];
}
-(void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:YES];
    [self setDynamicCollectionViewHeight];
}
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:YES];
    [[SlideNavigationController sharedInstance] setEnableSwipeGesture:YES];
}
//Set frame during swiping and adjust frame
-(void)SetFrame
{
    lblFrame= CGRectMake(_ProfileUserLbl.frame.origin.x ,_ProfileUserLbl.frame.origin.y ,_ProfileUserLbl.frame.size.width, _ProfileUserLbl.frame.size.height);
    lblFrame2 = CGRectMake(_LblTags.frame.origin.x ,_LblTags.frame.origin.y ,_LblTags.frame.size.width, _LblTags.frame.size.height);
    lblFrame3 = CGRectMake(_txtViewForTab.frame.origin.x ,_txtViewForTab.frame.origin.y ,_txtViewForTab.frame.size.width, _txtViewForTab.frame.size.height);
    lblFrame4 = CGRectMake(_ViewBlue.frame.origin.x ,_ViewBlue.frame.origin.y ,_ViewBlue.frame.size.width, _ViewBlue.frame.size.height);
    lblFrame5=CGRectMake(_LblCaptionStr.frame.origin.x, _LblCaptionStr.frame.origin.y, _LblCaptionStr.frame.size.width, _LblCaptionStr.frame.size.height);
}
//Call when you adjust frame set again as it is.
-(void)GetFrame
{
    _ProfileUserLbl.frame= lblFrame;
    _LblTags.frame=lblFrame2;
    _txtViewForTab.frame= lblFrame3;
    _ViewBlue.frame=lblFrame4;
    _LblCaptionStr.frame=lblFrame5;
}
//Calls method when resetdata after swipe
-(void)AfterResetData
{
    _ProfileUserLbl.text=[NSString stringWithFormat:@"%@",UDGetObject(@"username")];
    _LblCaptionStr.text=[NSString stringWithFormat:@"%@",[_Dictrecententry valueForKey:@"caption"]];
    NSString *codeR = [NSString stringWithFormat:@"%@",[_Dictrecententry valueForKey:@"shopDet"]];
    if ([codeR isEqualToString:@"1"])
    {
        _BtnAddToShopOutlet.hidden=NO;
        _BtnUnchekOutlet.hidden=NO;
    }
    else
    {
        _BtnAddToShopOutlet.hidden=YES;
        _BtnUnchekOutlet.hidden=YES;
    }
    NSString *str=[_Dictrecententry valueForKey:@"imgStr"];
    
    str = [NSString stringWithFormat:@"%@/convert?w=700&h=700",str] ;
    _postImageurl=str;
    [self loadImage];
    _ProfileAryForTag = [[NSMutableArray alloc] init];
    NSArray *arr=[[NSArray alloc]init];
    
    arr =[_Dictrecententry valueForKey:@"tag"];
    
    
    if (arr.count==0) {
        if (IS_IPHONE5) {
            _LblCaptionStr.frame=CGRectMake(_ProfileUserLbl.frame.origin.x, _ProfileUserLbl.frame.origin.y+70, _LblCaptionStr.frame.size.width, _LblCaptionStr.frame.size.height);
            
            _ViewBlue.frame=CGRectMake(_LblCaptionStr.frame.origin.x, _LblCaptionStr.frame.origin.y+30, _ViewBlue.frame.size.width,_ViewBlue.frame.size.height);
            _LblTags.hidden=YES;
            _txtViewForTab.frame=CGRectMake(_ViewBlue.frame.origin.x, _ViewBlue.frame.origin.y+10, _txtViewForTab.frame.size.width,100);
            
        }
        else if (IS_IPHONE6)
        {
            
            _LblCaptionStr.frame=CGRectMake(_ProfileUserLbl.frame.origin.x, _ProfileUserLbl.frame.origin.y+70, _LblCaptionStr.frame.size.width, _LblCaptionStr.frame.size.height);
            
            _ViewBlue.frame=CGRectMake(_LblCaptionStr.frame.origin.x, _LblCaptionStr.frame.origin.y+30, _ViewBlue.frame.size.width,_ViewBlue.frame.size.height);
            _LblTags.hidden=YES;
            _txtViewForTab.frame=CGRectMake(_ViewBlue.frame.origin.x, _ViewBlue.frame.origin.y+20, _txtViewForTab.frame.size.width, 120);
            
        }
        
        
    }
    
    else
    {
        [self GetFrame];
        self.view.autoresizesSubviews = YES;
        
        _LblTags.hidden=NO;
        arr =[_Dictrecententry valueForKey:@"tag"];
        
        
        [_ProfileAryForTag addObjectsFromArray:arr];
    }
    _ProfileUserLbl.text=[[NSString stringWithFormat:@"%@",UDGetObject(@"username")] uppercaseString];
    _profileAryCmnt=[_Dictrecententry valueForKey:@"cmnt"];
    _ProfileImageId = [_Dictrecententry valueForKey:@"ID"];
    [self SetCmntdata];
    _CollectionViewTag.delegate=self;
    _CollectionViewTag.dataSource=self;
    [self.CollectionViewTag reloadData];
}
//Call method when image select from Myphotoviewcontroller
-(void)DictionaryforData:(NSDictionary *)DictData
{
    _Dictrecententry=DictData;
    [self AfterResetData];
    
}
//Call method when image select from RecentViewcontroller
-(void)DictionaryDataRecent:(NSDictionary *)data;
{
    _Dictrecententry=data;
    [self AfterResetData];
}
//Set comment
-(void)SetCmntdata
{
    [[self.txtViewForTab layer] setBorderColor:(__bridge CGColorRef _Nullable)([UIColor blackColor])];
    
    if (_profileAryCmnt.count!=0) {
        [_txtViewForTab setText:[NSString stringWithFormat:@"%@",[_profileAryCmnt objectAtIndex:0]]];
    }
    else
    {
        [_txtViewForTab setText:@"No Comments"];
        _txtViewForTab.editable = NO;
        
    }
}

//call when load image from connection delegate methods
- (void)loadImage {
    NSURL *url = [NSURL URLWithString:_postImageurl];
    [NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:url] delegate:self];
}

//Connection methods for image load with progressview
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    self.expectedBytes = response.expectedContentLength;
    if (self.expectedBytes>0) {
        self.data = [NSMutableData dataWithCapacity:self.expectedBytes];
        self.progressView.progress = 0.0;
        
    }
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [self.data appendData:data];
    double receivedBytes = self.data.length;
    self.progressView.progress = receivedBytes / self.expectedBytes;
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    self.bigImageView.image = [UIImage imageWithData:self.data];
    self.progressView.progress = 1.0;
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    self.progressView.progress = 1.0;
}
#pragma collectionView delegates
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _ProfileAryForTag.count;
}

-(void)collectionView:(UICollectionView *)collectionView didEndDisplayingCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath
{
    first=YES;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"Cell";
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    UILabel *textLabel=(UILabel *)[cell viewWithTag:100];
    arrstring= [[NSMutableArray alloc] init];
    
    [_ProfileAryForTag enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [arrstring addObject:[obj valueForKey:@"tagname"]];
    }];
    if (arrstring.count!=0) {
        
        [textLabel setText:[[arrstring objectAtIndex:indexPath.row]uppercaseString]];
    }
    
    
    return cell;
}
//When change width of string for tag which is display in collection view
- (CGFloat)widthOfString:(NSString *)string{
    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:13.0f], NSFontAttributeName, nil];
    return [[[NSAttributedString alloc] initWithString:[APPDATA isNullOrEmpty:string] attributes:attributes] size].width;
}
//When hight of string for tag which is display in collection view
-(CGFloat)hightOfString:(NSString *)string
{
    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:13.0f], NSFontAttributeName, nil];
    return [[[NSAttributedString alloc] initWithString:[APPDATA isNullOrEmpty:string] attributes:attributes] size].height;
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    arrstring = [[NSMutableArray alloc] init];
    [_ProfileAryForTag enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [arrstring addObject:[obj valueForKey:@"tagname"]];
    }];
    CGSize cellSize;
    if (arrstring.count!=0) {
        
        CGFloat sizew = [self widthOfString:[[arrstring objectAtIndex:indexPath.row] uppercaseString]];
        CGFloat sizew2 = [self hightOfString:[[arrstring objectAtIndex:indexPath.row] uppercaseString]];
        cellSize =CGSizeMake(sizew+30, sizew2+12);
    }
    return cellSize;
    
}
//call when change of collectionview hight
-(void)setDynamicCollectionViewHeight {
    
    NSInteger totalItems = [_CollectionViewTag numberOfItemsInSection:0];
    // How many items are there per row?
    if (totalItems>0) {
        
        NSInteger currItem;
        CGFloat currRowOriginY = CGFLOAT_MAX;
        for (currItem = 0; currItem < totalItems; currItem++) {
            UICollectionViewLayoutAttributes *attributes =
            [_CollectionViewTag.collectionViewLayout layoutAttributesForItemAtIndexPath:
             [NSIndexPath indexPathForItem:currItem inSection:0]];
            
            if (currItem == 0) {
                currRowOriginY = attributes.frame.origin.y;
                continue;
            }
            
            if (attributes.frame.origin.y > currRowOriginY + 5.0f) {
                break;
            }
        }
        
        NSLog(@"new row started at item %ld", (long)currItem);
        
        
        CGSize size =  _CollectionViewTag.contentSize;
        NSLog(@"%f",size.height);
        if (size.height > 70)
        {
            _CollectionViewTag.frame = CGRectMake(_CollectionViewTag.frame.origin.x,_CollectionViewTag.frame.origin.y,_CollectionViewTag.frame.size.width,70);
            _ViewBlue.frame=CGRectMake(_LblCaptionStr.frame.origin.x, _CollectionViewTag.frame.origin.y+100, _ViewBlue.frame.size.width,_ViewBlue.frame.size.height);
        } else
        {
            _CollectionViewTag.frame = CGRectMake(_CollectionViewTag.frame.origin.x,_CollectionViewTag.frame.origin.y,_CollectionViewTag.frame.size.width,35);
            _ViewBlue.frame=CGRectMake(_LblCaptionStr.frame.origin.x, _CollectionViewTag.frame.origin.y+_CollectionViewTag.frame.size.height+ 10, _ViewBlue.frame.size.width,_ViewBlue.frame.size.height);
        }
        _txtViewForTab.frame=CGRectMake(_ViewBlue.frame.origin.x, _ViewBlue.frame.origin.y+10, _txtViewForTab.frame.size.width,100);
        [_CollectionViewTag reloadData];
    }
    
    
}
//Method call for spacing between text and collectionview
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionView *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    return 1;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

NSInteger currentPage;
//Scrollview for swipe
-(void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset
{
    if (scrollView == self.scrlOutView) {
        
        int pageNum = (int)(self.scrlOutView.contentOffset.x / self.view.bounds.size.width);
        newPage =pageNum;
        NSLog(@"%ld",(long)newPage);
        if (newPage!=currentPage) {
            
            if (_IsFlagForRecentEntries==YES)
            {
                if (newPage>APPDATA.recent.aryRecentImage.count-1)
                {
                }
                else
                {
                    
                    if (newPage < 0)
                        newPage = 0;
                    [self resolveContentOffsetForPage:newPage];
                }
            }
            else
            {
                if (newPage>APPDATA.recent.aryMyphotoImage.count-1)
                {
                }
                else
                {
                    [self resolveContentOffsetForPage:newPage];
                }
            }
        }
        currentPage = newPage;
        [self setDynamicCollectionViewHeight];
        [self setTagList];
    }
    
    
}


-(void)resolveContentOffsetForPage:(NSInteger)page
{
    
    if (_IsFlagForRecentEntries==YES)
    {
        [objRecentVc intRecentdata:page];
    }
    else
    {
        [ObjPhotosVC intdata:page];
    }
    [self setDynamicCollectionViewHeight];
    
}
#pragma mark Tab button action...
- (IBAction) btninfoPressedTab:(id)sender {
    InfoViewController *viewController =(InfoViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"InfoViewController"];
    [APPDATA pushNewViewController:viewController];
    
}
//tab button Upload action
- (IBAction)btnuploadPressedTab:(id)sender {
    [APPDATA btnuploadPressedTab];
}
- (IBAction)btnuploadPhotoTab:(id)sender {
    [APPDATA btnuploadPressedTab];
}
//tab button contest action perform
- (IBAction)btnContestTab:(id)sender {
    [APPDATA btnContestsPressedTab];
}
//tab button myphotos action perform
- (IBAction)btnMyphotosPressedTab:(id)sender {
    [APPDATA btnMyphotoPressedTab];
}
//On cancel button pressed action perform
- (IBAction)btnCancelPressed:(id)sender {
    [self.navigationController popViewControllerAnimated:NO];
}
-(void)DeleteMethod
{
    
}
//Call method when flag image
- (void) flageImage:(NSString*)strFlag index:(NSInteger)index {
    @try {
        [APPDATA showLoader];
        RecentEntries *recent = [[RecentEntries alloc] init];
        recent.imageId=[[NSString stringWithFormat:@"%@",_ProfileImageId]mutableCopy];
        recent.profileid=[[NSString stringWithFormat:@"%@",APPDATA.user.strOtherId] mutableCopy];
        recent.flaggedbyId=[[NSString stringWithFormat:@"%@",APPDATA.user.profileid]mutableCopy];
        [recent flageImage:^(NSDictionary *dict, NSString *result, int status)
         {
             if (status == 1)
             {
                 
                 [APPDATA hideLoader];
                 
                 NSLog(@"success");
                 [APPDATA ShowAlertWithTitle:@"" Message:@"Comment Flagged Successfully"];
                 
                 NSInteger inte=_profileIdRecent+1;
                 [objRecentVc intRecentdata:inte++];
             }
             else {
                 NSString *strmsg=[APPDATA isValueNullOrEmpty:[NSString stringWithFormat:@"%@",result]];
                 [APPDATA ShowAlertWithTitle:@"" Message:strmsg];
                 
                 
                 NSLog(@"Failed");
                 [APPDATA hideLoader];
             }
         }];
        
    }
    @catch (NSException *exception) {
        
    }
    @finally {
        
    }
    
}
//Call method when image displayed from recententry
-(void)deleteImage:(NSString*)strFlag index:(NSInteger)index
{
    
    @try {
        RecentEntries *recent = [[RecentEntries alloc] init];
        if (_IsFlagForRecentEntries==YES)
        {
            [APPDATA showLoader];
            
            recent.imageId=[[NSString stringWithFormat:@"%@",_ProfileImageId]mutableCopy];
            
            [recent deleteImageFromDashboard:^(NSDictionary *dict, NSString *result, int status)
             {
                 if (status == 1) {
                     
                     [APPDATA hideLoader];
                     
                     NSLog(@"success");
                     
                     
                     
                     NSInteger inte=_profileIdRecent+1;
                     if (inte>APPDATA.recent.aryRecentImage.count) {
                         inte=0;
                     }
                     [objRecentVc intRecentdata:inte++];
                 }
                 else {
                     NSString *strmsg=[APPDATA isValueNullOrEmpty:[NSString stringWithFormat:@"%@",result]];
                     [APPDATA ShowAlertWithTitle:@"" Message:strmsg];
                     
                     
                     NSLog(@"Failed");
                     [APPDATA hideLoader];
                 }
             }];
            
        }
        else
        {
            
            [APPDATA showLoader];
            
            RecentEntries *recent = [[RecentEntries alloc] init];
            recent.imageId=[[NSString stringWithFormat:@"%@",_ProfileImageId]mutableCopy];
            
            [recent deleteImageFromDashboard:^(NSDictionary *dict, NSString *result, int status)
             {
                 int del;
                 if (!_profileId) {
                     del=appDelegate.pageChangeNo;
                 }
                 else
                 {
                     del=(int)_profileId;
                 }
                 
                 @try {
                     if (status == 1)
                     {
                         
                         [APPDATA hideLoader];
                         NSLog(@"success");
                         NSInteger inte1=del+1;
                         if (inte1>=APPDATA.recent.aryMyphotoImage.count)
                         {
                             inte1=0;
                         }
                         [ObjPhotosVC intdata:inte1++];
                     }
                     
                     else {
                         
                         NSLog(@"Failed");
                         NSString *strmsg=[APPDATA isValueNullOrEmpty:[NSString stringWithFormat:@"%@",result]];
                         [APPDATA ShowAlertWithTitle:@"" Message:strmsg];
                         
                         
                         [APPDATA hideLoader];
                     }
                 }
                 @catch (NSException *exception)
                 
                 {
                 }
                 @finally
                 {
                 }
                 
                 
             }];
            
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

//Alertview display and on Ok button action delete image based on id
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0)
    {
        NSInteger inte;
        if ([[NSString stringWithFormat:@"%@",APPDATA.user.strOtherId] isEqualToString:[NSString stringWithFormat:@"%@",APPDATA.user.profileid]]) {
            
            if (_IsFlagForRecentEntries==YES)
            {
                [self deleteImage:_ProfileImageId index:inte];
            }
            else
            {
                [self deleteImage:_ProfileImageId index:inte];
            }
        }
        else
        {
            
            [self flageImage:[NSString stringWithFormat:@"%@",_ProfileImageId] index:inte];
            
        }
    }
}

//Cross button is for delete or flag image
- (IBAction)CrossButton:(id)sender
{
    if ([[NSString stringWithFormat:@"%@",APPDATA.user.strOtherId] isEqualToString:[NSString stringWithFormat:@"%@",APPDATA.user.profileid]]) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Delete Image" message:DELETE_IMAGE delegate:self          cancelButtonTitle:@"Yes" otherButtonTitles:@"No",nil];
        [alert show];
    }
    else {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Flage Image" message:FLAG_IMAGE delegate:self          cancelButtonTitle:@"Yes" otherButtonTitles:@"No",nil];
        [alert show];
    }
    
}
@end
