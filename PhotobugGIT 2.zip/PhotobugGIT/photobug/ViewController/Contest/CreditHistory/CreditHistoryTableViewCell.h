//
//  CreditHistoryTableViewCell.h
//  photobug
//
//   on 1/1/16.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CreditHistoryViewController.h"

@interface CreditHistoryTableViewCell : UITableViewCell

@property (nonatomic,strong) IBOutlet UILabel *lblType;
@property (nonatomic,strong) IBOutlet UILabel *lblCredit;
@property (nonatomic,strong) IBOutlet UILabel *lblCreditDate;

@end
