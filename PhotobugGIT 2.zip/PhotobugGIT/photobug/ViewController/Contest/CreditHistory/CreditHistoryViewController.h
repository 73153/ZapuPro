//
//  CreditHistoryViewController.h
//  photobug
//
//   on 01/01/16.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreditHistoryViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong) IBOutlet UITableView *tableView;
@property (strong, nonatomic) IBOutlet UIButton *menuButton;
@property (strong,nonatomic)  NSMutableArray *aryCreditHistory;

@end
