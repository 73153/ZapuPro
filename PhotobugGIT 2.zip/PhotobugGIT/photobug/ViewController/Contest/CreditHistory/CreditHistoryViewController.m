//
//  CreditHistoryViewController.m
//  photobug
//
//   on 01/01/16.
//  Copyright © Photobug. All rights reserved.
//
#import "CreditHistoryViewController.h"
#import "SlideNavigationController.h"
#import "APICall.h"
#import "Constant.h"
#import "ApplicationData.h"
#import "CreditHistoryTableViewCell.h"
#import "MyDashboardViewController.h"

@interface CreditHistoryViewController ()
@end

@implementation CreditHistoryViewController
@synthesize aryCreditHistory;

- (void)viewDidLoad
{
    [super viewDidLoad];
    [_menuButton addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleRightMenu) forControlEvents:UIControlEventTouchUpInside];
    // Do any additional setup after loading the view.
    [self criditHistoryMethod];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnBackAction:(id)sender
{
    MyDashboardViewController *objDashboardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MyDashboardViewController"];
    [APPDATA turnBackToAnOldViewController:objDashboardViewController];
}

-(void)criditHistoryMethod
{
    [APPDATA showLoader];
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        self.aryCreditHistory=[responseObject objectForKey:@"data"];
        [self.tableView reloadData];
        [APPDATA hideLoader];
    };
    void (^failure)(NSError * error) = ^(NSError *error) {
        [APPDATA hideLoader];
    };
    NSDictionary  *dict = @{@"key":API_KEY,@"profile_id":APPDATA.user.profileid,@"method":API_CREDIT_HISTORY
                            };
    [APICall sendToService:dict success:successed failure:failure];
}

#pragma mark Tableview Delegate ....
-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section
{
   return [aryCreditHistory count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableId=@"cell";
    CreditHistoryTableViewCell *cell=(CreditHistoryTableViewCell*)[tableView dequeueReusableCellWithIdentifier:simpleTableId];
    if (cell == nil) {
        cell = [[CreditHistoryTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:simpleTableId];
    }
    NSDictionary *dict = [self.aryCreditHistory objectAtIndex:indexPath.row];
    cell.lblType.text = [dict objectForKey:@"type"];
    cell.lblCredit.text = [NSString stringWithFormat:@"%@",[dict objectForKey:@"amount"]];
    return cell;
}
@end
