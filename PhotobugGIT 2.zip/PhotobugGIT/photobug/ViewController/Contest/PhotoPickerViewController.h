//
//  PhotoPickerViewController.h
//  photobug
//
//   on 12/2/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constant.h"

@interface PhotoPickerViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIView *ViewForUploads;
@property(strong ,nonatomic)NSString *tabDisplayFlag;
@property(strong ,nonatomic)NSString *contest_idStr;
@property(strong ,nonatomic)NSString *image_idStr;
@property(strong ,nonatomic)NSString *tagName;
@property(strong ,nonatomic)NSString *captionStr;
@property(strong,nonatomic)IBOutlet UIView *viewSelected1;
@property(strong,nonatomic)IBOutlet UIView *viewSelected2;
@property(strong,nonatomic)IBOutlet UIView *viewSelected3;
@property (strong, nonatomic) IBOutlet UIView *tabView;
@property BOOL FlagForContest;

- (void)pickerModalAction:(NSString *)sender;
- (IBAction)btnAlbumAction:(id)sender;

@end
