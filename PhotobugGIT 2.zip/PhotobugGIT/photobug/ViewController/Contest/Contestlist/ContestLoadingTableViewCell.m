//
//  ContestLoadingTableViewCell.m
//  photobug
//
//   on 2/3/16.
//  Copyright © Photobug. All rights reserved.
//

#import "ContestLoadingTableViewCell.h"

@implementation ContestLoadingTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
