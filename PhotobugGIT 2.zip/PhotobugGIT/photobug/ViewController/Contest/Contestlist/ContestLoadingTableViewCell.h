//
//  ContestLoadingTableViewCell.h
//  photobug
//
//   on 2/3/16.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContestLoadingTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIButton *btnEnterContest;
@property (strong, nonatomic) IBOutlet UILabel *lblContestLabel;
@property (strong, nonatomic) IBOutlet UIButton *btnCridit;
@property (strong, nonatomic) IBOutlet UILabel *lblCountEnters;
@property (strong, nonatomic) IBOutlet UIImageView *imgContest;
@property (strong, nonatomic) IBOutlet UILabel *lblDecs;

@end
