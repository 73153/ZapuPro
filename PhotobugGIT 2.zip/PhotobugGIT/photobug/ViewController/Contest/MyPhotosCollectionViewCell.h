//
//  MyPhotosCollectionViewCell.h
//  photobug
//
//   on 19/07/16.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyPhotosCollectionViewCell : UICollectionViewCell
@property (strong, nonatomic) IBOutlet UIButton *Tineyebtn;
@property (strong, nonatomic) IBOutlet UIButton *TineEyeBtnForEntri;

@end
