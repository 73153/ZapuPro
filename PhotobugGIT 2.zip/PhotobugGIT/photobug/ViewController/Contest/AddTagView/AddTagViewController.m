//
//  AddTagViewController.m
//  photobug
//
//   on 2/10/16.
//  Copyright © Photobug. All rights reserved.
//
#import "AddTagViewController.h"
#import "ApplicationData.h"
#import "APICall.h"
#import "Constant.h"
#import "Contest.h"
#import "AddTagTableViewCell.h"
#import "SubmitAnEntryViewController.h"

@interface AddTagViewController ()
{
    NSArray *arrTagData;
    NSMutableArray *checkMarkArray;
    NSMutableArray *SelectArray;
}
@end

@implementation AddTagViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    APPDATA.contest.selectTagArray = [[NSMutableArray alloc] init];
    APPDATA.contest. selectTagNameArray=[[NSMutableArray alloc]init];
    [self AllTagMethod];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)AllTagMethod{
    [APPDATA showLoader];
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        checkMarkArray=[[NSMutableArray alloc]init];
        APPDATA.contest.selectTagArray=[[NSMutableArray alloc]init];
        APPDATA.contest. selectTagNameArray=[[NSMutableArray alloc]init];
        arrTagData = [responseObject valueForKey:@"data"];
        [_tblTag reloadData];
        if (arrTagData>0) {
            for (int i=0; i<arrTagData.count; i++)
            {
                [checkMarkArray addObject:@"0"];
            }
        }
        [APPDATA hideLoader];
    };
    void (^failure)(NSError * error) = ^(NSError *error) {
        [APPDATA hideLoader];
    };
    NSDictionary *dict = @{@"key":API_KEY,@"method":API_CONTEST_NEW_TAGS
                           };
    [APICall sendToService:dict success:successed failure:failure];
}

#pragma mark table view delegate
-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section
{
    return arrTagData.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableId=@"AddTagTableViewCell";
    AddTagTableViewCell *cell=(AddTagTableViewCell*)[_tblTag dequeueReusableCellWithIdentifier:simpleTableId];
    if (cell == nil) {
        cell = [[AddTagTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableId];
    }
    NSLog(@"%@",[NSString stringWithFormat:@"%@",[[arrTagData objectAtIndex:indexPath.row] valueForKey:@"tagname"]]);
    cell.lblTagname.text=[NSString stringWithFormat:@"%@",[[arrTagData objectAtIndex:indexPath.row] valueForKey:@"tagname"]];
    NSString *checkStr=[NSString stringWithFormat:@"%@",[checkMarkArray objectAtIndex:indexPath.row]];
    if ([checkStr isEqualToString:@"0"])
    {
        [cell.imgSelect setImage:[UIImage imageNamed:@"uncheck"]];
    }else{
        [cell.imgSelect setImage:[UIImage imageNamed:@"check"]];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *checkStr=[NSString stringWithFormat:@"%@",[checkMarkArray objectAtIndex:indexPath.row]];
    if ([checkStr isEqualToString:@"0"])
    {
        [checkMarkArray replaceObjectAtIndex: indexPath.row withObject: @"1"];
    }else{
        [checkMarkArray replaceObjectAtIndex: indexPath.row withObject: @"0"];
    }
    [_tblTag reloadData];
}

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.view removeFromSuperview];
}

- (IBAction)btnOk:(id)sender {
    for (int i=0; i<checkMarkArray.count; i++)
    {
        NSString *checkStr=[NSString stringWithFormat:@"%@",[checkMarkArray objectAtIndex:i]];
        if ([checkStr isEqualToString:@"1"])
        {
            [APPDATA.contest.selectTagArray addObject:[NSString stringWithFormat:@"%@",[[arrTagData objectAtIndex:i] valueForKey:@"id"]]];
            [APPDATA.contest. selectTagNameArray addObject:[NSString stringWithFormat:@"%@",[[arrTagData objectAtIndex:i] valueForKey:@"tagname"]]];
        }
    }
    if ([_txtNewtag.text length]>0)
    {
        [APPDATA.contest.selectTagArray addObject:_txtNewtag.text];
        [APPDATA.contest. selectTagNameArray addObject:_txtNewtag.text];
    }
  
    [[NSNotificationCenter defaultCenter] postNotificationName:@"Message"  object:nil userInfo:nil];
    [self.view removeFromSuperview];
}
@end
