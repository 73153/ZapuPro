//
//  AddTagTableViewCell.h
//  photobug
//
//   on 2/10/16.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddTagTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblTagname;
@property (strong, nonatomic) IBOutlet UIImageView *imgSelect;
@property (strong, nonatomic) IBOutlet UILabel *lblTagName;

@end
