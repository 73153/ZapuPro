//
//  AddTagViewController.h
//  photobug
//
//   on 2/10/16.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddTagViewController : UIViewController

@property (strong, nonatomic) IBOutlet UITableView *tblTag;
@property (strong, nonatomic) IBOutlet UITextField *txtNewtag;

- (IBAction)btnOk:(id)sender;
-(void)AllTagMethod;

@end
