//
//  AddTagTableViewCell.m
//  photobug
//
//   on 2/10/16.
//  Copyright © Photobug. All rights reserved.
//

#import "AddTagTableViewCell.h"

@implementation AddTagTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
