//
//  MyPhotosCollectionViewCell.m
//  photobug
//
//   on 19/07/16.
//  Copyright © Photobug. All rights reserved.
//

#import "MyPhotosCollectionViewCell.h"

@implementation MyPhotosCollectionViewCell
- (IBAction)Tineyebtn:(id)sender
{
}

@end
