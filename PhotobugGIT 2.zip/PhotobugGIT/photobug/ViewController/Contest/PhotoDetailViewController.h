//
//  PhotoDetailViewController.h
//  photobug
//
//   on 10/05/16.
//  Copyright © Photobug. All rights reserved.
//

#import "ScrollViewController.h"
#import <UCZProgressView.h>
#import "MyPhotosViewController.h"
@interface PhotoDetailViewController : ScrollViewController

@property BOOL IsFlagForRecentEntries ,Call;
;
@property (strong, nonatomic) IBOutlet UICollectionView *CollectionViewTag;
@property (strong, nonatomic) IBOutlet UILabel *ProfileUserLbl;
@property(strong,nonatomic)NSString*profilidStr,*profileCaptionStr,*ProfileUserStr,*profileAddShopDet,*ProfileImageId,*ProfileRecentImageId;
@property(nonatomic,strong)NSString *mainViewFl;
@property(nonatomic,strong)NSMutableArray *ProfileAryForTag,*profileAryCmnt;
@property(nonatomic,strong)NSMutableArray *DictObjContestData;
@property NSDictionary *Dictrecententry;
@property (strong, nonatomic) IBOutlet UIView *contest_TabView;
@property (strong, nonatomic) IBOutlet UITableView *ProfileUserTabView;
@property (nonatomic) IBOutlet UCZProgressView *progressView;
@property (nonatomic) NSMutableData *data;
@property (nonatomic) double expectedBytes;
@property (strong, nonatomic) IBOutlet UIView *mainTabview;
@property (strong, nonatomic) IBOutlet UIImageView *bigImageView;
@property (strong,nonatomic) IBOutlet UIView *viewSelected2;
@property (strong,nonatomic) IBOutlet UIView *viewSelected;
@property (strong, nonatomic) IBOutlet UIButton *menuButton;
@property (strong, nonatomic) IBOutlet UILabel *lblnavTit;
@property (strong, nonatomic) IBOutlet UIButton *backButton;
@property (strong, nonatomic) IBOutlet UIImageView *titLogo;
@property (strong, nonatomic) IBOutlet NSString *postImageurl;
@property NSInteger profileId,profileDetailId,profileIdRecent;
@property (strong, nonatomic) IBOutlet UIButton *BtnAddToShopOutlet;
@property (strong, nonatomic) IBOutlet UIScrollView *scrlOutView;
@property (strong, nonatomic) IBOutlet UIImageView *BtnUnchekOutlet;
@property (strong, nonatomic) IBOutlet UIView *ViewForSWipe;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollview;
@property (strong, nonatomic) IBOutlet UILabel *CaptionLbl;
@property (strong, nonatomic) IBOutlet UITextView *txtViewForTab;
@property (strong, nonatomic) IBOutlet UIButton *DeleteBtn;
@property (strong, nonatomic) IBOutlet UILabel *LblTags;
@property (strong, nonatomic) IBOutlet UILabel *LblCaptionStr;
@property (strong, nonatomic) IBOutlet UILabel *titleCaption;
@property (strong, nonatomic) IBOutlet UIView *ViewBlue;
@property (nonatomic,strong) IBOutlet UIView *viewMainTag;
@property (nonatomic,strong) IBOutlet UIView *viewInnerTag;
@property (nonatomic,strong) IBOutlet UIScrollView *scrollViewTag;

- (IBAction)CrossButton:(id)sender;
- (IBAction)btninfoPressedTab:(id)sender;
- (IBAction)btnMyphotosPressedTab:(id)sender;
- (IBAction)btnuploadPressedTab:(id)sender;
- (IBAction)btnuploadPhotoTab:(id)sender;
- (IBAction)btnContestTab:(id)sender;

 @end
