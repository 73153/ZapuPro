//
//  PickerTabViewController.m
//  photobug
//
//   on 12/3/15.
//  Copyright © Photobug. All rights reserved.
//

#import "PickerTabViewController.h"

@interface PickerTabViewController ()

@end

@implementation PickerTabViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
