//
//  RecentEntriesViewController.m
//  photobug
//
//   on 11/19/15.
//  Copyright © Photobug. All rights reserved.
//
#import "PhotoDetailViewController.h"
#import "MyPhotosViewController.h"
#import "RecentEntriesViewController.h"
#import "Constant.h"
#import "Users.h"
#import "ApplicationData.h"
#import "RecentDatilsViewController.h"
#import <UIActivityIndicator-for-SDWebImage/UIImageView+UIActivityIndicatorForSDWebImage.h>
#import "MyPhotosCollectionViewCell.h"

#define IMAGE_VIEW_TAG 999

@interface RecentEntriesViewController ()<UICollectionViewDataSource,UICollectionViewDelegate>
{
    NSArray *recentImages;
    int pageNo;
  PhotoDetailViewController *objPhotos;
    MyPhotosViewController *ObjPhotosVC;
}
@end

@implementation RecentEntriesViewController

@synthesize profilidStr,RecentProtoDelegate;

- (void)viewDidLoad {
    [super viewDidLoad];
    _collectionView.bounces=NO;
    pageNo = 1;
    _DictDataForRecentEntr=[[NSDictionary alloc]init];
   
}
//API Call for Getting RecentEntries image Data
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self getRecentEntry];
}
// Manage and show data according to page pass in API
-(void)intdata:(NSInteger)pagechange
{
    if (pagechange < 0 && pagechange > APPDATA.recent.arycontestsMyPhotosImage.count-1)
    {
        
        
    }
    else
    {
        NSString *imagestr=[NSString stringWithFormat:@"%@",[APPDATA.recent.arycontestsMyPhotosImage objectAtIndex:pagechange]];
        
        NSDictionary *fix=@{@"imgStr":imagestr,@"caption":[APPDATA.recent.aryContestsComment objectAtIndex:pagechange],@"tag":[[APPDATA.recent.aryContestsTag objectAtIndex:pagechange]valueForKey:@"tagname"],@"cmnt":[APPDATA.recent.aryConstentCmnt objectAtIndex:pagechange],@"shopDet":[APPDATA.recent.aryAddShop objectAtIndex:pagechange],@"userStr":[APPDATA.recent.aryConstentUser objectAtIndex:pagechange]};
        NSLog(@"%@",fix);
    }
    
    
}
#pragma mark Reload Data ....
- (void)reloadData {
    if (APPDATA.recent.lastPage > pageNo)
    {
        pageNo = pageNo+1;
        [self getRecentEntry];
    }
    [self.collectionView reloadData];
}

#pragma mark Get Recent Entry Method ..
- (void) getRecentEntry {
    [APPDATA showLoader];
    RecentEntries *recent = [[RecentEntries alloc] init];
    recent.profileid = [profilidStr mutableCopy];
    recent.filter_by = [[NSString stringWithFormat:@"%d",1]mutableCopy];
    [recent getRecentEntriesImage:^(NSDictionary *result, NSString *str, int status)
     {
         _DictDataForRecentEntr=result;
         if (status == 1)
         {
             if (APPDATA.recent.aryRecentImage.count == 0){
                 self.lblNoDataFound.hidden = NO;
                 CGRect frame = self.lblNoDataFound.frame;
                 frame.origin.y = (self.view.superview.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
                 [self.lblNoDataFound setFrame:frame];
                 [self.collectionView reloadData];
             }
             else
             {
                 self.lblNoDataFound.hidden = YES;
                 [self.collectionView reloadData];
             }
             [APPDATA hideLoader];
         }
         else {
             [APPDATA hideLoader];
             self.lblNoDataFound.hidden = NO;
             CGRect frame = self.lblNoDataFound.frame;
             frame.origin.y = (self.view.superview.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
             [self.lblNoDataFound setFrame:frame];
         }
     }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark collectionView delegate method...
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    NSLog(@"%lu",(unsigned long)APPDATA.recent.aryRecentImage.count);
    return APPDATA.recent.aryRecentImage.count;
}
// get data and set data in a collection view with convert image size
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"hideDropDown" object:nil];
    static NSString *identifier = @"Cell";
    MyPhotosCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    UIImageView *recentImageView = (UIImageView *)[cell viewWithTag:100];
    if (![[APPDATA.recent.aryRecentImage objectAtIndex:indexPath.row] isKindOfClass:[NSNull class]] &&
        [[APPDATA.recent.aryRecentImage objectAtIndex:indexPath.row] length] > 3)
    {
        NSString *imgStr=[NSString stringWithFormat:@"%@",[APPDATA.recent.aryRecentImage objectAtIndex:indexPath.row]];
        NSString *fCharStr =[imgStr substringToIndex:22];
        if ([imgStr rangeOfString:@"convert"].location == NSNotFound && [fCharStr isEqualToString:@"https://www.filepicker"])
        {
            imgStr = [NSString stringWithFormat:@"%@/convert?w=1200&h=1200",imgStr];
            
        }else if([fCharStr isEqualToString:@"https://www.filepicker"])
        {
            imgStr = [imgStr substringToIndex:[imgStr length]-20];
            imgStr = [NSString stringWithFormat:@"%@/convert?w=1200&h=1200",imgStr] ;
        }
        if([imgStr length]>2){
      
            
            [recentImageView setImageWithURL:[NSURL URLWithString:imgStr] placeholderImage:[UIImage imageNamed:@"no_imgV.png"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                if (!image) {
//                [recentImageView setImage:[UIImage imageNamed:@"no_imgV.png"]];
                }
                
            } usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            
            
        }else{
            [recentImageView setImage:[UIImage imageNamed:@"no_imgV.png"]];
        }
        recentImageView.contentMode = UIViewContentModeScaleAspectFill;
    }else{
        [recentImageView setImage:[UIImage imageNamed:@"no_imgV.png"]];
    }
    
    if ([[APPDATA.recent.aryRecentTintEye objectAtIndex:indexPath.row] isEqual:@"1"])
    {
        cell.TineEyeBtnForEntri.hidden=NO;
    }
    else
    {
        cell.TineEyeBtnForEntri.hidden=YES;
    }
    [APPDATA hideLoader];
    return cell;
}
//collection view layout siza changes according to device...
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    CGSize cgsize ;
    if( IS_IPHONE6){
        cgsize = CGSizeMake(183, 183);
    }else if(IS_IPHONE6plus)
    {
        cgsize = CGSizeMake(202, 202);
    }else
    {
        cgsize = CGSizeMake(156, 156);
    }
    return cgsize;
}

// pass data to photodetail view controller
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"hideDropDown" object:nil];
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
    objPhotos= (PhotoDetailViewController*)[mainStoryboard instantiateViewControllerWithIdentifier:@"PhotoDetailViewController"];
    objPhotos.profileIdRecent=indexPath.row;
    objPhotos.postImageurl=[APPDATA.recent.aryRecentImage objectAtIndex:indexPath.row];
    objPhotos.profileCaptionStr=[APPDATA.recent.aryRecentComment objectAtIndex:indexPath.row];
    
    NSArray *arrTag = [[NSArray alloc]initWithArray:[APPDATA.recent.aryRecentTag objectAtIndex:indexPath.row]];
    objPhotos.ProfileAryForTag = [[NSMutableArray alloc] init];
    [objPhotos.ProfileAryForTag addObjectsFromArray:arrTag];
    
    
    objPhotos.profileAryCmnt=[APPDATA.recent.aryRecentCmnt objectAtIndex:indexPath.row];
    objPhotos.profileAddShopDet=[APPDATA.recent.aryRecentAddShop objectAtIndex:indexPath.row];
    objPhotos.ProfileImageId=[APPDATA.recent.AryRecentphotoId objectAtIndex:indexPath.row];
    objPhotos.IsFlagForRecentEntries=YES;
    objPhotos.ProfileUserStr=[APPDATA.recent.aryRecentUser objectAtIndex:indexPath.row];
    [[self navigationController] pushViewController:objPhotos animated:YES];
}
// store the data in dictionary..
-(void)intRecentdata:(NSInteger)pagechange
{
    if (pagechange>APPDATA.recent.aryRecentImage.count)
    {
        
    }
    else
        
    {
        NSString *imagestr=[NSString stringWithFormat:@"%@",[APPDATA.recent.aryRecentImage objectAtIndex:pagechange]];
        NSDictionary *fix=@{@"imgStr":imagestr,@"caption":[APPDATA.recent.aryRecentComment objectAtIndex:pagechange],@"tag":[APPDATA.recent.aryRecentTag objectAtIndex:pagechange],@"cmnt":[APPDATA.recent.aryRecentCmnt objectAtIndex:pagechange],@"shopDet":[APPDATA.recent.aryRecentAddShop objectAtIndex:pagechange],@"userStr":[APPDATA.recent.aryRecentUser objectAtIndex:pagechange],@"ID":[APPDATA.recent.AryRecentphotoId objectAtIndex:pagechange]};
        [RecentProtoDelegate DictionaryDataRecent:fix];
    }
}


@end
