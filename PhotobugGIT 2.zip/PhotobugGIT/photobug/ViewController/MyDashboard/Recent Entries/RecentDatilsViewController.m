//
//  RecentDatilsViewController.m
//  photobug
//
//   on 1/8/16.
//  Copyright © Photobug. All rights reserved.
//
#import "RecentDatilsViewController.h"
#import "UIImageView+WebCache.h"
#import "UCZProgressView.h"

@interface RecentDatilsViewController ()
@property (nonatomic) IBOutlet UCZProgressView *progressView;
@property (nonatomic) NSMutableData *data;
@property (nonatomic) double expectedBytes;
@end

@implementation RecentDatilsViewController
{
    UIImageView *tempImg;
}

@synthesize imageStr;

//convert image siza and pass image string in loadimage method..
- (void)viewDidLoad
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"hideDropDown" object:nil];
    [super viewDidLoad];
    NSString *imgStr1=[NSString stringWithFormat:@"%@",imageStr];
    NSString *fCharStr =[imgStr1 substringToIndex:22];
    if ([imgStr1 rangeOfString:@"convert"].location == NSNotFound && [fCharStr isEqualToString:@"https://www.filepicker"])
    {
        imgStr1 = [NSString stringWithFormat:@"%@/convert?w=500&h=500",imgStr1] ;
    }else if([fCharStr isEqualToString:@"https://www.filepicker"])
    {
        imgStr1 = [imgStr1 substringToIndex:[imgStr1 length]-20];
        imgStr1 = [NSString stringWithFormat:@"%@/convert?w=500&h=500",imgStr1] ;
    }
    tempImg=[UIImageView new];
    tempImg.frame=self.image_view.frame;
    [self loadImage:imgStr1];
}
// add gesture  for big image view
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.image_view.userInteractionEnabled = YES;
    UIPinchGestureRecognizer *pinchGestureRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(handlePinchWithGestureRecognizer:)];
    [self.image_view addGestureRecognizer:pinchGestureRecognizer];
    
    self.image_view.userInteractionEnabled = YES;
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSingleTapGesture:)];
    [self.image_view addGestureRecognizer:tapGestureRecognizer];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

// for zoom in out we using pinch gesture..
-(void)handlePinchWithGestureRecognizer:(UIPinchGestureRecognizer *)pinchGestureRecognizer{
    self.image_view.transform = CGAffineTransformScale(self.image_view.transform, pinchGestureRecognizer.scale, pinchGestureRecognizer.scale);
    pinchGestureRecognizer.scale = 1.0;
    
    if(pinchGestureRecognizer.state==UIGestureRecognizerStateEnded){
        
        
        if (tempImg.frame.size.height>self.image_view.frame.size.height &&tempImg.frame.size.width>self.image_view.frame.size.width ) {
            self.image_view.frame=tempImg.frame;
        }
    }
    
}

// single tap gesture for hide image
-(void)handleSingleTapGesture:(UITapGestureRecognizer *)tapGestureRecognizer{
   
    [self.view removeFromSuperview];
    self.image_view.hidden=YES;
}


#pragma mark - private methods
- (void)loadImage:(NSString *)imgstr {
    self.image_view.image=[UIImage imageNamed:@""];
    self.image_view.contentMode = UIViewContentModeCenter;
    self.image_view.contentMode = UIViewContentModeScaleAspectFit;
    NSURL *url = [NSURL URLWithString:imgstr];
    [NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:url] delegate:self];
}

#pragma mark -for image size converter require methods..
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    self.expectedBytes = response.expectedContentLength;
    self.data = [NSMutableData dataWithCapacity:self.expectedBytes];
    self.progressView.progress = 0.0;
}
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [self.data appendData:data];
    double receivedBytes = self.data.length;
    self.progressView.progress = receivedBytes / self.expectedBytes;
}
- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    self.image_view.image = [UIImage imageWithData:self.data];
    self.progressView.progress = 1.0;
}
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    self.progressView.progress = 1.0;
}
@end
