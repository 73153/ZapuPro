//
//  RecentEntriesViewController.h
//  photobug
//
//   on 11/19/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyDashboardViewController.h"
#import "ScrollViewController.h"

@protocol protRecentdel <NSObject>

-(void)DictionaryDataRecent:(NSDictionary *)data;

@end

@interface RecentEntriesViewController : ScrollViewController

@property (strong, nonatomic) IBOutlet UICollectionView *collectionView;
@property NSDictionary *DictDataForRecentEntr;
@property(strong,nonatomic)NSString *profilidStr;
@property (nonatomic,strong) IBOutlet UILabel *lblNoDataFound;
@property (weak,nonatomic) id <protRecentdel> RecentProtoDelegate;
-(void)intRecentdata:(NSInteger)pagechange;

@end
