//
//  RecentDatilsViewController.h
//  photobug
//
//   on 1/8/16.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecentDatilsViewController : UIViewController
@property (strong, nonatomic) IBOutlet UIImageView *image_view;
@property(strong,nonatomic)NSString *imageStr;
- (void)loadImage:(NSString *)imgstr;
@end
