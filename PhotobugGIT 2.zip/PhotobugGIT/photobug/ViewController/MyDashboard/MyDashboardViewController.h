//
//  MyDashboardViewController.h
//  photobug
//
//   on 11/18/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RightMenuViewController.h"
#import "Constant.h"
#import "Users.h"
#import "ApplicationData.h"
#import "FeedViewController.h"
#import <FBSDKShareKit/FBSDKShareKit.h>
#import "UIPlaceHolderTextView.h"
#import "UCZProgressView.h"

typedef enum {
    Loginuser,
    Guestuser,
    
} USERTYPE;

@interface MyDashboardViewController : UIViewController<UIDocumentInteractionControllerDelegate,UITextViewDelegate,UITableViewDataSource,UITableViewDelegate,UIScrollViewDelegate,imgProto>
{
    FBSDKShareButton *shareButton;
    FBSDKShareLinkContent *content;
    NSString *shareUserNameStr,*shareUserImageStr;
}

@property (strong, nonatomic) IBOutlet UIImageView *arrowImage;
@property (strong, nonatomic) IBOutlet UIButton *menuButton;
@property (strong, nonatomic) IBOutlet UIView *viewdropDown;
@property (strong, nonatomic) IBOutlet UITableView *dropDowntableview;
@property (weak, nonatomic) IBOutlet UIView *viewNewPost;
@property (weak, nonatomic) IBOutlet UIButton *btnNewPost;
@property (strong, nonatomic) IBOutlet UIButton *dropdownButton;
@property (strong, nonatomic) IBOutlet UILabel *downlabel;
@property  BOOL isNewProfile;
@property (nonatomic) USERTYPE usertype;
@property (strong, nonatomic) IBOutlet UILabel *lbluserName;
@property (strong, nonatomic) IBOutlet UILabel *lblfollowing;
@property (strong, nonatomic) IBOutlet UILabel *lblfollowers;
@property (strong, nonatomic) IBOutlet UITableView *lblguestuser;
@property (strong, nonatomic) IBOutlet UIButton *btnEdit;
@property (strong, nonatomic) IBOutlet UITextField *txtusername;
@property (strong, nonatomic) IBOutlet UIButton *btnfacebook;
@property (strong, nonatomic) IBOutlet UIButton *btpin;
@property (strong, nonatomic) IBOutlet UIButton *btninsta;
@property (strong, nonatomic) IBOutlet UIButton *btnfollow;
@property (strong, nonatomic) IBOutlet UILabel *lblshare;
@property (strong, nonatomic) IBOutlet UIImageView *changeTranImage;
@property (strong, nonatomic) IBOutlet UIButton *btnmessage;
@property (strong, nonatomic) IBOutlet UIImageView *profilephoto;
@property (strong, nonatomic) IBOutlet UIButton *btnaddPhto;
@property (strong, nonatomic) IBOutlet UIImageView *imgBorder;
@property (strong, nonatomic) IBOutlet UILabel *lblchangeprofile;
@property (strong, nonatomic) IBOutlet UILabel *lblsocialsiteaddphoto;
@property(strong ,nonatomic)IBOutlet UIView *viewPlugInComment;
@property(strong ,nonatomic)NSArray *AllcommentArray;
@property (strong, nonatomic) IBOutlet UIImageView *addphotoImage;
@property (strong, nonatomic) IBOutlet UIPlaceHolderTextView *txtpost;
@property (strong, nonatomic) IBOutlet NSString *otherProfiletag;
@property (strong, nonatomic) IBOutlet NSString *messageProfileid;
@property (strong,nonatomic) NSDictionary *dictUserDetail;
@property (strong,nonatomic) FeedViewController *objFeedViewController;
@property NSString *data;
@property (nonatomic, retain) UIDocumentInteractionController *dic;
@property (nonatomic, retain) UIDocumentInteractionController *documentController;
@property (strong, nonatomic) IBOutlet UIButton *btnBack;
@property (strong, nonatomic) IBOutlet UIButton *btnPublishProfile;
@property (strong, nonatomic) IBOutlet UILabel *lblYourProfilefeed;
@property(nonatomic,retain)NSString *backStr;
@property (strong, nonatomic) IBOutlet UIImageView *BigImageView;
@property (strong, nonatomic) IBOutlet UIView *photDisplayView;
@property (nonatomic) IBOutlet UCZProgressView *progressView;
@property (nonatomic) NSMutableData *data1;
@property (nonatomic) double expectedBytes;
@property (nonatomic) IBOutlet UIScrollView *bigimgScrollView;

- (IBAction)btnMessageAction:(id)sender;
- (IBAction)btnCloseTapped:(id)sender;
- (IBAction)btnNewPostTapped:(id)sender;
- (IBAction)btnDownarrowAction:(id)sender;
- (IBAction)btnEditAction:(id)sender;
- (IBAction)btnaddPhotoAction:(id)sender;
- (IBAction)btnaddimage:(id)sender;
- (IBAction)addpostAction:(id)sender;
-(void)profileUpdateMethod;
-(void)myprofileuserMethod;
- (IBAction)addPhotoCloseButtonAction:(id)sender;
-(void)reloadFeedVCData;
- (IBAction)facebookSharing:(id)sender;
- (IBAction)instagramSharing:(id)sender;
- (IBAction)pintButtonAction:(id)sender;
- (IBAction)btnContestPressedTab:(id)sender;
- (IBAction)btnMyphotosPressedTab:(id)sender;
- (IBAction)btnuploadPressedTab:(id)sender;
- (IBAction)btnBackAction:(id)sender;
-(void)folloewUpdate;
-(void)hideDropDown;
- (IBAction)publishProfile:(id)sender;

@end
