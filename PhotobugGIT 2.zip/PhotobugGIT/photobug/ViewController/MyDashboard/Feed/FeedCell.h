//
//  FeedCell.h
//  photobug
//
//   on 23/11/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FeedCell : UITableViewCell

@property (nonatomic,strong) IBOutlet UILabel *lblUserName;
@property (nonatomic,strong) IBOutlet UILabel *lblTime;
@property (nonatomic,strong) IBOutlet UILabel *lblComment;
@property (nonatomic,strong) IBOutlet UIButton *btnComment;
@property (nonatomic,strong) IBOutlet UIButton *btnShare;
@property (nonatomic,strong) IBOutlet UITextField *txtComment;
@property (nonatomic,strong) IBOutlet UIImageView *imgFeed;
@property (strong, nonatomic) IBOutlet UILabel *lblCommentcount;
@property (strong, nonatomic) IBOutlet UIButton *imgbtnFeed;
@property (strong, nonatomic) IBOutlet UITextView *txtmeassage;
@property (nonatomic,strong) IBOutlet UIButton *btnDeletePostImg;

@end
