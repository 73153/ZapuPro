

//
//  EditProfileViewController.m
//  photobug
//
//   on 27/06/16.
//  Copyright © Photobug. All rights reserved.
//

#import "EditProfileViewController.h"
#import "RecentEntries.h"
#import "STCollapseTableView.h"
#import "Constant.h"
#import "ApplicationData.h"
#import "Users.h"
#import "ChngpwdTableViewCell.h"
#import "DescriptionTableViewCell.h"
#import "DashboardViewController.h"
#import "LoginViewController.h"
#import <IQKeyboardManager/IQKeyboardManager.h>

@interface EditProfileViewController ()<PickerDataDele>
{
    RecentEntries *recent;
    DescriptionTableViewCell *cell1;
    CntcInfoTableViewCell *cell2;
    ChngpwdTableViewCell *cell3;
    STCollapseTableView *objSt;
    NSMutableArray *arr;
    NSString *addtoshopStr;
    BOOL addtoshopFlag;
    BOOL IsAlert,IsAlert2;
    Users *user;
    UILabel *lab;
    NSArray *Arry1;
    UIImage *imgName;
    UIImageView *imgErow ;
    NSString *YourselectedTitle;
    NSArray *pickerAryData,*Ary1,*PickerArry;
    
}
@end

@implementation EditProfileViewController
@synthesize delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        [self setupViewController];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self)
    {
        [self setupViewController];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [[IQKeyboardManager sharedManager] setEnable:NO];
    [[IQKeyboardManager sharedManager] setEnableAutoToolbar:NO];
    _isAdded=NO;
    _isPicker=NO;
    addtoshopFlag=YES;
    user=[[Users alloc]init];
    pickerAryData = [[NSArray alloc]init];
    Ary1 = [[NSArray alloc]init];
    PickerArry = [[NSArray alloc]init];
    cell2=[[CntcInfoTableViewCell alloc]init];
    cell2.delegate=self;
    objSt=[[STCollapseTableView alloc]init];
    recent=[[RecentEntries alloc]init];
    Arry1=[[NSArray alloc]init];
    self.tableview.allowsSelection=NO;
     if (APPDATA.user.isFacebookLogin==1)
    {
        Arry1=@[@"",@"CONTACT INFORMATION"];
    }
    else
    {
        Arry1=@[@"",@"CONTACT INFORMATION",@"CHANGE PASSWORD"];

    }
    [self setupViewController];
    
    _pickerView2=[[UIPickerView alloc]initWithFrame:CGRectMake(0, 527, _pickerView.frame.size.width-190, _pickerView.frame.size.height-70)];
    _pickerView2.center=CGPointMake(self.view.center.x, _pickerView2.center.y);
    [_pickerView2 setBackgroundColor:[UIColor whiteColor]];
    _pickerView2.layer.masksToBounds = NO;
    _pickerView2.layer.borderWidth = 1.0f;
    _pickerView2.layer.shadowColor = [UIColor blackColor].CGColor;
    _pickerView2.delegate=self;
    _pickerView2.dataSource=self;
    _pickerView.hidden=YES;
    _VIEWPICKERVIEW.hidden=YES;
    [self setViewFooter];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(receivedNotification:)
                                                 name:@"Arrow Found"
     
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(receivedNotification:)
                                                 name:@"Arrow Found1"
     
                                               object:nil];
    [self.tableview reloadData];
    [self.tableview openSection:0 animated:NO];
    if (APPDATA.user.strAccPrivate == YES) {
        [ _btnMakeUrAcPrivate setImage:[UIImage imageNamed:@"checkin_btn_select"] forState:UIControlStateNormal];
        addtoshopFlag=NO;
    }
    else{
        [_btnMakeUrAcPrivate setImage:[UIImage imageNamed:@"checkin_btn"] forState:UIControlStateNormal];
        addtoshopFlag=YES;
    }
    [[_btnSubmit layer] setBorderWidth:1.0f];
    [[_btnSubmit layer] setCornerRadius:2.0f];
    [[_btnSubmit layer] setBorderColor:[UIColor colorWithRed:50.0/255.0 green:198.0/255.0 blue:244.0/255.0 alpha:1.0].CGColor];
}

-(void)Detailview
{
     APPDATA.user.StrTextViewDescription= [_StrDescription mutableCopy];
     APPDATA.user.strtxtfildUserName= [_StrUserName mutableCopy];
     APPDATA.user.strTxtfildPhonenom=     [_StrCntc mutableCopy];
     APPDATA.user.strTextfildStreet=      [_Stradd1 mutableCopy];
     APPDATA.user.strtxtFildStreet2=      [_Stradd2 mutableCopy];
     APPDATA.user.strtxtfildCity=        [_StrCity mutableCopy];
     APPDATA.user.strtxtfildZip=          [_StrZip mutableCopy];
    
}
-(void)setViewFooter
{
    self.tableview.tableFooterView= _SampleView;
}
- (void)setupViewController
{
    arr=[NSMutableArray new];
    
    for (int i =0 ; i < Arry1.count ; i++)
    {
        UIView* header = [[UIView alloc] initWithFrame:CGRectMake(0, 0,DEVICE_WIDTH, 40)];
        lab=[UILabel new];
        lab.frame=CGRectMake(25, header.frame.size.height/2,DEVICE_WIDTH, 14);
        lab.text=Arry1[i];
        
        [lab sizeToFit];
        lab.font=[UIFont fontWithName:@"Avenir-Black" size:13.0f];
        lab.textColor=[UIColor colorWithRed:20.0/255.0 green:34.0/255.0 blue:70.0/255.0 alpha:1.0f];
        header.backgroundColor = [UIColor whiteColor];
        [header addSubview:lab];
        imgErow = [[UIImageView alloc] initWithFrame:CGRectMake(lab.frame.origin.x+lab.frame.size.width-25, lab.frame.origin.y+7,12, 6)];
        if (i != 0)
            [header addSubview:imgErow];
        imgName = [UIImage imageNamed:@"down-arrow"];
        [imgErow setImage:imgName];
        [arr addObject:header];
    }
    
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self resignFirstResponder];
    return YES;
}
- (void)receivedNotification:(NSNotification *) notification
{
    if ([[notification name] isEqualToString:@"Arrow Found"])
    {
        UIView *view = [arr objectAtIndex:APPDATA.index];
        for (UIView *view1 in view.subviews) {
            [view1 removeFromSuperview];
        }
        lab=[UILabel new];
        lab.frame=CGRectMake(25, view.frame.size.height/2,DEVICE_WIDTH, 14);
        lab.text=Arry1[APPDATA.index];
        [lab sizeToFit];
        lab.font=[UIFont fontWithName:@"Avenir-Black" size:13.0f];
        lab.textColor=[UIColor colorWithRed:20.0/255.0 green:34.0/255.0 blue:70.0/255.0 alpha:1.0f];
        view.backgroundColor = [UIColor whiteColor];
        [view addSubview:lab];
        
        imgErow = [[UIImageView alloc] initWithFrame:CGRectMake(lab.frame.origin.x+lab.frame.size.width-25, lab.frame.origin.y+7,12, 6)];
        imgName = [UIImage imageNamed:@"UpArrow"];
        [imgErow setImage:imgName];
        if (APPDATA.index != 0)
            [view addSubview:imgErow];
        [arr replaceObjectAtIndex:APPDATA.index withObject:view];
    }
    else if ([[notification name] isEqualToString:@"Arrow Found1"])
    {
        UIView *view = [arr objectAtIndex:APPDATA.index];
        for (UIView *view1 in view.subviews) {
            [view1 removeFromSuperview];
        }
        lab=[UILabel new];
        lab.frame=CGRectMake(25, view.frame.size.height/2,DEVICE_WIDTH, 14);
        lab.text=Arry1[APPDATA.index];
        [lab sizeToFit];
        lab.font=[UIFont fontWithName:@"Avenir-Black" size:13.0f];
        lab.textColor=[UIColor colorWithRed:20.0/255.0 green:34.0/255.0 blue:70.0/255.0 alpha:1.0f];
        view.backgroundColor = [UIColor whiteColor];
        [view addSubview:lab];
        
        imgErow = [[UIImageView alloc] initWithFrame:CGRectMake(lab.frame.origin.x+lab.frame.size.width-25, lab.frame.origin.y+7,12, 6)];
        imgName = [UIImage imageNamed:@"down-arrow"];
        
        [imgErow setImage:imgName];
        if (APPDATA.index != 0)
            [view addSubview:imgErow];
            [arr replaceObjectAtIndex:APPDATA.index withObject:view];
    }
}

- (IBAction)BtnDwnArrowPasswrd:(id)sender
{
    
}

- (IBAction)BtnClose:(id)sender
{
    [self.tableview setHidden:YES];
    [self.view removeFromSuperview];
}

- (IBAction)BtnSubmit:(id)sender
{
//    NSString *strPass =UDGetObject(@"PASSWORD");
    Users *user1 = [[Users alloc] init];
    user1.StrTextViewDescription=[cell1.TxtViewDescription.text mutableCopy];
    
    
    
    user1.strtxtfildUserName=[cell1.txtUserName.text mutableCopy];
    user1.strTxtfildPhonenom= [_StrCntc mutableCopy];
    user1.strTextfildStreet=[_Stradd1 mutableCopy];
    user1.strtxtFildStreet2=[_Stradd2 mutableCopy];
    user1.strtxtfildCity= [_StrCity mutableCopy];
    user1.strtxtfildZip= [_StrZip mutableCopy];
    user1.strStateId = APPDATA.user.strStateId;
    
    if (APPDATA.user.strtxtFildCurrntpwd.length == 0 && APPDATA.user.strTxtFildRetypNewPwd.length == 0 && APPDATA.user.strTxtFildNewPwd.length == 0) {
        [user1 getSubmitProfile:^(NSString *result, int status) {
            if (status == 1)
            {
                NSLog(@"%@",result);
                [APPDATA.user.strtxtfildUserName = [NSMutableString stringWithFormat:@"%@", cell1.txtUserName.text] mutableCopy];
                [[NSNotificationCenter defaultCenter]
                 postNotificationName:@"UserNameNotification"
                 object:self];
                UDSetObject(APPDATA.user.strtxtfildUserName, @"username");
                UDSetObject(APPDATA.user.StrTextViewDescription, @"discription");
                UDSetObject(APPDATA.user.strTxtfildPhonenom, @"phonenumber");
                UDSetObject(APPDATA.user.strTextfildStreet,@"streetaddress1");
                UDSetObject(APPDATA.user.strtxtFildStreet2,@"streetaddress2");
                UDSetObject(APPDATA.user.strtxtfildCity, @"city");
                UDSetObject(APPDATA.user.strtxtfildZip, @"zip");
 
                APPDATA.user.strTxtFildNewPwd = [@"" mutableCopy];
                APPDATA.user.strTxtFildRetypNewPwd= [@"" mutableCopy];
                APPDATA.user.strtxtFildCurrntpwd= [@"" mutableCopy];
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"" message:UPDATE_PROFILE delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                IsAlert2=YES;
                [alert show];
                [self.tableview setHidden:YES];
                [self.view removeFromSuperview];
            }
            else
            {
                @try
                {
                    NSLog(@"%@",result);
                    [APPDATA ShowAlertWithTitle:@"" Message:result];
                }
                @catch (NSException *exception) {
                    
                }
                @finally {
                    
                }
            }
        }];
    }
    else {
    if (APPDATA.user.strtxtFildCurrntpwd.length > 0 && APPDATA.user.strTxtFildNewPwd.length == 0)
    {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_ADD_PASSWORD];
        [[NSNotificationCenter defaultCenter]postNotificationName:@"newFirst" object:nil];
    }
    else if (APPDATA.user.strtxtFildCurrntpwd.length > 0 && APPDATA.user.strTxtFildNewPwd.length > 0 && APPDATA.user.strTxtFildRetypNewPwd.length == 0)
    {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_ADD_RePASSWORD];
        [[NSNotificationCenter defaultCenter]postNotificationName:@"reTypeFirst" object:nil];
    }
   else if (APPDATA.user.strTxtFildNewPwd.length > 0 && APPDATA.user.strtxtFildCurrntpwd.length == 0)
    {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_OLD_PASSWORD];
        [[NSNotificationCenter defaultCenter]postNotificationName:@"oldFirst" object:nil];
    }
    else if (APPDATA.user.strTxtFildNewPwd.length > 0 && APPDATA.user.strTxtFildRetypNewPwd.length == 0 ){
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_ADD_RePASSWORD];
        [[NSNotificationCenter defaultCenter]postNotificationName:@"reTypeFirst" object:nil];
    }
    else if (APPDATA.user.strtxtFildCurrntpwd.length < 6) {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_MINLENGTH_PASSWORD];
        [[NSNotificationCenter defaultCenter]postNotificationName:@"oldFirst" object:nil];
    }
    else if (APPDATA.user.strTxtFildNewPwd.length < 6) {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_MINLENGTH_PASSWORD];
        [[NSNotificationCenter defaultCenter]postNotificationName:@"newFirst" object:nil];
    }
    else if (APPDATA.user.strTxtFildRetypNewPwd.length < 6) {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_MINLENGTH_PASSWORD];
        [[NSNotificationCenter defaultCenter]postNotificationName:@"reTypeFirst" object:nil];
    }
    else  if (![APPDATA.user.strTxtFildNewPwd isEqualToString:APPDATA.user.strTxtFildRetypNewPwd])
    {
        [APPDATA ShowAlertWithTitle:@"" Message:@"New Password and re-type not same."];
        [[NSNotificationCenter defaultCenter]postNotificationName:@"reTypeFirst" object:nil];
    }
    else  if ([APPDATA.user.strTxtFildNewPwd isEqualToString:APPDATA.user.strTxtFildRetypNewPwd] && APPDATA.user.strtxtFildCurrntpwd.length == 0)
    {
        [[NSNotificationCenter defaultCenter]postNotificationName:@"oldFirst" object:nil];
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_OLD_PASSWORD];
    }
    else {
        [user1 getSubmitProfile:^(NSString *result, int status) {
            if (status == 1)
            {
                NSLog(@"%@",result);
                 UDSetObject(APPDATA.user.strtxtfildUserName, @"username");
                UDSetObject(APPDATA.user.StrTextViewDescription, @"discription");
                UDSetObject(APPDATA.user.strTxtfildPhonenom, @"phonenumber");
                UDSetObject(APPDATA.user.strTextfildStreet,@"streetaddress1");
                UDSetObject(APPDATA.user.strtxtFildStreet2,@"streetaddress2");
                UDSetObject(APPDATA.user.strtxtfildCity, @"city");
                UDSetObject(APPDATA.user.strtxtfildZip, @"zip");
                UDSetObject(APPDATA.user.strtxtFildCurrntpwd, @"CurrentPwd");
                UDSetObject(APPDATA.user.strTxtFildNewPwd, @"PASSWORD");
                APPDATA.user.strTxtFildNewPwd = [@"" mutableCopy];
                APPDATA.user.strTxtFildRetypNewPwd= [@"" mutableCopy];
                APPDATA.user.strtxtFildCurrntpwd= [@"" mutableCopy];
                [APPDATA ShowAlertWithTitle:@"" Message:[result valueForKey:@"message"]];
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"" message:UPDATE_PROFILE delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
                IsAlert2=YES;
               

                [alert show];
                [self.tableview setHidden:YES];
                [self.view removeFromSuperview];
            }
            else
            {
                @try
                {
                    NSLog(@"%@",result);
                    [APPDATA ShowAlertWithTitle:@"" Message:result];
                    [APPDATA ShowAlertWithTitle:@"" Message:[result valueForKey:@"message"]];
                }
                @catch (NSException *exception) {
                    
                }
                @finally {
                    
                }
            }
            
        }];
    }
    }
}
- (IBAction)btnDeleteProfile:(id)sender
{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Are you sure you want to delete your profile? This is irreversible and will permanently delete all content, points and earnings." delegate:self cancelButtonTitle:@"Yes" otherButtonTitles:@"No", nil];
    alert.tag = 1;
    [alert show];
    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag==0)
    {
        if (IsAlert2==YES)
        {
            cell1.txtUserName.text=@"";
            cell2.TxtFieldPhoneNom.text=@"";
            cell2.TxtFieldStreet.text=@"";
            cell2.TxtFieldStreet2.text=@"";
            cell2.TxtFieldCity.text=@"";
            cell2.TxtFieldZip.text=@"";
            cell2.txtFildPicker.text=@"";
            cell3.TxtFieldCurrentPwd.text=@"";
            cell3.TxtFieldNewPwd.text=@"";
            cell3.TxtFieldReTypePwd.text=@"";
             UDSetObject(APPDATA.user.strtxtfildUserName, @"");
            UDSetObject(APPDATA.user.StrTextViewDescription, @"");
            UDSetObject(APPDATA.user.strTxtfildPhonenom, @"");
            UDSetObject(APPDATA.user.strTextfildStreet,@"");
            UDSetObject(APPDATA.user.strtxtFildStreet2,@"");
            UDSetObject(APPDATA.user.strtxtfildCity, @"");
            UDSetObject(APPDATA.user.strtxtfildZip, @"");
            UDSetObject(APPDATA.user.strtxtFildCurrntpwd, @"");
            UDSetObject(APPDATA.user.strTxtFildRetypNewPwd, @"");
            UDSetObject(APPDATA.user.strTxtFildNewPwd, @"");
        }
    }
    else if (alertView.tag == 1)
    {
        if (buttonIndex == 0) {
            
            [user getDeleteProfile:^(NSString *result, int status)
             {
                 if (status == 1) {
                     [APPDATA ShowAlertWithTitle:@"" Message:@"User Deleted Successfully"];
                     [self.tableview setHidden:YES];
                     [self.view removeFromSuperview];
                     [delegate Buttonhidden];
                     APPDATA.isUserLogin = NO;
                     IsAlert=NO;
                     [((AppDelegate*)[[UIApplication sharedApplication] delegate]).social logoutFacebook];
                     UDSetBool(APPDATA.isUserLogin, @"isuserlogin");
                     UDSetBool(APPDATA.isUserLogin, @"isuserFBlogin");
                     UDSetBool(APPDATA.isUserLogin, @"isPublishProfile");
                     APPDATA.user = [[Users alloc]init];
                     appDelegate.profilid_AppStr =@"";
                     [[SlideNavigationController sharedInstance] toggleRightMenu];
                     LoginViewController *objDashboardViewController =(LoginViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"LoginViewController"];
                     [APPDATA pushNewViewControllerFromContest:objDashboardViewController];
                 }
                 else {
                     [APPDATA ShowAlertWithTitle:@"" Message:result];
                     [APPDATA hideLoader];
                 }
             }];
        }
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;

{
    return 1;
}

-(void)createCells{
    [[self tableview] registerNib:[UINib nibWithNibName:@"DescriptionTableViewCell" bundle:nil] forCellReuseIdentifier:@"Cell1"];
    
    [[self tableview] registerNib:[UINib nibWithNibName:@"CntcInfoTableViewCell" bundle:nil] forCellReuseIdentifier:@"Cell2"];
    
    [[self tableview] registerNib:[UINib nibWithNibName:@"ChngpwdTableViewCell" bundle:nil] forCellReuseIdentifier:@"Cell3"];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    [self createCells];
    
    
    if (indexPath.section==0) {
        cell1 = [tableView dequeueReusableCellWithIdentifier:@"Cell1"];
        
        cell1.TxtViewDescription.text = [APPDATA isNullOrEmpty:APPDATA.user.StrTextViewDescription];
         cell1.txtUserName.text = [APPDATA isNullOrEmpty:APPDATA.user.strtxtfildUserName];
        if (!APPDATA.user.strSMS) {
                       cell1.btnUncheck.selected =FALSE;
            [cell1.btnUncheck setImage:[UIImage imageNamed:@"checkin_btn"] forState:UIControlStateNormal];
        }
        else {
                        cell1.btnUncheck.selected =TRUE;
            [cell1.btnUncheck setImage:[UIImage imageNamed:@"checkin_btn_select"] forState:UIControlStateNormal];
        }        return cell1;
        
    }
    else if(indexPath.section==1){
        cell2 = [tableView dequeueReusableCellWithIdentifier:@"Cell2"];
        cell2.delegate=self;
        
        cell2.txtFildPicker.text=[APPDATA.user.strStateName uppercaseString];
        _pickerView.hidden=YES;
        _VIEWPICKERVIEW.hidden=YES;
        cell2.TxtFieldPhoneNom.text = [APPDATA isNullOrEmpty:APPDATA.user.strTxtfildPhonenom];
        cell2.TxtFieldStreet.text = [APPDATA isNullOrEmpty:APPDATA.user.strTextfildStreet];
        cell2.TxtFieldStreet2.text = [APPDATA isNullOrEmpty:APPDATA.user.strtxtFildStreet2];
        cell2.TxtFieldCity.text = [APPDATA isNullOrEmpty:APPDATA.user.strtxtfildCity];
        cell2.TxtFieldZip.text = [APPDATA isNullOrEmpty:APPDATA.user.strtxtfildZip];
        return cell2;
    }else
    {
        cell3 = [tableView dequeueReusableCellWithIdentifier:@"Cell3"];
        
        if (APPDATA.user.isFacebookLogin==1)
        {
            cell3.hidden=YES;
        }
        else
        {
            cell3.hidden=NO;
        }
        return cell3;
    }
    return cell2;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 40;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if(indexPath.section==0)
    {
        return 240;
    }
    else if(indexPath.section==1)
    {
        if (!_isAdded) {
            return 230;
        }
        if (_pickerView2.isHidden) {
            return 230;
        }
        else
        {
            return 370;
        }
    }
    else
    {
        return 250;
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    return [arr objectAtIndex:section];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [arr count];
}
- (CGFloat)tableView:(UITableView *)tableView HeightForFooterInSection:(NSInteger)section {
    return 100;
}

- (IBAction)btnAddShopTapped:(id)sender
{
    if (addtoshopFlag==YES)
    {
        addtoshopStr=@"1";
        APPDATA.user.strAccPrivate=[addtoshopStr boolValue];
        [ _btnMakeUrAcPrivate setImage:[UIImage imageNamed:@"checkin_btn_select"] forState:UIControlStateNormal];
        addtoshopFlag=NO;
    }
    else
    {
        addtoshopStr=@"0";
        APPDATA.user.strAccPrivate=[addtoshopStr boolValue];
        [_btnMakeUrAcPrivate setImage:[UIImage imageNamed:@"checkin_btn"] forState:UIControlStateNormal];
        addtoshopFlag=YES;
    }
}

-(void)Pickerdata:(NSMutableArray *)pickerAry
{
    pickerAryData =[pickerAry valueForKey:@"name"];
    PickerArry=pickerAry;
    _pickerView.delegate=self;
    _pickerView.dataSource=self;
    _VIEWPICKERVIEW.hidden=NO;
    _pickerView.hidden=YES;
    _isPicker=YES;
    if (!_isAdded) {
        [self.tableview addSubview:_pickerView2];
        [_pickerView2 bringSubviewToFront:self.tableview];
        _isAdded=YES;
    }
    else
    {
        [_pickerView2 setHidden:NO];
    }
    [self.tableview reloadData];
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView;
{
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component;
{
    return pickerAryData.count;
}

- (UIView *)pickerView:(UIPickerView *)pickerView
            viewForRow:(NSInteger)row
          forComponent:(NSInteger)component
           reusingView:(UIView *)view {
    UILabel *pickerLabel = (UILabel *)view;
    if (pickerLabel == nil) {
        CGRect frame = CGRectMake(0.0, 0.0, 80, 32);
        pickerLabel = [[UILabel alloc] initWithFrame:frame];
        [pickerLabel setBackgroundColor:[UIColor clearColor]];
        [pickerLabel setFont:[UIFont boldSystemFontOfSize:13]];
    }
    [pickerLabel setText:[pickerAryData[row]uppercaseString]];
    return pickerLabel;
}

-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return [pickerAryData[row]uppercaseString];
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    APPDATA.user.strStateName=  [pickerAryData objectAtIndex:[self.pickerView2 selectedRowInComponent:0]];
   NSDictionary * dict=[PickerArry objectAtIndex:[self.pickerView2 selectedRowInComponent:0]];
    APPDATA.user.strStateId=[dict valueForKey:@"id"];
    NSLog(@"%@",  APPDATA.user.strId);
    [_pickerView2 setHidden:YES];
    _isPicker=NO;
    [_tableview reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

