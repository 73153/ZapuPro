//
//  AddCommentTableViewCell.h
//  photobug
//
//   on 11/20/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AddCommentViewController.h"

@interface AddCommentTableViewCell : UITableViewCell
@property (strong,nonatomic)IBOutlet UILabel *lblComment;
@property (strong,nonatomic)IBOutlet UILabel *lblUserName;
@property (strong,nonatomic)IBOutlet UILabel *lblTime;
@property (strong,nonatomic)IBOutlet UIButton *btnDeleteComment;








@end
