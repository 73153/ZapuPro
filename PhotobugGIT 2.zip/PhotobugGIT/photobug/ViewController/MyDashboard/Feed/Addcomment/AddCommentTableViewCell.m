//
//  AddCommentTableViewCell.m
//  photobug
//
//   on 11/20/15.
//  Copyright © Photobug. All rights reserved.
//

#import "AddCommentTableViewCell.h"

@implementation AddCommentTableViewCell


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
