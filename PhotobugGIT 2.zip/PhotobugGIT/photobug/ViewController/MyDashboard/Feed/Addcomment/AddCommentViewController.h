//
//  AddCommentViewController.h
//  photobug
//
//   on 11/20/15.
//  Copyright © Photobug. All rights reserved.
//
typedef enum {
    SelectGroup,
    SelectProfile,
    
} SELECTIONTYPE;

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>

@interface AddCommentViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,MFMailComposeViewControllerDelegate>
{
    NSString *postMessageStr,*feed_typeStr,*postImageStr;

}

@property (strong,nonatomic)IBOutlet UITableView *tableviewAddComment;
@property(strong,nonatomic)IBOutlet  UIImageView *imgViewComment;
@property (weak, nonatomic) IBOutlet UITextField *txtFieldWriteComment;
@property(strong,nonatomic)IBOutlet UIImageView *imgView;
@property (nonatomic)BOOL usertype;
@property (nonatomic) SELECTIONTYPE *selectType;

@property(strong,nonatomic)NSArray *allCommentsArray;
@property(strong,nonatomic)NSString *tagStr;
@property (strong, nonatomic) IBOutlet UILabel *lblCommentcount;
@property (strong, nonatomic) IBOutlet UIButton *btnSend;
@property (weak, nonatomic) IBOutlet UIView *ShareView;

@property (weak, nonatomic) IBOutlet UIButton *btnEmail;
@property (weak, nonatomic) IBOutlet UIButton *btnFackebook;

@property(strong,retain)NSString *otherProfileid;
@property (nonatomic,strong) IBOutlet UILabel *lblNoDataFound;
@property (weak, nonatomic) IBOutlet UIButton *btnMyfeed;
@property(strong,nonatomic)NSString *gropCommentStr;
@property (nonatomic,strong) IBOutlet UIImageView *imgGBView;

@property (nonatomic,strong) IBOutlet UIView *commentView;
@property (weak, nonatomic) IBOutlet UIImageView *imgviewBorder;
@property (strong, nonatomic) IBOutlet UIButton *btnshare;

@property(strong ,nonatomic)NSString *groupStrCommentFlag;
@property(strong ,nonatomic)NSString *strjoin;
@property (strong, nonatomic) IBOutlet UIView *imgMainView;
@property (nonatomic) BOOL isFromGroup;
@property (weak, nonatomic) IBOutlet UIButton *btnClose;
@property (weak, nonatomic) IBOutlet UIButton *btnCloseText;

- (IBAction)btnEmailTapped:(id)sender;

- (IBAction)btnFacebookTapped:(id)sender;
- (IBAction)btnMyfeedTapped:(id)sender;
- (IBAction)btnCancelPressed:(id)sender;
- (IBAction)btnSendPressed:(id)sender;
-(void)addCommentPost;
-(void)feedupdateMethod;
- (IBAction)btnShareTapped:(id)sender;

-(void)cancelAction:(UIBarButtonItem*)barButton;

-(void)doneAction:(UIBarButtonItem*)barButton;

- (IBAction)btnclose_Actions:(id)sender;

@end
