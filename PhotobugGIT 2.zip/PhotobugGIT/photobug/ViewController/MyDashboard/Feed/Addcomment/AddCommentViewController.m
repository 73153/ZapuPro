//
//  AddCommentViewController.m
//  photobug
//
//   on 11/20/15.
//  Copyright © Photobug. All rights reserved.
//
#import "AddCommentViewController.h"
#import "AddCommentTableViewCell.h"
#import "Constant.h"
#import "ApplicationData.h"
#import "APICall.h"
#import "IQKeyboardManager.h"
#import "RTLabel.h"
#import "UIImageView+WebCache.h"
#import "AsyncImageView.h"
#import "FeedViewController.h"
#import "APICall.h"
#import "MyDashboardViewController.h"
#import <FBSDKShareKit/FBSDKShareKit.h>
#import "GroupFeedViewController.h"
#import "IQKeyboardManager.h"
#import "IQKeyboardManagerConstants.h"
#import "IQKeyboardReturnKeyHandler.h"
#import "IQUIView+IQKeyboardToolbar.h"
#import <UIActivityIndicator-for-SDWebImage/UIImageView+UIActivityIndicatorForSDWebImage.h>

@interface AddCommentViewController ()<UITextFieldDelegate>
{
    NSArray *dictFeed;
    NSMutableArray *commentsArray;
    CGSize optimumSize;
    NSString *postid,*strUserId,*strOtherId,*rowId,*userName,*userCommentName,*groupId,*postedBy;
    NSString *commentid;
    FeedViewController *objFeedViewController;
    FBSDKShareButton *shareButton;
    FBSDKShareLinkContent *content;
    NSString *strGroupId;
     NSInteger indexToDeleteComment;
    IQKeyboardReturnKeyHandler *returnKeyHandler;
     Users *user;
    NSArray *commentsArray2;
    Group *objGroup;
  
}
@end

@implementation AddCommentViewController

@synthesize usertype,tagStr,otherProfileid,gropCommentStr,groupStrCommentFlag;

//check comment from group or feed class and set comment box frame according to device..
- (void)viewDidLoad {
    [super viewDidLoad];
    [_ShareView setHidden:YES];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(hideShareView) name:@"hideShareView" object:nil];
    [[IQKeyboardManager sharedManager] setEnable:YES];
    [[IQKeyboardManager sharedManager] setEnableAutoToolbar:YES];
    returnKeyHandler = [[IQKeyboardReturnKeyHandler alloc] initWithViewController:self];
    [_txtFieldWriteComment addCancelDoneOnKeyboardWithTarget:self cancelAction:@selector(cancelAction:) doneAction:@selector(doneAction:)];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self
                                                                         action:@selector(tapShareView)];
    [self.view addGestureRecognizer:tap];
     _btnCloseText.hidden=YES;
      user = [[Users alloc]init];
    objGroup= [[Group alloc] init];
    _txtFieldWriteComment.delegate=self;
    
    _btnshare.hidden=YES;
   
    if (self.selectType == SelectGroup)
    {
        commentsArray = [[NSMutableArray alloc] init];
        [[[APPDATA.group.arrGroupFeed objectAtIndex:[tagStr integerValue]] valueForKey:@"comments"] enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop)
         {
             [commentsArray addObject:obj];
         }];
        strGroupId=[NSString stringWithFormat:@"%@",[[APPDATA.group.arrGroupFeed objectAtIndex:[tagStr integerValue]] valueForKey:@"group_id"]];
        postid=[NSString stringWithFormat:@"%@",[[APPDATA.group.arrGroupFeed objectAtIndex:[tagStr integerValue]] valueForKey:@"id"]];
        if (![gropCommentStr isKindOfClass:[NSNull class]] &&
            [gropCommentStr length] > 3) {
            _imgMainView.hidden=NO;
            [[self view] bringSubviewToFront:_commentView];
            [[self view] bringSubviewToFront:_imgMainView];
            [_imgViewComment setImageWithURL:[NSURL URLWithString:gropCommentStr] placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            
        } else
        {

            _btnCloseText.hidden=NO;
            _commentView.frame=CGRectMake(_commentView.frame.origin.x, (self.view.frame.size.height -_commentView.frame.size.height)/2,_commentView.frame.size.width , _commentView.frame.size.height-_imgViewComment.frame.size.height);
            
            _tableviewAddComment.frame=CGRectMake(_tableviewAddComment.frame.origin.x, 30, _tableviewAddComment.frame.size.width, _commentView.frame.size.height-_txtFieldWriteComment.frame.size.height-40);
            
            _btnCloseText.frame=CGRectMake(_btnCloseText.frame.origin.x+5, _tableviewAddComment.frame.origin.y-30, _btnCloseText.frame.size.width, _btnCloseText.frame.size.height);
            
            
            
            if (IS_IPHONE6) {
                _commentView.frame=CGRectMake(_commentView.frame.origin.x, _commentView.frame.origin.y+100,_commentView.frame.size.width , _commentView.frame.size.height);
            }

            _commentView.center = self.view.center;
            _imgMainView.hidden=YES;
            [self.imgViewComment setImage:[UIImage imageNamed:@""]];
        }
        _lblCommentcount.text = [NSString stringWithFormat:@" (%lu)",(unsigned long)commentsArray.count];
        [self.tableviewAddComment reloadData];
    }
    else
    {
        if (usertype==0)
        {
            otherProfileid=[NSString stringWithFormat:@"%@",appDelegate.profilid_AppStr];
        }
        [self feedupdateMethod];
    }
    [_ShareView setHidden:YES];
    UITapGestureRecognizer *singleTap =  [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapping)];
    [singleTap setNumberOfTapsRequired:1];
    [self.imgGBView addGestureRecognizer:singleTap];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

// get the required IDs from globals..
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
     strOtherId=[NSString stringWithFormat:@"%@",APPDATA.user.strOtherId];
     strUserId = [NSString stringWithFormat:@"%@",APPDATA.user.profileid];
     userName = [NSString stringWithFormat:@"%@",UDGetObject(@"username")];
    groupId = [NSString stringWithFormat:@"%@",APPDATA.group.groupId];
    postedBy = [NSString stringWithFormat:@"%@",APPDATA.group.postedBy];
}

#pragma Mark Comment view hidden....

- (IBAction)btnCancelPressed:(id)sender{
    [self.view removeFromSuperview];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

#pragma mark All Feed geting method...
-(void)feedupdateMethod;
{
    @try{

    [APPDATA showLoader];
    _lblNoDataFound.hidden = YES;
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        if(responseObject == NULL)
        {
        }else{
            NSDictionary *datadic= [responseObject objectForKey:@"data"];
           
            dictFeed=[datadic objectForKey:@"feed_data"];
            if ([ [[dictFeed objectAtIndex:[tagStr intValue]] objectForKey:@"feed_type"] isEqualToString:@"post"])
            {
                if (![[[dictFeed objectAtIndex:[tagStr intValue]] objectForKey:@"post_image"] isKindOfClass:[NSNull class]] &&
                    [[[dictFeed objectAtIndex:[tagStr intValue]] objectForKey:@"post_image"] length] > 3) {
                    _imgMainView.hidden=NO;
                    [[self view] bringSubviewToFront:_commentView];
                    [[self view] bringSubviewToFront:_imgMainView];
                    //change image
                    _btnCloseText.hidden=YES;
                    [_imgViewComment sd_setImageWithURL:[NSURL URLWithString:[[dictFeed objectAtIndex:[tagStr intValue]] objectForKey:@"post_image"]]
                                       placeholderImage:[UIImage imageNamed:@"no_imgV.png"]
                                                options:SDWebImageRefreshCached];

                } else
                {
                      _btnCloseText.hidden=NO;
                        _imgMainView.hidden=YES;
                    _commentView.frame=CGRectMake(_commentView.frame.origin.x, (self.view.frame.size.height -_commentView.frame.size.height)/2,_commentView.frame.size.width , _commentView.frame.size.height-_imgViewComment.frame.size.height);
                    
                    _tableviewAddComment.frame=CGRectMake(_tableviewAddComment.frame.origin.x, 30, _tableviewAddComment.frame.size.width, _commentView.frame.size.height-_txtFieldWriteComment.frame.size.height-40);
                    
                      _btnCloseText.frame=CGRectMake(_btnCloseText.frame.origin.x+5, _tableviewAddComment.frame.origin.y-30, _btnCloseText.frame.size.width, _btnCloseText.frame.size.height);
                    
                }
            }
            if (![[[dictFeed objectAtIndex:[tagStr intValue]] objectForKey:@"post_image"] isKindOfClass:[NSNull class]] &&
                [[[dictFeed objectAtIndex:[tagStr intValue]] objectForKey:@"post_image"] length] > 3) {
                _imgMainView.hidden=NO;
                [[self view] bringSubviewToFront:_commentView];
                [[self view] bringSubviewToFront:_imgMainView];
                NSString *imgstr=[NSString stringWithFormat:@"%@",[[dictFeed objectAtIndex:[tagStr intValue]] objectForKey:@"post_image"]];
                NSString *fCharStr =[imgstr substringToIndex:22];
                if ([imgstr rangeOfString:@"convert"].location == NSNotFound && [fCharStr isEqualToString:@"https://www.filepicker"])
                {
                    imgstr = [NSString stringWithFormat:@"%@/convert?w=1200&h=1200",imgstr] ;
                }else if([fCharStr isEqualToString:@"https://www.filepicker"])
                {
                    imgstr = [imgstr substringToIndex:[imgstr length]-20];
                    imgstr = [NSString stringWithFormat:@"%@/convert?w=1200&h=1200",imgstr] ;
                }
                [_imgViewComment setImageWithURL:[NSURL URLWithString:imgstr] placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            } else
            {
                if (_imgViewComment.image==nil && usertype==0)
                {
                    _commentView.frame=CGRectMake(_commentView.frame.origin.x, (self.view.frame.size.height -_commentView.frame.size.height)/2,_commentView.frame.size.width , _commentView.frame.size.height);
                }
                else if(_imgViewComment.image==nil && usertype==1)
                {
                    _imgMainView.hidden=YES;
                    _btnCloseText.hidden=NO;
                    _commentView.frame=CGRectMake(_commentView.frame.origin.x, (self.view.frame.size.height -_commentView.frame.size.height),_commentView.frame.size.width , _commentView.frame.size.height-_imgViewComment.frame.size.height);
                    
                    _tableviewAddComment.frame=CGRectMake(_tableviewAddComment.frame.origin.x, 30, _tableviewAddComment.frame.size.width, _commentView.frame.size.height-_txtFieldWriteComment.frame.size.height-40);
                    
                    _btnCloseText.frame=CGRectMake(_btnCloseText.frame.origin.x+5, _tableviewAddComment.frame.origin.y-30, _btnCloseText.frame.size.width, _btnCloseText.frame.size.height);
                    

                }
                
            }
            postMessageStr=[[dictFeed objectAtIndex:[tagStr intValue]] objectForKey:@"message"];
            commentsArray=[[dictFeed objectAtIndex:[tagStr intValue]] objectForKey:@"comments"];
            if (commentsArray.count == 0) {
                _lblNoDataFound.hidden = NO;
                CGRect frame = self.lblNoDataFound.frame;
                frame.origin.y = (self.view.superview.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
                [self.lblNoDataFound setFrame:frame];

                
            }
            _lblCommentcount.text=[NSString stringWithFormat:@"( %lu )",(unsigned long)[commentsArray count]];
            NSNumber *message_id = [[dictFeed objectAtIndex:[tagStr intValue]] objectForKey:@"id"];
            postid=[message_id stringValue];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.tableviewAddComment reloadData];
                [APPDATA hideLoader];
            });
        }
    };
    void (^failure)(NSError * error) = ^(NSError *error) {
    };
    NSString  *strDeviceToken=[[NSUserDefaults standardUserDefaults] objectForKey:@"strDeviceToken"];
    if ([strDeviceToken isKindOfClass:[NSNull class]] || strDeviceToken == nil || [strDeviceToken isEqualToString:@""])
    {
        strDeviceToken=nil;
    }
    NSDictionary *dict = @{@"key":API_KEY,@"profile_id":otherProfileid,@"method":API_PROFILE_FEED
                           };
    [APICall sendToService:dict success:successed failure:failure];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

- (UIViewController *)parentViewController1 {
    UIResponder *responder = self;
    while ([responder isKindOfClass:[UIView class]])
        responder = [responder nextResponder];
    return (UIViewController *)responder;
}

#pragma mark Add comment Methdo
-(void)addCommentPost
{
    @try {
      if (self.selectType == SelectGroup)
    {
        [APPDATA showLoader];
        objGroup.key = [API_KEY mutableCopy];
        objGroup.profileid = APPDATA.user.profileid;
        objGroup.comment = [_txtFieldWriteComment.text mutableCopy];
        objGroup.postId = [postid mutableCopy];
        objGroup.groupId = [strGroupId mutableCopy];
        [objGroup sendCommentInGroup:^(NSDictionary *result, NSString *str, int status) {
            if (status == 1) {
                 [[NSNotificationCenter defaultCenter] postNotificationName:@"reloadGroup"  object:nil userInfo:nil];
                 APPDATA.group.isGroupCommentAdd = YES;
                [self.view removeFromSuperview];
              
            }
            else {
               
                self.lblNoDataFound.hidden = NO;
                CGRect frame = self.lblNoDataFound.frame;
                frame.origin.y = (self.view.superview.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
                [self.lblNoDataFound setFrame:frame];

                [APPDATA hideLoader];
            }
        }];
    }else{
        [APPDATA showLoader];
        void (^successed)(id responseObject) = ^(id responseObject)
        {
            int check=[[responseObject objectForKey:@"error"]intValue];
            if (check==1)
            {
            }else{
                APPDATA.group.AddCommentsuccess=YES;

                [(MyDashboardViewController *)[[self.view superview] nextResponder] reloadFeedVCData];
                [self.view removeFromSuperview];

            }
            [APPDATA hideLoader];
        };
        void (^failure)(NSError * error) = ^(NSError *error) {
            [APPDATA hideLoader];
        };
        NSString  *strDeviceToken=[[NSUserDefaults standardUserDefaults] objectForKey:@"strDeviceToken"];
        if ([strDeviceToken isKindOfClass:[NSNull class]] || strDeviceToken == nil || [strDeviceToken isEqualToString:@""])
        {
            strDeviceToken=nil;
        }
        NSDictionary *dict = @{@"key":API_KEY,@"method":API_ADDCOMMENTONPOST,@"profile_id":appDelegate.profilid_AppStr,@"post_id":postid,@"comment":_txtFieldWriteComment.text
                               };
        [APICall sendToService:dict success:successed failure:failure];
    }
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

// Add comment API call with checking condition with comment add or not
- (IBAction)btnSendPressed:(id)sender;
{
    NSCharacterSet *set = [NSCharacterSet whitespaceCharacterSet];
    if ([_txtFieldWriteComment.text length]<1)
    {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_COMMENT];
    }
    else if ([[_txtFieldWriteComment.text stringByTrimmingCharactersInSet: set] length] == 0)
    {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_COMMENT];
    }else{
        [self addCommentPost];
    }
}

#pragma mark Tableview Delegate ....
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    RTLabel *viewComment = [[RTLabel alloc] initWithFrame:CGRectMake(0,0,230,10000)];
    NSString *messageStr= [[commentsArray objectAtIndex:indexPath.row] valueForKey:@"comment"];
    [viewComment setText:messageStr];
    optimumSize = [viewComment optimumSize];
    viewComment = nil;
    return optimumSize.height+50;
}

-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section
{
    return [commentsArray count];
}

// set comments and delete button actions and checking group join or not for display delete buttons
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableId=@"AddCommentTableViewCell";
    AddCommentTableViewCell *cell=(AddCommentTableViewCell*)[tableView dequeueReusableCellWithIdentifier:simpleTableId];
    if (cell == nil) {
        cell = [[AddCommentTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableId];
    }
      cell.selectionStyle = UITableViewCellSelectionStyleNone;
    NSString *userNameStr;
    userNameStr= [[commentsArray objectAtIndex:indexPath.row] valueForKey:@"username"];
    NSString *getTimeStr=[NSString stringWithFormat:@"%@",[appDelegate LocalToday:[[commentsArray objectAtIndex:indexPath.row] objectForKey:@"created_at"]]];
    NSMutableAttributedString *AddStr=[appDelegate opensSemiBold:userNameStr :getTimeStr];
    cell.lblUserName.attributedText=AddStr;
    cell.lblComment.text = [[commentsArray objectAtIndex:indexPath.row] valueForKey:@"comment"];
    CGRect newFrame = cell.lblComment.frame;
    newFrame.size = CGSizeMake(cell.lblComment.frame.size.width, optimumSize.height);
    cell.lblComment.frame = newFrame;
    
    
    if ([_strjoin isEqualToString:@"1"])
    {
        cell.btnDeleteComment.hidden=NO;
    }
    else if ([_strjoin isEqualToString:@"0"])
    {
         cell.btnDeleteComment.hidden=YES;
    }
    else
     {
        cell.btnDeleteComment.hidden=NO;
        
      }
    cell.btnDeleteComment.tag=indexPath.row;
    [cell.btnDeleteComment addTarget:self
                              action:@selector(btnDeletePressed:) forControlEvents:UIControlEventTouchUpInside];
    

    return cell;
}

#pragma mark Share view hidden...
-(void)hideShareView
{
    [_ShareView setHidden:YES];
}

#pragma mark Sharing Btn Actions...
- (IBAction)btnShareTapped:(id)sender;
{
    content = [[FBSDKShareLinkContent alloc] init];
    content.contentTitle =  [[dictFeed objectAtIndex:[sender tag]] valueForKey:@"username"];
    content.contentDescription =  [[dictFeed objectAtIndex:[sender tag]] valueForKey:@"message"];
    if (![[[dictFeed objectAtIndex:[sender tag]] valueForKey:@"post_image"] isKindOfClass:[NSNull class]] &&
        [[[dictFeed objectAtIndex:[sender tag]] valueForKey:@"post_image"] length] > 3) {
        postImageStr = [NSString stringWithFormat:@"%@",[[dictFeed objectAtIndex:[sender tag]] valueForKey:@"post_image"]] ;
    }else{
        postImageStr=@"";
    }
    feed_typeStr=[[dictFeed objectAtIndex:[sender tag]] objectForKey:@"feed_type"];
    postMessageStr=[[dictFeed objectAtIndex:[sender tag]] valueForKey:@"message"];
    if (self.selectType == SelectGroup) {
    }
    else{
        CGRect frame = _ShareView.frame;
        CGRect frame1 =_imgviewBorder.frame;
        frame.size.height = 64;
        _ShareView.frame = frame;
        frame1.size.height = 64;
        _imgviewBorder.frame = frame1;
        [_btnMyfeed setHidden:YES];
    }
    [_ShareView setHidden:NO];
    [self.view bringSubviewToFront:_ShareView];
}

-(void)tapShareView
{
    [_ShareView setHidden:YES];
}


// sharing with email..
- (IBAction)btnEmailTapped:(id)sender;
{
    [_ShareView setHidden:YES];
    if ([feed_typeStr isEqualToString:@"post"]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"Are you sure email,this post ?"
                                                       delegate:self
                                              cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:@"OK",nil];
        alert.tag=401;
        [alert show];
    }else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"Are you sure email,this message ?"
                                                       delegate:self
                                              cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:@"OK",nil];
        alert.tag=402;
        [alert show];
    }
}
// sharing with facebook
- (IBAction)btnFacebookTapped:(id)sender;
{
    [_ShareView setHidden:YES];
    if ([feed_typeStr isEqualToString:@"post"]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"Are you sure share,this post ?"
                                                       delegate:self
                                              cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:@"OK",nil];
        alert.tag=101;
        [alert show];
    }else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"Are you sure share,this message ?"
                                                       delegate:self
                                              cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:@"OK",nil];
        alert.tag=102;
        [alert show];
    }
}

// sharing feed post
- (IBAction)btnMyfeedTapped:(id)sender{
    [_ShareView setHidden:YES];
    if ([feed_typeStr isEqualToString:@"post"]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"Are you sure share,this post ?"
                                                       delegate:self
                                              cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:@"OK",nil];
        alert.tag=301;
        [alert show];
    }else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"Are you sure share,this message ?"
                                                       delegate:self
                                              cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:@"OK",nil];
        alert.tag=302;
        [alert show];
    }
}

#pragma mark AlertView Delagate...
- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    if (alertView.tag==101) {
        if (buttonIndex == 1) {
            [APPDATA showLoader];
            content = [[FBSDKShareLinkContent alloc] init];
            content.contentURL = [NSURL URLWithString:postImageStr];
            NSURL *imageURL =
            [NSURL URLWithString:postImageStr];
            content.contentDescription=[NSString stringWithFormat:@"User Details ;%@",postMessageStr];
            content.contentTitle=@"Photo Bug";
            content.imageURL=imageURL;
            [FBSDKShareDialog showFromViewController:self withContent:content delegate:nil];
            [APPDATA hideLoader];
        }
    }
    if (alertView.tag==102) {
        if (buttonIndex == 1) {
            [APPDATA showLoader];
            content = [[FBSDKShareLinkContent alloc] init];
            content.contentURL = [NSURL URLWithString:@"http://www.zaptechsolutions.com"];
            NSURL *imageURL =
            [NSURL URLWithString:@""];
            content.contentDescription=[NSString stringWithFormat:@"User Details ;%@",postMessageStr];
            content.contentTitle=@"Photo Bug";
            content.imageURL=imageURL;
            [FBSDKShareDialog showFromViewController:self withContent:content delegate:nil];
            [APPDATA hideLoader];
        }
    }
    if (alertView.tag==301) {
        if (buttonIndex == 1) {
            [self addPost];
        }
    }
    if (alertView.tag==302) {
        [self addMessage];
    }
    if (alertView.tag==401) {
        if (buttonIndex == 1) {
            if ([MFMailComposeViewController canSendMail]) {
                MFMailComposeViewController *mailController = [[MFMailComposeViewController alloc] init];
                [APPDATA showLoader];
                [mailController setMailComposeDelegate:self];
                UIImage *pic = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:postImageStr]]];
                NSData *exportData = UIImageJPEGRepresentation(pic ,1.0);
                [mailController addAttachmentData:exportData mimeType:@"image/jpeg" fileName:@"Picture.jpeg"];
                [mailController setToRecipients:[NSArray arrayWithObject:@"Enter email address"]];
                [mailController setMessageBody:postMessageStr isHTML:NO];
                [self presentViewController:mailController animated:YES completion:nil];
                [_ShareView setHidden:YES];
                [APPDATA hideLoader];
            }
        }
    }
    if (alertView.tag==402) {
        if (buttonIndex == 1) {
            if ([MFMailComposeViewController canSendMail]) {
                MFMailComposeViewController *mailController = [[MFMailComposeViewController alloc] init];
                [APPDATA showLoader];
                [mailController setMailComposeDelegate:self];
                [mailController setToRecipients:[NSArray arrayWithObject:@"Enter email address"]];
                [mailController setMessageBody:postMessageStr isHTML:NO];
                [self presentViewController:mailController animated:YES completion:nil];
                [_ShareView setHidden:YES];
                [APPDATA hideLoader];
            }
        }
    }
}

#pragma mark MFMailComposeViewController Delegate...
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error {
    //handle any error
    switch (result)
    {
        case MFMailComposeResultCancelled:
            break;
        case MFMailComposeResultSaved:
            break;
        case MFMailComposeResultSent:
            [APPDATA ShowAlertWithTitle:@"" Message:@"Comment successfully share"];
            break;
        case MFMailComposeResultFailed:
            break;
        default:
            break;
    }
    [controller dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark Add Post Sharing  ...
-(void)addPost
{
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        [(MyDashboardViewController *)[[self.view superview] nextResponder] reloadFeedVCData];
        [self.view removeFromSuperview];
    };
    void (^failure)(NSError * error) = ^(NSError *error) {
    };
    [APPDATA showLoader];
    //1 log
    NSString  *strDeviceToken=[[NSUserDefaults standardUserDefaults] objectForKey:@"strDeviceToken"];
    if ([strDeviceToken isKindOfClass:[NSNull class]] || strDeviceToken == nil || [strDeviceToken isEqualToString:@""])
    {
        strDeviceToken=nil;
    }
    if ([postImageStr length]<1)
    {
        postImageStr=@"";
    }
    NSDictionary *dict = @{@"key":API_KEY,@"post_image":postImageStr,@"feed_type":@"post",@"message":postMessageStr,@"profile_id":appDelegate.profilid_AppStr,@"method":API_ADD_POST
                           };
    [APICall sendToService:dict success:successed failure:failure];
}

#pragma mark add Message Sharing ..
-(void)addMessage{
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        [(MyDashboardViewController *)[[self.view superview] nextResponder] reloadFeedVCData];
        [self.view removeFromSuperview];
    };
    void (^failure)(NSError * error) = ^(NSError *error) {
    };
    //1 log
    NSString  *strDeviceToken=[[NSUserDefaults standardUserDefaults] objectForKey:@"strDeviceToken"];
    if ([strDeviceToken isKindOfClass:[NSNull class]] || strDeviceToken == nil || [strDeviceToken isEqualToString:@""])
    {
        strDeviceToken=nil;
    }
    NSDictionary *dict = @{@"key":API_KEY,@"feed_type":@"message",@"message":postMessageStr,@"profile_id":appDelegate.profilid_AppStr,@"method":API_ADD_POST
                           };
    [APICall sendToService:dict success:successed failure:failure];
}

- (void) singleTapping
{

    [self.view removeFromSuperview];
}

#pragma mark Key board Done Actions.....
-(void)doneAction:(UIBarButtonItem*)barButton
{
    NSCharacterSet *set = [NSCharacterSet whitespaceCharacterSet];
    if ([_txtFieldWriteComment.text length]<1)
    {
        if (_isFromGroup==YES) {
            if (![_strjoin isEqualToString:@"1"])
            {
                [self.view endEditing:YES];
                [APPDATA ShowAlertWithTitle:@"" Message:ERROR_JOIN_COMMENT];
        
            }
         }
        else
        {
            [self.view endEditing:YES];
            [APPDATA ShowAlertWithTitle:@"" Message:ERROR_COMMENT];
        }
    }
    
  
    else if ([[_txtFieldWriteComment.text stringByTrimmingCharactersInSet: set] length] == 0)
    {
        if (_isFromGroup==YES) {

            if (![_strjoin isEqualToString:@"1"])
            {
                [self.view endEditing:YES];
                [APPDATA ShowAlertWithTitle:@"" Message:ERROR_JOIN_COMMENT];
            
            }
        }
           else
        {
            [self.view endEditing:YES];
            [APPDATA ShowAlertWithTitle:@"" Message:ERROR_COMMENT];
        }
    }
    else{
        [self addCommentPost];
    }
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string;
{
    if (_isFromGroup==YES) {
        if (![_strjoin isEqualToString:@"1"])
        {
            [self.view endEditing:YES];
            [APPDATA ShowAlertWithTitle:@"" Message:ERROR_JOIN_COMMENT];
            return NO;
        }

    }
    return YES;

}


- (IBAction)btnclose_Actions:(id)sender {
    
    [self.view removeFromSuperview];
}

-(void)cancelAction:(UIBarButtonItem*)barButton
{
    [_txtFieldWriteComment resignFirstResponder];
}

//  delete comments alert view method selections..
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag==310) {
   
    if (buttonIndex == [alertView cancelButtonIndex])
    {
        
         if (_isFromGroup==YES) {
             
              if ([strUserId isEqualToString:strOtherId])
             {
                 [self groupDeleteCommentAction:rowId index:indexToDeleteComment];
             }
             
             else if ((![strUserId isEqualToString:strOtherId]) && [userName isEqualToString:userCommentName])
             {
                  [self groupDeleteCommentAction:rowId index:indexToDeleteComment];
             }
             else if ([strUserId isEqualToString:postedBy])
             {
                  [self groupDeleteCommentAction:rowId index:indexToDeleteComment];
             }
             else
                 
             {
                [self flagGroupCommentAction:rowId index:indexToDeleteComment];
                 
             }
          }
       
        
         else{
             
             if ([strOtherId isEqualToString:@""])
             {
                 [self feedDeleteCommentAction:rowId index:indexToDeleteComment];
             }
             else if ([strUserId isEqualToString:strOtherId])
             {
                 [self feedDeleteCommentAction:rowId index:indexToDeleteComment];

             }
             
             else if ((![strUserId isEqualToString:strOtherId]) && [userName isEqualToString:userCommentName])
             {
                 [self feedDeleteCommentAction:rowId index:indexToDeleteComment];

             }
             else if ([strUserId isEqualToString:postedBy])
             {
                 [self feedDeleteCommentAction:rowId index:indexToDeleteComment];
             }
             else
                 
             {
                 
                 [self flagDashboardCommentAction:rowId index:indexToDeleteComment];
                 
             }

             
         }
      }
    else{

       }
    }
}

// delete button action and get required IDs...
-(void)btnDeletePressed:(id)sender
{
    @try{
        
        UIButton *btnTapped = (UIButton*)sender;
        NSInteger btnTag = btnTapped.tag;
        indexToDeleteComment = btnTag;
        
        
        if (![[[commentsArray objectAtIndex:[sender tag]] valueForKey:@"id"] isKindOfClass:[NSNull class]])
        {
            rowId = [NSString stringWithFormat:@"%@",[[commentsArray objectAtIndex:[sender tag]] valueForKey:@"id"]] ;
        }else{
            rowId=@"";
        }
        if (![[[commentsArray objectAtIndex:[sender tag]] valueForKey:@"profile_id"] isKindOfClass:[NSNull class]])
        {
            
                userCommentName = [NSString stringWithFormat:@"%@",[[commentsArray objectAtIndex:[sender tag]] valueForKey:@"username"]] ;
            
           
        }
        
        strUserId = [NSString stringWithFormat:@"%@",APPDATA.user.profileid];
        strOtherId=[NSString stringWithFormat:@"%@",APPDATA.user.strOtherId];
        groupId = [NSString stringWithFormat:@"%@",APPDATA.group.groupId];
        postedBy = [NSString stringWithFormat:@"%@",APPDATA.group.postedBy];
         userName = [NSString stringWithFormat:@"%@",UDGetObject(@"username")];
        
        
        if (_isFromGroup==YES) {
            if ([strUserId isEqualToString:postedBy]) {
                
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Delete Comment" message:DELETE_COMMENT delegate:self          cancelButtonTitle:@"Yes"
                                                     otherButtonTitles:@"No",nil];
                [alert show];
                alert.tag=310;
                
                
            }
            
            
            else  if ([strUserId isEqualToString:strOtherId])
            {
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Delete Comment" message:DELETE_COMMENT delegate:self          cancelButtonTitle:@"Yes"
                                                     otherButtonTitles:@"No",nil];
                [alert show];
                
                 alert.tag=310;
            }
            else if ((![strUserId isEqualToString:strOtherId]) && [userName isEqualToString:userCommentName])
            {
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Delete Comment" message:DELETE_COMMENT delegate:self          cancelButtonTitle:@"Yes"
                                                     otherButtonTitles:@"No",nil];
                [alert show];
                 alert.tag=310;
            }

            
            else
            {
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Flag Comment" message:FLAG_COMMENT delegate:self          cancelButtonTitle:@"Yes"
                                                     otherButtonTitles:@"No",nil];
                [alert show];
                 alert.tag=310;
            }
            
            

            

        }
        else
        {
        
        if ([strUserId isEqualToString:postedBy]) {
            
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Delete Comment" message:DELETE_COMMENT delegate:self          cancelButtonTitle:@"Yes"
                                                 otherButtonTitles:@"No",nil];
            [alert show];
            
             alert.tag=310;
        }
        
        
        else  if ([strUserId isEqualToString:strOtherId])
        {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Delete Comment" message:DELETE_COMMENT delegate:self          cancelButtonTitle:@"Yes"
                                                 otherButtonTitles:@"No",nil];
            [alert show];
             alert.tag=310;
            
        }
        else if ((![strUserId isEqualToString:strOtherId]) && [userName isEqualToString:userCommentName])
        {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Delete Comment" message:DELETE_COMMENT delegate:self          cancelButtonTitle:@"Yes"
                                                 otherButtonTitles:@"No",nil];
            [alert show];
             alert.tag=310;
        }
        else if ([strOtherId isEqualToString:@""])
        {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Delete Comment" message:DELETE_COMMENT delegate:self          cancelButtonTitle:@"Yes"
                                                 otherButtonTitles:@"No",nil];
            [alert show];
             alert.tag=310;
        }

        else
        {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Flag Comment" message:FLAG_COMMENT delegate:self
                                      cancelButtonTitle:@"Yes"
                                            otherButtonTitles:@"No",nil];
            [alert show];
            alert.tag=310;
        }
        
        
        }
        
        
  
        return;
        
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    
    
}


// feed delete comment API methods call...
-(void)feedDeleteCommentAction:(NSString*)strFlag index:(NSInteger)index
{
    @try{
        [APPDATA showLoader];
        
        user.rowID = [NSMutableString stringWithFormat:@"%@",rowId];
        [user deleteFeedCommentPost:^(NSString *result, int status)
         {
             if (status == 1) {
                 [[NSNotificationCenter defaultCenter] postNotificationName:@"reloadFeed"  object:nil userInfo:nil];
                 dispatch_async (dispatch_get_main_queue(), ^{
                     
                     NSMutableArray *arrComent = [[NSMutableArray alloc] initWithArray:commentsArray];
                     [arrComent removeObjectAtIndex:index];
                     commentsArray = [[NSMutableArray alloc] init];
                     commentsArray = arrComent;
                     [self.tableviewAddComment reloadData];
                     NSUInteger comInt=commentsArray.count;
                     if (comInt==0)
                     {
                         [self.view removeFromSuperview];
                     }

                     
                 });

                 [APPDATA hideLoader];
                 
                 NSLog(@"success");
             }
             else {
                 
                 NSLog(@"Failed");
                 NSString *strmsg=[APPDATA isValueNullOrEmpty:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]]];
                 [APPDATA ShowAlertWithTitle:@"" Message:strmsg];
                 [APPDATA hideLoader];
             }
         }];
        
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}


//  flag  dashboard comment API methods call...
-(void)flagDashboardCommentAction:(NSString*)strFlag index:(NSInteger)index
{
    @try{
        [APPDATA showLoader];
        
        user.rowID = [rowId mutableCopy];
        user.userid = [NSMutableString stringWithFormat:@"%@",strOtherId];
        [user flagDashboardComment:^(NSString *result, int status)
         {
             if (status == 1) {
                
                 dispatch_async (dispatch_get_main_queue(), ^{
                     
                 });
                 
                 [self.tableviewAddComment reloadData];
                 [APPDATA hideLoader];
                 
                 NSLog(@"success");
                [APPDATA ShowAlertWithTitle:@"" Message:@"Comment Flagged Successfully."];
             }
             else {
                 
                 NSLog(@"Failed");
                 NSString *strmsg=[APPDATA isValueNullOrEmpty:[NSString stringWithFormat:@"%@",result]];
                 [APPDATA ShowAlertWithTitle:@"" Message:strmsg];
                 [APPDATA hideLoader];
             }
         }];
        
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

// flag group comment API methods call...
-(void)flagGroupCommentAction:(NSString*)strFlag index:(NSInteger)index
{
    @try{
        [APPDATA showLoader];
        
        objGroup.rowID = [rowId mutableCopy];
        objGroup.groupId = [NSMutableString stringWithFormat:@"%@",groupId];
       
        [objGroup flagGroupComment:^(NSDictionary *result, NSString *g, int status) {
            
            if (status == 1) {
                [self.tableviewAddComment reloadData];
                 [APPDATA hideLoader];
                 [APPDATA ShowAlertWithTitle:@"" Message:@"Comment Flagged Successfully."];
                 NSLog(@"success");
             }
             else {
                 
                 NSLog(@"Failed");
                  [APPDATA hideLoader];
                 NSString *strmsg=[APPDATA isValueNullOrEmpty:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]]];
                 [APPDATA ShowAlertWithTitle:@"" Message:strmsg];
                
             }
         }];
        
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

// Group delete comment API methods call...
-(void)groupDeleteCommentAction:(NSString*)strFlag index:(NSInteger)index
{
    @try{
        [APPDATA showLoader];
        
        objGroup.rowID = [NSMutableString stringWithFormat:@"%@",rowId];
          objGroup.groupId = [NSMutableString stringWithFormat:@"%@",groupId];
        
        [objGroup deleteGroupCommentPost:^(NSDictionary *result, NSString *str, int status) {
            if (status == 1) {
               [[NSNotificationCenter defaultCenter] postNotificationName:@"reloadGroup"  object:nil userInfo:nil];
                
                    [commentsArray removeObjectAtIndex:index];
                      [self.tableviewAddComment reloadData];
                     NSUInteger comInt=commentsArray.count;
                    if (comInt==0)
                    {
                        [self.view removeFromSuperview];
                    }
                
                [APPDATA hideLoader];
                
                NSLog(@"success");
            }
            else {
                 [APPDATA hideLoader];
                NSLog(@"Failed");
                NSString *strmsg=[APPDATA isValueNullOrEmpty:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]]];
                [APPDATA ShowAlertWithTitle:@"" Message:strmsg];
               
            }
        }];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}




@end
