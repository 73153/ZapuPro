//
//  CntcInfoTableViewCell.m
//  photobug
//
//   on 28/06/16.
//  Copyright © Photobug. All rights reserved.
//

#import "CntcInfoTableViewCell.h"
#import "Users.h"
#import "Constant.h"
#import "ApplicationData.h"
#import "APICall.h"
#import "EditProfileViewController.h"

@implementation CntcInfoTableViewCell
{
    Users *user;
    NSMutableArray *arrPicker,*ArrPickerdata;
    UIPickerView *pickerView;
    EditProfileViewController *objEdit;
}

@synthesize TblViewPicker,lblPickerView,delegate;

- (void)awakeFromNib
{
    [super awakeFromNib];
    arrPicker=[[NSMutableArray alloc]init];
    ArrPickerdata=[[NSMutableArray alloc]init];
    user = [[Users alloc]init];
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    objEdit = (EditProfileViewController*)[mainStoryboard
                                                                    instantiateViewControllerWithIdentifier: @"EditProfileViewController"];
    _txtFildPicker.userInteractionEnabled=NO;
    [self.TxtFieldStreet addTarget:self
                  action:@selector(textFieldDidChangeStreet:)
        forControlEvents:UIControlEventEditingChanged];
    [self.TxtFieldStreet2 addTarget:self
                            action:@selector(textFieldDidChangeStreet2:)
                  forControlEvents:UIControlEventEditingChanged];
    [self.TxtFieldCity addTarget:self
                            action:@selector(textFieldDidChangeCity:)
                  forControlEvents:UIControlEventEditingChanged];
    [self.TxtFieldZip addTarget:self
                            action:@selector(textFieldDidChangeZip:)
                  forControlEvents:UIControlEventEditingChanged];
    [self.TxtFieldPhoneNom addTarget:self
                         action:@selector(textFieldDidChangePhone:)
               forControlEvents:UIControlEventEditingChanged];
}

-(void)textFieldDidChangePhone :(UITextField *)theTextField{
    NSLog( @"text changed: %@", theTextField.text);
    APPDATA.user.strTxtfildPhonenom=theTextField.text.mutableCopy;
}

-(void)textFieldDidChangeStreet :(UITextField *)theTextField{
      APPDATA.user.strTextfildStreet=theTextField.text.mutableCopy;
     UDSetObject(APPDATA.user.strTextfildStreet, @"streetaddress1");
}

-(void)textFieldDidChangeStreet2 :(UITextField *)theTextField{
     APPDATA.user.strtxtFildStreet2=theTextField.text.mutableCopy;
    UDSetObject(APPDATA.user.strtxtFildStreet2   , @"streetaddress2");
}

-(void)textFieldDidChangeCity :(UITextField *)theTextField{
     APPDATA.user.strtxtfildCity=theTextField.text.mutableCopy;
    UDSetObject(APPDATA.user.strtxtfildCity, @"city");
}

-(void)textFieldDidChangeZip :(UITextField *)theTextField{
    APPDATA.user.strtxtfildZip=theTextField.text.mutableCopy;
    UDSetObject(APPDATA.user.strtxtfildZip, @"zip");
}

-(void)GetPickerData
{
    NSString *url_String = [NSString stringWithFormat:@"%@",API_PICKERLIST];
        NSDictionary *parameters = @{@"key":API_KEY,};
    [APICall callGetWebService:url_String andDictionary:parameters completion:^(NSMutableDictionary *user1, NSError *error, long code) {
        if(error)
        {
        }
        else
        {
            [arrPicker addObject:user1];
            ArrPickerdata=[[arrPicker objectAtIndex:0]valueForKey:@"data"];
            
            [self.delegate Pickerdata:ArrPickerdata];
        }
    }];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

- (IBAction)ButStatePicker:(id)sender
{
       [self GetPickerData];
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

@end
