//
//  DescriptionTableViewCell.h
//  photobug
//
//   on 28/06/16.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Singleton.h"

@interface DescriptionTableViewCell : UITableViewCell<UITextFieldDelegate,UITextViewDelegate>
@property (strong, nonatomic) IBOutlet UITextView *TxtViewDescription;
@property (strong, nonatomic) IBOutlet UIImageView *imgViewUncheck;
@property (strong, nonatomic) IBOutlet UIButton *btnUncheck;
@property (strong, nonatomic) IBOutlet UITextField *txtUserName;    

@end
