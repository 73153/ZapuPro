//
//  FeedCell2TableViewCell.h
//  photobug
//
//   on 12/11/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FeedCell2TableViewCell : UITableViewCell

@property (nonatomic,strong) IBOutlet UILabel *lblUserName;
@property (nonatomic,strong) IBOutlet UILabel *lblTime;
@property (nonatomic,strong) IBOutlet UILabel *lblComment;
@property (nonatomic,strong) IBOutlet UIButton *btnComment;
@property (nonatomic,strong) IBOutlet UIButton *btnShare;
@property (nonatomic,strong) IBOutlet UITextField *txtComment;
@property (strong,nonatomic) IBOutlet UITextView *txtmeassage;
@property (strong,nonatomic) IBOutlet UILabel *lblCommentCount;
@property (nonatomic,strong) IBOutlet UIButton *btnDeletePost;



@end
