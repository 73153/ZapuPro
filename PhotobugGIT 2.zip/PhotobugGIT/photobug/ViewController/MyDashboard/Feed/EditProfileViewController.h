

//
//  EditProfileViewController.h
//  photobug
//
//   on 27/06/16.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "STCollapseTableView.h"
#import "CntcInfoTableViewCell.h"
//#import "ActionSheetStringPicker.h"

@protocol SignInSignUp <NSObject>

-(void)Buttonhidden;

@end

@interface EditProfileViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UIPickerViewDelegate,UIPickerViewDataSource,UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UIPickerView *pickerView,*pickerView2;
@property (strong, nonatomic) id <SignInSignUp> delegate;
@property (strong, nonatomic) IBOutlet UIView *VIEWPICKERVIEW;
@property (strong, nonatomic) IBOutlet UIButton *btnSubmit;
@property (strong, nonatomic) NSString *Stradd1,*Stradd2,*StrCity,*StrCntc,*StrEnableSMS,*StrIsPrivate,*StrDescription,*StrZip,*StrState,*StrUserName;
@property (strong, nonatomic) IBOutlet STCollapseTableView *tableview;
@property (strong, nonatomic) IBOutlet UIView *SampleView;
@property (strong, nonatomic) IBOutlet UIImageView *imgUncheck;
@property BOOL isAdded;
@property BOOL isPicker;
@property (strong, nonatomic) IBOutlet UIButton *btnMakeUrAcPrivate;
- (IBAction)BtnClose:(id)sender;

@end

