//
//  FeedCell2TableViewCell.m
//  photobug
//
//   on 12/11/15.
//  Copyright © Photobug. All rights reserved.
//

#import "FeedCell2TableViewCell.h"

@implementation FeedCell2TableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
