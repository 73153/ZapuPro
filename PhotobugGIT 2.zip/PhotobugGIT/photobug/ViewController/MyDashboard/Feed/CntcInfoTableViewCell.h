

#import <UIKit/UIKit.h>
#import "EditProfileViewController.h"

@protocol PickerDataDele <NSObject>

-(void)Pickerdata: (NSMutableArray *)pickerAry;

@end

@interface CntcInfoTableViewCell : UITableViewCell<UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UITextField *txtFildPicker;
@property (strong, nonatomic) id <PickerDataDele> delegate;
@property (strong, nonatomic) IBOutlet UITextField *TxtFieldPhoneNom;
@property (strong, nonatomic) IBOutlet UITextField *TxtFieldStreet;
@property (strong, nonatomic) IBOutlet UITextField *TxtFieldStreet2;
@property (strong, nonatomic) IBOutlet UIButton *BtnPicker;
@property (strong, nonatomic) IBOutlet UITextField *TxtFieldCity;
@property (strong, nonatomic) IBOutlet UITextField *TxtFieldZip;
@property (strong, nonatomic) IBOutlet UITableView *TblViewPicker;
@property (strong, nonatomic) IBOutlet UILabel *lblPickerView;
@property (strong, nonatomic) IBOutlet UIView *PickerViewState;
@property (strong, nonatomic) IBOutlet UIPickerView *pickerview;
- (IBAction)ButStatePicker:(id)sender;

@end
