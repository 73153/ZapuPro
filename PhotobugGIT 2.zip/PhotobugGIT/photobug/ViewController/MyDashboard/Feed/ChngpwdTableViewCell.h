//
//  ChngpwdTableViewCell.h
//  photobug
//
//   on 28/06/16.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChngpwdTableViewCell : UITableViewCell<UITextFieldDelegate>
@property (strong, nonatomic) IBOutlet UITextField *TxtFieldCurrentPwd;
@property (strong, nonatomic) IBOutlet UITextField *TxtFieldNewPwd;
@property (strong, nonatomic) IBOutlet UITextField *TxtFieldReTypePwd;
@end
