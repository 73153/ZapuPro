//
//  DescriptionTableViewCell.m
//  photobug
//
//   on 28/06/16.
//  Copyright © Photobug. All rights reserved.
//

#import "DescriptionTableViewCell.h"
#import "Users.h"
#import "Constant.h"
#import "ApplicationData.h"

@implementation DescriptionTableViewCell
{
    Users *user;
    NSString *addtoshopStr;
    BOOL addtoshopFlag,FlagCheck;
}
- (void)awakeFromNib {
    [super awakeFromNib];
    user=[[Users alloc]init];
    addtoshopFlag=YES;
    _TxtViewDescription.delegate=self;
    user.StrTextViewDescription.string=self.TxtViewDescription.text;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}

-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([Validations checkMaxLength:textView.text withLimit:250 ])
    {
        APPDATA.user.StrTextViewDescription.string=textView.text.mutableCopy;
        UDSetObject(APPDATA.user.StrTextViewDescription, @"Description");
        return YES;
    }
    else
    {
        NSLog(@"Out of limit");
        return NO;
    }
    return YES;
}

- (IBAction)btnAddShopTapped:(id)sender
{
    if (!_btnUncheck.selected)
    {
        _btnUncheck.selected = TRUE;
        addtoshopStr=@"1";
       APPDATA. user.strSMS=YES;
        [_btnUncheck setImage:[UIImage imageNamed:@"checkin_btn_select"] forState:UIControlStateNormal];
        NSLog(@"%@",addtoshopStr);
    }
    else
    {
        _btnUncheck.selected = FALSE;
        addtoshopStr=@"0";
        APPDATA.user.strSMS=NO;
        [_btnUncheck setImage:[UIImage imageNamed:@"checkin_btn"] forState:UIControlStateNormal];
        FlagCheck=YES;
        NSLog(@"%@",addtoshopStr);
    }
}

@end
