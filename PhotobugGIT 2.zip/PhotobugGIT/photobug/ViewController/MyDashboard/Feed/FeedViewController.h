//
//  FeedViewController.h
//  photobug
//
//   on 11/19/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FeedCell.h"
#import "FeedMessageCell.h"
#import "RTLabel.h"
#import <MessageUI/MessageUI.h>
#import "Constant.h"

@protocol imgProto <NSObject>
-(void)imgGet:(NSString *)imgCLickComment;
@end

@interface FeedViewController : UIViewController <MFMailComposeViewControllerDelegate,UITableViewDataSource,UITableViewDelegate>
{
    NSString *postMessageStr,*feed_typeStr,*postImageStr;
}

@property (nonatomic)BOOL usertype,addCommentSuccess;
@property (strong, nonatomic) IBOutlet UITableView *tableviewFeed;
@property (weak, nonatomic) IBOutlet UIButton *btnEmail;
@property (weak, nonatomic) IBOutlet UIButton *btnFackebook;
@property (nonatomic,strong) IBOutlet UILabel *lblNoDataFound;
@property (weak, nonatomic) IBOutlet UIButton *btnMyfeed;
@property (weak,nonatomic) id <imgProto> imgProtocol;
@property (nonatomic, weak) IBOutlet RTLabel *postviewComment;
@property(nonatomic ,retain)NSString *strProfileid, *strOtherProfileID;
@property (weak, nonatomic) IBOutlet UIView *ShareView;
@property (weak, nonatomic) IBOutlet UIImageView *imgviewBorder;
@property (strong, nonatomic) IBOutlet UIImageView *bigimageVIew;

- (IBAction)btnEmailTapped:(id)sender;
- (IBAction)btnFacebookTapped:(id)sender;
- (IBAction)btnMyfeedTapped:(id)sender;
-(void)feedupdateUpdateMethod;
-(IBAction)shareDispalyMethod:(id)sender;
-(IBAction)commentDispalyMethod:(id)sender;
- (IBAction)imgFeedAction:(id)sender;
-(void)doneAction:(UIBarButtonItem*)barButton;

@end
