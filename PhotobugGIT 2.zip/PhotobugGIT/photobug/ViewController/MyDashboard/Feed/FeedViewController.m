    //
//  FeedViewController.m
//  photobug
//
//   on 11/19/15.
//  Copyright © Photobug. All rights reserved.
//
#import "FeedViewController.h"
#import "APICall.h"
#import "ApplicationData.h"
#import "Constant.h"
#import "APICall.h"
#import "FeedCell.h"
#import "FeedMessageCell.h"
#import "AddCommentViewController.h"
#import "MyDashboardViewController.h"
#import "NSDate+DateTools.h"
#import "DTTimePeriod.h"
#import "IQKeyboardManager.h"
#import "IQKeyboardManagerConstants.h"
#import "IQKeyboardReturnKeyHandler.h"
#import "IQUIView+IQKeyboardToolbar.h"
#import <FBSDKShareKit/FBSDKShareKit.h>
#import "FeedCell2TableViewCell.h"
#import <UIActivityIndicator-for-SDWebImage/UIImageView+UIActivityIndicatorForSDWebImage.h>
#define IMAGE_VIEW_TAG 999

@interface FeedViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    NSString *strProfileid;
    UIImage * imageForBigView;
    NSMutableArray *dictFeed;
    NSArray *commentsArray;
    CGSize optimumSize;
    MyDashboardViewController *objMyDashboardViewController;
    UITapGestureRecognizer *singleTap;
    NSMutableArray *aryCellHeight;
    IQKeyboardReturnKeyHandler *returnKeyHandler;
    FBSDKShareButton *shareButton;
    FBSDKShareLinkContent *content;
    NSString *commentStr,*postidStr,*rowid,*userId,*strUserId;
    NSString *strForImage;
    BOOL _wasKeyboardManagerEnabled;
    Users *user;
     NSInteger indexToDeletePost;
   
}
@end

@implementation FeedViewController
@synthesize usertype,strProfileid,imgProtocol,addCommentSuccess;


- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableviewFeed setBounces:NO];
    [SlideNavigationController sharedInstance].enableSwipeGesture = YES;

    SDImageCache *imageCache = [SDImageCache sharedImageCache];
    [imageCache clearMemory];
    [imageCache clearDisk];
    [[IQKeyboardManager sharedManager] setEnable:YES];
    [[IQKeyboardManager sharedManager] setEnableAutoToolbar:YES];
    
    returnKeyHandler = [[IQKeyboardReturnKeyHandler alloc] initWithViewController:self];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self
                                                                         action:@selector(tapShareView)];
    [self.view addGestureRecognizer:tap];
    UITapGestureRecognizer *tap2 = [[UITapGestureRecognizer alloc]initWithTarget:self
                                                                          action:@selector(tapShareView2)];
    [self.tableviewFeed addGestureRecognizer:tap2];
    [_ShareView setHidden:YES];
     user = [[Users alloc]init];
    dictFeed=[[NSMutableArray alloc]init];
   }

-(BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return YES;
}
// CAll FeedUpdate method API
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self feedupdateUpdateMethod];
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(hideShareView) name:@"hideShareView" object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(feedupdateUpdateMethod) name:@"reloadFeed" object:nil];
    _tableviewFeed.delegate=self;
    _tableviewFeed.dataSource=self;
    if (usertype==0)
    {
        strProfileid=[NSString stringWithFormat:@"%@",APPDATA.user.profileid];
    }
    if (APPDATA.otherprofile==1)
    {
        usertype=1;
        strProfileid = _strOtherProfileID;
        

    }
    if (usertype == 1) {
        APPDATA.strFollowby = [NSString stringWithFormat:@"%@",strProfileid];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"IsUserFollow" object:nil];
    }
     }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark MFMailComposeViewController Delegate ...
- (void) mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    switch (result)
    {
        case MFMailComposeResultCancelled:
            break;
        case MFMailComposeResultSaved:
            break;
        case MFMailComposeResultSent:
            [APPDATA ShowAlertWithTitle:@"" Message:@"Post successfully share"];
            break;
        case MFMailComposeResultFailed:
            break;
        default:
            break;
    }
    [self dismissViewControllerAnimated:YES completion:NULL];
}

#pragma mark Sharing Btn Method....
- (IBAction)btnEmailTapped:(id)sender {
    [_ShareView setHidden:YES];
    if ([feed_typeStr isEqualToString:@"post"]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"Are you sure email,this post ?"
                                                       delegate:self cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:@"OK",nil];
        alert.tag=201;
        [alert show];
    }else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"Are you sure email,this message ?" delegate:self cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:@"OK",nil];
        alert.tag=202;
        [alert show];
    }
}

// Sharing facebook post methods alert action..
- (IBAction)btnFacebookTapped:(id)sender {
    [_ShareView setHidden:YES];
    if ([feed_typeStr isEqualToString:@"post"]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"Are you sure share,this post ?"
                                                       delegate:self
                                              cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:@"OK",nil];
        alert.tag=301;
        [alert show];
    }else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"Are you sure share,this message ?"
                                                       delegate:self
                                              cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:@"OK",nil];
        alert.tag=302;
        [alert show];
    }
}

// Sharing feed post methods alert action..
- (IBAction)btnMyfeedTapped:(id)sender {
    [_ShareView setHidden:YES];
    if ([feed_typeStr isEqualToString:@"post"]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"Are you sure share,this post ?"
                                                       delegate:self
                                              cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:@"OK",nil];
        alert.tag=101;
        [alert show];
    }else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:@"Are you sure share,this message ?"
                                                       delegate:self
                                              cancelButtonTitle:@"Cancel"
                                              otherButtonTitles:@"OK",nil];
        alert.tag=102;
        [alert show];
    }
}

#pragma mark Alertview Delegate
- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    if (alertView.tag==101) {
        if (buttonIndex == 1) {
            [self addPostMethd];
        }
    }
    if (alertView.tag==102) {
        if (buttonIndex == 1) {
            [self addmessageMethd];
        }
    }
    if (alertView.tag==201) {
        if (buttonIndex == 1) {
            [APPDATA showLoader];
            MFMailComposeViewController *mc=[[MFMailComposeViewController alloc]init];
            UIImage *pic = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:postImageStr]]];
            NSData *exportData = UIImageJPEGRepresentation(pic ,1.0);
            [mc addAttachmentData:exportData mimeType:@"image/jpeg" fileName:@"Picture.jpeg"];
            mc.mailComposeDelegate=self;
            [mc setMessageBody:postMessageStr isHTML:NO];
            
            [self presentViewController:mc animated:YES completion:NULL];
            [_ShareView setHidden:YES];
            [APPDATA hideLoader];
        }
    }
    if (alertView.tag==202) {
        if (buttonIndex == 1) {
            [APPDATA showLoader];
            MFMailComposeViewController *mc=[[MFMailComposeViewController alloc]init];
            mc.mailComposeDelegate=self;
            [mc setMessageBody:postMessageStr isHTML:NO];
            [self presentViewController:mc animated:YES completion:NULL];
            [_ShareView setHidden:YES];
            [APPDATA hideLoader];
        }
    }
    if (alertView.tag==301) {
        if (buttonIndex == 1) {
            [APPDATA showLoader];
            content = [[FBSDKShareLinkContent alloc] init];
            content.contentURL = [NSURL URLWithString:postImageStr];
            NSURL *imageURL =
            [NSURL URLWithString:postImageStr];
            content.contentDescription=[NSString stringWithFormat:@"User Details ;%@",postMessageStr];
            content.contentTitle=@"Photo Bug";
            content.imageURL=imageURL;
            [FBSDKShareDialog showFromViewController:self withContent:content delegate:nil];
            //////////////////////////////////
            [APPDATA hideLoader];
        }
    }
    if (alertView.tag==302) {
        if (buttonIndex == 1) {
            [APPDATA showLoader];
            content = [[FBSDKShareLinkContent alloc] init];
            content.contentURL = [NSURL URLWithString:@"http://www.zaptechsolutions.com"];
            NSURL *imageURL =
            [NSURL URLWithString:@""];
            content.contentDescription=[NSString stringWithFormat:@"User Details ;%@",postMessageStr];
            content.contentTitle=@"Photo Bug";
            content.imageURL=imageURL;
            [FBSDKShareDialog showFromViewController:self withContent:content delegate:nil];
            [APPDATA hideLoader];
        }
    }
}

#pragma mark Feed Geeting Method ....
-(void)feedupdateUpdateMethod;
{
    [APPDATA showLoader];
    void (^successed)(id responseObject) = ^(id responseObject)
    {
          [[NSNotificationCenter defaultCenter] postNotificationName:@"hideBtnPost" object:nil];
        if([[responseObject objectForKey:@"data"]  isEqual: @""])
        {
            [APPDATA hideLoader];
        }
        else
        {
            if ([responseObject count]>1)
            {
                _lblNoDataFound.hidden= YES;
                NSDictionary *datadic=[responseObject objectForKey:@"data"];
                dictFeed=[datadic objectForKey:@"feed_data"];
                APPDATA.user.isProfilePublish = [[[responseObject valueForKey:@"data"] valueForKey:@"user_status"] boolValue];
                UDSetBool(APPDATA.user.isProfilePublish, @"isPublishProfile");
                [[NSNotificationCenter defaultCenter]postNotificationName:@"checkPublishProfile" object:nil];
                if (dictFeed.count == 0)
                {
                    if (usertype==0){
                        _lblNoDataFound.text=@"Click the New Post button to begin sharing images and posting comments to your feed.";
                    }else{
                        _lblNoDataFound.text=@"Click the Post button to begin sharing images and post comments to the feed.";
                    }
                    _lblNoDataFound.hidden= NO;
                    CGRect frame = self.lblNoDataFound.frame;
                    frame.origin.y = (self.view.superview.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
                    [self.lblNoDataFound setFrame:frame];


                    [self.tableviewFeed reloadData];
                    if (APPDATA.group.AddCommentsuccess==YES)
                    {
                        [APPDATA hideLoader];
                        APPDATA.group.AddCommentsuccess=NO;
                        [APPDATA ShowAlertWithTitle:@"" Message:SUCCES_COMMENT];
                        
                    }
                    
                    [self.view endEditing:true];
                }else{
                    appDelegate.followedby_AppStr=[NSString stringWithFormat:@"%@",[datadic objectForKey:@"followedby"]];
                    appDelegate.followers_AppStr=[NSString stringWithFormat:@"%@",[datadic objectForKey:@"followers"]];
                   
                    dispatch_async (dispatch_get_main_queue(), ^{
                        
                        [self.tableviewFeed reloadData];
                    });
                    if (APPDATA.group.AddCommentsuccess==YES)
                    {
                        [APPDATA hideLoader];
                        APPDATA.group.AddCommentsuccess=NO;
                        [APPDATA ShowAlertWithTitle:@"" Message:SUCCES_COMMENT];
                    }
                    [self.view endEditing:true];
                }
            }
            [APPDATA hideLoader];
        }
    };
    void (^failure)(NSError * error) = ^(NSError *error)
    {
        _lblNoDataFound.hidden= NO;
        CGRect frame = self.lblNoDataFound.frame;
        frame.origin.y = (self.view.superview.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
        [self.lblNoDataFound setFrame:frame];


        if (usertype==0){
            _lblNoDataFound.text=@"Click the New Post button to begin sharing images and posting comments to your feed.";
        }else{
            _lblNoDataFound.text=@"Click the Post button to begin sharing images and post comments to the feed.";
        }
        [self feedupdateUpdateMethod];
        [self.tableviewFeed reloadData];
        [APPDATA hideLoader];
    };
    @try {
        NSDictionary *dict;
        if (usertype==0)
        {
            dict = @{@"key":API_KEY,@"profile_id":appDelegate.profilid_AppStr,@"method":API_PROFILE_FEED
                     };
        }else
        {
            dict = @{@"key":API_KEY,@"followed_by":appDelegate.profilid_AppStr,@"profile_id":APPDATA.user.strOtherId,@"method":API_PROFILE_FEED
                     };
            
            APPDATA.otherprofile=0;
        }
        [APICall sendToService:dict success:successed failure:failure];
    }
    @catch (NSException *exception) {
    }
    @finally {
    }
}

#pragma mark TableView Delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex {
    return [dictFeed count];
}
// set the data like image ,comments ,times and checking the own feed or other profile  set data aaccording and delete post actions.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    [[NSNotificationCenter defaultCenter] postNotificationName:@"hideDropDown" object:nil];
    
    if ([ [[dictFeed objectAtIndex:indexPath.row] objectForKey:@"feed_type"] isEqualToString:@"post"])
    {
        NSString *imagestrChek = [NSString stringWithFormat:@"%@",[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"post_image"]] ;
        if ([imagestrChek length]>3)
        {
            static NSString *CellIdentifier = @"FeedCell";
            FeedCell  *cell = (FeedCell *)[self.tableviewFeed dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            NSString *userNameStr;
            if (![[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"other_username"] isKindOfClass:[NSNull class]] &&
                [[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"other_username"] length] > 3) {
                userNameStr =[[NSString stringWithFormat:@"%@",[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"other_username"]] uppercaseString];
            }else{
                userNameStr=[[NSString stringWithFormat:@"%@",[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"username"]] uppercaseString];
            }
            cell.txtmeassage.textContainerInset = UIEdgeInsetsMake(10, -5.0, 0.0, 0.0);
            cell.txtmeassage.text=[NSString stringWithFormat:@"%@",[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"message"]];
            NSString *getTimeStr=[NSString stringWithFormat:@"%@",[appDelegate LocalToday:[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"created_at"]]];
            cell.lblUserName.text=userNameStr;
                cell.lblTime.text= getTimeStr;
            

            commentsArray=[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"comments"];
            cell.lblCommentcount.text=[NSString stringWithFormat:@"( %lu )",(unsigned long)[commentsArray count]];
            
            cell.btnDeletePostImg.tag=indexPath.row;
            [cell.btnDeletePostImg addTarget:self
                                   action:@selector(btnDeletePressed:) forControlEvents:UIControlEventTouchUpInside];
            
            
            
            cell.btnShare.tag=indexPath.row;
            [cell.btnShare addTarget:self
                              action:@selector(shareDispalyMethod:)
                    forControlEvents:UIControlEventTouchUpInside];
            cell.btnComment.tag=indexPath.row;
            [cell.btnComment addTarget:self
                                action:@selector(commentDispalyMethod:)
                      forControlEvents:UIControlEventTouchUpInside];
            NSString *imagestr;
            if (![[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"post_image"] isKindOfClass:[NSNull class]] &&
                [[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"post_image"] length] > 3)
            {
                imagestr = [NSString stringWithFormat:@"%@",[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"post_image"]] ;
                NSString *fCharStr =[imagestr substringToIndex:22];
                if ([imagestr rangeOfString:@"convert"].location == NSNotFound && [fCharStr isEqualToString:@"https://www.filepicker"])
                {
                  
                }else if([fCharStr isEqualToString:@"https://www.filepicker"])
                {
                    imagestr = [imagestr substringToIndex:[imagestr length]-20];
                   
                }
                if(imagestr.length>3)
                {
                    [cell.imgFeed setImageWithURL:[NSURL URLWithString:imagestr] placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                    cell.imgFeed.clipsToBounds=YES;
                }else{
                    [cell.imgFeed setImage:[UIImage imageNamed:@"no_imgV.png"]];
                }
                cell.imgFeed.contentMode = UIViewContentModeScaleAspectFill;
                cell.imgFeed.clipsToBounds=YES;
            }else
            {
                [cell.imgFeed setImage:[UIImage imageNamed:@"no_imgV.png"]];
            }
            cell.imgFeed.contentMode = UIViewContentModeScaleAspectFill;
            cell.imgFeed.clipsToBounds=YES;
             cell.imgbtnFeed.tag=indexPath.row;
            cell.txtComment.tag=indexPath.row;
            cell.txtComment.text=@"";
            [cell.txtComment addCancelDoneOnKeyboardWithTarget:self cancelAction:@selector(cancelAction:) doneAction:@selector(doneAction:)];
            cell.btnShare.hidden=YES;
            return cell;
        }else{
            static NSString *CellIdentifier = @"FeedCell2TableViewCell";
            FeedCell2TableViewCell  *cell = (FeedCell2TableViewCell *)[self.tableviewFeed dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
              cell.selectionStyle = UITableViewCellSelectionStyleNone;
            NSString *userStr;
            if (![[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"other_username"] isKindOfClass:[NSNull class]] &&
                [[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"other_username"] length] > 3) {
                userStr=[[NSString stringWithFormat:@"%@",[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"other_username"]] uppercaseString];
            }else{
                
                userStr=[[NSString stringWithFormat:@"%@",[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"username"]] uppercaseString];
                
            }
            cell.txtmeassage.textContainerInset = UIEdgeInsetsMake(10, -5.0, 0.0, 0.0);
            cell.txtmeassage.text=[NSString stringWithFormat:@"%@",[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"message"]];
            NSString *getTimeStr=[NSString stringWithFormat:@"%@",[appDelegate LocalToday:[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"created_at"]]];
            NSMutableAttributedString *AddStr=[appDelegate opensSemiBold:[NSString stringWithFormat:@"%@",[[APPDATA isNullOrEmpty:userStr] mutableCopy]]:getTimeStr];
            cell.lblUserName.attributedText=AddStr;
            commentsArray=[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"comments"];
            cell.lblCommentCount.text=[NSString stringWithFormat:@"( %lu )",(unsigned long)[commentsArray count]];
            
             cell.btnDeletePost.tag=indexPath.row;
            [cell.btnDeletePost addTarget:self
                action:@selector(btnDeletePressed:) forControlEvents:UIControlEventTouchUpInside];
            
            
            cell.btnShare.tag=indexPath.row;
            [cell.btnShare addTarget:self
                              action:@selector(shareDispalyMethod:)
                    forControlEvents:UIControlEventTouchUpInside];
            cell.btnComment.tag=indexPath.row;
            [cell.btnComment addTarget:self
                                action:@selector(commentDispalyMethod:)
                      forControlEvents:UIControlEventTouchUpInside];
            cell.txtComment.tag=indexPath.row;
            cell.txtComment.text=@"";
            [cell.txtComment addCancelDoneOnKeyboardWithTarget:self cancelAction:@selector(cancelAction:) doneAction:@selector(doneAction:)];
           
            cell.btnShare.hidden=YES;
            return cell;
        }
    }else
    {
        static NSString *CellIdentifier = @"MessageCell";
        FeedMessageCell  *cell = (FeedMessageCell *)[self.tableviewFeed dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
          cell.selectionStyle = UITableViewCellSelectionStyleNone;
        NSString *userStr;
        if (![[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"other_username"] isKindOfClass:[NSNull class]] &&
            [[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"other_username"] length] > 3) {
            userStr=[[NSString stringWithFormat:@"%@",[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"other_username"]] uppercaseString];
        }else
        {
            userStr=[[NSString stringWithFormat:@"%@",[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"username"]] uppercaseString];
        }
        cell.txtmeassage.textContainerInset = UIEdgeInsetsMake(10, -5.0, 0.0, 0.0);
        cell.txtmeassage.text=[NSString stringWithFormat:@"%@",[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"message"]];
        NSString *getTimeStr=[NSString stringWithFormat:@"%@",[appDelegate LocalToday:[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"created_at"]]];
        NSMutableAttributedString * AddStr=[appDelegate opensSemiBold:[NSString stringWithFormat:@"%@",[[APPDATA isNullOrEmpty:userStr] mutableCopy]]:getTimeStr];
        cell.lblUserName.attributedText=AddStr;
        commentsArray=[[dictFeed objectAtIndex:indexPath.row] objectForKey:@"comments"];
        cell.lblCommentCount.text=[NSString stringWithFormat:@"( %lu )",(unsigned long)[commentsArray count]];
      
        
        cell.btnDeletePostMsg.tag=indexPath.row;
        [cell.btnDeletePostMsg addTarget:self
                                  action:@selector(btnDeletePressed:) forControlEvents:UIControlEventTouchUpInside];
        
        cell.btnShare.tag=indexPath.row;
        [cell.btnShare addTarget:self
                          action:@selector(shareDispalyMethod:)
                forControlEvents:UIControlEventTouchUpInside];
        cell.btnComment.tag=indexPath.row;
        [cell.btnComment addTarget:self
                            action:@selector(commentDispalyMethod:)
                  forControlEvents:UIControlEventTouchUpInside];
        cell.txtComment.tag=indexPath.row;
        [cell.txtComment addCancelDoneOnKeyboardWithTarget:self cancelAction:@selector(cancelAction:) doneAction:@selector(doneAction:)];
        cell.txtComment.text=@"";
        cell.btnShare.hidden=YES;
        return cell;
    }
    return nil;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([APPDATA validateWebURL:[[dictFeed objectAtIndex:indexPath.row]valueForKey:@"post_image"]]) {
        FeedCell *Cell=[tableView cellForRowAtIndexPath:indexPath];
        imageForBigView=Cell.imgFeed.image;
        strForImage= [[dictFeed objectAtIndex:indexPath.row]valueForKey:@"post_image"];
    }

 }

// get image string
- (IBAction)imgFeedAction:(id)sender
{
    dispatch_async(dispatch_get_main_queue(), ^{
        strForImage= [[dictFeed objectAtIndex:[sender tag]]valueForKey:@"post_image"];
        [imgProtocol imgGet:strForImage];
    });
}

#pragma mark Scrllview Delegate ...
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [_ShareView setHidden:YES];
}

-(void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView
{
    [_ShareView setHidden:YES];
}

#pragma mark Comment Dispaly Method ....
-(IBAction)commentDispalyMethod:(id)sender{
    @try{
    NSArray *commentsArray2=[[dictFeed objectAtIndex:[sender tag]] objectForKey:@"comments"];
    NSUInteger comInt=commentsArray2.count;
    if (comInt==0)
    {
        [APPDATA ShowAlertWithTitle:@"" Message:@"No comment found."];
    }else{
        if (APPDATA.isUserLogin==YES)
        {
            AddCommentViewController *controller =(AddCommentViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"AddCommentViewController"];
            controller.tagStr=[NSString stringWithFormat:@"%ld",(long)[sender tag]];
            controller.otherProfileid=[NSString stringWithFormat:@"%@",strProfileid];
            controller.usertype=usertype;
             controller.isFromGroup=NO;
            controller.selectType = (SELECTIONTYPE*)SelectProfile;
            [self.parentViewController addChildViewController:controller];
            [self.parentViewController.view addSubview:controller.view];
            [controller didMoveToParentViewController:self];
            [controller.view setFrame:CGRectMake(0,0,controller.view.frame.size.width,self.view.frame.size.height)];
        }else{
            [APPDATA ShowAlertWithTitle:@"" Message:ERROR_LOGIN];
        }
    }
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}



#pragma mark Sharing view Hidden..
-(void)hideShareView
{
    [_ShareView setHidden:YES];
}

#pragma mark Sharing Main Btn action...
- (IBAction)shareDispalyMethod:(UIButton *)sender {
    UIButton *senderButton = (UIButton *)sender;
    NSIndexPath *path = [NSIndexPath indexPathForRow:senderButton.tag inSection:0];
    CGRect rectOfCellInTableView = [_tableviewFeed rectForRowAtIndexPath: path ];
    CGRect rectOfCellInSuperview = [_tableviewFeed convertRect: rectOfCellInTableView toView:self.view.superview];
    content = [[FBSDKShareLinkContent alloc] init];
    content.contentTitle =  [[dictFeed objectAtIndex:[sender tag]] valueForKey:@"username"];
    content.contentDescription =  [[dictFeed objectAtIndex:[sender tag]] valueForKey:@"message"];
    if (![[[dictFeed objectAtIndex:[sender tag]] valueForKey:@"post_image"] isKindOfClass:[NSNull class]] &&
        [[[dictFeed objectAtIndex:[sender tag]] valueForKey:@"post_image"] length] > 3) {
        postImageStr = [NSString stringWithFormat:@"%@",[[dictFeed objectAtIndex:[sender tag]] valueForKey:@"post_image"]] ;
    }else{
        postImageStr=@"";
    }
    feed_typeStr=[[dictFeed objectAtIndex:[sender tag]] objectForKey:@"feed_type"];
    postMessageStr=[[dictFeed objectAtIndex:[sender tag]] valueForKey:@"message"];
    content.imageURL = [NSURL URLWithString:postImageStr];
    if (sender.frame.origin.x < 160)
    {
        if (usertype==0)
        {
            if (sender.tag == dictFeed.count-1)
            {
                [_ShareView setFrame:CGRectMake(sender.frame.origin.x, rectOfCellInSuperview.origin.y+40, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                [_ShareView setHidden:NO];
            }
            else{
                CGRect frame = _ShareView.frame;
                CGRect frame1 =_imgviewBorder.frame;
                frame.size.height = 80;
                _ShareView.frame = frame;
                frame1.size.height = 80;
                _imgviewBorder.frame = frame1;
                [_btnMyfeed setHidden:YES];
                [_ShareView setFrame:CGRectMake(sender.frame.origin.x, rectOfCellInSuperview.origin.y+136, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                [_ShareView setHidden:NO];
            }
        }
        else
        {
            if (sender.tag == dictFeed.count-1) {
                [_ShareView setFrame:CGRectMake(sender.frame.origin.x, rectOfCellInSuperview.origin.y, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                [_ShareView setHidden:NO];
            }
            else
            {
                [_ShareView setFrame:CGRectMake(sender.frame.origin.x, rectOfCellInSuperview.origin.y+136, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                [_ShareView setHidden:NO];
            }
        }
    }
    else
    {
        if (usertype==0)
        {
            if (sender.tag == dictFeed.count-1)
            {
                [_ShareView setFrame:CGRectMake(sender.frame.origin.x+20, rectOfCellInSuperview.origin.y, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                [_ShareView setHidden:NO];
            }
            else{
                CGRect frame = _ShareView.frame;
                CGRect frame1 =_imgviewBorder.frame;
                frame.size.height = 80;
                _ShareView.frame = frame;
                frame1.size.height = 80;
                _imgviewBorder.frame = frame1;
                [_btnMyfeed setHidden:YES];
                if (IS_IPHONE6plus) {
                    [_ShareView setFrame:CGRectMake(sender.frame.origin.x-10, rectOfCellInSuperview.origin.y+132, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                    [_ShareView setHidden:NO];
                }
                else{
                    [_ShareView setFrame:CGRectMake(sender.frame.origin.x-10, rectOfCellInSuperview.origin.y+130, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                    [_ShareView setHidden:NO];
                }
            }
        }
        else
        {
            if (IS_IPHONE6plus) {
                [_ShareView setFrame:CGRectMake(sender.frame.origin.x-40, rectOfCellInSuperview.origin.y+132, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                [_ShareView setHidden:NO];
            }
            else
            {
                if (sender.tag == dictFeed.count-1)
                {
                    [_ShareView setFrame:CGRectMake(sender.frame.origin.x-40, rectOfCellInSuperview.origin.y+40, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                    [_ShareView setHidden:NO];
                }
                else{
                    [_ShareView setFrame:CGRectMake(sender.frame.origin.x-40, rectOfCellInSuperview.origin.y+126, _ShareView.frame.size.width, _ShareView.frame.size.height)];
                    [_ShareView setHidden:NO];
                }
            }
        }
    }
    [_ShareView setHidden:NO];
}


-(void)tapShareView
{
    [_ShareView setHidden:YES];
}
-(void)tapShareView2
{
    [SlideNavigationController sharedInstance].enableSwipeGesture = YES;
}

#pragma mark UitextFild Delegate method...
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if (APPDATA.isUserLogin==YES)
    {
        return YES;
    }else{
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_LOGIN];
        return NO;
    }
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string;
{
    postidStr=[NSString stringWithFormat:@"%@",[[dictFeed objectAtIndex:[textField tag]] objectForKey:@"id"]];
    commentStr = [textField.text stringByReplacingCharactersInRange:range withString:string];
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

// ADD comment API call and checking that comment add or not..
#pragma mark Key board Done Actions.....
-(void)doneAction:(UIBarButtonItem*)barButton
{
    NSCharacterSet *set = [NSCharacterSet whitespaceCharacterSet];
    if ([commentStr length]<1)
    {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_COMMENT];
        [self.tableviewFeed reloadData];
    }
    else if ([[commentStr stringByTrimmingCharactersInSet: set] length] == 0)
    {
         [APPDATA ShowAlertWithTitle:@"" Message:ERROR_COMMENT];
        [self.tableviewFeed reloadData];
    }
    else{
        [self addComment];
    }
}
-(void)cancelAction:(UIBarButtonItem*)barButton
{
    [self.tableviewFeed reloadData];
}

#pragma Add Comment Method ...
-(void)addComment{
    [self resignFirstResponder];
    [APPDATA showLoader];
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        int check=[[responseObject objectForKey:@"error"]intValue];
        commentStr= nil;
        if (check==1)
        {
            [APPDATA hideLoader];
            [APPDATA ShowAlertWithTitle:@"" Message:ERROR_COMMENT];
        }else{
            
            
            commentStr= nil;
            APPDATA.group.AddCommentsuccess=YES;
             [self.view endEditing:true];
            [self resignFirstResponder];
            [self feedupdateUpdateMethod];
        }
    };
    void (^failure)(NSError * error) = ^(NSError *error) {
        [APPDATA hideLoader];
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_COMMENT];
    };
    NSDictionary *dict = @{@"key":API_KEY,@"method":API_ADDCOMMENTONPOST,@"profile_id":appDelegate.profilid_AppStr,@"post_id":postidStr,@"comment":commentStr};
    [APICall sendToService:dict success:successed failure:failure];
}

#pragma mark Add post Method ....
-(void)addPostMethd{
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        [APPDATA hideLoader];
        [self feedupdateUpdateMethod];
        [APPDATA ShowAlertWithTitle:@"" Message:@"MyFeed post successfully share"];

    };
    void (^failure)(NSError * error) = ^(NSError *error) {
        [APPDATA hideLoader];
    };
    [APPDATA showLoader];
    if ([postImageStr length]<1)
    {
        postImageStr=@"";
    }
    NSDictionary *dict = @{@"key":API_KEY,@"post_image":postImageStr,@"feed_type":@"post",@"message":postMessageStr,@"profile_id":appDelegate.profilid_AppStr,@"method":API_ADD_POST};
    [APICall sendToService:dict success:successed failure:failure];
}

#pragma mark Add Message method ..
-(void)addmessageMethd{
    [APPDATA showLoader];
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        
        [self feedupdateUpdateMethod];
        [APPDATA ShowAlertWithTitle:@"" Message:@"MyFeed post successfully share"];
    };
    void (^failure)(NSError * error) = ^(NSError *error) {
    };
    NSString  *strDeviceToken=[[NSUserDefaults standardUserDefaults] objectForKey:@"strDeviceToken"];
    if ([strDeviceToken isKindOfClass:[NSNull class]] || strDeviceToken == nil || [strDeviceToken isEqualToString:@""])
    {
        strDeviceToken=nil;
    }
    NSDictionary *dict = @{@"key":API_KEY,@"feed_type":@"message",@"message":postMessageStr,@"profile_id":appDelegate.profilid_AppStr,@"method":API_ADD_POST};
    [APICall sendToService:dict success:successed failure:failure];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    _ShareView.hidden=YES;
    [[NSNotificationCenter defaultCenter] postNotificationName:@"hideDropDown" object:nil];
    [self resignFirstResponder];
}

// delete post alterview actions..
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag==320) {
        
    if (buttonIndex == 0)
    {
        NSLog(@"%@",userId);
        if ([userId isEqualToString:strUserId])
        {
            [self feeddeletePostListAction:rowid index:indexToDeletePost];
        }
        else
        {
            [self flagDashboardPostAction:rowid index:indexToDeletePost];
            
            
        }
    }
    else
       {
       }
    }
}

// delete actions and get required IDs..
-(void)btnDeletePressed:(id)sender
{
    @try{
        
        UIButton *btnTapped = (UIButton*)sender;
        NSInteger btnTag = btnTapped.tag;
        indexToDeletePost = btnTag;
        if (![[[dictFeed objectAtIndex:[sender tag]] valueForKey:@"id"] isKindOfClass:[NSNull class]])
        {
            rowid = [NSString stringWithFormat:@"%@",[[dictFeed objectAtIndex:[sender tag]] valueForKey:@"id"]] ;
        }
        if (![[[dictFeed objectAtIndex:[sender tag]] valueForKey:@"profile_id"] isKindOfClass:[NSNull class]])
        {
            if (usertype==0) {
              userId = [NSString stringWithFormat:@"%@",[[dictFeed objectAtIndex:[sender tag]] valueForKey:@"profile_id"]] ;
        }  else if(usertype==1){
              userId = [NSString stringWithFormat:@"%@",[[dictFeed objectAtIndex:[sender tag]] valueForKey:@"other_profile_id"]] ;
        
            }
        }
         strUserId = [NSString stringWithFormat:@"%@",APPDATA.user.profileid];
        
        if ([userId isEqualToString:strUserId])
        {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Delete Post" message:@"Are you sure you want to delete this post?" delegate:self          cancelButtonTitle:@"Yes"
                                                 otherButtonTitles:@"No",nil];
            [alert show];
            alert.tag=320;
            
        }
        else
        {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Flag Post" message:@"Are you sure you want to flag this post?" delegate:self          cancelButtonTitle:@"Yes"
                                                 otherButtonTitles:@"No",nil];
            [alert show];
            alert.tag=320;

        }
        return;
        
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    
}

// feed delete post API call
-(void)feeddeletePostListAction:(NSString*)strFlag index:(NSInteger)index
{
    @try{
        [APPDATA showLoader];

        user.rowID = [rowid mutableCopy];
        [user deleteDashboardPost:^(NSString *result, int status)
         {
                 if (status == 1) {
                     dispatch_async (dispatch_get_main_queue(), ^{
                         
                         [self feedupdateUpdateMethod];
                     });
                      [self.tableviewFeed reloadData];
                     [APPDATA hideLoader];
                     
                     NSLog(@"success");
                 }
                 else {

                     NSLog(@"Failed");
                     NSString *strmsg=[APPDATA isValueNullOrEmpty:[NSString stringWithFormat:@"%@",[result valueForKey:@"message"]]];
                     [APPDATA ShowAlertWithTitle:@"" Message:strmsg];
                     [APPDATA hideLoader];
                 }
             }];
      
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

// Flag Dashboard delete post API call
-(void)flagDashboardPostAction:(NSString*)strFlag index:(NSInteger)index
{
    @try{
        [APPDATA showLoader];
        
        user.rowID = [rowid mutableCopy];
        user.userid = [NSMutableString stringWithFormat:@"%@",userId];
        [user flagDashboardPost:^(NSString *result, int status)
         {
             if (status == 1) {
                
                 
                     [APPDATA hideLoader];
                     [APPDATA ShowAlertWithTitle:@"" Message:@"Comment Flagged Successfully"];

                 [self.tableviewFeed reloadData];
                NSLog(@"success");
             }
             else {
                 
                 NSLog(@"Failed");
                 NSString *strmsg=[APPDATA isValueNullOrEmpty:[NSString stringWithFormat:@"%@",result]];
                 [APPDATA ShowAlertWithTitle:@"" Message:strmsg];
                 [APPDATA hideLoader];
             }
         }];
        
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

@end
