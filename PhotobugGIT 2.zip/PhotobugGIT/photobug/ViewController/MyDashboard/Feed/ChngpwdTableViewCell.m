//
//  ChngpwdTableViewCell.m
//  photobug
//
//   on 28/06/16.
//  Copyright © Photobug. All rights reserved.
//

#import "ChngpwdTableViewCell.h"
#import "Users.h"
#import "Constant.h"
#import "ApplicationData.h"
@implementation ChngpwdTableViewCell
{
    Users *user;
}
- (void)awakeFromNib {
    [super awakeFromNib];
      user = [[Users alloc]init];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(oldPwdFirstResponder) name:@"oldFirst" object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(newPwdFirstResponder) name:@"newFirst" object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(reTypePwdFirstResponder) name:@"reTypeFirst" object:nil];
    
    [self.TxtFieldCurrentPwd addTarget:self
                            action:@selector(textFieldDidChangeCurrentPwd:)
                  forControlEvents:UIControlEventEditingChanged];
    [self.TxtFieldReTypePwd addTarget:self
                             action:@selector(textFieldDidChangeReTypePwd:)
                   forControlEvents:UIControlEventEditingChanged];
    [self.TxtFieldNewPwd addTarget:self
                          action:@selector(textFieldDidChangeNewPwd:)
                forControlEvents:UIControlEventEditingChanged];
   }


-(void)textFieldDidChangeCurrentPwd :(UITextField *)theTextField{
    NSLog( @"text changed: %@", theTextField.text);
    
   APPDATA.user.strtxtFildCurrntpwd=theTextField.text.mutableCopy;
    UDSetObject(APPDATA.user.strtxtFildCurrntpwd, @"CurrentPwd");
}

-(void)textFieldDidChangeReTypePwd :(UITextField *)theTextField{
    NSLog( @"text changed: %@", theTextField.text);
    APPDATA.user.strTxtFildRetypNewPwd=theTextField.text.mutableCopy;
    UDSetObject(APPDATA.user.strTxtFildRetypNewPwd, @"RetypePwd");
}

-(void)textFieldDidChangeNewPwd :(UITextField *)theTextField{
    NSLog( @"text changed: %@", theTextField.text);
    APPDATA.user.strTxtFildNewPwd=theTextField.text.mutableCopy;
    UDSetObject(APPDATA.user.strTxtFildNewPwd, @"NewPwd");
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)oldPwdFirstResponder
{
    [_TxtFieldCurrentPwd becomeFirstResponder];
}

-(void)newPwdFirstResponder
{
    [_TxtFieldNewPwd becomeFirstResponder];
}

-(void)reTypePwdFirstResponder
{
    [_TxtFieldReTypePwd becomeFirstResponder];
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
   [textField resignFirstResponder];
    return YES;
}
@end
