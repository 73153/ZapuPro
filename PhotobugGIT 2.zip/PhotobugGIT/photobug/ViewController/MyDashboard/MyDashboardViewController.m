 //
//  MyDashboardViewController.m
//  photobug
//
//   on 11/18/15.
//  Copyright © Photobug. All rights reserved.
//
#import "MyDashboardViewController.h"
#import "MyprofileViewController.h"
#import "FeedViewController.h"
#import "PhotoDetailViewController.h"
#import "MyactivityViewController.h"
#import "RecentEntriesViewController.h"
#import "GroupViewController.h"
#import "IQKeyboardManager.h"
#import "MyActivity.h"
#import "ApplicationData.h"
#import "Constant.h"
#import "APICall.h"
#import "AddCommentViewController.h"
#import <FPPicker/FPPicker.h>
#import "LoginViewController.h"
#import "MessageViewController.h"
#import "InstagramEngine.h"
#import "MyGroupsViewController.h"
#import "IQKeyboardManager.h"
#import "IQKeyboardManagerConstants.h"
#import "IQKeyboardReturnKeyHandler.h"
#import "IQUIView+IQKeyboardToolbar.h"
#import <Social/Social.h>
#import <UIKit/UIKit.h>
#import "EditProfileViewController.h"
#import <Pinterest/Pinterest.h>
#import <UIActivityIndicator-for-SDWebImage/UIImageView+UIActivityIndicatorForSDWebImage.h>
#define IMAGE_VIEW_TAG 999
@interface MyDashboardViewController ()<UITableViewDelegate, UITableViewDataSource,FPPickerControllerDelegate,
FPSaveControllerDelegate,UIActionSheetDelegate>
{
    BOOL ImgUpload;
    IBOutlet UIView *viewPlugIn;
    NSString *profileimageStr,*StrForImg;
    NSMutableArray *downpoptableDataArry;
    BOOL downpopFlag;
    BOOL  AlredyCheck;
    NSArray *recipeImages;
    NSString *addpostimageFlage;
    NSString *postImageurl,*struserid,*strotherProfileid;
    IQKeyboardReturnKeyHandler *returnKeyHandler;
    MessageViewController *objMessagecontroller;
    SLComposeViewController *controller;
     UIImageView *tempImg;
    Users *User;
}
@property (nonatomic, strong) FPSaveController *fpSave;
@property (nonatomic, strong) UIPopoverController *myPopoverController;
@property (nonatomic, strong) NSMutableArray<UIImage *> *displayedImages;
@property (nonatomic, strong) FPTheme *theme;
@end
@implementation MyDashboardViewController
@synthesize usertype,viewPlugInComment,AllcommentArray,otherProfiletag,isNewProfile,objFeedViewController,messageProfileid,backStr,lblYourProfilefeed;

//buttons hide and show as per requirement and  arrow frame set..
- (void)viewDidLoad {
    [super viewDidLoad];
    _btnNewPost.hidden= YES;
    _btnPublishProfile.hidden = YES;
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(isPublishProfile) name:@"checkPublishProfile" object:nil];
    APPDATA.recent = [[RecentEntries alloc] init];
    APPDATA.dashboard=[[DashBoard alloc] init];
    if (IS_IPHONE6plus)
    {
        _downlabel.frame=CGRectMake(62+20 , 184,146 , 14);
        _arrowImage.frame=CGRectMake(221+20, 188,13 , 7);
    }else if(IS_IPHONE6){
        _downlabel.frame=CGRectMake(49+20 , 184,146 , 14);
        _arrowImage.frame=CGRectMake(204+20, 188,13 , 7);
    }else{
        _downlabel.frame=CGRectMake(12+20 , 184,146 , 14);
        _arrowImage.frame=CGRectMake(167+20, 188,13 , 7);
    }
    tempImg=[UIImageView new];
    tempImg.frame=_BigImageView.frame;
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(hideDropDown) name:@"hideDropDown" object:nil];
    [_dropDowntableview setUserInteractionEnabled:YES];
    _dropDowntableview.delegate=self;
   _dropDowntableview.dataSource=self;
    _dropDowntableview.layer.borderWidth = 2.0;
    self.bigimgScrollView.bounces=NO;
    self.bigimgScrollView.contentSize = self.BigImageView.size;
    self.bigimgScrollView.delegate = self;
    self.bigimgScrollView.maximumZoomScale = 100.0;
    User = [[Users alloc]init];  profileimageStr=[NSString stringWithFormat:@"%@",APPDATA.activity.profileImage];
          [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(checkUserfollowOrNot)
                                                 name:@"IsUserFollow"
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(btnPostHide) name:@"hideBtnPost" object:nil];
        //usertype= 0 My profile or usertype=1 other profile
    [[_btnmessage layer] setBorderWidth:1.0f];
    [[_btnmessage layer] setCornerRadius:2.0f];
    [[_btnmessage layer] setBorderColor:[UIColor colorWithRed:50.0/255.0 green:198.0/255.0 blue:244.0/255.0 alpha:1.0].CGColor];
    
    [[_btnNewPost layer] setBorderWidth:1.0f];
    [[_btnNewPost layer] setCornerRadius:2.0f];
    [[_btnNewPost layer] setBorderColor:[UIColor colorWithRed:50.0/255.0 green:198.0/255.0 blue:244.0/255.0 alpha:1.0].CGColor];
    
    [[_btnPublishProfile layer] setBorderWidth:1.0f];
    [[_btnPublishProfile layer] setCornerRadius:2.0f];
    [[_btnPublishProfile layer] setBorderColor:[UIColor colorWithRed:50.0/255.0 green:198.0/255.0 blue:244.0/255.0 alpha:1.0].CGColor];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// get my activity data and user profile API call whn own profile and navigate controller  as per the deopdown menus selections..
-(void)viewWillAppear:(BOOL)animated
{
    
    [super viewWillAppear:animated];

    _BigImageView.userInteractionEnabled = YES;
    _photDisplayView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSingleTapGesture:)];
    [_BigImageView addGestureRecognizer:tapGestureRecognizer];
      _viewNewPost.userInteractionEnabled = YES;
    UITapGestureRecognizer *tapGestureRecognizerPost = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSingleTapGesturePost:)];
    [_viewNewPost addGestureRecognizer:tapGestureRecognizerPost];
    downpopFlag=NO;
    shareButton=[FBSDKShareButton new];
    _txtpost.placeholder = @" Write a Post";
    _txtpost.textColor = [UIColor blackColor];
    [_txtpost setFont:[UIFont fontWithName:@"OpenSans-SemiBold" size:10]];
    [_viewdropDown setFrame:CGRectMake(_viewdropDown.frame.origin.x, _viewdropDown.frame.origin.y,  _viewdropDown.frame.size.width, 0)];
    [_dropDowntableview setFrame:CGRectMake(_dropDowntableview.frame.origin.x, _dropDowntableview.frame.origin.y,  _dropDowntableview.frame.size.width, 0)];
    downpoptableDataArry=[[NSMutableArray alloc]init];
    self.dropdownButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
    objFeedViewController= (FeedViewController*)[mainStoryboard instantiateViewControllerWithIdentifier:@"FeedViewController"];
    
    objFeedViewController.imgProtocol=self;

    returnKeyHandler = [[IQKeyboardReturnKeyHandler alloc] initWithViewController:self];
    [_txtusername addDoneOnKeyboardWithTarget:self action:@selector(doneAction:)];
    
    if (usertype==0)
    {
        [self getMyActivityData];

        [self myprofileuserMethod];
        _downlabel.text=@"MY FEED";
        lblYourProfilefeed.hidden=NO;
        
        CGSize sizeFont = [_txtusername.text sizeWithAttributes:
                       @{NSFontAttributeName: _txtusername.font}];
        
        float usernameWidth = sizeFont.width;
        if (usernameWidth >= 118) {
            [_txtusername setFrame:CGRectMake(20, _txtusername.frame.origin.y, 118, _txtusername.frame.size.height)];
        }
        else{
            [_txtusername setFrame:CGRectMake(20, _txtusername.frame.origin.y, usernameWidth, _txtusername.frame.size.height)];
        }
        [_btnEdit setFrame:CGRectMake(_txtusername.frame.origin.x + _txtusername.frame.size.width , _btnEdit.frame.origin.y, _btnEdit.frame.size.width, _btnEdit.frame.size.height)];
        _lblfollowers.hidden=NO;
        _lblfollowing.hidden=NO;
    }
    else
    {
        
        _lblfollowers.hidden=YES;
        _lblfollowing.hidden=YES;
        _downlabel.text=@"FEED";
        lblYourProfilefeed.hidden=NO;
        if (APPDATA.isUserLogin == YES)
            self.btnmessage.hidden = NO;
        else
            self.btnmessage.hidden = YES;
        objFeedViewController.usertype=1;
        _btnBack.hidden=NO;
        _lblshare.hidden=YES;
        _btninsta.hidden=YES;
        _btnfacebook.hidden=YES;
        _btpin.hidden=YES;
        _btnfollow.hidden=NO;
        _btnNewPost.hidden=YES;
        [downpoptableDataArry addObject:@"FEED"];
        [downpoptableDataArry addObject:@"RECENT ENTRIES"];
        objFeedViewController.strProfileid= [[APPDATA.user.aryMyProfileImage objectAtIndex:[otherProfiletag intValue]]objectForKey:@"profile_id"];
        objFeedViewController.usertype=Guestuser;
        _txtusername.autocapitalizationType = UITextAutocapitalizationTypeAllCharacters;
        _txtusername.text=[[NSString stringWithFormat:@"%@.",[[APPDATA.user.aryMyProfileImage objectAtIndex:[otherProfiletag intValue]]objectForKey:@"username"]]uppercaseString];
        
        if (APPDATA.isUserLogin==YES)
        {
            _btnfollow.hidden=NO;
            _btnmessage.hidden=NO;
        }else
        {
            _btnfollow.hidden=YES;
        }
        lblYourProfilefeed.text=[[NSString stringWithFormat:@"%@’s Photofeed",[[APPDATA.user.aryMyProfileImage objectAtIndex:[otherProfiletag intValue]]objectForKey:@"username"]]uppercaseString];
        profileimageStr=[NSString stringWithFormat:@"%@",[[APPDATA.user.aryMyProfileImage objectAtIndex:[otherProfiletag intValue]]objectForKey:@"profile_photo"]];
        if([profileimageStr length]>1)
        {
            NSString *fCharStr =[profileimageStr substringToIndex:22];
            if ([profileimageStr rangeOfString:@"convert"].location == NSNotFound && [fCharStr isEqualToString:@"https://www.filepicker"])
            {
                profileimageStr = [NSString stringWithFormat:@"%@/convert?w=1000&h=1000",profileimageStr] ;
            }
            else if([fCharStr isEqualToString:@"https://www.filepicker"])
            {
                profileimageStr = [profileimageStr substringToIndex:[profileimageStr length]-20];
               profileimageStr = [NSString stringWithFormat:@"%@/convert?w=1000&h=1000",profileimageStr] ;
            }
        }
            if ([profileimageStr length]>2) {
            [_profilephoto setImageWithURL:[NSURL URLWithString:profileimageStr] placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                _profilephoto.contentMode=UIViewContentModeScaleAspectFill;
                _profilephoto.clipsToBounds=YES;
        }else {
            [_profilephoto setImage:[UIImage imageNamed:@"no_imgV.png"]];
        }
        int userProid=[appDelegate.profilid_AppStr intValue];
        int otherProid=[objFeedViewController.strProfileid intValue];
        if (userProid==otherProid)
        {
            [self myprofileuserMethod];
        }
        
        NSAttributedString *attributedText =
        [[NSAttributedString alloc]
         initWithString:_txtusername.text
         attributes:@
         {
         NSFontAttributeName: _txtusername.font
         }];
        
        CGRect rect = [attributedText boundingRectWithSize:_txtusername.size
                                                   options:NSStringDrawingUsesLineFragmentOrigin
                                                   context:nil];
         float usernameWidth = rect.size.width;
        
        
        if ([[NSString stringWithFormat:@"%@",APPDATA.user.strOtherId ] isEqualToString:[NSString stringWithFormat:@"%@",APPDATA.user.profileid]]) {
            if (usernameWidth >= 118) {
                [_txtusername setFrame:CGRectMake(20, _txtusername.frame.origin.y, 118, _txtusername.frame.size.height)];
            }
            else{
                [_txtusername setFrame:CGRectMake(20, _txtusername.frame.origin.y, usernameWidth, _txtusername.frame.size.height)];
            }
            [_btnEdit setFrame:CGRectMake(_txtusername.frame.origin.x + _txtusername.frame.size.width , _btnEdit.frame.origin.y, _btnEdit.frame.size.width, _btnEdit.frame.size.height)];
        } else {
        if (usernameWidth >= 190) {
            [_txtusername setFrame:CGRectMake(20, _txtusername.frame.origin.y, 190, _txtusername.frame.size.height)];
        }
        else{
            [_txtusername setFrame:CGRectMake(20, _txtusername.frame.origin.y, usernameWidth, _txtusername.frame.size.height)];
        }
        }
        [_btnEdit setFrame:CGRectMake(_txtusername.frame.origin.x + _txtusername.frame.size.width, _btnEdit.frame.origin.y, _btnEdit.frame.size.width, _btnEdit.frame.size.height)];
    }
   
    NSLog(@"-----------%f",_txtusername.frame.size.width);
    
    NSLog(@"============%f",_txtusername.frame.size.width);
    
    _txtusername.enabled = NO;
    [_menuButton addTarget:[SlideNavigationController sharedInstance] action:@selector(toggleRightMenu) forControlEvents:UIControlEventTouchUpInside];
    [self addChildViewController:objFeedViewController];
    [viewPlugIn addSubview:objFeedViewController.view];
    [objFeedViewController didMoveToParentViewController:self];
    [objFeedViewController.view setFrame:CGRectMake(0,0,objFeedViewController.view.frame.size.width,objFeedViewController.view.frame.size.height)];
    _dropDowntableview.scrollEnabled = NO;
    _dropDowntableview.separatorColor = DarkBlue_COLOR;
    if ([_downlabel.text isEqualToString:@"MY GROUPS"])
    {
        MyGroupsViewController *objRecentEntriesViewController =(MyGroupsViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"MyGroupsViewController"];
        [controller.view setFrame:CGRectMake(0,0,controller.view.frame.size.width,viewPlugIn.frame.size.height)];
        [self addChildViewController:objRecentEntriesViewController];
        [viewPlugIn addSubview:objRecentEntriesViewController.view];
        [controller didMoveToParentViewController:self];
    }else if([_downlabel.text isEqualToString:@"RECENT ENTRIES"])
    {
        lblYourProfilefeed.hidden=YES;
        _btnNewPost.hidden=YES;
        _downlabel.text=@"MY ENTRIES";
        RecentEntriesViewController *objRecentEntriesViewController =(RecentEntriesViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"RecentEntriesViewController"];
        if (usertype==0)
        {
            objRecentEntriesViewController.profilidStr=[NSString stringWithFormat:@"%@",APPDATA.user.profileid];
        }else{
            objRecentEntriesViewController.profilidStr=[NSString stringWithFormat:@"%@",[[APPDATA.user.aryMyProfileImage objectAtIndex:[otherProfiletag intValue]]objectForKey:@"profile_id"]];
        }
        [controller.view setFrame:CGRectMake(0,0,controller.view.frame.size.width,viewPlugIn.frame.size.height)];
        [self addChildViewController:objRecentEntriesViewController];
        [viewPlugIn addSubview:objRecentEntriesViewController.view];
        [controller didMoveToParentViewController:self];
    }else if([_downlabel.text isEqualToString:@"MY ACTIVITY"]){
        _btnNewPost.hidden=YES;
        lblYourProfilefeed.hidden=YES;
        _downlabel.text=@"MY ACTIVITY";
        MyactivityViewController *objMyactivityViewController =(MyactivityViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"MyactivityViewController"];
        [self addChildViewController:objMyactivityViewController];
        [viewPlugIn addSubview:objMyactivityViewController.view];
        [objMyactivityViewController didMoveToParentViewController:self];
        [objMyactivityViewController.view setFrame:CGRectMake(0,0,objMyactivityViewController.view.frame.size.width,viewPlugIn.frame.size.height)];
    }
    else {
        [self feedupdateUpdateMethod];
    }
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(UserNameNotification)
                                                 name:@"UserNameNotification"
                                               object:nil];
}

-(void)UserNameNotification
{
    _txtusername.autocapitalizationType = UITextAutocapitalizationTypeAllCharacters;
    _txtusername.text=[[NSString stringWithFormat:@"%@.",APPDATA.user.strtxtfildUserName]uppercaseString];
}

// get my activity data API call
- (void) getMyActivityData
{
    appDelegate.profilid_AppStr = APPDATA.user.profileid ;
    APPDATA.activity.key = [API_KEY mutableCopy];
    [APPDATA.activity getMyActivity:^(NSDictionary *result, NSString *str, int status) {
        [APPDATA hideLoader];
        if (status == 1)
        {
            [self myprofileuserMethod];
  
        }
        else
        {
            [APPDATA ShowAlertWithTitle:@"" Message:@"The selected profile id is invalid"];
        }
    }];
}


-(void)handleSingleTapGesture:(UITapGestureRecognizer *)tapGestureRecognizer{
    _photDisplayView.hidden=YES;
    _BigImageView.hidden=YES;
    _bigimgScrollView.contentSize = CGSizeMake(self.BigImageView.frame.size.width, self.view.size.height);

   
}
-(void)handleSingleTapGesturePost:(UITapGestureRecognizer *)tapGestureRecognizer{
    _viewNewPost.hidden=YES;
    
}

//------------------------------------------------------------------------------------------------------
#pragma mark Login user Mainten...-------------------------------------------------
// my dashboard buttons hide show as per the reuirement and set dropdown menu and set the profile name and related informations for a perticular profile selections
-(void)myprofileuserMethod{
    objFeedViewController.usertype=0;
    [downpoptableDataArry addObject:@"MY FEED"];
    [downpoptableDataArry addObject:@"MY ENTRIES"];
    [downpoptableDataArry addObject:@"MY ACTIVITY"];
    [downpoptableDataArry addObject:@"MY GROUPS"];
    _btnmessage.hidden=YES;
    _lblshare.hidden=YES;
    _btninsta.hidden=YES;
    _btnfacebook.hidden=YES;
    _btpin.hidden=YES;
    _btnfollow.hidden=YES;
    
    _lblfollowing.hidden=NO;
    _lblfollowers.hidden=NO;
    _txtusername.enabled = NO;
    _changeTranImage.hidden=NO;
    _lblsocialsiteaddphoto.hidden=NO;
    _lblchangeprofile.hidden=NO;
    _lblsocialsiteaddphoto.hidden=NO;
    _btnaddPhto.hidden=NO;
    if ([backStr isEqualToString:@"1"])
    {
        _btnBack.hidden=NO;
    }else{
        _btnBack.hidden=YES;
    }
    _txtusername.autocapitalizationType = UITextAutocapitalizationTypeAllCharacters;
    _txtusername.text=[[NSString stringWithFormat:@"%@.",APPDATA.user.username]uppercaseString];
    NSString *followeStr=[NSString stringWithFormat:@"%@  ", APPDATA.activity.follower];
    NSString *followingstr=[NSString stringWithFormat:@"%@  ",APPDATA.activity.following];
    UIFont *font1 = [UIFont fontWithName:@"OpenSans-ExtraBold" size:9];
    NSDictionary *arialDict = [NSDictionary dictionaryWithObject: font1 forKey:NSFontAttributeName];
    NSMutableAttributedString *aAttrString1 = [[NSMutableAttributedString alloc] initWithString:followeStr attributes: arialDict];
    UIFont *font2 = [UIFont fontWithName:@"OpenSans" size:10];
    NSDictionary *arialDict2 = [NSDictionary dictionaryWithObject: font2 forKey:NSFontAttributeName];
    NSMutableAttributedString *aAttrString2 = [[NSMutableAttributedString alloc] initWithString:@"FOLLOWING" attributes: arialDict2];
    [aAttrString1 appendAttributedString:aAttrString2];
    _lblfollowers.attributedText = aAttrString1;
    UIFont *font3 = [UIFont fontWithName:@"OpenSans-ExtraBold" size:9];
    NSDictionary *arialDict3 = [NSDictionary dictionaryWithObject: font3 forKey:NSFontAttributeName];
    NSMutableAttributedString *aAttrString3 = [[NSMutableAttributedString alloc] initWithString:followingstr attributes: arialDict3];
    UIFont *font4 = [UIFont fontWithName:@"OpenSans" size:10];
    NSDictionary *arialDict4 = [NSDictionary dictionaryWithObject: font4 forKey:NSFontAttributeName];
    NSMutableAttributedString *aAttrString4 = [[NSMutableAttributedString alloc] initWithString:@"FOLLOWERS" attributes: arialDict4];
    [aAttrString3 appendAttributedString:aAttrString4];
    _lblfollowing.attributedText = aAttrString3;
    profileimageStr=[NSString stringWithFormat:@"%@",APPDATA.activity.profileImage];
    if ([profileimageStr length]>0)
    {
        NSString *fCharStr =[profileimageStr substringToIndex:22];
        if ([profileimageStr rangeOfString:@"convert"].location == NSNotFound && [fCharStr isEqualToString:@"https://www.filepicker"])
        {
            profileimageStr = [NSString stringWithFormat:@"%@/convert?w=1000&h=1000",profileimageStr] ;
        }
        else if([fCharStr isEqualToString:@"https://www.filepicker"])
        {
            profileimageStr = [profileimageStr substringToIndex:[profileimageStr length]-20];
         profileimageStr = [NSString stringWithFormat:@"%@/convert?w=1000&h=1000",profileimageStr] ;
        }
    }
 
    if ([profileimageStr length]>2)
    {
        [_profilephoto setImageWithURL:[NSURL URLWithString:profileimageStr] placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        _profilephoto.contentMode=UIViewContentModeScaleAspectFill;
        _profilephoto.clipsToBounds=YES;
    }
    else
    {
        [_profilephoto setImage:[UIImage imageNamed:@"no_imgV.png"]];
    }
}

//------------------------------------------------------------------------------------------------------
#pragma mark Message Buttonaction....-------------------------------------------------
- (IBAction)btnMessageAction:(id)sender {
    if (APPDATA.isUserLogin==YES)
    {
        objMessagecontroller =(MessageViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"MessageViewController"];
        objMessagecontroller.messageProid=objFeedViewController.strProfileid;
        [self.view addSubview:objMessagecontroller.view];
        //
        [objMessagecontroller.view setFrame:CGRectMake(0,0,objMessagecontroller.view.frame.size.width,self.view.frame.size.height)];
    }else{
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_LOGIN];
    }
}
//------------------------------------------------------------------------------------------------------
#pragma mark Add Reload FeedTable view ..-------------------------------------------------
-(void)reloadFeedVCData {
    [objFeedViewController removeFromParentViewController];
    [self addChildViewController:objFeedViewController];
    [viewPlugIn addSubview:objFeedViewController.view];
    [objFeedViewController didMoveToParentViewController:self];
    [objFeedViewController feedupdateUpdateMethod];

    objFeedViewController.imgProtocol=self;

}
// follow state update
-(void)folloewUpdate
{
    _lblfollowers.text=[NSString stringWithFormat:@"%@ FOLLOWERS", appDelegate.followers_AppStr];
    _lblfollowing.text=[NSString stringWithFormat:@"%@ FOLLOWING",appDelegate.followedby_AppStr];
}
//------------------------------------------------------------------------------------------------------
#pragma mark Facebook Sharing ....-------------------------------------------------
- (IBAction)facebookSharing:(id)sender {
    [APPDATA showLoader];
    content = [[FBSDKShareLinkContent alloc] init];
    content.contentURL = [NSURL URLWithString:profileimageStr];
    NSURL *imageURL =
    [NSURL URLWithString:profileimageStr];
    content.contentDescription=[NSString stringWithFormat:@"User Details ;%@.",_txtusername.text];
    content.contentTitle=@"Photo Bug";
    content.imageURL=imageURL;
    [FBSDKShareDialog showFromViewController:self withContent:content delegate:nil];
    [APPDATA hideLoader];
}
//------------------------------------------------------------------------------------------------------
#pragma Mark Add Instageram Sharing ...-------------------------------------------------
- (IBAction)instagramSharing:(id)sender;
{
    NSURL *instagramURL = [NSURL URLWithString:@"instagram://app"];
    if([[UIApplication sharedApplication] canOpenURL:instagramURL]) //check for App is install or not
    {
        NSData *imageData = UIImagePNGRepresentation(_profilephoto.image); //convert image into .png format.
        NSFileManager *fileManager = [NSFileManager defaultManager];//create instance of NSFileManager
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES); //create an array and store result of our search for the documents directory in it
        NSString *documentsDirectory = [paths objectAtIndex:0]; //create NSString object, that holds our exact path to the documents directory
        NSString *fullPath = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"insta.igo"]]; //add our image to the path
        [fileManager createFileAtPath:fullPath contents:imageData attributes:nil]; //finally save the path (image)
        CGRect rect = CGRectMake(0 ,0 , 0, 0);
        UIGraphicsBeginImageContextWithOptions(self.view.bounds.size, self.view.opaque, 0.0);
        [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
        UIGraphicsEndImageContext();
        NSString *fileNameToSave = [NSString stringWithFormat:@"Documents/insta.igo"];
        NSString  *jpgPath = [NSHomeDirectory() stringByAppendingPathComponent:fileNameToSave];
        NSString *newJpgPath = [NSString stringWithFormat:@"file://%@",jpgPath];
        NSURL *igImageHookFile = [[NSURL alloc]initFileURLWithPath:newJpgPath];
        self.documentController.UTI = @"com.instagram.exclusivegram";
        self.documentController=[UIDocumentInteractionController interactionControllerWithURL:igImageHookFile];
        NSString *caption = @"#Your Text"; //settext as Default Caption
        self.documentController.annotation=[NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%@",caption],@"InstagramCaption", nil];
        [self.documentController presentOpenInMenuFromRect:rect inView: self.view animated:YES];
    }
    else
    {
        UIAlertView *errMsg = [[UIAlertView alloc] initWithTitle:@"Warning" message:@"No Instagram Available" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [errMsg show];
    }
}
- (IBAction)pintButtonAction:(id)sender {
 
    SLComposeViewController *composeController = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeTwitter];
    NSURL *imageURL =
    [NSURL URLWithString:profileimageStr];
    NSData * data = [NSData dataWithContentsOfURL:imageURL];
    UIImage * image = [UIImage imageWithData:data];
    NSString *textName=[NSString stringWithFormat:@"User Details ;%@.",_txtusername.text];
    content.contentTitle=@"Photo Bug";
    [composeController setInitialText:textName];
    [composeController addImage:image];
    [composeController addURL: [NSURL URLWithString:
                                @"http://216.55.169.45/~photobug/"]];
    [self presentViewController:composeController
                       animated:YES completion:nil];
    SLComposeViewControllerCompletionHandler myBlock = ^(SLComposeViewControllerResult result){
        if (result == SLComposeViewControllerResultCancelled) {
            [composeController dismissViewControllerAnimated:YES completion:Nil];
        } else
        {
            [composeController dismissViewControllerAnimated:YES completion:Nil];
        }
    };
    composeController.completionHandler =myBlock;
}
//------------------------------------------------------------------------------------------------------
#pragma Mark Follow Button Action ...-------------------------------------------------
// get sate follow or following or not and add follow API call
- (IBAction)btnfollowPressed:(id)sender {
    if (APPDATA.isUserLogin==YES)
    {
        if([_btnfollow.titleLabel.text isEqualToString:@"UNFOLLOW"])
        {
            [APPDATA showLoader];
            void (^successed)(id responseObject) = ^(id responseObject)
            {
                if(responseObject == NULL)
                {
                }
                else{
                    if ([responseObject count]>1) {
                        NSString *floStr=[responseObject objectForKey:@"data"];
                        //Unfollowed successfully.
                        if ([floStr isEqualToString:@"Unfollowed successfully."])
                        {
                            [APPDATA ShowAlertWithTitle:@"" Message:SUCCES_UNFOLLOW];
                            [_btnfollow setTitle:@"FOLLOW" forState:UIControlStateNormal];
                            _btnmessage.hidden=YES;
                            [self feedupdateUpdateMethod];
                        }
                    }
                    [APPDATA hideLoader];
                }
            };
            void (^failure)(NSError * error) = ^(NSError *error) {
                [APPDATA hideLoader];
            };
            NSDictionary* dict = @{@"key":API_KEY,@"profile_id":APPDATA.user.profileid,@"followed_by":objFeedViewController.strProfileid,@"method":API_PROFILE_DELETE_FOLLOW
                                   };
            [APICall sendToService:dict success:successed failure:failure];
        }
        else
        {
            [APPDATA showLoader];
            Users *objUser = [[Users alloc] init];
            objUser.key = [API_KEY mutableCopy];
            objUser.profileid = [self.dictUserDetail valueForKey:@"profile_id"];
            [objUser addFollow:^(NSString *result, int status){
                [APPDATA hideLoader];
                if (status == 1) {
                    [self feedupdateUpdateMethod];
                    [APPDATA ShowAlertWithTitle:@"" Message:SUCCES_FOLLOW];
                    if ([result isEqualToString:@"Followed successfully."])
                    {
                        [_btnfollow setAttributedTitle:nil forState:UIControlStateNormal];
                        [_btnfollow setTitle:@"UNFOLLOW" forState:UIControlStateNormal];
                          _btnmessage.hidden=NO;
                    }
                    else if ([result isEqualToString:@"You have already followed this user."])
                    {
                        [_btnfollow setAttributedTitle:nil forState:UIControlStateNormal];
                        [_btnfollow setTitle:@"UNFOLLOW" forState:UIControlStateNormal];
                        _btnmessage.hidden=NO;

                    }
                }
                else {
                }
            }];
        }
    }else{
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_LOGIN];
    }
}

// check user following or not API call
- (void)checkUserfollowOrNot{
    
    Users *objUser = [[Users alloc] init];
    objUser.key = [API_KEY mutableCopy];
    objUser.followedby =[APPDATA.strFollowby mutableCopy];
    objUser.profileid =APPDATA.user.profileid;
    [objUser checkfollowedornot:^(NSString *result, int status){
        [APPDATA hideLoader];
        if (status == 1) {
            if ([result  boolValue] == YES) {
                [_btnfollow setAttributedTitle:nil forState:UIControlStateNormal];
                [_btnfollow setTitle:@"UNFOLLOW" forState:UIControlStateNormal];
                APPDATA.strFollowby = @"";
                _btnmessage.hidden=NO;
            }
            else if ([result boolValue] == NO) {
                
                [_btnfollow setAttributedTitle:nil forState:UIControlStateNormal];
                [_btnfollow setTitle:@"FOLLOW" forState:UIControlStateNormal];
                APPDATA.strFollowby = @"";
                _btnmessage.hidden=YES;
            }

        }
        else {
        }
    }];
}
//------------------------------------------------------------------------------------------------------
#pragma Mark Add New Post Method ...-------------------------------------------------
- (IBAction)btnNewPostTapped:(id)sender {
    NSString *textStr11= [[NSString stringWithFormat:@"YOU (%@) ",APPDATA.user.username] uppercaseString];
    UIFont *font1 = [UIFont fontWithName:@"OpenSans-Bold" size:10];
    NSDictionary *arialDict = [NSDictionary dictionaryWithObject: font1 forKey:NSFontAttributeName];
    NSMutableAttributedString *aAttrString1 = [[NSMutableAttributedString alloc] initWithString:textStr11 attributes: arialDict];
    UIFont *font2 = [UIFont fontWithName:@"OpenSans" size:9];
    NSDictionary *arialDict2 = [NSDictionary dictionaryWithObject: font2 forKey:NSFontAttributeName];
    NSMutableAttributedString *aAttrString2 = [[NSMutableAttributedString alloc] initWithString:@"NOW" attributes: arialDict2];
    NSUInteger length1 = [aAttrString1 length];
    NSUInteger length2 = [aAttrString2 length];
    [aAttrString1 addAttribute:NSForegroundColorAttributeName value:[UIColor grayColor] range:NSMakeRange(0,length1)];
    [aAttrString2 addAttribute:NSForegroundColorAttributeName value:[UIColor lightGrayColor] range:NSMakeRange(0,length2)];
    [aAttrString1 appendAttributedString:aAttrString2];
    _lbluserName.attributedText=aAttrString1;
    [_viewNewPost setHidden:NO];
    [self.view bringSubviewToFront:_viewNewPost];
    [_addphotoImage setImage:[UIImage imageNamed:@"addphoto-bg"]];
    self.addphotoImage.contentMode=UIViewContentModeScaleAspectFit;
    [[IQKeyboardManager sharedManager] setEnable:YES];
    [[IQKeyboardManager sharedManager] setEnableAutoToolbar:YES];
}
//------------------------------------------------------------------------------------------------------
#pragma Mark Add DownarrowAction Action ...-------------------------------------------------
- (IBAction)btnDownarrowAction:(id)sender {
    if (!downpopFlag)
    {
        [_arrowImage setImage:[UIImage imageNamed:@"UpArrow"]];
        downpopFlag=YES;
        _viewdropDown.hidden=NO;
        [UIView animateWithDuration:0.50
                              delay:0.0
                            options:UIViewAnimationOptionBeginFromCurrentState
                         animations:^{
                             if (usertype==0){
                                 [_dropDowntableview setFrame:CGRectMake(_dropDowntableview.frame.origin.x, _dropDowntableview.frame.origin.y,  _dropDowntableview.frame.size.width, _dropDowntableview.frame.size.height+119)];
                                 [_viewdropDown setFrame:CGRectMake(_viewdropDown.frame.origin.x, _viewdropDown.frame.origin.y,  _viewdropDown.frame.size.width, _viewdropDown.frame.size.height+119)];
                             }else
                             
                             {
                                 
                                 NSLog(@"dsown arrow");
                                 [_dropDowntableview setFrame:CGRectMake(_dropDowntableview.frame.origin.x, _dropDowntableview.frame.origin.y,  _dropDowntableview.frame.size.width, _dropDowntableview.frame.size.height+59)];
                                 [_viewdropDown setFrame:CGRectMake(_viewdropDown.frame.origin.x, _viewdropDown.frame.origin.y,  _viewdropDown.frame.size.width, _viewdropDown.frame.size.height+59)];
                             }
                         }
                         completion:^(BOOL END){
                         }];
    }else{
         [_arrowImage setImage:[UIImage imageNamed:@"down-arrow"]];
        downpopFlag=NO;
        [UIView animateWithDuration:0.50
                              delay:0.0
                            options:UIViewAnimationOptionBeginFromCurrentState
                         animations:^{
                             if (usertype==0){

                                 [_dropDowntableview setFrame:CGRectMake(_dropDowntableview.frame.origin.x, _dropDowntableview.frame.origin.y,  _dropDowntableview.frame.size.width, _dropDowntableview.frame.size.height-119)];
                                 [_viewdropDown setFrame:CGRectMake(_viewdropDown.frame.origin.x, _viewdropDown.frame.origin.y,  _viewdropDown.frame.size.width, _viewdropDown.frame.size.height-119)];
                             }else
                             {
                                 [_dropDowntableview setFrame:CGRectMake(_dropDowntableview.frame.origin.x, _dropDowntableview.frame.origin.y,  _dropDowntableview.frame.size.width, _dropDowntableview.frame.size.height-59)];
                                 [_viewdropDown setFrame:CGRectMake(_viewdropDown.frame.origin.x, _viewdropDown.frame.origin.y,  _viewdropDown.frame.size.width, _viewdropDown.frame.size.height-59)];
                             }
                         }
                         completion:^(BOOL END){
                             _viewdropDown.hidden=YES;
                         }];
    }
}
//------------------------------------------------------------------------------------------------------
#pragma Mark User name Edit Button Action ...-------------------------------------------------

- (IBAction)btnEditAction:(id)sender
{
        [APPDATA.user EditProfile:^( NSString *result1, int status)
                {
                    [APPDATA hideLoader];
                    if (status == 1)
                    {
                        NSLog(@"%@",result1);
                        EditProfileViewController *controller1 =(EditProfileViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"EditProfileViewController"];
                        [self.view addSubview:controller1.view];
                        [self.view addSubview:controller1.view];
                        [controller1 didMoveToParentViewController:self];
                        [controller1.view setFrame:CGRectMake(0,0,controller1.view.frame.size.width,self.view.frame.size.height)];
                    }
                    else
                    {
                        [APPDATA ShowAlertWithTitle:@"" Message:result1];

                    }
                }];
         }

//------------------------------------------------------------------------------------------------------
#pragma mark add Profile Image Button Action....-------------------------------------------------
- (IBAction)btnaddPhotoAction:(id)sender {
    [_txtusername resignFirstResponder];
    addpostimageFlage=@"0";
    [self pickerModalAction:@"lip"];

}
//------------------------------------------------------------------------------------------------------
#pragma mark add Post Image Button Action....
- (IBAction)btnaddimage:(id)sender {
    [self hideDropDown];
    addpostimageFlage=@"1";
    [self pickerModalAction:@"lip"];

    
}
//------------------------------------------------------------------------------------------------------
#pragma Mark Add Post Action... -------------------------------------------------
- (IBAction)addpostAction:(id)sender {
    [self hideDropDown];
    if ([_txtpost.text length]<1 || [_txtpost.text isEqualToString:@"Write a Post"])
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:ERROR_COMMENT
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
    }else{
        [self addPostMethd];
    }
}
// add post API call
-(void)addPostMethd{
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        postImageurl=@"";
        [[IQKeyboardManager sharedManager] setEnable:YES];
        [[IQKeyboardManager sharedManager] setEnableAutoToolbar:YES];
        [self reloadFeedVCData];
        _viewNewPost.hidden=YES;
         [APPDATA ShowAlertWithTitle:@"" Message:POST_SUBMIT];
    };
    void (^failure)(NSError * error) = ^(NSError *error) {
    };
    if ([_txtpost.text length]<1 || [_txtpost.text isEqualToString:@"Write a Post"])
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:ERROR_COMMENT
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
    }else{
        //1 log
        NSString  *strDeviceToken=[[NSUserDefaults standardUserDefaults] objectForKey:@"strDeviceToken"];
        if ([strDeviceToken isKindOfClass:[NSNull class]] || strDeviceToken == nil || [strDeviceToken isEqualToString:@""])
        {
            strDeviceToken=@" ";
        }
        if ([postImageurl length]<1)
        {
            postImageurl=@"";
        }
        NSDictionary *dict = @{@"key":API_KEY,@"post_image":postImageurl,@"feed_type":@"post",@"message":_txtpost.text,@"profile_id":APPDATA.user.profileid,@"method":API_ADD_POST
                               };
        [APICall sendToService:dict success:successed failure:failure];
        _txtpost.text = @"";
    }
}

//------------------------------------------------------------------------------------------------------
#pragma Mark Table View Delegate Method ...-------------------------------------------------
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 30;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [downpoptableDataArry count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"downpopTableItem";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    cell.textLabel.textColor = DarkBlue_COLOR;
    cell.textLabel.text = [downpoptableDataArry objectAtIndex:indexPath.row];
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    cell.textLabel.font = [UIFont fontWithName:@"OpenSans-Light" size:12.0];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    for (UIViewController* vc in self.childViewControllers)
    {
    [vc willMoveToParentViewController:nil];
    [vc.view removeFromSuperview];
    [vc removeFromParentViewController];
}
     [_arrowImage setImage:[UIImage imageNamed:@"down-arrow"]];
    downpopFlag=NO;
    [UIView animateWithDuration:0.50
                          delay:0.0
                        options:UIViewAnimationOptionBeginFromCurrentState
                     animations:^{
                         if (usertype==0)
                         {
                             [_dropDowntableview setFrame:CGRectMake(_dropDowntableview.frame.origin.x, _dropDowntableview.frame.origin.y,  _dropDowntableview.frame.size.width, _dropDowntableview.frame.size.height-119)];
                             [_viewdropDown setFrame:CGRectMake(_viewdropDown.frame.origin.x, _viewdropDown.frame.origin.y,  _viewdropDown.frame.size.width, _viewdropDown.frame.size.height-119)];
                         }else
                         {
                            // usertype=1;
                             APPDATA.otherprofile=1;
                             [_dropDowntableview setFrame:CGRectMake(_dropDowntableview.frame.origin.x, _dropDowntableview.frame.origin.y,  _dropDowntableview.frame.size.width, _dropDowntableview.frame.size.height-59)];
                             [_viewdropDown setFrame:CGRectMake(_viewdropDown.frame.origin.x, _viewdropDown.frame.origin.y,  _viewdropDown.frame.size.width, _viewdropDown.frame.size.height-59)];
                         }
                     }
                     completion:^(BOOL END){
                         _viewdropDown.hidden=YES;
                     }];
    if (indexPath.row==0)
    {
        lblYourProfilefeed.hidden=NO;
        if (usertype==0)
        {
            _downlabel.text=@"MY FEED";
        }else{
            _downlabel.text=@"FEED";
            if (IS_IPHONE6plus)
            {
                _downlabel.frame=CGRectMake(62+20 , 184,146 , 14);
                _arrowImage.frame=CGRectMake(221+20, 188,13 , 7);
            }else if(IS_IPHONE6){
                _downlabel.frame=CGRectMake(49+20 , 184,146 , 14);
                _arrowImage.frame=CGRectMake(204+20, 188,13 , 7);
            }else{
                _downlabel.frame=CGRectMake(12+20 , 184,146 , 14);
                _arrowImage.frame=CGRectMake(167+20, 188,13 , 7);
            }
        }
        objFeedViewController =(FeedViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"FeedViewController"];
        objFeedViewController.usertype=1;

        UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle: nil];
        objFeedViewController= (FeedViewController*)[mainStoryboard instantiateViewControllerWithIdentifier:@"FeedViewController"];
        objFeedViewController.imgProtocol=self;

        if (usertype==0)
        {
            objFeedViewController.strProfileid=[NSString stringWithFormat:@"%@",APPDATA.user.profileid];
        }else{
            objFeedViewController.strProfileid=[NSString stringWithFormat:@"%@",[[APPDATA.user.aryMyProfileImage objectAtIndex:[otherProfiletag intValue]]objectForKey:@"profile_id"]];
            objFeedViewController.usertype=1;
            objFeedViewController.strOtherProfileID = [NSString stringWithFormat:@"%@",[[APPDATA.user.aryMyProfileImage objectAtIndex:[otherProfiletag intValue]]objectForKey:@"profile_id"]];
        }
        [self addChildViewController:objFeedViewController];
        [viewPlugIn addSubview:objFeedViewController.view];
        [objFeedViewController didMoveToParentViewController:self];
        [objFeedViewController.view setFrame:CGRectMake(0,0,objFeedViewController.view.frame.size.width,objFeedViewController.view.frame.size.height)];
    }else if (indexPath.row==1)
    {
        lblYourProfilefeed.hidden=YES;
        _btnNewPost.hidden=YES;
        if (usertype==0)
        {
            _downlabel.text=@"MY ENTRIES";
        }else
        {
            _downlabel.text=@"RECENT ENTRIES";
            if (IS_IPHONE6plus)
            {
                _downlabel.frame=CGRectMake(62+50 , 184,146 , 14);
                _arrowImage.frame=CGRectMake(221+50, 188,13 , 7);
            }else if(IS_IPHONE6){
                _downlabel.frame=CGRectMake(49+50 , 184,146 , 14);
                _arrowImage.frame=CGRectMake(204+50, 188,13 , 7);
            }else{
                _downlabel.frame=CGRectMake(12+50 , 184,146 , 14);
                _arrowImage.frame=CGRectMake(167+50, 188,13 , 7);
            }
        }
        RecentEntriesViewController *objRecentEntriesViewController =(RecentEntriesViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"RecentEntriesViewController"];
        objFeedViewController.usertype=usertype;
        if (usertype==0)
        {
            objRecentEntriesViewController.profilidStr=[NSString stringWithFormat:@"%@",APPDATA.user.profileid];
        }else{
            objRecentEntriesViewController.profilidStr=[NSString stringWithFormat:@"%@",[[APPDATA.user.aryMyProfileImage objectAtIndex:[otherProfiletag intValue]]objectForKey:@"profile_id"]];
        }
        [controller.view setFrame:CGRectMake(0,0,controller.view.frame.size.width,viewPlugIn.frame.size.height)];
        [self addChildViewController:objRecentEntriesViewController];
        [viewPlugIn addSubview:objRecentEntriesViewController.view];
        [controller didMoveToParentViewController:self];
    }else if (indexPath.row==2)
    {
        _btnNewPost.hidden=YES;
        lblYourProfilefeed.hidden=YES;
        _downlabel.text=@"MY ACTIVITY";
        MyactivityViewController *objMyactivityViewController =(MyactivityViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"MyactivityViewController"];
        [self addChildViewController:objMyactivityViewController];
        [viewPlugIn addSubview:objMyactivityViewController.view];
        [objMyactivityViewController didMoveToParentViewController:self];
        [objMyactivityViewController.view setFrame:CGRectMake(0,0,objMyactivityViewController.view.frame.size.width,viewPlugIn.frame.size.height)];
    }else if (indexPath.row==3)
    {
        lblYourProfilefeed.hidden=YES;
        _btnNewPost.hidden=YES;
        _downlabel.text=@"MY GROUPS";
        MyGroupsViewController *objRecentEntriesViewController =(MyGroupsViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"MyGroupsViewController"];
        [controller.view setFrame:CGRectMake(0,0,controller.view.frame.size.width,viewPlugIn.frame.size.height)];
        [self addChildViewController:objRecentEntriesViewController];
        [viewPlugIn addSubview:objRecentEntriesViewController.view];
        [controller didMoveToParentViewController:self];
    }
    
    
}
// get image string for big image view..
-(void)imgGet:(NSString *)imgCLickComment
{
    StrForImg=imgCLickComment;
    [self loadImage:imgCLickComment];
     _BigImageView.frame=tempImg.frame;

}

// set image and size covert
- (void)loadImage:(NSString *)imgstr {
    
    
   [_BigImageView setHidden:NO];
    self.BigImageView.image=[UIImage imageNamed:@""];
    _photDisplayView.hidden=NO;
   imgstr = [NSString stringWithFormat:@"%@/convert?w=1200&h=1200",imgstr];
    _BigImageView.contentMode = UIViewContentModeCenter;
    _BigImageView.contentMode = UIViewContentModeScaleAspectFit;
    NSURL *url = [NSURL URLWithString:imgstr];
    [NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:url] delegate:self];
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}


- (void)scrollViewDidZoom:(UIScrollView *)sv
{
    UIView* zoomView = [sv.delegate viewForZoomingInScrollView:sv];
    CGRect zvf = zoomView.frame;
    if(zvf.size.width < sv.bounds.size.width)
    {
        zvf.origin.x = (sv.bounds.size.width - zvf.size.width) / 2.0;
    }
    else
    {
        zvf.origin.x = 0.0;
    }
    if(zvf.size.height < sv.bounds.size.height)
    {
        zvf.origin.y = (sv.bounds.size.height - zvf.size.height) / 2.0;
    }
    else
    {
        zvf.origin.y = 0.0;
    }
    zoomView.frame = zvf;
}



- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    CGPoint centerPoint = CGPointMake(CGRectGetMidX(self.bigimgScrollView.bounds),
                                      CGRectGetMidY(self.bigimgScrollView.bounds));
    [self view:self.BigImageView setCenter:centerPoint];
}
- (void)view:(UIView*)view setCenter:(CGPoint)centerPoint
{
    CGRect vf = view.frame;
    CGPoint co = self.bigimgScrollView.contentOffset;
    
    CGFloat x = centerPoint.x - vf.size.width / 2.0;
    CGFloat y = centerPoint.y - vf.size.height / 2.0;
    
    if(x < 0)
    {
        co.x = -x;
        vf.origin.x = 0.0;
    }
    else
    {
        vf.origin.x = x;
    }
    if(y < 0)
    {
        co.y = -y;
        vf.origin.y = 0.0;
    }
    else
    {
        vf.origin.y = y;
    }
    
    view.frame = vf;
    self.bigimgScrollView.contentOffset = co;
}
- (UIView*)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return  self.BigImageView;
}
#pragma mark -
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
     self.expectedBytes = response.expectedContentLength;
    if (self.expectedBytes==-1)
    {
        NSURL *url = [NSURL URLWithString:StrForImg];
        [NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:url] delegate:self];
        SDWebImageManager *manager = [SDWebImageManager sharedManager];
        [manager downloadImageWithURL:url                options:0
                             progress:^(NSInteger receivedSize, NSInteger expectedSize) {
                                 // progression tracking code
                             }
                            completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, BOOL finished, NSURL *imageURL) {
                                if (image) {
                                  self.BigImageView.image=image;
                                }
                            }];
        
    }
    else
    {
        self.data1 = [NSMutableData dataWithCapacity:self.expectedBytes];
        self.progressView.progress = 0.0;
    }
}
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [self.data1 appendData:data];
    double receivedBytes = self.data.length;
    self.progressView.progress = receivedBytes / self.expectedBytes;
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    self.BigImageView.image = [UIImage imageWithData:self.data1];
    if (self.BigImageView.image==nil)
    {
        NSURL *url = [NSURL URLWithString:StrForImg];
        [NSURLConnection connectionWithRequest:[NSURLRequest requestWithURL:url] delegate:self];
        SDWebImageManager *manager = [SDWebImageManager sharedManager];
        [manager downloadImageWithURL:url                options:0
                             progress:^(NSInteger receivedSize, NSInteger expectedSize) {
                                 // progression tracking code
                             }
                            completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, BOOL finished, NSURL *imageURL) {
                                if (image) {
                                    self.BigImageView.image=image;
                                }
                            }];
        
    }
    self.progressView.progress = 1.0;
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    self.progressView.progress = 1.0;
}

//------------------------------------------------------------------------------------------------------
#pragma mark textField delegate...-------------------------------------------------
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    _txtusername.enabled = YES;
    _changeTranImage.hidden=YES;
    _lblsocialsiteaddphoto.hidden=YES;
    _lblchangeprofile.hidden=YES;
    _lblsocialsiteaddphoto.hidden=YES;
    _btnaddPhto.hidden=YES;
    if(![Validations checkMinLength:self.txtusername.text withLimit:6 ])
    {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_UNAME];
    }else{
        [self profileUpdateMethod];
    }
    [textField resignFirstResponder];
    return YES;
}
//------------------------------------------------------------------------------------------------------
#pragma Mark Update Profile Method ...-------------------------------------------------
-(void)profileUpdateMethod;
{
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        [self reloadFeedVCData];
        NSDictionary *dict=[responseObject objectForKey:@"data"];
        
        _txtusername.autocapitalizationType = UITextAutocapitalizationTypeAllCharacters;
        _txtusername.text=[NSString stringWithFormat:@"%@.",[[dict objectForKey:@"username"] uppercaseString]];
        APPDATA.activity.username=[[NSString stringWithFormat:@"%@",[dict objectForKey:@"username"]]mutableCopy ];
        APPDATA.user.username=[[NSString stringWithFormat:@"%@",[dict objectForKey:@"username"]]mutableCopy ];
        UDSetObject(APPDATA.user.username, @"username");
        profileimageStr=[NSString stringWithFormat:@"%@",[dict objectForKey:@"profile_photo"]];
        [APPDATA ShowAlertWithTitle:@"" Message:IMAGE_UPLOAD];

        APPDATA.activity.profileImage= [profileimageStr mutableCopy];
        if ([profileimageStr length]>0) {
            NSString *fCharStr =[profileimageStr substringToIndex:22];
            if ([profileimageStr rangeOfString:@"convert"].location == NSNotFound && [fCharStr isEqualToString:@"https://www.filepicker"])
            {
                profileimageStr = [NSString stringWithFormat:@"%@/convert?w=1000&h=1000",profileimageStr] ;
            }else if([fCharStr isEqualToString:@"https://www.filepicker"])
            {
                profileimageStr = [profileimageStr substringToIndex:[profileimageStr length]-20];
profileimageStr = [NSString stringWithFormat:@"%@/convert?w=1000&h=1000",profileimageStr] ;
            }
        }
  
        if ([profileimageStr length]>2)
        {
            [_profilephoto setImageWithURL:[NSURL URLWithString:profileimageStr] placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            _profilephoto.contentMode=UIViewContentModeScaleAspectFill;
            _profilephoto.clipsToBounds=YES;
        }else{
            [_profilephoto setImage:[UIImage imageNamed:@"no_imgV.png"]];
        }
          };
    void (^failure)(NSError * error) = ^(NSError *error)
    {
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_IMAGE_UPLOAD];

    };
    
    //1 log
    NSString  *strDeviceToken=[[NSUserDefaults standardUserDefaults] objectForKey:@"strDeviceToken"];
    if ([strDeviceToken isKindOfClass:[NSNull class]] || strDeviceToken == nil || [strDeviceToken isEqualToString:@""])
    {
        strDeviceToken=@" ";
    }
    NSDictionary *dict = @{@"key":API_KEY,@"profile_photo":profileimageStr,@"user_id":APPDATA.user.userid,@"username":APPDATA.user.username,@"method":API_PROFILE_UPDATE
                           };
    [APICall sendToService:dict success:successed failure:failure];
}
#pragma mark filefilker Delegate...-------------------------------------------------
- (FPTheme *)theme
{
    if (!_theme)
    {
        FPTheme *theme = [FPTheme new];
        CGFloat hue = 0.5616;
        theme.navigationBarStyle = UIBarStyleBlack;
        theme.navigationBarBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.12 alpha:1.0];
        theme.navigationBarTintColor = [UIColor colorWithHue:hue saturation:0.1 brightness:0.98 alpha:1.0];
        theme.headerFooterViewTintColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.28 alpha:1.0];
        theme.headerFooterViewTextColor = [UIColor whiteColor];
        theme.tableViewBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.49 alpha:1.0];
        theme.tableViewSeparatorColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.38 alpha:1.0];
        theme.tableViewCellBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.49 alpha:1.0];
        theme.tableViewCellTextColor = [UIColor colorWithHue:hue saturation:0.1 brightness:1.0 alpha:1.0];
        theme.tableViewCellTintColor = [UIColor colorWithHue:hue saturation:0.3 brightness:0.7 alpha:1.0];
        theme.tableViewCellSelectedBackgroundColor = [UIColor colorWithHue:hue saturation:0.8 brightness:0.18 alpha:1.0];
        theme.tableViewCellSelectedTextColor = [UIColor whiteColor];
        theme.uploadButtonBackgroundColor = [UIColor blackColor];
        theme.uploadButtonHappyTextColor = [UIColor yellowColor];
        theme.uploadButtonAngryTextColor = [UIColor redColor];
        _theme = theme;
    }
    return _theme;
}
- (NSMutableArray <UIImage *>*)displayedImages
{
    if (!_displayedImages)
    {
        _displayedImages = [NSMutableArray array];
    }
    return _displayedImages;
}
#pragma mark - Actions -------------------------------------------------
- (IBAction)pickerAction:(id)sender
{
    /*
     * Create the object
     */
    FPPickerController *fpController = [FPPickerController new];
    /*
     * Set the delegate
     */
    fpController.fpdelegate = self;
    /*
     * Apply theme
     */
    fpController.theme = self.theme;
    /*
     * Ask for specific data types. (Optional) Default is all files.
     */
    fpController.dataTypes = @[@"image/*"];
    /*
     * Select and order the sources (Optional) Default is all sources
     */
    //fpController.sourceNames = [[NSArray alloc] initWithObjects: FPSourceImagesearch, nil];
    /*
     * Enable multselect (Optional) Default is single select
     */
    fpController.selectMultiple = YES;
    /*
     * Specify the maximum number of files (Optional) Default is 0, no limit
     */
    fpController.maxFiles = 5;
    /*
     * Optionally disable the front camera mirroring (experimental)
     */
    fpController.disableFrontCameraLivePreviewMirroring = NO;
    /*
     * Display it.
     */
    UIPopoverController *popoverController = [[UIPopoverController alloc] initWithContentViewController:fpController];
    self.myPopoverController = popoverController;
    self.myPopoverController.popoverContentSize = CGSizeMake(320, 520);
    [self.myPopoverController presentPopoverFromRect:[sender frame]
                                              inView:self.view
                            permittedArrowDirections:UIPopoverArrowDirectionAny
                                            animated:YES];
}
- (void)pickerModalAction:(NSString *)sender
{
    /*
     * Create the object
     */
    FPPickerController *fpController = [FPPickerController new];
    /*
     * Set the delegate
     */
    fpController.fpdelegate = self;
    /*
     * Apply theme
     */
    fpController.theme = self.theme;
    /*
     * Ask for specific data types. (Optional) Default is all files.
     */
    fpController.dataTypes = @[@"image/*", @"video/*"];
    /*
     * Select and order the sources (Optional) Default is all sources
     */
    //fpController.sourceNames = @[FPSourceImagesearch];
    /*
     * Enable multselect (Optional) Default is single select
     */
    fpController.selectMultiple = YES;
    /*
     * Specify the maximum number of files (Optional) Default is 0, no limit
     */
    fpController.maxFiles = 10;
    /*
     * Optionally disable the front camera mirroring (experimental)
     */
    fpController.disableFrontCameraLivePreviewMirroring = NO;
    fpController.modalPresentationStyle = UIModalPresentationPopover;
    /*
     * If controller will show in popover set popover size (iPad)
     */
    fpController.preferredContentSize = CGSizeMake(400, 500);
    fpController.typeLogin=sender;
    UIPopoverPresentationController *presentationController = fpController.popoverPresentationController;
    presentationController.permittedArrowDirections = UIPopoverArrowDirectionAny;
    [self presentViewController:fpController
                       animated:YES
                     completion:nil];
}
- (IBAction)savingAction:(id)sender
{
    if (self.displayedImages.count == 0)
    {
        UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Nothing to Save"
                                                          message:@"Select an image first."
                                                         delegate:nil
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
        [message show];
        return;
    }
    UIImage *firstImage = self.displayedImages[0];
    NSData *imgData = UIImagePNGRepresentation(firstImage);
    /*
     * Create the object
     */
    self.fpSave = [FPSaveController new];
    /*
     * Set the delegate
     */
    self.fpSave.fpdelegate = self;
    /*
     * Apply theme
     */
    self.fpSave.theme = self.theme;
    /*
     * Select and order the sources (Optional) Default is all sources
     */
    //self.fpSave.sourceNames = @[FPSourceDropbox, FPSourceFacebook, FPSourceBox];
    /*
     * Set the data and data type to be saved.
     */
    self.fpSave.data = imgData;
    self.fpSave.dataType = @"image/png";
    self.fpSave.modalPresentationStyle = UIModalPresentationPopover;
    
    self.fpSave.preferredContentSize = CGSizeMake(400, 500);
    UIPopoverPresentationController *presentationController = self.fpSave.popoverPresentationController;
    presentationController.permittedArrowDirections = UIPopoverArrowDirectionAny;
    presentationController.sourceView = sender;
    presentationController.sourceRect = [sender bounds];
    [self presentViewController:self.fpSave
                       animated:YES
                     completion:nil];
}


#pragma mark - FPPickerControllerDelegate Methods
- (void)fpPickerController:(FPPickerController *)pickerController
      didPickMediaWithInfo:(FPMediaInfo *)info
{
}
- (IBAction)btnuploadPressedTab:(id)sender {
    if (APPDATA.isUserLogin==YES)
    {
        ImgUpload=YES;
        [self pickerModalAction:@"lip"];
    }else{
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_LOGIN];
    }

   
    
}
- (void)fpPickerController:(FPPickerController *)pickerController
didFinishPickingMediaWithInfo:(FPMediaInfo *)info
{
    //NSLog(@"FILE CHOSEN: %@", info);
    if (info)
    {
        if (info.containsImageAtMediaURL)
        {
            postImageurl=[NSString stringWithFormat:@"%@",info.remoteURL];
            [self.displayedImages removeAllObjects];

            if ([addpostimageFlage isEqualToString:@"1"])
            {
                NSLog(@"%@",info.remoteURL);
                UIImage *image = [UIImage imageWithContentsOfFile:info.mediaURL.path];
                [self.displayedImages addObject:image];
                [self.displayedImages removeAllObjects];
                [self.displayedImages addObject:image];
                self.addphotoImage.contentMode=UIViewContentModeScaleAspectFit;
                self.addphotoImage.image = image;
            }
            else if(ImgUpload==YES)
            {
                ImgUpload=NO;
                [self imgUpload:postImageurl];
            }
            else{
                profileimageStr=[NSString stringWithFormat:@"%@",info.remoteURL];
                NSLog(@"%@",info.remoteURL);
                UIImage *image = [UIImage imageWithContentsOfFile:info.mediaURL.path];
                [_profilephoto setImage:image];
                _profilephoto.contentMode=UIViewContentModeScaleAspectFill;
                _profilephoto.clipsToBounds=YES;
                [self.displayedImages addObject:image];
                [self.displayedImages removeAllObjects];
                [self.displayedImages addObject:image];
                [self profileUpdateMethod];
                self.profilephoto.image = image;

            }
            
        }
        [self dismissViewControllerAnimated:YES
                                 completion:nil];
    }
    else
    {
    }
}
- (void)fpPickerController:(FPPickerController *)pickerController
didFinishPickingMultipleMediaWithResults:(NSArray *)results
{
    if (results.count == 0)
    {
        return;
    }
    // Making a little carousel effect with the images
    [self.displayedImages removeAllObjects];
    for (FPMediaInfo *info in results)
    {
        // Check if uploaded file is an image to add it to carousel
        if (info.containsImageAtMediaURL)
        {
            postImageurl=[NSString stringWithFormat:@"%@",info.remoteURL];
            [self.displayedImages removeAllObjects];

            if ([addpostimageFlage isEqualToString:@"1"])
            {
                UIImage *image = [UIImage imageWithContentsOfFile:info.mediaURL.path];
                NSLog(@"%@",info.remoteURL);
                [self.displayedImages addObject:image];
                [self.displayedImages removeAllObjects];
                [self.displayedImages addObject:image];
                self.addphotoImage.contentMode=UIViewContentModeScaleAspectFit;
                self.addphotoImage.image = image;
            }else{
                UIImage *image = [UIImage imageWithContentsOfFile:info.mediaURL.path];
                [_profilephoto setImage:image];
                _profilephoto.contentMode=UIViewContentModeScaleAspectFill;
                _profilephoto.clipsToBounds=YES;
                profileimageStr=[NSString stringWithFormat:@"%@",info.remoteURL];
                [self profileUpdateMethod];
                if ([profileimageStr length]>2)
                {
                    [_profilephoto setImageWithURL:[NSURL URLWithString:profileimageStr] placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                    _profilephoto.contentMode=UIViewContentModeScaleAspectFill;
                    _profilephoto.clipsToBounds=YES;
                }
                else if(ImgUpload==YES)
                {
                    ImgUpload=NO;
                    [self imgUpload:postImageurl];
                }
                else{
                    [_profilephoto setImage:[UIImage imageNamed:@"no_imgV.png"]];
                }
            }
        }
    }}
- (void)fpPickerControllerDidCancel:(FPPickerController *)pickerController
{
    // NSLog(@"FP Cancelled Open");
    [self dismissViewControllerAnimated:YES
                             completion:nil];
}
#pragma mark - FPSaveControllerDelegate Methods
- (void)fpSaveController:(FPSaveController *)saveController
    didFinishSavingMediaWithInfo:(FPMediaInfo *)info
{
    //NSLog(@"FP finished saving with info %@", info);
    [self.fpSave dismissViewControllerAnimated:YES
                                    completion:nil];
}
- (void)fpSaveControllerDidCancel:(FPSaveController *)saveController
{
    // NSLog(@"FP Cancelled Save");
    [self.fpSave dismissViewControllerAnimated:YES
                                    completion:nil];
}
- (void)fpSaveController:(FPSaveController *)saveController
                didError:(NSError *)error
{
    // NSLog(@"FP Error: %@", error);
}
//------------------------------------------------------------------------------------------------------
#pragma Mark Post Close Button Action...-------------------------------------------------
- (IBAction)addPhotoCloseButtonAction:(id)sender {
    addpostimageFlage=@"";
    postImageurl=@"";
    [[IQKeyboardManager sharedManager] setEnable:YES];
    [[IQKeyboardManager sharedManager] setEnableAutoToolbar:YES];
    _viewNewPost.hidden=YES;
}
//------------------------------------------------------------------------------------------------------
#pragma Mark Key Board Done Button Action...-------------------------------------------------
-(void)doneAction:(UIBarButtonItem*)barButton
{
    _txtusername.enabled = YES;
    _changeTranImage.hidden=YES;
    _lblsocialsiteaddphoto.hidden=YES;
    _lblchangeprofile.hidden=YES;
    _lblsocialsiteaddphoto.hidden=YES;
    _btnaddPhto.hidden=YES;
    if(![Validations checkMinLength:self.txtusername.text withLimit:2 ])
    {
        [APPDATA ShowAlertWithTitle:@"" Message:@"Please enter minimum two character"];
    }else{
        [self profileUpdateMethod];
    }
    [_txtusername resignFirstResponder];
}
//------------------------------------------------------------------------------------------------------
#pragma mark Uitext view Delegate Method ...-------------------------------------------------
- (void)textViewDidBeginEditing:(UITextView *)textView
{
    if ([textView.text isEqualToString:@"placeholder text here..."]) {
        textView.text = @"";
        textView.textColor = [UIColor blackColor]; //optional
    }
    [textView becomeFirstResponder];
}
//------------------------------------------------------------------------------------------------------
#pragma mark Tab button action...
- (IBAction)btnContestPressedTab:(id)sender {
    [APPDATA btnContestsPressedTab];
}
- (IBAction)btnMyphotosPressedTab:(id)sender {
    [APPDATA btnMyphotoPressedTab];
}

-(void)imgUpload:(NSString *)imgStr
{
    [APPDATA showLoader];
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        int check=[[responseObject objectForKey:@"error"]intValue];
        if (check==1)
        {
            [APPDATA hideLoader];

            [APPDATA ShowAlertWithTitle:@"" Message:ERROR_IMAGE_UPLOAD];
            [self pickerModalAction:@"lip"];
        }else
        {
                        [APPDATA ShowAlertWithTitle:@"" Message:IMAGE_UPLOAD];
            
            [[NSNotificationCenter defaultCenter]postNotificationName:@"reloadCol" object:nil];
        }
        [APPDATA hideLoader];
    };
    void (^failure)(NSError * error) = ^(NSError *error) {
        [APPDATA hideLoader];
        [APPDATA ShowAlertWithTitle:@"" Message:ERROR_IMAGE_UPLOAD];
        [self pickerModalAction:@"lip"];
    };
    NSDictionary *dict = @{@"key":API_KEY,@"method":API_PROFILE_ALBUM_ADD_UPDATE,@"profile_id":appDelegate.profilid_AppStr,@"url":imgStr
                           };
    [APICall sendToService:dict success:successed failure:failure];
}


- (IBAction)btnBackAction:(id)sender {
    [self.navigationController popViewControllerAnimated:YES ];
}

// Feed data API Call..
-(void)feedupdateUpdateMethod;
{
    @try
    {
    [APPDATA showLoader];
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        if([[responseObject objectForKey:@"data"]  isEqual:@""])
        {
            
            [APPDATA hideLoader];
        }
        else{
            if ([responseObject count]>1) {
                NSDictionary *datadic=[responseObject objectForKey:@"data"];
                NSString *followeStr=[NSString stringWithFormat:@"%@  ", [datadic objectForKey:@"followers"]];
                NSString *followingstr=[NSString stringWithFormat:@"%@  ",[datadic objectForKey:@"followedby"]];
                APPDATA.user.isProfilePublish = [[datadic objectForKey:@"user_status"] boolValue];
                UDSetBool(APPDATA.user.isProfilePublish, @"isPublishProfile");

                UIFont *font1 = [UIFont fontWithName:@"OpenSans-ExtraBold" size:9];
                NSDictionary *arialDict = [NSDictionary dictionaryWithObject: font1 forKey:NSFontAttributeName];
                NSMutableAttributedString *aAttrString1 = [[NSMutableAttributedString alloc] initWithString:followeStr attributes: arialDict];
                UIFont *font2 = [UIFont fontWithName:@"OpenSans" size:10];
                NSDictionary *arialDict2 = [NSDictionary dictionaryWithObject: font2 forKey:NSFontAttributeName];
                NSMutableAttributedString *aAttrString2 = [[NSMutableAttributedString alloc] initWithString:@"FOLLOWING" attributes: arialDict2];
                [aAttrString1 appendAttributedString:aAttrString2];
                _lblfollowers.attributedText = aAttrString1;
            UIFont *font3 = [UIFont fontWithName:@"OpenSans-ExtraBold" size:9];
                NSDictionary *arialDict3 = [NSDictionary dictionaryWithObject: font3 forKey:NSFontAttributeName];
                NSMutableAttributedString *aAttrString3 = [[NSMutableAttributedString alloc] initWithString:followingstr attributes: arialDict3];
                UIFont *font4 = [UIFont fontWithName:@"OpenSans" size:10];
                NSDictionary *arialDict4 = [NSDictionary dictionaryWithObject: font4 forKey:NSFontAttributeName];
                NSMutableAttributedString *aAttrString4 = [[NSMutableAttributedString alloc] initWithString:@"FOLLOWERS" attributes: arialDict4];
                [aAttrString3 appendAttributedString:aAttrString4];
                _lblfollowing.attributedText = aAttrString3;
            }
            [APPDATA hideLoader];
        }
    };
    void (^failure)(NSError * error) = ^(NSError *error) {
        [APPDATA hideLoader];
    };
    NSString  *strDeviceToken=[[NSUserDefaults standardUserDefaults] objectForKey:@"strDeviceToken"];
    if ([strDeviceToken isKindOfClass:[NSNull class]] || strDeviceToken == nil || [strDeviceToken isEqualToString:@""])
    {
        strDeviceToken=@" ";
    }
    NSDictionary *dict;
    if (usertype==0) {
        dict = @{@"key":API_KEY,@"profile_id":APPDATA.user.profileid,@"method":API_PROFILE_FEED
                 };
    }else{
        // NSLog(@"%@",APPDATA.user.profileid);
        NSString *userprofileid=[NSString stringWithFormat:@"%@",APPDATA.user.profileid];
        if ([userprofileid isKindOfClass:[NSNull class]] || userprofileid == nil || [userprofileid isEqualToString:@""])
        {
            appDelegate.profilid_AppStr=@" ";
        }
        dict = @{@"key":API_KEY,@"profile_id":objFeedViewController.strProfileid,@"other_profile_id":APPDATA.user.profileid,@"method":API_PROFILE_FEED
            };
    }
    [APICall sendToService:dict success:successed failure:failure];
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}
- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    if (_dropDowntableview.isHidden)
    {
        addpostimageFlage=@"";
        postImageurl=@"";
       _viewNewPost.hidden=YES;
        [self hideDropDown];
    }
    else
    {
    }
}
// user following or not API call..
-(void)userfollowingornotMethod{
    [APPDATA showLoader];
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        if(responseObject == NULL)
        {
        }else{
            if ([responseObject count]>1) {
                NSDictionary *datadic=[responseObject objectForKey:@"data"];
                NSString *followeStr=[NSString stringWithFormat:@"%@", [datadic objectForKey:@"following"]];
                int followingStatus=[followeStr intValue];
                if (followingStatus ==1)
                {
                    [_btnfollow setTitle:@"UNFOLLOW" forState:UIControlStateNormal];
                }
            }
            [APPDATA hideLoader];
        }
    };
    void (^failure)(NSError * error) = ^(NSError *error) {
        [APPDATA hideLoader];
    };

    NSDictionary* dict = @{@"key":API_KEY,@"profile_id":objFeedViewController.strProfileid,@"followed_by":APPDATA.user.profileid,@"method":API_USER_FOLLOWING_OR_NOT
                           };
    [APICall sendToService:dict success:successed failure:failure];
}

// drop down menu hide with add animations
-(void)hideDropDown{
    if (!downpopFlag)
    {
    }else{
        downpopFlag=NO;
        [UIView animateWithDuration:0.50
                              delay:0.0
                            options:UIViewAnimationOptionBeginFromCurrentState
                         animations:^{
                             if (usertype==0){
                                 NSLog(@"Uppp2nd");                                 [_dropDowntableview setFrame:CGRectMake(_dropDowntableview.frame.origin.x, _dropDowntableview.frame.origin.y,  _dropDowntableview.frame.size.width, _dropDowntableview.frame.size.height-119)];
                                 [_viewdropDown setFrame:CGRectMake(_viewdropDown.frame.origin.x, _viewdropDown.frame.origin.y,  _viewdropDown.frame.size.width, _viewdropDown.frame.size.height-119)];
                             }else
                             {
                                 NSLog(@"Uppp3nd");
                             
                                 [_dropDowntableview setFrame:CGRectMake(_dropDowntableview.frame.origin.x, _dropDowntableview.frame.origin.y,  _dropDowntableview.frame.size.width, _dropDowntableview.frame.size.height-59)];
                                 [_viewdropDown setFrame:CGRectMake(_viewdropDown.frame.origin.x, _viewdropDown.frame.origin.y,  _viewdropDown.frame.size.width, _viewdropDown.frame.size.height-59)];
                             }
                         }
                         completion:^(BOOL END){
                             _viewdropDown.hidden=YES;
                         }];
    }
}

// publish profile button actions
- (IBAction)publishProfile:(id)sender {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
     message:@"Are you sure you want to publish your profile?"
                                                   delegate:self
                                          cancelButtonTitle:@"Yes"
                                          otherButtonTitles:@"No",nil];
    [alert show];
    alert.tag = 111;
    
    
}
// alert view button actions publish profile API call
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag==111) {
        
        if (buttonIndex == 0)
        {
            Users *objUser = [[Users alloc] init];
            objUser.key = [API_KEY mutableCopy];
            objUser.profileid =APPDATA.user.profileid;
            [objUser publishProfile:^(NSString *result, int status){
                [APPDATA hideLoader];
                if (status == 1) {
                    _btnNewPost.hidden = NO;
                    _btnPublishProfile.hidden = YES;
                    _btnEdit.hidden=NO;

                    UDSetBool(APPDATA.user.isProfilePublish, @"isPublishProfile");
                }
                else
                {
                    [APPDATA ShowAlertWithTitle:@"" Message:result];
                }
                
            }];
        }
    }
}

- (IBAction)btnCloseTapped:(id)sender {
}

-(void)btnPostHide
{
       if ([[NSString stringWithFormat:@"%@",APPDATA.user.strOtherId ] isEqualToString:[NSString stringWithFormat:@"%@",APPDATA.user.profileid]])
       {
           _btnmessage.hidden=YES;
       }
    
    
    
}
// profile is publish or not checking and set according data..
- (void) isPublishProfile {
    if (usertype==0)
    {
        
        if (UDGetBool(@"isPublishProfile") == NO)
        {
            _btnPublishProfile.hidden =NO;
            _btnNewPost.hidden = YES;
            _btnEdit.hidden = YES;
        }
        else
        {
            _btnPublishProfile.hidden =YES;
            _btnNewPost.hidden = NO;
            _btnEdit.hidden = NO;
        }
    }
    else
    {
       struserid = [NSString stringWithFormat:@"%@",APPDATA.user.profileid];
   
        strotherProfileid = [NSString stringWithFormat:@"%@",APPDATA.user.strOtherId];
        if (struserid==strotherProfileid) {
            
            if (UDGetBool(@"isPublishProfile") == NO)
            {
                _btnPublishProfile.hidden =NO;
                _btnNewPost.hidden = YES;
                _btnEdit.hidden = YES;
            }
            else
            {
                _btnPublishProfile.hidden =YES;
                _btnNewPost.hidden = NO;
                _btnEdit.hidden = NO;
            }

        }
        
        
    }
}
@end
