//
//  MyGroupsViewController.m
//  photobug
//
//   on 12/23/15.
//  Copyright © Photobug. All rights reserved.
//
#import "MyGroupsViewController.h"
#import "Constant.h"
#import "ApplicationData.h"
#import "MyDashboardViewController.h"
#import "GroupFeedViewController.h"
#import <UIActivityIndicator-for-SDWebImage/UIImageView+UIActivityIndicatorForSDWebImage.h>

@interface MyGroupsViewController ()
@end

@implementation MyGroupsViewController
{
    Group *objMyGroup;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    _collectionView.bounces=NO;
    _collectionView.dataSource=self;
    _collectionView.delegate=self;
    _collectionView.bounces=NO;
    objMyGroup  = [[Group alloc] init];
}

// API call for getting group list..
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self getMyGroupList];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma marrk Get profile info...
- (void) getMyGroupList
{
    [APPDATA showLoader];
       objMyGroup.key = [API_KEY mutableCopy];
    [objMyGroup getMyGroupList:^(NSDictionary *result, NSString *str, int status) {
        if (status == 1)
        {
            if (APPDATA.group.arrMyGroupList.count ==0){
                self.lblNoDataFound.hidden =NO;
                CGRect frame = self.lblNoDataFound.frame;
                frame.origin.y = (self.view.superview.frame.size.height/2)-(self.lblNoDataFound.frame.size.height /2);
                [self.lblNoDataFound setFrame:frame];

                
            }
            else{
                [self.collectionView reloadData];
                self.lblNoDataFound.hidden = YES;
            }
            [APPDATA hideLoader];
        }
        else
        {
            [APPDATA hideLoader];
        }
    }];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return APPDATA.group.arrMyGroupList.count;
}
// set data in collection view
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"Cell1";
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    UIImageView *recipeImageView = (UIImageView *)[cell viewWithTag:100];
    NSDictionary *dictUserData = [APPDATA.group.arrMyGroupList objectAtIndex:indexPath.row];
    if (![[dictUserData valueForKey:@"group_image"] isKindOfClass:[NSNull class]] &&
        [[dictUserData valueForKey:@"group_image"] length] > 3)
    {
        NSString *profile_photoStr=[NSString stringWithFormat:@"%@",[dictUserData valueForKey:@"group_image"]];
        NSString *fCharStr =[profile_photoStr substringToIndex:22];
        if ([profile_photoStr rangeOfString:@"convert"].location == NSNotFound && [fCharStr isEqualToString:@"https://www.filepicker"])
        {
            
        }else if([fCharStr isEqualToString:@"https://www.filepicker"])
        {
            profile_photoStr = [profile_photoStr substringToIndex:[profile_photoStr length]-20];
        }
        if ([profile_photoStr length]>2)
        {
            [recipeImageView setImageWithURL:[NSURL URLWithString:profile_photoStr] placeholderImage:[UIImage imageNamed:@""] usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        }
        else{
            [recipeImageView setImage:[UIImage imageNamed:@"no_imgV.png"]];
        }
        recipeImageView.contentMode = UIViewContentModeScaleAspectFill;
        recipeImageView.clipsToBounds=YES;
    }
    else{
        [recipeImageView setImage:[UIImage imageNamed:@"no_imgV.png"]];
    }
    UILabel *userLabel = (UILabel *)[cell viewWithTag:101];
    userLabel.text=[[dictUserData valueForKey:@"group_name"] uppercaseString];
    [APPDATA hideLoader];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"hideDropDown" object:nil];
    GroupFeedViewController  *objviewController =(GroupFeedViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"GroupFeedViewController"];
    
    NSDictionary *dictUserData = [APPDATA.group.arrMyGroupList objectAtIndex:indexPath.row];
    
    if ([[dictUserData valueForKey:@"posted_by"]integerValue] == APPDATA.user.profileid.integerValue) {
        objviewController.isMyGroup=YES;
    }
    else{
        objviewController.isMyGroup=NO;
    }
    APPDATA.group.groupId = [[APPDATA.group.arrMyGroupList objectAtIndex:indexPath.row]valueForKey:@"id"];

    objviewController.dictGroupDetail = [APPDATA.group.arrMyGroupList objectAtIndex:indexPath.row];
    objviewController.selectGroupeType = SelectMyGroup;
    objviewController.usertype = Guestuser;
    [APPDATA pushNewViewController:objviewController];
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    CGSize cgsize ;
    if( IS_IPHONE6){
        cgsize = CGSizeMake(183, 183);
    }else if(IS_IPHONE6plus)
    {
        cgsize = CGSizeMake(202, 202);
    }else
    {
        cgsize = CGSizeMake(156, 156);
    }
    return cgsize;
}

- (IBAction)btnBackPressed:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark Tab button action...
- (IBAction)btnContestPressedTab:(id)sender {
    [APPDATA btnContestsPressedTab];
}

- (IBAction)btnMyphotosPressedTab:(id)sender {
    [APPDATA btnMyphotoPressedTab];
}

- (IBAction)btnuploadPressedTab:(id)sender {
    [APPDATA btnuploadPressedTab];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"hideDropDown" object:nil];
}

@end
