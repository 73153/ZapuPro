//
//  CashoutViewController.h
//  photobug
//
//   on 3/2/16.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CashoutViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *btnSubmit;
@property (strong, nonatomic) IBOutlet UILabel *lblfullAmount;
@property (strong, nonatomic) IBOutlet UITextField *txtname;
@property (strong, nonatomic) IBOutlet UITextField *txtemail;
@property (strong, nonatomic) IBOutlet UITextField *txtphonenumber;
@property (strong, nonatomic) IBOutlet UITextField *txtadd1;
@property (strong, nonatomic) IBOutlet UITextField *txtadd2;
@property (strong, nonatomic) IBOutlet UITextField *txtcity;
@property (strong, nonatomic) IBOutlet UITextField *txtzip;
@property (strong, nonatomic) IBOutlet UIButton *btnstate;
@property (strong, nonatomic) IBOutlet UIView *stateView;
@property (strong, nonatomic) IBOutlet UILabel *lblStatename;
@property (strong, nonatomic) IBOutlet UITableView *tblstate;
- (IBAction)btncloseAction:(id)sender;
- (IBAction)btnStateAction:(id)sender;
- (IBAction)btnSumitAction:(id)sender;

@end
