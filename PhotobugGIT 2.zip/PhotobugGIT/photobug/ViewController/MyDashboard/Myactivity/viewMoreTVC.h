//
//  viewMoreTVC.h
//  photobug
//
//   on 24/11/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface viewMoreTVC : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblCredits;
@property (strong, nonatomic) IBOutlet UILabel *lblDate;
@end
