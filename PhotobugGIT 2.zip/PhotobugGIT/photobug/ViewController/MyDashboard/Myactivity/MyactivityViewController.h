//
//  MyactivityViewController.h
//  photobug
//
//   on 11/19/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyactivityViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong) IBOutlet UIScrollView *scrollView;
@property (nonatomic,strong) IBOutlet UILabel *lblCurrentCredits;
@property (nonatomic,strong) IBOutlet UILabel *lblCredit1;
@property (nonatomic,strong) IBOutlet UILabel *lblCredit2;
@property (nonatomic,strong) IBOutlet UILabel *lblCredit3;
@property (nonatomic,strong) IBOutlet UILabel *lblCredit4;
@property (nonatomic,strong) IBOutlet UILabel *lblCredit5;
@property (nonatomic,strong) IBOutlet UILabel *lblCredit6;
@property (nonatomic,strong) IBOutlet UILabel *lblTotalEarning;
@property (nonatomic,strong) IBOutlet UILabel *lblCurrentContests;
@property (nonatomic,strong) IBOutlet UILabel *lblAwards;
@property (nonatomic,strong) IBOutlet UILabel *lblAchiveCredits;
@property (nonatomic,strong) IBOutlet UIScrollView *mileStoneScrollView;
@property (strong, nonatomic) IBOutlet UILabel *lblmainSton;
@property (strong, nonatomic) IBOutlet UIScrollView *scrpast;
@property (nonatomic,strong) IBOutlet UIView *mainView;
@property (nonatomic,strong) IBOutlet UIButton *btnViewMore;
@property (strong, nonatomic) IBOutlet UIView *viewMoreView;
@property (strong, nonatomic) IBOutlet UITableView *tblviewViewMore;
@property (nonatomic,strong) IBOutlet UIButton *btnPastTranViewMore;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollViewPast;
@property (strong, nonatomic) IBOutlet UIButton *btncashout;
@property (strong, nonatomic) IBOutlet UILabel *lblcridesc;
@property (strong, nonatomic) IBOutlet UILabel *lblPastdesc;
@property (nonatomic) BOOL shouldRefresh;

- (IBAction)onbtnCancleViewMore:(id)sender;
- (IBAction)onbtnViewMore:(id)sender;
- (IBAction)btnPastTranViewMore:(id)sender;
-(void)setPastTrans;
- (IBAction)btnCashoutAction:(id)sender;
@end
