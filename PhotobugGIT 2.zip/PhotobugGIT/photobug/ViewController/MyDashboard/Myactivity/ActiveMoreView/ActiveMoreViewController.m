//
//  ActiveMoreViewController.m
//  photobug
//
//   on 2/8/16.
//  Copyright © Photobug. All rights reserved.
//

#import "ActiveMoreViewController.h"
#import "viewMoreTVC.h"
#import "MyactivityViewController.h"
#import "ApplicationData.h"
#import "Constant.h"
#import "MyActivity.h"
@interface ActiveMoreViewController ()
@end

@implementation ActiveMoreViewController
- (void)viewDidLoad {
    [super viewDidLoad];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

// header name and font change as per the requirement (creditTransaction,PastTransaction)
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    if (APPDATA.activity.isCreditTransaction==YES) {
    _lblHeaderName.text=@"Credits History";
    _lblHeaderName.font = [UIFont fontWithName:@"OpenSans-SemiBold" size:20];
    }
    else if (APPDATA.activity.isPastTransaction==YES) {
    _lblHeaderName.text=@"Past Transactions";
    _lblHeaderName.font = [UIFont fontWithName:@"OpenSans-SemiBold" size:20];
  }
}

#pragma mark table view delegate
-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section
{
    NSLog(@"%@",[ApplicationData sharedInstance].activity.aryCreditHostory);
    
    if (APPDATA.activity.isCreditTransaction==YES) {
        return [ApplicationData sharedInstance].activity.aryCreditHostory.count;
    }
    else 
    {
       return [ApplicationData sharedInstance].activity.pasttransaction.count;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 30;
}
// display the data based on credit and debit as per the pasttaransaction and credit history
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableId=@"viewMoreTVC";
    viewMoreTVC *cell=(viewMoreTVC*)[_tblviewViewMore dequeueReusableCellWithIdentifier:simpleTableId];
    if (cell == nil) {
        cell = [[viewMoreTVC alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableId];
    }
    
    if (APPDATA.activity.isCreditTransaction==YES) {
        NSString *amountStr;
        NSString *str=[NSString stringWithFormat:@"%@",[[[ApplicationData sharedInstance].activity.aryCreditHostory objectAtIndex:indexPath.row] valueForKey:@"type"]];
        
        if ([[str lowercaseString] isEqualToString:@"credit"])
        {
            NSNumber *someNumber = [NSNumber numberWithDouble:[[[[ApplicationData sharedInstance].activity.aryCreditHostory objectAtIndex:indexPath.row] valueForKey:@"amount"]integerValue]];
            
            NSNumberFormatter *nf = [[NSNumberFormatter alloc] init];
           // [nf setNumberStyle:NSNumberFormatterCurrencyStyle];
            [nf setGeneratesDecimalNumbers:NO];
            [nf setMaximumFractionDigits:0];
            NSString *someString = [nf stringFromNumber:someNumber];
            someString=[someString stringByReplacingOccurrencesOfString:@"$" withString:@""];
            
             amountStr=[NSString stringWithFormat:@"+%@",someString];
        }
        else if ([[str lowercaseString] isEqualToString:@"debit"])
        {
            NSNumber *someNumber = [NSNumber numberWithDouble:[[[[ApplicationData sharedInstance].activity.aryCreditHostory objectAtIndex:indexPath.row] valueForKey:@"amount"]integerValue]];
            
            NSNumberFormatter *nf = [[NSNumberFormatter alloc] init];
            [nf setNumberStyle:NSNumberFormatterCurrencyStyle];
            [nf setGeneratesDecimalNumbers:NO];
            [nf setMaximumFractionDigits:0];
            NSString *someString = [nf stringFromNumber:someNumber];

            amountStr=[NSString stringWithFormat:@"-%@",someString];

        }
        
        NSString *dateStr=[NSString stringWithFormat:@"%@",[[[ApplicationData sharedInstance].activity.aryCreditHostory objectAtIndex:indexPath.row] valueForKey:@"created_at"]];
        NSString *sectionStr=[NSString stringWithFormat:@"%@",[[[ApplicationData sharedInstance].activity.aryCreditHostory objectAtIndex:indexPath.row] valueForKey:@"section"]];
        dateStr = [dateStr substringFromIndex:5];
        dateStr=[dateStr substringToIndex:5];
        dateStr=[NSString stringWithFormat:@"%@ %@",sectionStr,dateStr];
        cell.lblCredits.text=amountStr;
        cell.lblDate.text=dateStr;

    }
    else if (APPDATA.activity.isPastTransaction==YES)
    {
        NSNumber *someNumber = [NSNumber numberWithDouble:[[[[ApplicationData sharedInstance].activity.pasttransaction objectAtIndex:indexPath.row] valueForKey:@"amount"]integerValue]];
        NSNumberFormatter *nf = [[NSNumberFormatter alloc] init];
        [nf setNumberStyle:NSNumberFormatterCurrencyStyle];
        [nf setGeneratesDecimalNumbers:NO];
        [nf setMaximumFractionDigits:0];
        NSString *someString = [nf stringFromNumber:someNumber];
       NSString *amountStr=[NSString stringWithFormat:@"%@",someString];
        
        NSString *dateStr=[NSString stringWithFormat:@"%@",[[[ApplicationData sharedInstance].activity.pasttransaction objectAtIndex:indexPath.row] valueForKey:@"created_at"]];
        NSString *purchasedStr=[NSString stringWithFormat:@"%@",[[[ApplicationData sharedInstance].activity.pasttransaction objectAtIndex:indexPath.row] valueForKey:@"purchased"]];
        NSString *strType;
        int intpur=[purchasedStr intValue];
        dateStr = [dateStr substringFromIndex:5];
        dateStr=[dateStr substringToIndex:5];
        if (intpur==2)
        {
            amountStr=[NSString stringWithFormat:@"%@",amountStr];
            strType=[NSString stringWithFormat:@"Cashout %@",dateStr];
        }else if(intpur==1){
            amountStr=[NSString stringWithFormat:@"-%@",amountStr];
            strType=[NSString stringWithFormat:@"Purchase %@",dateStr];
        }else{
           amountStr=[NSString stringWithFormat:@"+%@",amountStr];
            strType=[NSString stringWithFormat:@"Sold %@",dateStr];
        }
        
        dateStr=[NSString stringWithFormat:@"%@",strType];
        cell.lblCredits.text=amountStr;
        cell.lblDate.text=dateStr;
}
    
    return cell;
}

- (void)deselectRowAtIndexPath:(NSIndexPath *)indexPath animated:(BOOL)animated {
    [_tblviewViewMore deselectRowAtIndexPath:indexPath animated:TRUE];
}
- (IBAction)btnOkAction:(id)sender {
    
      [self.view removeFromSuperview];
}

// Use attributed string for formatiing some string fontstyle
-(NSMutableAttributedString *)opensSemiBold:(NSString *)textStr11 :(NSString *)textStr9
{
    
    textStr11=[NSString stringWithFormat:@"%@   ",textStr11];
    
    UIFont *font1 = [UIFont fontWithName:@"OpenSans-ExtraBold" size:16];
    NSDictionary *arialDict = [NSDictionary dictionaryWithObject: font1 forKey:NSFontAttributeName];
    NSMutableAttributedString *aAttrString1 = [[NSMutableAttributedString alloc] initWithString:textStr11 attributes: arialDict];
    
    UIFont *font2 = [UIFont fontWithName:@"OpenSans" size:15];
    
    NSDictionary *arialDict2 = [NSDictionary dictionaryWithObject: font2 forKey:NSFontAttributeName];
    NSMutableAttributedString *aAttrString2 = [[NSMutableAttributedString alloc] initWithString:textStr9 attributes: arialDict2];
    NSUInteger length1 = [aAttrString1 length];
    NSUInteger length2 = [aAttrString2 length];
    
    [aAttrString1 addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithRed:21.0/255.0 green:35.0/255.0 blue:66.0/255.0 alpha:1] range:NSMakeRange(0,length1)];
    
    [aAttrString2 addAttribute:NSForegroundColorAttributeName value:[UIColor grayColor] range:NSMakeRange(0,length2)];
    [aAttrString1 appendAttributedString:aAttrString2];
    return aAttrString1;
}




@end
