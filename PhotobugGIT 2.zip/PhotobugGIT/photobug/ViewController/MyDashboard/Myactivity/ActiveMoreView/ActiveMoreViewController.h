//
//  ActiveMoreViewController.h
//  photobug
//
//   on 2/8/16.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ActiveMoreViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITableView *tblviewViewMore;
@property (weak, nonatomic) IBOutlet UILabel *lblHeaderName;
- (IBAction)btnOkAction:(id)sender;
@end
