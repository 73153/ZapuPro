//
//  CashoutViewController.m
//  photobug
//
//   on 3/2/16.
//  Copyright © Photobug. All rights reserved.
//

#import "CashoutViewController.h"
#import "DashboardViewController.h"
#import "ApplicationData.h"
#import "DashBoardCell.h"
#import "AsyncImageView.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "LoginViewController.h"
#import "ContestLandingViewController.h"
#import "MyPhotosViewController.h"
#import "SubmitAnEntryViewController.h"
#import "PhotoPickerViewController.h"
#import "ContestCategoryViewController.h"
#import "MyDashboardViewController.h"
#import "cashTableViewCell.h"
#import "APICall.h"
@interface CashoutViewController (){
    NSArray *state_listArray;
}
@end

@implementation CashoutViewController
// set button style and color and cornerRadious
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[_btnSubmit layer] setBorderWidth:1.0f];
    [[_btnSubmit layer] setCornerRadius:2.0f];
    [[_btnSubmit layer] setBorderColor:[UIColor colorWithRed:50.0/255.0 green:198.0/255.0 blue:244.0/255.0 alpha:1.0].CGColor];
   }

- (void)didReceiveMemoryWarning {
   
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// API call for geting my activity data..
- (void)viewWillAppear:(BOOL)animated {
     [super viewWillAppear:animated];
     [self getMyActivityData];
    _txtzip.text = @"0";
}


- (IBAction)btncloseAction:(id)sender {
    [self.view removeFromSuperview];
}

- (IBAction)btnStateAction:(id)sender {
    _stateView.hidden=NO;
}

// check validations and then call API for submit the data on server..
- (IBAction)btnSumitAction:(id)sender {
     NSString *statStr=[NSString stringWithFormat:@"%@",_btnstate.titleLabel.text];
    if (![Validations checkMinLength:self.txtemail.text withLimit:2] || ![Validations isValidEmail:self.txtemail.text]) {
        [APPDATA ShowAlertWithTitle:@"" Message:@"Enter valid email id."];
    }
    else if (![Validations checkMinLength:self.txtadd1.text withLimit:1]) {
     
        [APPDATA ShowAlertWithTitle:@"" Message:@"Please enter address. "];
    }
    else if (![Validations checkMinLength:self.txtcity.text withLimit:1]) {
        
        [APPDATA ShowAlertWithTitle:@"" Message:@"Please enter city name. "];
    }
    else if (![Validations checkMinLength:self.txtphonenumber.text withLimit:1]) {
        
        [APPDATA ShowAlertWithTitle:@"" Message:@"Please enter phone number."];
    }
    else if (![Validations checkMinLength:self.txtzip.text withLimit:1]) {
        [APPDATA ShowAlertWithTitle:@"" Message:@"Please enter zip code."];
    }else if ([statStr isEqualToString:@"STATE"])
    {
        [APPDATA ShowAlertWithTitle:@"" Message:@"Please select state. "];
    }
    else{
        [self mainSubmitMethod];
    }
}
//Get my activity API call
- (void) getMyActivityData {
    
    appDelegate.profilid_AppStr = APPDATA.user.profileid ;
    APPDATA.activity.key = [API_KEY mutableCopy];
    
    [APPDATA showLoader];
    
    [APPDATA.activity getMyActivity:^(NSDictionary *result, NSString *str, int status) {
        [APPDATA hideLoader];
        if (status == 1) {
             NSDictionary *datadic=[result valueForKey:@"data"];
            state_listArray=[datadic valueForKey:@"state_list"];
            if ([[datadic valueForKey:@"address1"] length]>1)
            {
                _txtadd1.text=[APPDATA isNullOrEmpty:[NSString stringWithFormat:@"%@",[datadic valueForKey:@"address1"]]];
            }
            if ([[datadic valueForKey:@"address2"] length]>1)
            {
                _txtadd2.text=[APPDATA isNullOrEmpty:[NSString stringWithFormat:@"%@",[datadic valueForKey:@"address1"]]];
            }
                _txtphonenumber.text=[APPDATA isNullOrEmpty:[NSString stringWithFormat:@"%@",[datadic valueForKey:@"contact"]]];
            if ([[datadic valueForKey:@"username"] length]>1)
            {
                _txtname.text=[APPDATA isNullOrEmpty:[NSString stringWithFormat:@"%@",[datadic valueForKey:@"username"]]];
            }
            if ([[datadic valueForKey:@"city"] length]>1)
            {
                _txtcity.text=[APPDATA isNullOrEmpty:[NSString stringWithFormat:@"%@",[datadic valueForKey:@"city"]]];
            }
            if ([[datadic valueForKey:@"email"] length]>1)
            {
                _txtemail.text=[APPDATA isNullOrEmpty:[NSString stringWithFormat:@"%@",[datadic valueForKey:@"email"]]];
            }
            NSString *tTotalEarning=[NSString stringWithFormat:@"%@",APPDATA.activity.totalEarning];
            if ([tTotalEarning isKindOfClass:[NSNull class]] || tTotalEarning == nil || [tTotalEarning isEqualToString:@""]|| [tTotalEarning isEqualToString:@"<null>"])
            {
            }else{
                _lblfullAmount.text = [APPDATA isValueNullOrEmpty:[NSString stringWithFormat:@"$%@",APPDATA.activity.totalEarning]];
            }
            
            [self.tblstate reloadData];
        }
        else
        {
            [APPDATA ShowAlertWithTitle:@"" Message:[result valueForKey:@"message"]];
            [APPDATA hideLoader];

        }
    }];
}

// state view hide when single touch outside

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
     _stateView.hidden=YES;
}

#pragma mark table view delegate
-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section
{
    NSLog(@"%lu",(unsigned long)state_listArray.count);
    
    return state_listArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableId=@"cashTableViewCell";
    cashTableViewCell *cell=(cashTableViewCell*)[_tblstate dequeueReusableCellWithIdentifier:simpleTableId];
    if (cell == nil) {
        cell = [[cashTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableId];
    }
    cell.lblSatename.text=[NSString stringWithFormat:@"%@",[[state_listArray objectAtIndex:indexPath.row] objectForKey:@"name"]];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    NSString *strTitle=[NSString stringWithFormat:@"%@",[[state_listArray objectAtIndex:indexPath.row] objectForKey:@"name"]];
    
    [_btnstate setTitle: strTitle forState: UIControlStateNormal];
    _stateView.hidden=YES;
    
}

// API call for submit the data on server...
-(void)mainSubmitMethod
{
    [APPDATA showLoader];
    
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        
        [APPDATA hideLoader];
        
        [self.view removeFromSuperview];
    };
    
    void (^failure)(NSError * error) = ^(NSError *error) {
        [self.view removeFromSuperview];
        [APPDATA hideLoader];
    };
    
    NSLog(@"%@",appDelegate.profilid_AppStr);
    NSString *statStr=[NSString stringWithFormat:@"%@",_btnstate.titleLabel.text];
        NSDictionary * dict = @{@"key":API_KEY,@"profile_id":appDelegate.profilid_AppStr,@"method":API_SEND_REQUEST_CHECK_MAIL,@"amount":APPDATA.activity.totalEarning,@"name":_txtname.text,@"email":_txtemail.text,@"contact":_txtphonenumber.text,@"address1":_txtadd1.text,@"address2":_txtadd2.text,@"state":statStr,@"city":_txtcity.text,@"zip":_txtzip.text
                 };
    [APICall sendToService:dict success:successed failure:failure];
}

@end
