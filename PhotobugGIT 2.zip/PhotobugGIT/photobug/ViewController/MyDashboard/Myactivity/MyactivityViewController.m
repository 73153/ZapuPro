//
//  MyactivityViewController.m
//  photobug
//
//   on 11/19/15.
//  Copyright © Photobug. All rights reserved.
//
#import "MyactivityViewController.h"
#import "ApplicationData.h"
#import "Constant.h"
#import "MyActivity.h"
#import "viewMoreTVC.h"
#import "ActiveMoreViewController.h"
#import "CashoutViewController.h"

@interface MyactivityViewController ()
{
    int scrollviewhight;
}
@end

@implementation MyactivityViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    _viewMoreView.hidden=YES;
    self.scrollView.bounces=NO;
    self.scrollView.contentSize = CGSizeMake(320, 568);
    [self.scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
    int noOfMileston = 5;// no of milestone of the graph
    if (noOfMileston > 6)
    {
        scrollviewhight = noOfMileston * 48;// set scrollview width
        self.mileStoneScrollView.contentSize = CGSizeMake(160, scrollviewhight);
        [self.mileStoneScrollView setContentOffset:CGPointMake(0,scrollviewhight-(48*6)) animated:YES];
    }else{
        scrollviewhight = 260;
        self.mileStoneScrollView.contentSize = CGSizeMake(160, 260);
        [self.mileStoneScrollView setContentOffset:CGPointMake(0,30) animated:YES];
    }
    self.lblAwards.text = [APPDATA isValueNullOrEmpty:[NSString stringWithFormat:@"%@", APPDATA.activity.awards]];
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setGroupingSeparator:@","];
    [numberFormatter setGroupingSize:3];
    [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
    NSString *strCurrentCredit = [numberFormatter stringFromNumber:[NSNumber numberWithInteger:[APPDATA.activity.totalCredits integerValue]]];
    self.lblCurrentCredits.text =[APPDATA isValueNullOrEmpty:[NSString stringWithFormat:@"%@", strCurrentCredit]];
    NSString *tTotalEarning=[NSString stringWithFormat:@"%@",APPDATA.activity.totalEarning];
    if ([tTotalEarning isKindOfClass:[NSNull class]] || tTotalEarning == nil || [tTotalEarning isEqualToString:@""]|| [tTotalEarning isEqualToString:@"<null>"])
    {
        _btncashout.hidden=YES;
        self.lblTotalEarning.text=@"0";
    }else{
        self.lblTotalEarning.text = [APPDATA isValueNullOrEmpty:[NSString stringWithFormat:@"$%@",APPDATA.activity.totalEarning]];
    }
    self.lblCurrentContests.text = [APPDATA isValueNullOrEmpty:[NSString stringWithFormat:@"%@",APPDATA.activity.currentContest]];

    NSNumberFormatter *numberFormatter1 = [[NSNumberFormatter alloc] init];
    [numberFormatter1 setGroupingSeparator:@","];
    [numberFormatter1 setGroupingSize:3];
    [numberFormatter1 setNumberStyle:NSNumberFormatterDecimalStyle];
    NSString *strCurrentCredit1 = [numberFormatter stringFromNumber:[NSNumber numberWithInteger:[APPDATA.activity.totalMileston integerValue]]];
             self.lblAchiveCredits.text = [APPDATA isValueNullOrEmpty:strCurrentCredit1];

    if ([APPDATA.activity.aryNoOfMileStone containsObject:APPDATA.activity.totalMileston]) {
        self.lblAchiveCredits.hidden = YES;
    }
        [self setNoOfMilestonBox:noOfMileston];
        [self setMileStoneGraph];
    self.lblAchiveCredits.textAlignment = NSTextAlignmentRight;
    _lblcridesc.text=[NSString stringWithFormat:@"%@",APPDATA.activity.credits_history_descStr];
    _lblPastdesc.text=[NSString stringWithFormat:@"%@",APPDATA.activity.past_transactions_descStr];
    NSLog(@"%@",APPDATA.activity.totalEarning);
    [self setCreditHistory];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"RefreshTable" object:nil userInfo:nil];
}
// calculate graph base on credit .
- (void) setMileStoneGraph
{
    int maxCredit = 0 ;
    maxCredit =  [[APPDATA.activity.aryNoOfMileStone firstObject] intValue];
    int noOfMileston = 5;
    int getCredit =0;
    getCredit = [APPDATA.activity.totalMileston intValue];
    int CreditPart =(int) maxCredit/noOfMileston;
    int fullCredit =(int) (getCredit/CreditPart);
    float remainpart = (float) (getCredit%CreditPart);
    float remainPoint = (float)(remainpart/CreditPart);
    float point1;
    if (remainPoint != 0)
   point1 = 1-remainPoint;
    if (remainpart > 1)
        fullCredit = fullCredit +1;
    int point = point1 *100;
    [self fillColorinMileston:point credit:(int)fullCredit];
}
// set User Interface of Milestone
- (void)setNoOfMilestonBox:(int) noOfMileston {
    int boxW = 100;
    int boxH = 40;
    int gap = 5;
    int boxY = scrollviewhight - 10;
    int mile = 0;
       NSArray  *themutablearray=[[[APPDATA.activity.aryNoOfMileStone reverseObjectEnumerator] allObjects] mutableCopy];
    
    UILabel *mainStonlbl=[[UILabel alloc] initWithFrame: CGRectMake(5,scrollviewhight-30,40,50)];
    mainStonlbl.tag = 200;
    mainStonlbl.textColor = [UIColor colorWithRed:(27/255.0) green:(48/255.0) blue:(84/255.0) alpha:1];
    [mainStonlbl setFont:[UIFont fontWithName:@"OpenSans" size:12]];
    mainStonlbl.textAlignment=NSTextAlignmentRight;
    mainStonlbl.text = [NSString stringWithFormat:@"%@",[APPDATA.activity.aryNoOfMileStone lastObject]];
    [self.mileStoneScrollView addSubview:mainStonlbl];
    mile=2000;
    
    for (int i =0 ;i< noOfMileston; i++)
    {
        UIView *viewCredit = [[UIView alloc] init];
        [viewCredit setFrame:CGRectMake(50, boxY-30, boxW, boxH)];
        viewCredit.backgroundColor = LightGray_COLOR;
        viewCredit.tag = 100+i;
        UILabel *mainStonlbl=[[UILabel alloc] initWithFrame: CGRectMake(5,boxY-5,40,50)];
        mainStonlbl.textColor = [UIColor colorWithRed:(27/255.0) green:(48/255.0) blue:(84/255.0) alpha:1];
        mainStonlbl.tag = 201 + i;
        [mainStonlbl setFont:[UIFont fontWithName:@"OpenSans" size:12]];
        mainStonlbl.textAlignment=NSTextAlignmentRight;
        
        
        NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
        [numberFormatter setGroupingSeparator:@","];
        [numberFormatter setGroupingSize:3];
        [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
        NSString *strCurrentCredit = [numberFormatter stringFromNumber:[NSNumber numberWithInteger:[[themutablearray objectAtIndex:i] integerValue]]];
        if (i == 0) {
        mainStonlbl.text = @"";
        } else {
            mainStonlbl.text = [NSString stringWithFormat:@"%@",strCurrentCredit];
        }
    
        [self.mileStoneScrollView addSubview:viewCredit];
        [self.mileStoneScrollView addSubview:mainStonlbl];
        boxY = boxY -( boxH + gap);
        mile = [[APPDATA.activity.aryNoOfMileStone objectAtIndex:noOfMileston] intValue];
    }
    UILabel *mainStonlbl1=[[UILabel alloc] initWithFrame: CGRectMake(5, boxY-10, 40, 50)];
    mainStonlbl1.textColor = [UIColor colorWithRed:(27/255.0) green:(48/255.0) blue:(84/255.0) alpha:1];
    [mainStonlbl1 setFont:[UIFont fontWithName:@"OpenSans" size:12]];
    mainStonlbl1.textAlignment=NSTextAlignmentRight;
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setGroupingSeparator:@","];
    [numberFormatter setGroupingSize:3];
    [numberFormatter setNumberStyle:NSNumberFormatterDecimalStyle];
    NSString *strCurrentCredit1 = [numberFormatter stringFromNumber:[NSNumber numberWithInteger:[[APPDATA.activity.aryNoOfMileStone firstObject] integerValue]]];
    mainStonlbl1.text = [NSString stringWithFormat:@"%@",strCurrentCredit1];
    mainStonlbl1.tag = 200 +APPDATA.activity.aryNoOfMileStone.count;
    [self.mileStoneScrollView addSubview:mainStonlbl1];
    for (NSUInteger i = 0 ; i < APPDATA.activity.aryNoOfMileStone.count; i++) {
        UILabel *lbl = [self.mileStoneScrollView viewWithTag:200+i];
        if ([APPDATA.activity.totalMileston isEqualToString:lbl.text])
        {
            lbl.font = [UIFont boldSystemFontOfSize:12];
        }
    }
}
// fill color in milestone box for split in two part so user can assume how much cregit are he/she get and remain credit
- (void) fillColorinMileston:(int)point credit:(int)fullCredit
{
    for (int i = 0 ;i <fullCredit ; i++)
    {
        UIView *view = [self.view viewWithTag:100+i];
        view.backgroundColor = LightBlue_COLOR;
    }
    UIView *viewHalf = [[UIView alloc] init];
    viewHalf.backgroundColor = LightGray_COLOR;
    [viewHalf setFrame:CGRectMake([self.view viewWithTag:99+fullCredit].frame.origin.x, [self.view viewWithTag:99+fullCredit].frame.origin.y, [self.view viewWithTag:99+fullCredit].frame.size.width, (point*[self.view viewWithTag:99+fullCredit].frame.size.height)/100 )];
    [self.mileStoneScrollView addSubview:viewHalf];
    UIView *viewBorder = [[UIView alloc] init];
    viewBorder.backgroundColor = [UIColor colorWithRed:(28.0/255.0) green:(48.0/255.0) blue:(84.0/255.0) alpha:1];
    [viewBorder setFrame:CGRectMake([self.view viewWithTag:99+fullCredit].frame.origin.x, viewHalf.frame.size.height + viewHalf.frame.origin.y, [self.view viewWithTag:99+fullCredit].frame.size.width, 1)];
    [self.mileStoneScrollView addSubview:viewBorder];
   
    [self.lblAchiveCredits setFrame:CGRectMake(self.lblAchiveCredits.frame.origin.x-5,[self.view viewWithTag:100+(fullCredit-1)].frame.origin.y+15, 50, self.lblAchiveCredits.frame.size.height)];
}
// set credit history
- (void) setCreditHistory
{
    int CreditY = 130;
    int noOfCredit;
    if (APPDATA.activity.aryCreditHostory != nil)
        noOfCredit =(int) [APPDATA.activity.aryCreditHostory count];
    else
        noOfCredit = 0;
    if (noOfCredit <= 6) {
        self.btnViewMore.hidden = YES;
    }
    for (int i = 0 ;i< noOfCredit; i++) {
        if (i< 6)
        {
            UILabel *lblCredit = [[UILabel alloc] init];
            if (IS_IPHONE5) {
                  [lblCredit setFrame:CGRectMake(self.view.frame.size.width/2-30, CreditY, 70, 20)];
            }
            else{
                  [lblCredit setFrame:CGRectMake(self.view.frame.size.width/2-20, CreditY, 70, 20)];
            }
            
            lblCredit.textColor = LightBlue_COLOR;
            NSString *str=[NSString stringWithFormat:@"%@",[[[ApplicationData sharedInstance].activity.aryCreditHostory objectAtIndex:i] valueForKey:@"type"]];
            
            if ([[str lowercaseString] isEqualToString:@"credit"])
            {
                lblCredit.text=[NSString stringWithFormat:@"+%@",[[[ApplicationData sharedInstance].activity.aryCreditHostory objectAtIndex:i] valueForKey:@"amount"]];
            }
            else if ([[str lowercaseString] isEqualToString:@"debit"])
            {
                lblCredit.text=[NSString stringWithFormat:@"-%@",[[[ApplicationData sharedInstance].activity.aryCreditHostory objectAtIndex:i] valueForKey:@"amount"]];
            }
            
            lblCredit.font = [UIFont fontWithName:@"OpenSans-SemiBold" size:14];
            lblCredit.textAlignment = NSTextAlignmentRight;
            [self.scrollView addSubview:lblCredit];
            NSString *sectionStr=[NSString stringWithFormat:@"%@",[[[ApplicationData sharedInstance].activity.aryCreditHostory objectAtIndex:i] valueForKey:@"section"]];
            UILabel *lblCred = [[UILabel alloc] init];
            [lblCred setFrame:CGRectMake(lblCredit.frame.origin.x+78, CreditY, 120, 20)];
            lblCred.textAlignment = NSTextAlignmentLeft;
            lblCred.textColor = [UIColor colorWithRed:(28.0/255.0) green:(48.0/255.0) blue:(84.0/255.0) alpha:1];
            NSString *dateStr=[NSString stringWithFormat:@"%@",[[[ApplicationData sharedInstance].activity.aryCreditHostory objectAtIndex:i] valueForKey:@"created_at"]];
            dateStr = [dateStr substringFromIndex:5];
            dateStr=[dateStr substringToIndex:5];
            dateStr=[NSString stringWithFormat:@"%@ %@",sectionStr,dateStr];
            lblCred.text= dateStr;
            lblCred.font = [UIFont fontWithName:@"OpenSans-SemiBold" size:10];
            [self.scrollView addSubview:lblCred];
            CreditY = CreditY +20;
        }
    }
    [self performSelector:@selector(setPastTrans) withObject:self afterDelay:0.5 ];
}

- (void) setCurrentCreditCommas {
}

- (void )didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
// get updated activity detial
- (void) getMyActivityData {
    APPDATA.activity.key = [API_KEY mutableCopy];
    [APPDATA.activity getMyActivity:^(NSDictionary *result, NSString *str, int status) {
        [APPDATA hideLoader];
        if (status == 1) {
        }
        else {
        }
    }];
}
// view detail of the credit history of the activity
- (IBAction)onbtnViewMore:(id)sender
{
    APPDATA.activity.isCreditTransaction=YES;
     APPDATA.activity.isPastTransaction=NO;
    ActiveMoreViewController *objActiveMoreViewController =(ActiveMoreViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"ActiveMoreViewController"];
    [self.parentViewController addChildViewController:objActiveMoreViewController];
    [self.parentViewController.view addSubview:objActiveMoreViewController.view];
    [objActiveMoreViewController didMoveToParentViewController:self];
}

// view transaction in more detail
- (IBAction)btnPastTranViewMore:(id)sender;
{
    APPDATA.activity.isPastTransaction=YES;
     APPDATA.activity.isCreditTransaction=NO;
    ActiveMoreViewController *objActiveMoreViewController =(ActiveMoreViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"ActiveMoreViewController"];
    [self.parentViewController addChildViewController:objActiveMoreViewController];
    [self.parentViewController.view addSubview:objActiveMoreViewController.view];
    [objActiveMoreViewController didMoveToParentViewController:self];
}

- (IBAction)onbtnCancleViewMore:(id)sender {
    _viewMoreView.hidden=YES;
}

#pragma mark table view delegate
-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section
{
    NSLog(@"%@",[ApplicationData sharedInstance].activity.aryCreditHostory);
    return [ApplicationData sharedInstance].activity.aryCreditHostory.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableId=@"viewMoreTVC";
    viewMoreTVC *cell=(viewMoreTVC*)[_tblviewViewMore dequeueReusableCellWithIdentifier:simpleTableId];
    if (cell == nil) {
        cell = [[viewMoreTVC alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableId];
    }
    cell.lblCredits.font = [UIFont fontWithName:@"OpenSans-SemiBold" size:14];
    cell.lblCredits.textColor = LightBlue_COLOR;
    cell.lblCredits.text=[[NSString stringWithFormat:@"%@",[[[ApplicationData sharedInstance].activity.aryCreditHostory objectAtIndex:indexPath.row] valueForKey:@"amount"]] stringByAppendingString:@" Credits"];
    return cell;
}
//  set past transaction
-(void)setPastTrans{

    int noOfPast;
    if (APPDATA.activity.pasttransaction != nil)
        noOfPast =(int) [APPDATA.activity.pasttransaction count];
    else
        noOfPast = 0;
    if (noOfPast <= 6) {
        self.btnPastTranViewMore.hidden = YES;
    }
    _scrollViewPast.contentSize = CGSizeMake(_scrollViewPast.frame.size.width,APPDATA.activity.pasttransaction.count*10);
    int labl=2 ;
    
    for (int i = 0 ;i< noOfPast; i++) {
        if (i< 6)
    {
        UILabel *mainStonlbl1=[[UILabel alloc] initWithFrame: CGRectMake(5,labl ,150,21)];
        mainStonlbl1.textColor = [UIColor colorWithRed:(66.0/255.0) green:(165.0/255.0) blue:(204.0/255.0) alpha:1];
        [mainStonlbl1 setFont:[UIFont fontWithName:@"OpenSans-Bold" size:13]];
        mainStonlbl1.textAlignment=NSTextAlignmentLeft;
        //---------------------------------------------------------------------
        UILabel *dateLabel=[[UILabel alloc] initWithFrame: CGRectMake(30,labl ,150,21)];
        dateLabel.textColor = [UIColor colorWithRed:(27/255.0) green:(48/255.0) blue:(84/255.0) alpha:1];
        [dateLabel setFont:[UIFont fontWithName:@"OpenSans" size:12]];
        NSString *amountStr=[[APPDATA.activity.pasttransaction objectAtIndex:i] objectForKey:@"amount"];
        NSString *created_atStr=[[APPDATA.activity.pasttransaction objectAtIndex:i] objectForKey:@"created_at"];
        NSString *purchasedStr=[[APPDATA.activity.pasttransaction objectAtIndex:i] objectForKey:@"purchased"];
        created_atStr = [created_atStr substringFromIndex:5];
        created_atStr=[created_atStr substringToIndex:5];
        int intpur=[purchasedStr intValue];
        if (intpur==2)
        {
            mainStonlbl1.text=[NSString stringWithFormat:@"%@",amountStr];
            dateLabel.text=[NSString stringWithFormat:@"Cashout   %@",created_atStr];
        }else if(intpur==1){
            mainStonlbl1.text=[NSString stringWithFormat:@"-%@",amountStr];
            dateLabel.text=[NSString stringWithFormat:@"Purchased   %@",created_atStr];
        }else{
            mainStonlbl1.text=[NSString stringWithFormat:@"+%@",amountStr];
            dateLabel.text=[NSString stringWithFormat:@"Sold   %@",created_atStr];
        }
        [_scrollViewPast addSubview:mainStonlbl1];
        [_scrollViewPast addSubview:dateLabel];
        labl=labl+20;
      }
    }
}
// go to cashout view 
- (IBAction)btnCashoutAction:(id)sender {
    CashoutViewController *objCashoutViewController =(CashoutViewController *) [[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"CashoutViewController"];
    [self.parentViewController addChildViewController:objCashoutViewController];
    [self.parentViewController.view addSubview:objCashoutViewController.view];
    [objCashoutViewController didMoveToParentViewController:self];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"hideDropDown" object:nil];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"hideDropDown" object:nil];
}
@end
