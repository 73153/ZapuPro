//
//  cashTableViewCell.h
//  photobug
//
//   on 3/3/16.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface cashTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblSatename;
@end
