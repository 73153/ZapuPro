//
//  MessageViewController.m
//  photobug
//
//   on 11/24/15.
//  Copyright © Photobug. All rights reserved.
//

#import "MessageViewController.h"
#import "APICall.h"
#import "Users.h"
#import "MyActivity.h"
#import "Constant.h"
#import "ApplicationData.h"
#import "FeedViewController.h"
#import "MyDashboardViewController.h"
#import "IQKeyboardManager.h"
#import "IQKeyboardManagerConstants.h"
#import "IQKeyboardReturnKeyHandler.h"
#import "IQUIView+IQKeyboardToolbar.h"
@interface MessageViewController ()
{
    FeedViewController *objFeedViewController;
}
@end

@implementation MessageViewController
@synthesize messageProid;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _txtMessageView.placeholder = @"Write a Post";
    _txtMessageView.textColor = [UIColor blackColor];
     [_txtMessageView setFont:[UIFont fontWithName:@"OpenSans" size:12]];
    _lblUserName.text = [NSString stringWithFormat: @"YOU (%@) NOW",APPDATA.user.username];
    [[IQKeyboardManager sharedManager] setEnable:YES];
    [[IQKeyboardManager sharedManager] setEnableAutoToolbar:YES];
    [[_btnPost layer] setBorderWidth:1.0f];
    [[_btnPost layer] setCornerRadius:2.0f];
    [[_btnPost layer] setBorderColor:[UIColor colorWithRed:50.0/255.0 green:198.0/255.0 blue:244.0/255.0 alpha:1.0].CGColor];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (UIViewController *)parentViewController2 {
    UIResponder *responder = self;
    while ([responder isKindOfClass:[UIView class]])
        responder = [responder nextResponder];
    return (UIViewController *)responder;
}

#pragma mark Add message Methdo
-(void)addmessageMethd{
    [APPDATA showLoader];
    void (^successed)(id responseObject) = ^(id responseObject)
        {
             [APPDATA hideLoader];
            [(MyDashboardViewController *)[[self.view superview] nextResponder] reloadFeedVCData];
            [APPDATA ShowAlertWithTitle:@"" Message:@"Message successfully posted."];
           [self.view removeFromSuperview];
    };
    void (^failure)(NSError * error) = ^(NSError *error) {
         [APPDATA hideLoader];
    };
    if ([_txtMessageView.text length]<1 || [_txtMessageView.text isEqualToString:@"Write a Post"])
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:ERROR_COMMENT
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
    }else{
        //1 log
        NSString  *strDeviceToken=[[NSUserDefaults standardUserDefaults] objectForKey:@"strDeviceToken"];
        
        if ([strDeviceToken isKindOfClass:[NSNull class]] || strDeviceToken == nil || [strDeviceToken isEqualToString:@""])
        {
            strDeviceToken=nil;
            
        }
        //messageProid
        NSDictionary *dict = @{@"key":API_KEY,@"feed_type":@"message",@"message":_txtMessageView.text,@"other_profile_id":appDelegate.profilid_AppStr,@"profile_id":APPDATA.user.strOtherId,@"method":API_ADD_POST
                               };
        [APICall sendToService:dict success:successed failure:failure];
    }
}

- (IBAction)postMessaggeAction:(id)sender {
    if ([_txtMessageView.text length]<1 || [_txtMessageView.text isEqualToString:@"Write a Post"])
    {
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@""
                                                        message:ERROR_COMMENT
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
    }else{
        [self addmessageMethd];
    }
}

- (IBAction)closeButtonAction:(id)sender {
     [self.view removeFromSuperview];
}

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    
    [self.view removeFromSuperview];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

@end
