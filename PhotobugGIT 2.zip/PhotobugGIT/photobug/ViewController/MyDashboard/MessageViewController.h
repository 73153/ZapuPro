//
//  MessageViewController.h
//  photobug
//
//   on 11/24/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIPlaceHolderTextView.h"
@interface MessageViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIPlaceHolderTextView *txtMessageView;
@property(strong ,nonatomic)NSString *messageProid;
@property (nonatomic,strong) IBOutlet UILabel *lblUserName;
@property (weak, nonatomic) IBOutlet UIButton *btnPost;

- (IBAction)postMessaggeAction:(id)sender;
- (IBAction)closeButtonAction:(id)sender;
@end
