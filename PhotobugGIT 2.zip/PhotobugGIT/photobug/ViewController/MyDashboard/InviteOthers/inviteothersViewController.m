//
//  inviteothersViewController.m
//  photobug
//
//   on 12/17/15.
//  Copyright © Photobug. All rights reserved.
//

#import "inviteothersViewController.h"
#import "ApplicationData.h"
#import "Constant.h"
#import <Social/Social.h>
#import "LoginViewController.h"
#import "Users.h"
#import <MBProgressHUD.h>
#import "DashboardViewController.h"
#import "ImportPhotosViewController.h"
#import "ApplicationData.h"
#import "APICall.h"
#import "IQKeyboardManager.h"
#import "IQKeyboardManagerConstants.h"
#import "IQKeyboardReturnKeyHandler.h"
#import "IQUIView+IQKeyboardToolbar.h"
#import "APICall.h"
@interface inviteothersViewController ()<GPPSignInDelegate>

{
    NSString *str;
}
@property (nonatomic, strong) NSMutableArray *copyableLabels;
@end

@implementation inviteothersViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _txtMessageView.placeholder = @"Write a email address";
    _txtMessageView.textColor = [UIColor blackColor];
    [_viewMessage.layer setCornerRadius:3.0f];
    // border
    [_viewMessage.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [_viewMessage.layer setBorderWidth:0.5f];
      // drop shadow
    [_viewMessage.layer setShadowColor:[UIColor blackColor].CGColor];
    [_viewMessage.layer setShadowOpacity:0.8];
    [_viewMessage.layer setShadowRadius:3.0];
    [_viewMessage.layer setShadowOffset:CGSizeMake(2.0, 2.0)];
    
    UITapGestureRecognizer *singleTap =  [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapping)];
    [singleTap setNumberOfTapsRequired:1];
    [self.imgGBView addGestureRecognizer:singleTap];
    [self.view addSubview:self.imgGBView];
    [self.view bringSubviewToFront:_viewMessage];
    str=UDGetObject(@"invite_url");
    [self.customTextLabel setCustomString:str];
    [self.customTextLabel setText:str];
    for (UIView *subview in self.view.subviews) {
        if (subview.class == [TCCopyableLabel class])
        {
            [(TCCopyableLabel *)subview setDelegate:self];
            [self.copyableLabels addObject:subview];
        }
    }
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//Call method when sent email succeswsfully
-(void)addmessageMethd{
    
    [APPDATA showLoader];
    
    void (^successed)(id responseObject) = ^(id responseObject)
    {
        int error=[[responseObject objectForKey:@"error"]intValue];
        if (error == 1) {
           [APPDATA ShowAlertWithTitle:@"" Message:ERROR_EMAIL];
        }else{
            [APPDATA ShowAlertWithTitle:@"" Message:@"Invitation successfully send."];
            [self.view removeFromSuperview];
        }
        [APPDATA hideLoader];
    };
    void (^failure)(NSError * error) = ^(NSError *error) {
        [APPDATA hideLoader];
    };
    NSString *emailStr=[NSString stringWithFormat:@"%@",_txtMessageView.text];
    NSArray *parameters = @[emailStr];
    NSDictionary *dict = @{@"key":API_KEY,@"email":parameters,@"message":@"Hi",@"invited_by":APPDATA.user.profileid,@"method":API_USER_INVITE,@"invite_type":@"email",@"social_id":@" "
                           };
    _txtMessageView.text=@"";
    [APICall sendToService:dict success:successed failure:failure];
}


//Action perform for invite
- (IBAction)inv:(id)sender {
    if(![Validations checkMinLength:self.txtMessageView.text withLimit:2 ])
    {
         [APPDATA ShowAlertWithTitle:@"" Message:ERROR_EMAIL];
        [APPDATA hideLoader];
    }else{
        [self addmessageMethd];
    }
}
//On tap anywhere superview remove from superclass
- (void) singleTapping {
    [self.view removeFromSuperview];
}
//On close button action superview remove from superclass
- (IBAction)btnClossAction:(id)sender {
     [self.view removeFromSuperview];
}
//On facebook button action call this method for invite or post URL on facebook
- (IBAction)btnFacebookAction:(id)sender {
        if ([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook])
        {
            NSString* facebookText =str;
            SLComposeViewController *fbPostSheet = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
    
            [fbPostSheet setInitialText:facebookText];
    
            [fbPostSheet setCompletionHandler:^(SLComposeViewControllerResult result)
             {
                 if (result == SLComposeViewControllerResultCancelled)
                 {
                     [APPDATA hideLoader];
    
                     NSLog(@"The user cancelled.");
                 }
                 else if (result == SLComposeViewControllerResultDone)
                 {
    
                     UIAlertView *alertView = [[UIAlertView alloc]
                                               initWithTitle:@""
                                               message:POST_SUBMIT
                                               delegate:self
                                               cancelButtonTitle:@"OK"
                                               otherButtonTitles:nil];
    
                     NSLog(@"The user posted to Facebook");
    
                     [alertView show];
    
                     
                      [self.view removeFromSuperview];
                      [APPDATA hideLoader];
    
                 }
             }];
    
            [APPDATA hideLoader];
            [self presentViewController:fbPostSheet animated:YES completion:nil];
        }
        else{
            UIAlertView *alertView = [[UIAlertView alloc]
                                      initWithTitle:@"Unable to Connect to Facebook"
                                      message:@"Make sure your device has an internet connection and you have your Facebook account setup in the Settings App"
                                      delegate:self
                                      cancelButtonTitle:@"OK"
                                      otherButtonTitles:nil];
            [alertView show];
        }
}

//On twitter button action call this method and sharing in twitter
- (IBAction)btnTwiAction:(id)sender {
    if ([SLComposeViewController isAvailableForServiceType:SLServiceTypeTwitter])
    {
        NSString* facebookText =str;
        SLComposeViewController *fbPostSheet = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeTwitter];
        
        [fbPostSheet setInitialText:facebookText];
        [fbPostSheet setCompletionHandler:^(SLComposeViewControllerResult result)
         {
             if (result == SLComposeViewControllerResultCancelled)
             {
                 [APPDATA hideLoader];
                 
                 NSLog(@"The user cancelled.");
             }
             else if (result == SLComposeViewControllerResultDone)
             {
                 
                 UIAlertView *alertView = [[UIAlertView alloc]
                                           initWithTitle:@""
                                           message:POST_SUBMIT
                                           delegate:self
                                           cancelButtonTitle:@"OK"
                                           otherButtonTitles:nil];
                 [alertView show];
                   [self.view removeFromSuperview];
                 [APPDATA hideLoader];
                 
             }
         }];
        
        [APPDATA hideLoader];
        [self presentViewController:fbPostSheet animated:YES completion:nil];
    }
    else{
        UIAlertView *alertView = [[UIAlertView alloc]
                                  initWithTitle:@"Unable to Connect to Twitter"
                                  message:@"Make sure your device has an internet connection and you have your Twitter account setup in the Settings App"
                                  delegate:self
                                  cancelButtonTitle:@"OK"
                                  otherButtonTitles:nil];
        [alertView show];
    }
    
    

}
//on google button action call this method or sharing on google
-(IBAction)btnGoogleAction:(id)sender{
    
    
    self.app.social.socialType = socialTypeGoogle;
   
    
    if ([[GPPSignIn sharedInstance] authentication])
    {
         [self googleShare];
        
       
    } else
    {
        
        GPPSignIn *signIn = [GPPSignIn sharedInstance];
        signIn.shouldFetchGooglePlusUser = YES;
        
        signIn.clientID = @"810590258442-liiba31iben4932pmdknm1eb0ko757uh.apps.googleusercontent.com";
        
        signIn.actions = [NSArray arrayWithObjects:
                                              @"http://schemas.google.com/AddActivity",
                                              @"http://schemas.google.com/BuyActivity",
                                              @"http://schemas.google.com/CheckInActivity",
                                              @"http://schemas.google.com/CommentActivity",
                                              @"http://schemas.google.com/CreateActivity",
                                              @"http://schemas.google.com/ListenActivity",
                                              @"http://schemas.google.com/ReserveActivity",
                                              @"http://schemas.google.com/ReviewActivity",
                                              nil];
        
       
         signIn.scopes = @[ kGTLAuthScopePlusLogin,kGTLAuthScopePlusLogin,kGTLAuthScopePlusUserinfoEmail, @"profile",@"email" ];
        
      
        signIn.delegate = self;
        
        [signIn authenticate];
        
       
    }
   
    
    
}
//Finished With authentication

- (void)finishedWithAuth: (GTMOAuth2Authentication *)auth
                   error: (NSError *) error {
    if(error)
    {
        GPPSignIn *signIn = [GPPSignIn sharedInstance];
        signIn.shouldFetchGooglePlusUser = YES;
        
        signIn.clientID = @"810590258442-liiba31iben4932pmdknm1eb0ko757uh.apps.googleusercontent.com";
        
        signIn.actions = [NSArray arrayWithObjects:
                          @"http://schemas.google.com/AddActivity",
                          @"http://schemas.google.com/BuyActivity",
                          @"http://schemas.google.com/CheckInActivity",
                          @"http://schemas.google.com/CommentActivity",
                          @"http://schemas.google.com/CreateActivity",
                          @"http://schemas.google.com/ListenActivity",
                          @"http://schemas.google.com/ReserveActivity",
                          @"http://schemas.google.com/ReviewActivity",
                          nil];
        
        
        signIn.scopes = @[ kGTLAuthScopePlusUserinfoEmail, kGTLAuthScopePlusLogin, @"profile",@"email" ];
        signIn.delegate = self;
        [signIn authenticate];
    }
    else{
         [self googleShare];
    }
}
//after post on google log out from google this action button perform
-(void)logoutGoogle{
    [[GPPSignIn sharedInstance] signOut];
}
//Is google login or not checked in call this method
-(BOOL)isGoogleLoggedIn
{
    if ([[GPPSignIn sharedInstance] authentication]) {
        // The user is signed in.
        return YES;
        // Perform other actions here, such as showing a sign-out button
    } else {
        return  NO;
        // Perform other actions here
    }
}

//For post on google plus
-(void)postToGooglePlus{
    id<GPPNativeShareBuilder> shareBuilder = [[GPPShare sharedInstance] nativeShareDialog];
    [shareBuilder open];
}
//Get people list from google plus
-(void)peopleListGooglePlus:(google_completion_block) completion{
    GTLServicePlus* plusService = [[GTLServicePlus alloc] init ];
    plusService.retryEnabled = YES;
    [plusService setAuthorizer:[[GPPSignIn sharedInstance] authentication]];
    
    GTLQueryPlus *query =
    [GTLQueryPlus queryForPeopleListWithUserId:@"me"
                                    collection:kGTLPlusCollectionVisible];
    [plusService executeQuery:query
            completionHandler:^(GTLServiceTicket *ticket,
                                GTLPlusPeopleFeed *peopleFeed,
                                NSError *error) {
                if (error) {
                    GTMLoggerError(@"Error: %@", error);
                    if(completion)
                    {
                        completion(@"",error,@"Error Getting People List",-1);
                    }
                } else {
                    // Get an array of people from GTLPlusPeopleFeed
                    NSArray* peopleList = peopleFeed.items;
                    if(completion)
                    {
                        completion(peopleList,nil,@"Getting People List Success",1);
                    }
                }
            }];
}

//sharing on google
-(void)googleShare{
    id<GPPNativeShareBuilder> shareBuilder = [[GPPShare sharedInstance] nativeShareDialog];
    // This line will fill out the title, description, and thumbnail from
    // the URL that you are sharing and includes a link to that URL.
    [shareBuilder setURLToShare:[NSURL URLWithString:str]];
    NSString *strSetText = [NSString stringWithFormat:@"PhotoBug \n %@" ,str];
    [shareBuilder setPrefillText:strSetText];
    
    [shareBuilder open];
}

#pragma mark - TCCopyableLabelDelegate

- (void)label:(TCCopyableLabel *)copyableLabel didCopyText:(NSString *)copiedText
{
 
}
@end
