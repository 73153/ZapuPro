//
//  inviteothersViewController.h
//  photobug
//
//   on 12/17/15.
//  Copyright © Photobug. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FBSDKShareKit/FBSDKShareKit.h>
#import <MessageUI/MessageUI.h>
#import "UIPlaceHolderTextView.h"
#import "AppDelegate.h"
#import "TCCopyableLabel.h"
#import <GooglePlus/GooglePlus.h>
@interface inviteothersViewController : UIViewController<MFMailComposeViewControllerDelegate,TCCopyableLabelDelegate>
@property (strong, nonatomic) IBOutlet UITextField *txtemailid;
@property (strong, nonatomic) IBOutlet UIPlaceHolderTextView *txtMessageView;
@property (strong, nonatomic) IBOutlet UIView *viewMessage;
@property (nonatomic,strong) IBOutlet UIImageView *imgGBView;
@property (strong,nonatomic) AppDelegate *app;
@property (strong, nonatomic) IBOutlet UIPlaceHolderTextView *txtView;
@property (weak, nonatomic) IBOutlet TCCopyableLabel *customTextLabel;

- (IBAction)btnClossAction:(id)sender;
- (IBAction)btnFacebookAction:(id)sender;
- (IBAction)btnTwiAction:(id)sender;
- (IBAction)btnGoogleAction:(id)sender;

@end
