//
//  ViewController.h
//  photobug
//
//  Created by Bhushan on 11/2/15.
//  Copyright © 2015 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)menu_button_action:(id)sender;

@end

