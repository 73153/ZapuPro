//
//  ViewController.m
//  photobug
//
//  Created by Bhushan on 11/2/15.
//  Copyright © 2015 com.zaptechsolution. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)menu_button_action:(id)sender {
}
@end
