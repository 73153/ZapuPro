//
//  CalDetailsViewController.m
//  PrEP
//
//  Created by Bhushan on 5/23/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "CalDetailsViewController.h"

#import "DataBase.h"
@interface CalDetailsViewController ()
{
    DataBase *dbh;
}

@end

@implementation CalDetailsViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    dbh=[[DataBase alloc]init];
    
    SelMutableArray=[dbh Appointment_cal_info:appDelegate.Cal_dateStr];
    
    
    for (int i=0; i<[SelMutableArray count]; i++)
    {
        
        appDelegate.Title_App_Str=[[SelMutableArray objectAtIndex:0]objectForKey:@"TITLE"];
        appDelegate.Cal_dateStr=[[SelMutableArray objectAtIndex:0]objectForKey:@"DATE"];
        appDelegate.Cal_DescStr=[[SelMutableArray objectAtIndex:0]objectForKey:@"DESC"];

        
    }
    
    if ([SelMutableArray count] <1)
    {
        _date_label.hidden=YES;
        _tilte_name_button.hidden=YES;
        
    }else
    {
        _date_label.text=appDelegate.Cal_dateStr;
        
        [_tilte_name_button setTitle:appDelegate.Title_App_Str forState:UIControlStateNormal];
        
    }
    
    
    
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)back_button_action:(id)sender
{
    
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)edit_to_appointment_button_action:(id)sender
{
    EditAppointmentViewViewController *objEditAppointmentViewViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"EditAppointmentViewViewController"];
    
    [self.navigationController pushViewController:objEditAppointmentViewViewController animated:YES];
    
    
}
@end
