//
//  CalDetailsViewController.h
//  PrEP
//
//  Created by Bhushan on 5/23/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "ViewController.h"

@interface CalDetailsViewController : ViewController
{
    NSMutableArray *SelMutableArray;
}



- (IBAction)back_button_action:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *tilte_name_button;

@property (strong, nonatomic) IBOutlet UILabel *date_label;

- (IBAction)edit_to_appointment_button_action:(id)sender;

@end
