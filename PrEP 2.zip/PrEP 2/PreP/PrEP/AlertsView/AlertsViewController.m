//
//  AlertsViewController.m
//  PrEP
//
//  Created by Bhushan on 5/11/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "AlertsViewController.h"
#import "DataBase.h"

@interface AlertsViewController ()
{
    DataBase *dhb;
}

@end

@implementation AlertsViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    dhb=[[DataBase alloc]init];
    
    
    
    
    
    
    [_View1.layer setCornerRadius:5.0f];
    
    // border
    [_View1.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [_View1.layer setBorderWidth:1.5f];
    
    // drop shadow
    [_View1.layer setShadowColor:[UIColor blackColor].CGColor];
    [_View1.layer setShadowOpacity:0.8];
    [_View1.layer setShadowRadius:3.0];
    [_View1.layer setShadowOffset:CGSizeMake(2.0, 2.0)];
    
//--------------------------------------------------------------------------------------------------------------------
    
    [_view2.layer setCornerRadius:5.0f];
    
    // border
    [_view2.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [_view2.layer setBorderWidth:1.5f];
    
    // drop shadow
    [_view2.layer setShadowColor:[UIColor blackColor].CGColor];
    [_view2.layer setShadowOpacity:0.8];
    [_view2.layer setShadowRadius:3.0];
    [_view2.layer setShadowOffset:CGSizeMake(2.0, 2.0)];
    
//--------------------------------------------------------------------------------------------------------------------
    
    [_alerts_view.layer setCornerRadius:5.0f];
    
    // border
    [_alerts_view.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [_view2.layer setBorderWidth:1.5f];
    
    // drop shadow
    [_alerts_view.layer setShadowColor:[UIColor blackColor].CGColor];
    [_alerts_view.layer setShadowOpacity:0.8];
    [_alerts_view.layer setShadowRadius:3.0];
    [_alerts_view.layer setShadowOffset:CGSizeMake(2.0, 2.0)];
    
    
 //--------------------------------------------------------------------------------------------------------------------
    
    
    if ([appDelegate.AltertStr isEqualToString:@"Alerts Set By User"])
    {
         SlectAllAlerts=[dhb Select_All_Alerts:@"1"];
        
        _alerts_lable.text=@"Alerts Set By User";
        
    
    }else if ([appDelegate.AltertStr isEqualToString:@"Medical Alerts"])
    {
         SlectAllAlerts=[dhb Select_All_Alerts:@"2"];
         _alerts_lable.text=@"Medical Alerts";
        
        
        
    }else
    {
         SlectAllAlerts=[dhb Select_All_Alerts:@"3"];
         _alerts_lable.text=@"Normal Alerts";
        
        
    }
    
    
    AlertsArray=[[NSMutableArray alloc]init];
    
    
    for (int i=0; i<[SlectAllAlerts count]; i++)
    {
        [AlertsArray addObject:[[SlectAllAlerts objectAtIndex:i]objectForKey:@"ALERTMSG"]];
        
    }
    NSLog( @"%@",SlectAllAlerts);
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)back_button_action:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)alter_ok_button_action:(id)sender
{
    _alerts_view.hidden=YES;
}



#pragma mark UITableViewDelegate Protocol Methods-----------------------------------



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    
    return [AlertsArray count];
    
    
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath

{
    
    return 30;
    
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath

{
    
    
    static NSString *simpleTableIdentifier = @"AlertsTableViewCell";
    
    AlertsTableViewCell *cell = (AlertsTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"AlertsTableViewCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    //App_Comp
    
    
   
        cell.alerts_label.textColor=[UIColor grayColor];
  
    
    
    NSString *Ind=[NSString stringWithFormat:@"%d",(int)indexPath.row+1];
    
    cell.alerts_label.text=[NSString stringWithFormat:@"%@ %@",Ind,[AlertsArray objectAtIndex:indexPath.row]];
    
   
    
    
    
    return cell;
    
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    _alerts_view.hidden=NO;
    
    _alter_lable.text=[AlertsArray objectAtIndex:indexPath.row];
    
    
    
    
}


- (IBAction)noti_tab_button_action:(id)sender
{
    NotificationViewController *objNotificationViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"NotificationViewController"];
    
    
    [self.navigationController pushViewController:objNotificationViewController animated:YES];
    
}

- (IBAction)task_tab_button_action:(id)sender
{
    AppointmentViewController *objAppointmentViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"AppointmentViewController"];
    
    
    [self.navigationController pushViewController:objAppointmentViewController animated:YES];
    
}

- (IBAction)cal_tab_button_action:(id)sender
{
    CalViewController *objCalViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"CalViewController"];
    
    
    [self.navigationController pushViewController:objCalViewController animated:YES];
}
- (IBAction)setting_tab_button_action:(id)sender
{
    SettingViewController *objSettingViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"SettingViewController"];
    
    
    [self.navigationController pushViewController:objSettingViewController animated:YES];
}


@end
