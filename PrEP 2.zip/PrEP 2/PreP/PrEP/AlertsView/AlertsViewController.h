//
//  AlertsViewController.h
//  PrEP
//
//  Created by Bhushan on 5/11/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlertsViewController : UIViewController
{
    NSArray * SlectAllAlerts;
    NSMutableArray *AlertsArray;
}

@property (strong, nonatomic) IBOutlet UIView *View1;
@property (strong, nonatomic) IBOutlet UIView *view2;
@property (strong, nonatomic) IBOutlet UILabel *alerts_lable;

@property (strong, nonatomic) IBOutlet UITableView *alerts_tableview;
@property (strong, nonatomic) IBOutlet UILabel *alter_lable;
@property (strong, nonatomic) IBOutlet UIView *alerts_view;




- (IBAction)back_button_action:(id)sender;
- (IBAction)alter_ok_button_action:(id)sender;


- (IBAction)noti_tab_button_action:(id)sender;

- (IBAction)task_tab_button_action:(id)sender;

- (IBAction)cal_tab_button_action:(id)sender;

- (IBAction)setting_tab_button_action:(id)sender;


@end
