//
//  AddNewTaskViewController.m
//  PrEP
//
//  Created by Bhushan on 5/14/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "AddNewTaskViewController.h"
#import "viewTaskViewController.h"
#import "TaskConfirmViewController.h"
#import "viewTaskViewController.h"
#import "SettingViewController.h"
#import "DashBoardViewController.h"
#import "NotificationViewController.h"
#import "AppointmentViewController.h"
#import "CalViewController.h"

#define IS_IPHONE5 (([[UIScreen mainScreen] bounds].size.height-568)?NO:YES)

@interface AddNewTaskViewController ()

@end

@implementation AddNewTaskViewController

- (void)viewDidLoad
{
    
    [super viewDidLoad];
    
      AppDel=[[UIApplication sharedApplication] delegate];
    
   Array=[[NSMutableArray alloc]init];
    
    
    _title_text.layer.cornerRadius=2.0f;
    _title_text.layer.masksToBounds=YES;
    _title_text.layer.borderColor=[[UIColor grayColor]CGColor];
    _title_text.layer.borderWidth= 2.5f;
    _title_text.backgroundColor=[UIColor clearColor];
    
    
    _desc_text.layer.cornerRadius=2.0f;
    _desc_text.layer.masksToBounds=YES;
    _desc_text.layer.borderColor=[[UIColor grayColor]CGColor];
    _desc_text.layer.borderWidth= 2.5f;
    _desc_text.backgroundColor=[UIColor clearColor];
    
    
    _date_text.layer.cornerRadius=2.0f;
    _date_text.layer.masksToBounds=YES;
    _date_text.layer.borderColor=[[UIColor grayColor]CGColor];
    _date_text.layer.borderWidth= 2.5f;
    _date_text.backgroundColor=[UIColor clearColor];
    
    
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)save_button_action:(id)sender
{
    
    NSString *rawString = [_title_text text];
    NSCharacterSet *whitespace = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed = [rawString stringByTrimmingCharactersInSet:whitespace];
    
    NSString *rawString1 = [_desc_text text];
    NSCharacterSet *whitespace1 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed1 = [rawString1 stringByTrimmingCharactersInSet:whitespace1];
    
    NSString *rawString2 = [_date_text text];
    NSCharacterSet *whitespace2 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed2 = [rawString2 stringByTrimmingCharactersInSet:whitespace2];
    
    
    
    if([trimmed length] == 0)
    {
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"PrEP" message:@"Title Empty" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        
        
        
    }else if ([trimmed1 length] == 0)
    {
       
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"PrEP" message:@"Descripation Empty" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        
        
    }else if ([trimmed2 length]== 0)
    {
        
        
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"PrEP" message:@"Date Empty" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        
        
    }else
    {
        NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
        
        
        
      //  CREATE TABLE "TASK_LIST" ("TASK_NAME" VARCHAR DEFAULT (null) ,"TASK_DESCRIPTION" VARCHAR,"APPOITMENT_ID" INTEGER,"USER_ID" INTEGER,"TASK _DATE" DATETIME, "TIME" VARCHAR, "ISCOMPLETED" INTEGER)
        
        
        [dic setObject:_title_text.text forKey:@"TASK_NAME"];
        
        [dic setObject:_desc_text.text forKey:@"TASK_DESCRIPTION"];
        
         [dic setObject:AppDel.Sele_ID_viewApp_Str forKey:@"APPOITMENT_ID"];
        
         [dic setObject:AppDel.Sele_ID_viewApp_Str forKey:@"USER_ID"];
        
        [dic setObject:_date_text.text forKey:@"TASK _DATE"];
        
        [dic setObject:timeStr forKey:@"TIME"];
        
        [dic setObject:@"1" forKey:@"ISCOMPLETED"];
        
        
        
        
       
        
        [Array addObject:dic];
        
        
        if ([Array count]>0)
        {
            [dbh insertTask:Array];
            
        }
        
        
        
        viewTaskViewController *objviewTaskViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"viewTaskViewController"];
        
        
        [self.navigationController pushViewController:objviewTaskViewController animated:NO];
        
    }
    
    
    
}

- (IBAction)date_cancel_button_action:(id)sender
{
    
    _date_view.hidden=YES;
    
     CGPoint point = CGPointMake(0,0);
    [_scroll_view setContentOffset:point animated:YES] ;
    
}

- (IBAction)date_done_action:(id)sender
{
    NSDate *date = [_date_picker date];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"dd-MM-yyyy"];
    
    _date_text.text = [dateFormat stringFromDate:date];
    
   
    
    NSDateFormatter *dateFormat1 = [[NSDateFormatter alloc] init];
    [dateFormat1 setDateFormat:@"HH:mm:ss"];
     timeStr=[dateFormat1 stringFromDate:date];
    
    _date_view.hidden=YES;
    
    CGPoint point = CGPointMake(0,0);
    
    [_scroll_view setContentOffset:point animated:YES] ;
    
}

- (IBAction)back_button_action:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark textViewDidBeginEditing-----------------------------------------------------

static NSInteger stepRange1[] = {
    
    0,0,90,150
};



static NSInteger getScrollPos21(NSInteger i) {
    
    if (i < 1 || i > 3)
        return 0 ;
    return stepRange1[i] ;
}

static NSInteger stepRange[] = {
    
    0,0,90,150
};



static NSInteger getScrollPos2(NSInteger i) {
    
    if (i < 1 || i > 3)
        return 0 ;
    return stepRange[i] ;
}


- (void)textViewDidBeginEditing:(UITextView *)textView
{
    
    
    _scroll_view.scrollEnabled = YES;
    CGPoint point = CGPointMake(0,700);
    [_scroll_view setContentOffset:point animated:YES] ;
    
}

- (void) textFieldDidBeginEditing:(UITextField *)textField
{
    
    if (textField.tag==3)
    {
        _date_view.hidden=NO;
        
        [textField resignFirstResponder];
        [_title_text resignFirstResponder];
        
        [_desc_text resignFirstResponder];
        [_date_text resignFirstResponder];
        
        CGPoint point;
        
        point = CGPointMake(0, getScrollPos21(textField.tag));
        [_scroll_view setContentOffset:point animated:YES] ;
        
        
    }
    else
    {
        
        
        _scroll_view.scrollEnabled = YES;
        
        
        CGPoint point;
        
        if (IS_IPHONE5)
            point = CGPointMake(0, getScrollPos21(textField.tag));
        else
            point = CGPointMake(0, getScrollPos2(textField.tag));
        
        
        [_scroll_view setContentOffset:point animated:YES] ;
        
    }
    
    
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField.tag==3)
    {
        
        _date_view.hidden=NO;
        
        [textField resignFirstResponder];
        [_title_text resignFirstResponder];
        
        [_desc_text resignFirstResponder];
        [_date_text resignFirstResponder];
        
        CGPoint point;
        
        point = CGPointMake(0, getScrollPos21(textField.tag));
        [_scroll_view setContentOffset:point animated:YES] ;
        
        return NO;
    }else
    {
        return YES;
    }
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    _scroll_view.scrollEnabled = YES;
    
    
    
    NSInteger nextTag = textField.tag + 1;
    UIResponder* nextResponder = [textField.superview viewWithTag:nextTag];
    
    if (nextResponder)
    {
        if (nextTag==3)
        {
            
            _date_view.hidden=NO;
            
            CGPoint point = CGPointMake(0, getScrollPos2(nextTag));
            [_scroll_view setContentOffset:point animated:YES];
            
            [_title_text resignFirstResponder];
            
            [_desc_text resignFirstResponder];
            [_date_view resignFirstResponder];
            
            [textField resignFirstResponder];
        }
        else{
            
            [nextResponder becomeFirstResponder];
            CGPoint point = CGPointMake(0, getScrollPos2(nextTag));
            [_scroll_view setContentOffset:point animated:YES];
        }
        
    }
    else
    {
        CGPoint point = CGPointMake(0,64);
        [_scroll_view setContentOffset:point animated:YES] ;
        [textField resignFirstResponder];
        
        
        
        
    }
    
    return YES;
}

- (IBAction)dash_tab_button_action:(id)sender
{
    
    DashBoardViewController *objDashBoardViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    [self.navigationController pushViewController:objDashBoardViewController animated:YES];
    
}

- (IBAction)noti_tab_button_action:(id)sender
{
    NotificationViewController *objNotificationViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"NotificationViewController"];
    
    [self.navigationController pushViewController:objNotificationViewController animated:YES];
}



- (IBAction)cal_tab_button_action:(id)sender
{
    CalViewController *objCalViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"CalViewController"];
    
    [self.navigationController pushViewController:objCalViewController animated:YES];
    
}

- (IBAction)setting_tab_button_action:(id)sender
{
    SettingViewController *objSettingViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"SettingViewController"];
    
    [self.navigationController pushViewController:objSettingViewController animated:YES];
}


@end
