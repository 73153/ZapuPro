//
//  ViewController.h
//  PrEP
//
//  Created by Bhushan on 5/1/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "SteupViewController.h"
#import "DataBase.h"


@interface ViewController : UIViewController
{
    BOOL PinviewFlage;
    
    DataBase *dbh;
    NSArray *UserDateArray;
    NSString *PinStr;
    NSString *newStringPin;
    
}

@property (weak, nonatomic) IBOutlet UIButton *about_button;

@property (weak, nonatomic) IBOutlet UIButton *points_button;

@property (weak, nonatomic) IBOutlet UIButton *setup_button;

@property (weak, nonatomic) IBOutlet UIView *enter_pin_view;

@property (weak, nonatomic) IBOutlet UITextField *pin_text_field;





- (IBAction)go_button_action:(id)sender;

- (IBAction)Edit_button_action:(id)sender;

- (IBAction)about_button_Action:(id)sender;

- (IBAction)point_button_action:(id)sender;

- (IBAction)Setup_button_Action:(id)sender;

- (IBAction)process_button_Active:(id)sender;


@end

