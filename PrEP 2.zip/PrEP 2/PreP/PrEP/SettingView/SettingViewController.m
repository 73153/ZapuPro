//
//  SettingViewController.m
//  PrEP
//
//  Created by Bhushan on 5/15/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "SettingViewController.h"
#import "DashBoardViewController.h"
#import "NotificationViewController.h"
#import "AppointmentViewController.h"
#import "CalViewController.h"
#import "DataBase.h"
#import "SteupViewController.h"
@interface SettingViewController ()
{
    DataBase *dbh;
    NSMutableArray *UserArray;
}

@end

@implementation SettingViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    dbh=[[DataBase alloc]init];
    
    
    
    
    [_update_pill_button initWithBorders];
    
    [_update_pill_button initWithBorders];
    [_update_pill_button initWithBorders];
    [_medicine_reminders_button initWithBorders];
    [_task_reminder_button initWithBorders];
    [_appointment_rem_button initWithBorders];
    
    [_update_date_button initWithBorders];
    
    [_update_date_button initWithBorders];
    
    [_pill_setting_button initWithBorders];
    
    [_reports_button initWithBorders];
    
    
    //report view....
    
    [_rep_ove_app_button initWithBorders];
    [_rep_com_app_button initWithBorders];
    [_rep_hiv_button initWithBorders];
    [_rep_med_button initWithBorders];
    
    
    
    UserArray=[[NSMutableArray alloc]init];
    
    UserArray=[dbh selectAllUser];
    
    
    [self.edit_date_view setHidden:YES];
    [self.report_view setHidden:YES];
    [self.pin_view setHidden:YES];
    [self.update_date_editdate_view setHidden:YES];
    [self.date_pickview setHidden:YES];
    
    [_report_overdue_view setHidden:YES];
    [_report_completed_view setHidden:YES];
    [_report_hiv_tests_view setHidden:YES];
    [_report_medication_view setHidden:YES];
    [_medicine_reminder_view setHidden:YES];
  
    
    
    if ([UserArray count]>0)
    {
        
        DateStr=[[UserArray objectAtIndex:0] objectForKey:@"STARTDATE"];
        
        PinNewStr=[[UserArray objectAtIndex:0] objectForKey:@"PIN"];
        
        titleStr=[[UserArray objectAtIndex:0] objectForKey:@"NAME"];
        
        Pill_TIME=[[UserArray objectAtIndex:0] objectForKey:@"PILLTIME"];
        
        PillCountStr=[[UserArray objectAtIndex:0] objectForKey:@"PILLCOUNT"];
        
        _enter_date_text.text=DateStr;
        
    }
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)date_done_button_action:(id)sender
{
    NSDate *date = [_date_pickview date];
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    
    [dateFormat setDateFormat:@"dd-MM-yyyy"];
    
    _enter_date_text.text = [dateFormat stringFromDate:date];
    
    [self.edit_date_view setHidden:YES];
    
    DataBase *dbase = [[DataBase alloc]init];
    
    NSMutableArray *editeddata = [[NSMutableArray alloc]init];
    
    editeddata=[dbase selectAllUser];
    
    [editeddata setValue:_update_date_textfield.text forKey:@"STARTDATE"];
    
    [dbh UserUpdate:editeddata];
}

- (IBAction)pin_back_button_action:(id)sender
{
    _pin_view.hidden=YES;
}

- (IBAction)pin_save_button:(id)sender
{
    
    NSString *rawString = [_Pin_enter_old_pin_text text];
    NSCharacterSet *whitespace = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed = [rawString stringByTrimmingCharactersInSet:whitespace];
    
    NSString *rawString1 = [_pin_enter_new_pin_text text];
    NSCharacterSet *whitespace1 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed1 = [rawString1 stringByTrimmingCharactersInSet:whitespace1];
    
    
    
    
    
    if([trimmed length] == 0)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"PrEP" message:@"old pin is empty" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        
        
    }else if ([trimmed1 length] == 0)
    {
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"PrEP" message:@"New pin is empty" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        
    }else if ([_pin_enter_new_pin_text.text isEqual:PinNewStr])
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"PrEP" message:@"Perious and new pin number is same please enter new pin" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }else
    {
        
       
        
        
        NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
        
        [dic setObject:titleStr forKey:@"NAME"];
        
        [dic setObject:_pin_enter_new_pin_text.text forKey:@"PIN"];
        
        [dic setObject:DateStr forKey:@"STARTDATE"];
        
         [dic setObject:Pill_TIME forKey:@"PILLTIME"];
        
         [dic setObject:PillCountStr forKey:@"PILLCOUNT"];
        
        NSMutableArray *Array1=[[NSMutableArray alloc]init];
        
        [Array1 addObject:dic];
        
        
        if ([Array1 count]>0)
        {
            
            [dbh UserUpdate:Array1];
            _pin_view.hidden=YES;
            
        }
        
    }
    
    
    
}


- (IBAction)dash_tab_button_action:(id)sender
{
    DashBoardViewController *objDashBoardViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    
    
    [self.navigationController pushViewController:objDashBoardViewController animated:YES];
    
}

- (IBAction)noti_tab_button_action:(id)sender
{
    NotificationViewController *objNotificationViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"NotificationViewController"];
    
    
    [self.navigationController pushViewController:objNotificationViewController animated:YES];
    
}

- (IBAction)task_tab_button_action:(id)sender
{
    AppointmentViewController *objAppointmentViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"AppointmentViewController"];
    
    
    [self.navigationController pushViewController:objAppointmentViewController animated:YES];
    
}

- (IBAction)cal_tab_button_action:(id)sender
{
    CalViewController *objCalViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"CalViewController"];
    
    
    [self.navigationController pushViewController:objCalViewController animated:YES];
}


- (IBAction)back_button_action:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)report_back_button_action:(id)sender {
    [self.report_view setHidden:YES];
}

- (IBAction)update_pin_button_action:(id)sender
{
    _pin_view.hidden=NO;
    
}

- (IBAction)medicine_rem_button_action:(id)sender
{
    
    [_medicine_reminder_view setHidden:NO];
    
}

- (IBAction)task_rem_button_action:(id)sender
{
}

- (IBAction)app_rem_button_action:(id)sender
{
}

- (IBAction)update_strate_button_action:(id)sender
{
    _edit_date_view.hidden=NO;
    
    UserArray=[dbh selectAllUser];
    
    if ([UserArray count]>0)
    {
        
        _enter_date_text.text=[[UserArray objectAtIndex:0] objectForKey:@"STARTDATE"];
        
    }
    
}

- (IBAction)pill_button_action:(id)sender
{
    
    _pin_view.hidden=NO;
}

- (IBAction)save_edit_button_action:(id)sender
{
    if ([_enter_date_text.text isEqualToString:DateStr])
    {
        
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"PrEP" message:@"Perious and current date is same Please 'Choose different one'" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        
    }else
    {
        
        NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
        
        [dic setObject:titleStr forKey:@"NAME"];
        
        [dic setObject:PinNewStr forKey:@"PIN"];
        
        [dic setObject:_enter_date_text.text forKey:@"STARTDATE"];
        
        
        
        NSMutableArray  *Array=[[NSMutableArray alloc]init];
        
        [Array addObject:dic];
        
        
        if ([Array count]>0)
        {
            
            [dbh UserUpdate:Array];
            _edit_date_view.hidden=YES;
            
        }
    }
    
    
}

- (IBAction)edit_back_button_action:(id)sender
{
    
    _edit_date_view.hidden=YES;
}

- (IBAction)reports_button_action:(id)sender
{
    [self.report_view setHidden:NO];
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    
    
    if (textField.tag == 1)
    {
        
        
        /* for backspace */
        if([string length]==0)
        {
            return YES;
        }
        
        /*  limit to only numeric characters  */
        
        NSCharacterSet *myCharSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
        for (int i = 0; i < [string length]; i++) {
            unichar c = [string characterAtIndex:i];
            if ([myCharSet characterIsMember:c]) {
                return YES;
            }
        }
        
        return NO;
    } else if (textField.tag == 2)
    {
        
        
        /* for backspace */
        if([string length]==0)
        {
            return YES;
        }
        
        /*  limit to only numeric characters  */
        
        NSCharacterSet *myCharSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
        for (int i = 0; i < [string length]; i++) {
            unichar c = [string characterAtIndex:i];
            if ([myCharSet characterIsMember:c]) {
                return YES;
            }
        }
        
        return NO;
    }
    else
        
        return YES;
    
}

#pragma Mark Arth-------


-(IBAction)update_date_back_button:(id)sender
{
    [self.edit_date_view setHidden:YES];
}
-(IBAction)update_date_textfieldbutton_action:(id)sender
{
    [self.update_date_editdate_view setHidden:NO];
    [self.date_pickview setHidden:NO];
    
}
-(IBAction)update_date_editdate_view_donebutton:(id)sender
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    
    [dateFormatter setDateFormat:@"dd-MM-yyyy HH:mm"];
    
    NSString *formatedDate = [dateFormatter stringFromDate:self.date_pickview.date];
    
    self.update_date_textfield.text =formatedDate;
    
    //[datepk removeFromSuperview];
    self.date_pickview.hidden = YES;
    self.update_date_editdate_view.hidden=YES;
}
-(IBAction)update_date_editdate_view_cancel:(id)sender
{
    [self.update_date_editdate_view setHidden:YES];
    [self.date_pickview setHidden:YES];
}


-(IBAction)overdue_appointment_button_action:(id)sender
{
    [_report_overdue_view setHidden:NO];
}

-(IBAction)completed_appointment_button_action:(id)sender
{
    [_report_completed_view setHidden:NO];
}

-(IBAction)hiv_tests_completed_button_action:(id)sender
{
    [_report_hiv_tests_view setHidden:NO];
}

-(IBAction)medication_taken_button_action:(id)sender
{
    [_report_medication_view setHidden:NO];
}


//report back button actions...

-(IBAction)overdue_appointment_back_button_action:(id)sender
{
    [_report_overdue_view setHidden:YES];
    
}

-(IBAction)completed_appointment_back_button_action:(id)sender
{
    [_report_completed_view setHidden:YES];
    
}

-(IBAction)hiv_tests_completed_back_button_action:(id)sender
{
    [_report_hiv_tests_view setHidden:YES];
    
}

-(IBAction)medication_taken_back_button_action:(id)sender
{
    [_report_medication_view setHidden:YES];
    
}

- (IBAction)medicine_to_back:(id)sender {
    
    
    [_medicine_reminder_view setHidden:NO];

}
- (IBAction)medicine_reminder_save_action:(id)sender {
    
    
    [_medicine_reminder_view setHidden:YES];
    

    nameStr =[[NSString alloc]init];
    
    if ([UserArray count]>0)
    {
        Pill_TIME=[[UserArray objectAtIndex:0] objectForKey:@"PILLTIME"];
       DateStr= [[UserArray objectAtIndex:0] objectForKey:@"STARTDATE"];


        nameStr=[DateStr stringByAppendingString:Pill_TIME];
    }
    NSLog(@"nnn%@",nameStr);
    
   
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT+05:00"];
    [formatter setTimeZone:gmt];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:a"];
    NSDate *date1 = [formatter dateFromString:nameStr];
    
    NSLog(@"vvvv%@",date1);
    
    
    
    NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
    
    [dic setObject:titleStr forKey:@"NAME"];
    
    [dic setObject:PinNewStr forKey:@"PIN"];
    
   
    
     [dic setObject:DateStr forKey:@"STARTDATE"];
    
    
    [dic setObject:Pill_TIME forKey:@"PILLTIME"];
    
    [dic setObject:PillCountStr forKey:@"PILLCOUNT"];
    
    NSMutableArray  *Array=[[NSMutableArray alloc]init];
    
    [Array addObject:dic];

    
    
    
    [dbh UserUpdate:Array];
    
   // [NSDate dateWithTimeIntervalSinceNow:10]
    
    UILocalNotification* localNotification = [[UILocalNotification alloc] init];
    localNotification.fireDate = [NSDate dateWithTimeInterval:20 sinceDate:date1];
    localNotification.alertBody = @"pill time..";
    localNotification.alertAction = @"reminderr...";
    localNotification.timeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT+05:00"];
    localNotification.applicationIconBadgeNumber = [[UIApplication sharedApplication] applicationIconBadgeNumber] + 1;
    
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
    
    // Request to reload table view data
    [[NSNotificationCenter defaultCenter] postNotificationName:@"reloadData" object:self];
    
    // Dismiss the view controller
    [self dismissViewControllerAnimated:YES completion:nil];
    
    
  //  [self MainUserData];
    
    
}
@end
