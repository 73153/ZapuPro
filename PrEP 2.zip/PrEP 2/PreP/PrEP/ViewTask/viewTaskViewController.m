//
//  viewTaskViewController.m
//  PrEP
//
//  Created by Bhushan on 5/14/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "viewTaskViewController.h"
#import "AddNewTaskViewController.h"
#import "DataBase.h"
#import "AppointmentTableViewCell.h"
#import "AppointmentViewController.h"
#import "TaskConfirmViewController.h"
#import "SettingViewController.h"
#import "DashBoardViewController.h"
#import "NotificationViewController.h"
#import "AppointmentViewController.h"
#import "CalViewController.h"
@interface viewTaskViewController ()
{
    DataBase *dbh;
}
@end

@implementation viewTaskViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    AppDel=[[UIApplication sharedApplication] delegate];
    dbh=[[DataBase alloc]init];
    
    taskNameArray=[[NSMutableArray alloc]init];
    taskIDArray=[[NSMutableArray alloc]init];
    
   
    
    
      
    _title_label.text=AppDel.ViewTask_tital;
    
    NSArray *SelTask=[dbh AllTask:AppDel.Sele_ID_viewApp_Str];
    
    NSLog(@"%@",SelTask);
 
    
    for (int i=1; i<[SelTask count]; i++)
    {
       
         
         [taskNameArray addObject:[[SelTask objectAtIndex:i]objectForKey:@"TASK_NAME"]];
         
         [taskIDArray addObject:[[SelTask objectAtIndex:i]objectForKey:@"ISCOMPLETED"]];
         
    }
    
    
    
    //
    NSLog(@"%@",AppDel.ViewTask_Date);
    
    if ([AppDel.ViewTask_Date isEqualToString:@"1"])
    {
       
        [_click_button setBackgroundImage:[UIImage imageNamed:@"check"] forState:UIControlStateNormal];
    }else
    {
       
        
        [_click_button setBackgroundImage:[UIImage imageNamed:@"uncheck"] forState:UIControlStateNormal];
        
    }
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)click_button_action:(id)sender
{
    if ([AppDel.ViewTask_Date isEqualToString:@"0"])
    {
        AppDel.ViewTask_Date=@"1";
        
        [_click_button setBackgroundImage:[UIImage imageNamed:@"check"] forState:UIControlStateNormal];
    }else
    {
          AppDel.ViewTask_Date=@"0";
        
                [_click_button setBackgroundImage:[UIImage imageNamed:@"uncheck"] forState:UIControlStateNormal];
        
    }
    
    
}

- (IBAction)edit_date_button_action:(id)sender
{
   AppDel.Edit_Date_Appstr=@"1";
    
    TaskConfirmViewController *objTaskConfirmViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"TaskConfirmViewController"];
    
    
    [self.navigationController pushViewController:objTaskConfirmViewController animated:YES];
    
}

- (IBAction)Add_newTask_button_action:(id)sender
{
    
    AddNewTaskViewController *objAddNewTaskViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"AddNewTaskViewController"];
    
    
    [self.navigationController pushViewController:objAddNewTaskViewController animated:NO];
}

- (IBAction)back_button_action:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)save_button_action:(id)sender

{
    
    //ckickStr
    
    [dbh UpdateAppointDate:AppDel.ViewTask_Date];
    
    AppointmentViewController *objAppointmentViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"AppointmentViewController"];
    
    
    [self.navigationController pushViewController:objAppointmentViewController animated:YES];
    
    
    
}



#pragma mark UITableViewDelegate Protocol Methods-----------------------------------



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    
    return [taskNameArray count];
    
    
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath

{
    
    return 40;
    
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath

{
    
    
    static NSString *simpleTableIdentifier = @"AppointmentTableViewCell";
    
    AppointmentTableViewCell *cell = (AppointmentTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"AppointmentTableViewCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    //App_Comp
    
    
   
    
    NSString *CompleteStr=[taskIDArray objectAtIndex:indexPath.row];
    
    if([CompleteStr isEqualToString:@"1"])
    {
        cell.tital_label.textColor=[UIColor redColor];
    }else
    {
        cell.tital_label.textColor=[UIColor grayColor];
    }
    
    
        
    cell.tital_label.text=[taskNameArray objectAtIndex:indexPath.row];
    
    cell.index_lable.text=@"";
    
    
    
    return cell;
    
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    AppDel.Edit_Date_Appstr=@"0";
    
    
    NSString *CompleteStr=[taskIDArray objectAtIndex:indexPath.row];
    
    if([CompleteStr isEqualToString:@"1"])
    {
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"PrEP" message:@"This Task Already completed" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];

        
    }else
    {
        TaskConfirmViewController *objTaskConfirmViewController=[[TaskConfirmViewController alloc]init];
        
        
        objTaskConfirmViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"TaskConfirmViewController"];
        
        
        objTaskConfirmViewController.TaskTitleStr=[taskNameArray objectAtIndex:indexPath.row];
        
        
        [self.navigationController pushViewController:objTaskConfirmViewController animated:YES];
    }

    
   
    
    
}

- (IBAction)dash_tab_button_action:(id)sender
{
    
    DashBoardViewController *objDashBoardViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    [self.navigationController pushViewController:objDashBoardViewController animated:YES];
    
}

- (IBAction)noti_tab_button_action:(id)sender
{
    NotificationViewController *objNotificationViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"NotificationViewController"];
    
    [self.navigationController pushViewController:objNotificationViewController animated:YES];
}



- (IBAction)cal_tab_button_action:(id)sender
{
    CalViewController *objCalViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"CalViewController"];
    
    [self.navigationController pushViewController:objCalViewController animated:YES];
    
}

- (IBAction)setting_tab_button_action:(id)sender
{
    SettingViewController *objSettingViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"SettingViewController"];
    
    [self.navigationController pushViewController:objSettingViewController animated:YES];
}




@end
