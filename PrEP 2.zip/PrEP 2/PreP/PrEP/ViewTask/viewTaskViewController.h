//
//  viewTaskViewController.h
//  PrEP
//
//  Created by Bhushan on 5/14/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"

@interface viewTaskViewController : ViewController
{
    
    AppDelegate *AppDel;
    
    NSMutableArray *taskNameArray,*taskIDArray;
    NSString *ckickStr;
    
}



@property (strong, nonatomic) IBOutlet UITableView *task_tableview;

@property (strong, nonatomic) IBOutlet UILabel *title_label;

@property (strong, nonatomic) IBOutlet UILabel *desc_label;
@property (strong, nonatomic) IBOutlet UIButton *click_button;



- (IBAction)click_button_action:(id)sender;

- (IBAction)edit_date_button_action:(id)sender;

- (IBAction)Add_newTask_button_action:(id)sender;

- (IBAction)back_button_action:(id)sender;

- (IBAction)save_button_action:(id)sender;


- (IBAction)dash_tab_button_action:(id)sender;

- (IBAction)noti_tab_button_action:(id)sender;


- (IBAction)cal_tab_button_action:(id)sender;

- (IBAction)setting_tab_button_action:(id)sender;


@end
