//
//  TaskConfirmViewController.m
//  PrEP
//
//  Created by Bhushan on 5/14/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "TaskConfirmViewController.h"
#import "viewTaskViewController.h"
#import "SettingViewController.h"
#import "DashBoardViewController.h"
#import "NotificationViewController.h"
#import "AppointmentViewController.h"
#import "CalViewController.h"
@interface TaskConfirmViewController ()

@end

@implementation TaskConfirmViewController
@synthesize TaskTitleStr,TaskCompStr;

- (void)viewDidLoad
{
    [super viewDidLoad];
   
     AppDel=[[UIApplication sharedApplication] delegate];
    
    
    if ([AppDel.Edit_Date_Appstr isEqualToString:@"1"])
    {
        _date_edit_view.hidden=NO;
        
    }else
    {
        _date_edit_view.hidden=YES;
        
    }
    
    AppDel.Edit_Date_Appstr=@"0";
    
    task_confStr=@"1";
    
    
    _task_title_label.text=TaskTitleStr;
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
    
    // Dispose of any resources that can be recreated.
}



- (IBAction)task_back_button_action:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)save_Date_button_action:(id)sender
{
    NSString *rawString = [_date_text text];
    NSCharacterSet *whitespace = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed = [rawString stringByTrimmingCharactersInSet:whitespace];
    
    if([trimmed length] == 0)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"PrEP" message:@"Date Empty" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        
    }else
    {
        [self.navigationController popViewControllerAnimated:YES];
        
        
    }
    
    
}

- (IBAction)date_done_button_action:(id)sender
{
    NSDate *date = [_date_picker date];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    NSDateFormatter *dateFormat1 = [[NSDateFormatter alloc] init];
    
    [dateFormat setDateFormat:@"dd-MM-yyyy"];
    _date_text.text = [dateFormat stringFromDate:date];
    
    [dateFormat1 setDateFormat:@"HH:mm:ss"];
    
   // NSString *timeStr=[dateFormat1 stringFromDate:date];
    
    
    
}

- (IBAction)back_date_button_action:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)task_click_button:(id)sender
{
    
    if ([task_confStr isEqualToString:@"1"])
    {
         task_confStr=@"0";
        
        [_task_click_button setBackgroundImage:[UIImage imageNamed:@"check"] forState:UIControlStateNormal];
    }else
    {
         task_confStr=@"1";
        
        [_task_click_button setBackgroundImage:[UIImage imageNamed:@"uncheck"] forState:UIControlStateNormal];
        
    }
}

- (IBAction)task_save_button_action:(id)sender
{
    
    if ([[_task_click_button backgroundImageForState:UIControlStateNormal] isEqual:[UIImage imageNamed:@"check"]])
    {
        
        [dbh TaskUpdateCompleted:_task_title_label.text];
        
        viewTaskViewController *objviewTaskViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"viewTaskViewController"];
        
        [self.navigationController pushViewController:objviewTaskViewController animated:YES];
        
    }else
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
    
    

}

- (IBAction)dash_tab_button_action:(id)sender
{
    
    DashBoardViewController *objDashBoardViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    [self.navigationController pushViewController:objDashBoardViewController animated:YES];
    
}

- (IBAction)noti_tab_button_action:(id)sender
{
    NotificationViewController *objNotificationViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"NotificationViewController"];
    
    [self.navigationController pushViewController:objNotificationViewController animated:YES];
}



- (IBAction)cal_tab_button_action:(id)sender
{
    CalViewController *objCalViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"CalViewController"];
    
    [self.navigationController pushViewController:objCalViewController animated:YES];
    
}

- (IBAction)setting_tab_button_action:(id)sender
{
    SettingViewController *objSettingViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"SettingViewController"];
    
    [self.navigationController pushViewController:objSettingViewController animated:YES];
}
@end
