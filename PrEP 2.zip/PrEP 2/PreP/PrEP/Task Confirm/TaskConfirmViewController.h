//
//  TaskConfirmViewController.h
//  PrEP
//
//  Created by Bhushan on 5/14/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"
@interface TaskConfirmViewController : ViewController
{
    AppDelegate *AppDel;
    NSString *task_confStr;
    
}


@property (strong, nonatomic) IBOutlet UIView *date_edit_view;

@property (strong, nonatomic) IBOutlet UITextField *date_text;
@property (strong, nonatomic) IBOutlet UIDatePicker *date_picker;
@property (strong, nonatomic) IBOutlet UILabel *task_title_label;

@property (strong, nonatomic) NSString *TaskTitleStr;

@property (strong, nonatomic) NSString *TaskCompStr;

@property (strong, nonatomic) IBOutlet UIButton *task_click_button;







- (IBAction)task_back_button_action:(id)sender;
- (IBAction)save_Date_button_action:(id)sender;

- (IBAction)date_done_button_action:(id)sender;

- (IBAction)back_date_button_action:(id)sender;

- (IBAction)task_click_button:(id)sender;

- (IBAction)task_save_button_action:(id)sender;




- (IBAction)dash_tab_button_action:(id)sender;

- (IBAction)noti_tab_button_action:(id)sender;

- (IBAction)task_tab_button_action:(id)sender;

- (IBAction)cal_tab_button_action:(id)sender;

- (IBAction)setting_tab_button_action:(id)sender;

@end
