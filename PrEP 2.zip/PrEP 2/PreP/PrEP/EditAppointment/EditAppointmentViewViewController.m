//
//  EditAppointmentViewViewController.m
//  PrEP
//
//  Created by Bhushan on 5/12/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "EditAppointmentViewViewController.h"
#import "DataBase.h"

@interface EditAppointmentViewViewController ()
{
    DataBase *dbh;
}

@end

@implementation EditAppointmentViewViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
    
     dbh=[[DataBase alloc]init];
     AddArray=[[NSMutableArray alloc]init];
    
    NSLog(@"%@",appDelegate.Title_App_Str);
    
     SelectionArray=[dbh EditAppointment:appDelegate.Title_App_Str];
    
    if ([SelectionArray count]==0)
    {
        
    }
    else
    {
    
        _title_text_field.text=[[SelectionArray objectAtIndex:0]objectForKey:@"TITLE"];
        
        _date_text_field.text=[[SelectionArray objectAtIndex:0]objectForKey:@"DATE"];
        
        _desc_text_field.text=[[SelectionArray objectAtIndex:0]objectForKey:@"DESC"];
        
         _title_text_field.userInteractionEnabled=NO;
         _date_text_field.userInteractionEnabled=NO;
         _desc_text_field.userInteractionEnabled=NO;
        
        
    }
    if ([appDelegate.CompSel_App_Str isEqualToString:@"1"])
    {
        _edit_button.hidden=YES;
    }
    
    _save_button.hidden=YES;

    
   #pragma textfield layout
    
    _title_text_field.layer.cornerRadius=2.0f;
    _title_text_field.layer.masksToBounds=YES;
    _title_text_field.layer.borderColor=[[UIColor grayColor]CGColor];
    _title_text_field.layer.borderWidth= 2.5f;
    _title_text_field.backgroundColor=[UIColor clearColor];
    
    
    _desc_text_field.layer.cornerRadius=2.0f;
   _desc_text_field.layer.masksToBounds=YES;
    _desc_text_field.layer.borderColor=[[UIColor grayColor]CGColor];
    _desc_text_field.layer.borderWidth= 2.5f;
    _desc_text_field.backgroundColor=[UIColor clearColor];
    
    
    _date_text_field.layer.cornerRadius=2.0f;
    _date_text_field.layer.masksToBounds=YES;
    _date_text_field.layer.borderColor=[[UIColor grayColor]CGColor];
    _date_text_field.layer.borderWidth= 2.5f;
    _date_text_field.backgroundColor=[UIColor clearColor];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)save_button_action:(id)sender
{
      appDelegate.CompSel_App_Str=@"";
    NSString *rawString = [_title_text_field text];
    NSCharacterSet *whitespace = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed = [rawString stringByTrimmingCharactersInSet:whitespace];
    
    NSString *rawString1 = [_desc_text_field text];
    NSCharacterSet *whitespace1 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed1 = [rawString1 stringByTrimmingCharactersInSet:whitespace1];
    
    NSString *rawString2 = [_date_text_field text];
    NSCharacterSet *whitespace2 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed2 = [rawString2 stringByTrimmingCharactersInSet:whitespace2];
    
    
    
    if([trimmed length] == 0)
    {
        
        [appDelegate.window makeToast:@"Title Empty" duration:1.0 position:@"center"];
        
    }else if ([trimmed1 length] == 0)
    {
        [appDelegate.window makeToast:@"Descrptions Empty" duration:1.0 position:@"center"];
        
    }else if ([trimmed2 length]== 0)
    {
        
        [appDelegate.window makeToast:@" Date Empty" duration:1.0 position:@"center"];
        
    }else
    {
        NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
        
        [dic setObject:_title_text_field.text forKey:@"TITLE"];
        
        [dic setObject:_desc_text_field.text forKey:@"DESC"];
        
        [dic setObject:_date_text_field.text forKey:@"DATE"];
        
        
       
        
        [AddArray addObject:dic];
        
        
        if ([AddArray count]>0)
        {
            [dbh AppointmentUpdate:AddArray];
            
        }
                
        
        
        DashBoardViewController *objDashBoardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
        
        
        [self.navigationController pushViewController:objDashBoardViewController animated:NO];
        
    }

}

- (IBAction)date_cancel_button_action:(id)sender
{
    
    _dateview.hidden=YES;
    
    CGPoint point = CGPointMake(0,0);
    [_main_scroll_view setContentOffset:point animated:YES] ;
    
}

- (IBAction)date_done_button_action:(id)sender
{
    
    NSDate *date = [_date_picker date];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"dd-MM-yyyy"];
    _date_text_field.text = [dateFormat stringFromDate:date];
    
    
    
    
    _dateview.hidden=YES;
    
    CGPoint point = CGPointMake(0,0);
    [_main_scroll_view setContentOffset:point animated:YES] ;
}

- (IBAction)edit:(id)sender
{
     _save_button.hidden=NO;
    _title_text_field.userInteractionEnabled=YES;
    _date_text_field.userInteractionEnabled=YES;
    _desc_text_field.userInteractionEnabled=YES;
    
    
}

- (IBAction)back_button_action:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
    
    appDelegate.CompSel_App_Str=@"";
    
}

- (IBAction)completed_button_action:(id)sender
{
    UIAlertView *myAlert = [[UIAlertView alloc]
                            initWithTitle:@""
                            message:@"You will not be able to edit appointment details once you mark it as completed do you want to proceed ?"
                            delegate:self
                            cancelButtonTitle:@"Cancel"
                            otherButtonTitles:@"Ok",nil];
    [myAlert show];
}


#pragma mark textViewDidBeginEditing-----------------------------------------------------

static NSInteger stepRange1[] = {
    
    0,0,90,100
};



static NSInteger getScrollPos21(NSInteger i) {
    
    if (i < 1 || i > 3)
        return 0 ;
    return stepRange1[i] ;
}

static NSInteger stepRange[] = {
    
    0,0,90,100
};



static NSInteger getScrollPos2(NSInteger i) {
    
    if (i < 1 || i > 3)
        return 0 ;
    return stepRange[i] ;
}


- (void)textViewDidBeginEditing:(UITextView *)textView
{
    
    
    _main_scroll_view.scrollEnabled = YES;
    CGPoint point = CGPointMake(0,700);
    [_main_scroll_view setContentOffset:point animated:YES] ;
    
}

- (void) textFieldDidBeginEditing:(UITextField *)textField
{
    
    if (textField.tag==3)
    {
         _dateview.hidden=NO;
        
        [textField resignFirstResponder];
        [_title_label resignFirstResponder];
        
        [_date_label resignFirstResponder];
        [_desc_label resignFirstResponder];
        
        CGPoint point;
        
        point = CGPointMake(0, getScrollPos21(textField.tag));
        [_main_scroll_view setContentOffset:point animated:YES] ;
        
        
    }
    else
    {
        
        
        _main_scroll_view.scrollEnabled = YES;
        
        
        CGPoint point;
        
        if (IS_IPHONE5)
            point = CGPointMake(0, getScrollPos21(textField.tag));
        else
            point = CGPointMake(0, getScrollPos2(textField.tag));
        
        
        [_main_scroll_view setContentOffset:point animated:YES] ;
        
    }
    
    
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField.tag==3)
    {
        
        _dateview.hidden=NO;
        
        [textField resignFirstResponder];
        [_title_label resignFirstResponder];
        
        [_dateview resignFirstResponder];
        [_desc_text_field resignFirstResponder];
        
        CGPoint point;
        
        point = CGPointMake(0, getScrollPos21(textField.tag));
        [_main_scroll_view setContentOffset:point animated:YES] ;
        
        return NO;
    }else
    {
        return YES;
    }
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    _main_scroll_view.scrollEnabled = YES;
    
    
    
    NSInteger nextTag = textField.tag + 1;
    UIResponder* nextResponder = [textField.superview viewWithTag:nextTag];
    
    if (nextResponder)
    {
        if (nextTag==3)
        {
            
            _dateview.hidden=NO;
            
            CGPoint point = CGPointMake(0, getScrollPos2(nextTag));
            [_main_scroll_view setContentOffset:point animated:YES];
            
            [_title_label resignFirstResponder];
            
            [_date_text_field resignFirstResponder];
            [_date_text_field resignFirstResponder];
            
            [textField resignFirstResponder];
        }
        else{
            
            [nextResponder becomeFirstResponder];
            CGPoint point = CGPointMake(0, getScrollPos2(nextTag));
            [_main_scroll_view setContentOffset:point animated:YES];
        }
        
    }
    else
    {
        CGPoint point = CGPointMake(0,64);
        [_main_scroll_view setContentOffset:point animated:YES] ;
        [textField resignFirstResponder];
        
        
        
        
    }
    
    return YES;
}



- (IBAction)noti_tab_button_action:(id)sender
{
    NotificationViewController *objNotificationViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"NotificationViewController"];
    
    
    [self.navigationController pushViewController:objNotificationViewController animated:YES];
    
}

- (IBAction)task_tab_button_action:(id)sender
{
    AppointmentViewController *objAppointmentViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"AppointmentViewController"];
    
    
    [self.navigationController pushViewController:objAppointmentViewController animated:YES];
    
}

- (IBAction)cal_tab_button_action:(id)sender
{
    CalViewController *objCalViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"CalViewController"];
    
    
    [self.navigationController pushViewController:objCalViewController animated:YES];
}
- (IBAction)setting_tab_button_action:(id)sender
{
    SettingViewController *objSettingViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"SettingViewController"];
    
    
    [self.navigationController pushViewController:objSettingViewController animated:YES];
}


- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    // the user clicked OK
    if (buttonIndex == 0)
    {
        // do something here...
    }else
    {
        [dbh Comp_task:appDelegate.Title_App_Str];
        
        
        CalViewController *objCalViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"CalViewController"];
        
        
        [self.navigationController pushViewController:objCalViewController animated:YES];
    }
}



@end
