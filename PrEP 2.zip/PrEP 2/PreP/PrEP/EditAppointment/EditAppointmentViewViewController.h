//
//  EditAppointmentViewViewController.h
//  PrEP
//
//  Created by Bhushan on 5/12/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "ViewController.h"

@interface EditAppointmentViewViewController : ViewController

{
    NSMutableArray  *AddArray;
   
    NSArray *SelectionArray;
    
}


@property (strong, nonatomic) IBOutlet UITextField *title_label;
@property (strong, nonatomic) IBOutlet UITextField *desc_label;
@property (strong, nonatomic) IBOutlet UITextField *date_label;

@property (strong, nonatomic) IBOutlet UIDatePicker *date_picker;

@property (strong, nonatomic) IBOutlet UITextField *title_text_field;

@property (strong, nonatomic) IBOutlet UITextField *desc_text_field;

@property (strong, nonatomic) IBOutlet UITextField *date_text_field;

@property (strong, nonatomic) IBOutlet UIScrollView *main_scroll_view;
@property (strong, nonatomic) IBOutlet UIButton *save_button;

@property (strong, nonatomic) IBOutlet UIButton *edit_button;

@property (strong, nonatomic) IBOutlet UIView *dateview;




- (IBAction)save_button_action:(id)sender;
- (IBAction)date_cancel_button_action:(id)sender;
- (IBAction)date_done_button_action:(id)sender;
- (IBAction)edit:(id)sender;
- (IBAction)back_button_action:(id)sender;




- (IBAction)completed_button_action:(id)sender;

- (IBAction)noti_tab_button_action:(id)sender;

- (IBAction)task_tab_button_action:(id)sender;

- (IBAction)cal_tab_button_action:(id)sender;

- (IBAction)setting_tab_button_action:(id)sender;


@end
