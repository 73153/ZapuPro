//
//  AddAppointmentViewController.m
//  PrEP
//
//  Created by Bhushan on 5/13/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "AddAppointmentViewController.h"
#import "AddApoinmentCell.h"
#import <QuartzCore/QuartzCore.h>

@interface AddAppointmentViewController ()
{
    DataBase *dbh;
}

@end

@implementation AddAppointmentViewController
@synthesize addApoinmentTableView;
- (void)viewDidLoad
{
    [super viewDidLoad];
    
   addArray=[[NSMutableArray alloc]init];
   dbh=[[DataBase alloc]init];
    addApoinmentTitleArray=[[NSMutableArray alloc] initWithObjects:@"3 Day Phone Call",@"14 Day Phone Call",@"1 Month Vist",@"3 Month Vist",@"6 Month Vist",@"9 Month Vist",@"12 Month Vist",@"other", nil];
    [_addApoinmentTitleView setHidden:YES];
    
    
#pragma textfield layout
    
    CALayer *border = [CALayer layer];
    CGFloat borderWidth = 2;
    border.borderColor = [UIColor darkGrayColor].CGColor;
    border.frame = CGRectMake(0, _addSetTitleTextFild.frame.size.height - borderWidth, _addSetTitleTextFild.frame.size.width, _addSetTitleTextFild.frame.size.height);
    border.borderWidth = borderWidth;
    [_addSetTitleTextFild.layer addSublayer:border];
    _addSetTitleTextFild.layer.masksToBounds = YES;
    
    
   _title_text.layer.cornerRadius=2.0f;
   _title_text.layer.masksToBounds=YES;
   _title_text.layer.borderColor=[[UIColor grayColor]CGColor];
   _title_text.layer.borderWidth= 2.5f;
   _title_text.backgroundColor=[UIColor clearColor];
    
    
    _desc_text.layer.cornerRadius=2.0f;
    _desc_text.layer.masksToBounds=YES;
    _desc_text.layer.borderColor=[[UIColor grayColor]CGColor];
    _desc_text.layer.borderWidth= 2.5f;
    _desc_text.backgroundColor=[UIColor clearColor];
    
    
    _date_text.layer.cornerRadius=2.0f;
    _date_text.layer.masksToBounds=YES;
    _date_text.layer.borderColor=[[UIColor grayColor]CGColor];
    _date_text.layer.borderWidth= 2.5f;
    _date_text.backgroundColor=[UIColor clearColor];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)save_button_action:(id)sender
{
    
    NSString *rawString = [_title_text text];
    NSCharacterSet *whitespace = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed = [rawString stringByTrimmingCharactersInSet:whitespace];
    
    
    NSString *rawString4 = [_addSetTitleTextFild text];
    NSCharacterSet *whitespace4 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed4 = [rawString4 stringByTrimmingCharactersInSet:whitespace4];

    
    NSString *rawString1 = [_desc_text text];
    NSCharacterSet *whitespace1 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed1 = [rawString1 stringByTrimmingCharactersInSet:whitespace1];
    
    NSString *rawString2 = [_date_text text];
    NSCharacterSet *whitespace2 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed2 = [rawString2 stringByTrimmingCharactersInSet:whitespace2];
    
    
    
     if ([trimmed1 length] == 0)
    {
        [appDelegate.window makeToast:@"Description Empty" duration:1.0 position:@"center"];
        
    }else if ([trimmed2 length]== 0)
    {
        
        [appDelegate.window makeToast:@"Date Empty" duration:1.0 position:@"center"];
        
    } else if ([trimmed4 isEqualToString:@"other"])
    {
        if ([trimmed length] == 0)
        {
             [appDelegate.window makeToast:@"Title Empty" duration:1.0 position:@"center"];
            
        }else
        {
            [self addAppMethod];
            
        }
        
        
       
        
    }else
    {
        
         [self addAppMethod];
        
        
       
        
    }
    
    
    
}

- (IBAction)back_button_action:(id)sender
{
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (IBAction)dash_Tabbutton_action:(id)sender
{
    
    DashBoardViewController *objDashBoardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    
    
    [self.navigationController pushViewController:objDashBoardViewController animated:NO];
    
}

- (IBAction)notification_Tabbutton_action:(id)sender
{
    NotificationViewController *objNotificationViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"NotificationViewController"];
    
    
    [self.navigationController pushViewController:objNotificationViewController animated:NO];
}



- (IBAction)cal_Tab_button_action:(id)sender
{
    CalViewController *objCalViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"CalViewController"];
    
    
    [self.navigationController pushViewController:objCalViewController animated:YES];
    
}

- (IBAction)setting_Tab_button_action:(id)sender
{
    SettingViewController *objSettingViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"SettingViewController"];
    
    
    [self.navigationController pushViewController:objSettingViewController animated:NO];
}



- (IBAction)date_cancel_button_action:(id)sender
{
    _dateview.hidden=YES;
    
    CGPoint point = CGPointMake(0,0);
    [_main_scroll_view setContentOffset:point animated:YES] ;
}

- (IBAction)date_done_button_action:(id)sender
{
    
    
    NSDate *date = [_date_picker date];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    NSDateFormatter *dateFormat1 = [[NSDateFormatter alloc] init];
    
    [dateFormat setDateFormat:@"yyyy-MM-dd"];
    _date_text.text = [dateFormat stringFromDate:date];
    
    [dateFormat1 setDateFormat:@"HH:mm:ss"];
    
    timeStr=[dateFormat1 stringFromDate:date];
    
    
    _dateview.hidden=YES;
    
    CGPoint point = CGPointMake(0,0);
    [_main_scroll_view setContentOffset:point animated:YES] ;
    
}

- (IBAction)add_app_buttona_action:(id)sender
{
//    NSLog(@"myUIView origin=%@", NSStringFromCGPoint(_save_view.frame.origin));
//    
//     CGRect frame = _save_view.frame;
//  
//    int ypos=frame.origin.y;
//    
//    ypos= ypos+40;
    
    [_addApoinmentTitleView setHidden:NO];
    
}




#pragma mark textViewDidBeginEditing-----------------------------------------------------

static NSInteger stepRange1[] = {
    
    0,0,90,150
};



static NSInteger getScrollPos21(NSInteger i) {
    
    if (i < 1 || i > 3)
        return 0 ;
    return stepRange1[i] ;
}

static NSInteger stepRange[] = {
    
    0,0,90,150
};



static NSInteger getScrollPos2(NSInteger i) {
    
    if (i < 1 || i > 3)
        return 0 ;
    return stepRange[i] ;
}


- (void)textViewDidBeginEditing:(UITextView *)textView
{
    
    
    _main_scroll_view.scrollEnabled = YES;
    CGPoint point = CGPointMake(0,700);
    [_main_scroll_view setContentOffset:point animated:YES] ;
    
}

- (void) textFieldDidBeginEditing:(UITextField *)textField
{
    
    if (textField.tag==3)
    {
        _dateview.hidden=NO;
        
        [textField resignFirstResponder];
        [_title_text resignFirstResponder];
        
        [_desc_text resignFirstResponder];
        [_date_text resignFirstResponder];
        
        CGPoint point;
        
        point = CGPointMake(0, getScrollPos21(textField.tag));
        [_main_scroll_view setContentOffset:point animated:YES] ;
        
        
    }
    else
    {
         _dateview.hidden=YES;
        
        _main_scroll_view.scrollEnabled = YES;
        
        
        CGPoint point;
        
        if (IS_IPHONE5)
            point = CGPointMake(0, getScrollPos21(textField.tag));
        else
            point = CGPointMake(0, getScrollPos2(textField.tag));
        
        
        [_main_scroll_view setContentOffset:point animated:YES] ;
        
    }
    
    
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField.tag==3)
    {
        
        _dateview.hidden=NO;
        
        [textField resignFirstResponder];
        [_title_text resignFirstResponder];
        
        [_desc_text resignFirstResponder];
        [_date_text resignFirstResponder];
        
        CGPoint point;
        
        point = CGPointMake(0, getScrollPos21(textField.tag));
        [_main_scroll_view setContentOffset:point animated:YES] ;
        
        return NO;
    }else
    {
        return YES;
    }
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    _main_scroll_view.scrollEnabled = YES;
    
    
    
    NSInteger nextTag = textField.tag + 1;
    UIResponder* nextResponder = [textField.superview viewWithTag:nextTag];
    
    if (nextResponder)
    {
        if (nextTag==3)
        {
            
            _dateview.hidden=NO;
            
            CGPoint point = CGPointMake(0, getScrollPos2(nextTag));
            [_main_scroll_view setContentOffset:point animated:YES];
            
            [_title_text resignFirstResponder];
            
            [_desc_text resignFirstResponder];
            [_date_text resignFirstResponder];
            
            [textField resignFirstResponder];
        }
        else{
            
            [nextResponder becomeFirstResponder];
            CGPoint point = CGPointMake(0, getScrollPos2(nextTag));
            [_main_scroll_view setContentOffset:point animated:YES];
        }
        
    }
    else
    {
        CGPoint point = CGPointMake(0,64);
        [_main_scroll_view setContentOffset:point animated:YES] ;
        [textField resignFirstResponder];
        
        
        
        
    }
    
    return YES;
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
 
    
    
    
    return YES;
}






#pragma mark -table view dat sources

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1 ;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [addApoinmentTitleArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath*)indexPath {
    static NSString *CellIdentifier = @"celll";
    AddApoinmentCell *cell = [addApoinmentTableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    // NOTE: Add some code like this to create a new cell if there are none to reuse
    if(cell == nil)
    {
        cell = [[AddApoinmentCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        
    }
    
    NSString *string = [addApoinmentTitleArray objectAtIndex:indexPath.row];
    
    cell.textLabel.text = string;
    NSLog(@"%@",string);
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *str1 = [addApoinmentTitleArray objectAtIndex:indexPath.row];
    
    if (![str1 isEqualToString:@"other"]) {
        _addSetTitleTextFild.text=str1;
        _save_view.frame=CGRectMake(0, 80, 320, 294);
    }else
    {
       _addSetTitleTextFild.text=str1;
        _save_view.frame=CGRectMake(0, 115, 320, 294);
    }
    
    
    [_addApoinmentTitleView setHidden:YES];
    
}
-(void)addAppMethod
{
    
  
    
    NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
    
    
    //("DATE" VARCHAR,"ISCOMPLETED" INTEGER DEFAULT (null) ,"USERID" INTEGER,"TITLE" VARCHAR,"DESC" VARCHAR, "ID" INTEGER, "TIME" VARCHAR, "ISCONFORM" INTEGER)
    
    
    [dic setObject:@"1" forKey:@"USERID"];
    
    [dic setObject:_desc_text.text forKey:@"DESC"];
    
    
    NSString *TitleStr=_addSetTitleTextFild.text;
    
    if ([TitleStr isEqualToString:@"other"])
    {
        [dic setObject:_title_text.text forKey:@"TITLE"];
    }else{
        [dic setObject:_addSetTitleTextFild.text forKey:@"TITLE"];
    }
    
    
    
    [dic setObject:_date_text.text forKey:@"DATE"];
    
    [dic setObject:@"1" forKey:@"ISCOMPLETED"];
    
    [dic setObject:appDelegate.Increment_Id_App_Str forKey:@"ID"];
    
    [dic setObject:timeStr forKey:@"TIME"];
    
    [dic setObject:@"1" forKey:@"ISCONFORM"];
    
    
    
    [addArray addObject:dic];
    
    
    if ([addArray count]>0)
    {
        [dbh AddAppointment:addArray];
        
        
        CalViewController *objCalViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"CalViewController"];
        
        
        [self.navigationController pushViewController:objCalViewController animated:NO];
        
        
    }
    
    
    
    
}

- (IBAction)task_tab_button_action:(id)sender {
    
    AppointmentViewController *objAppointmentViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"AppointmentViewController"];
    
    
    [self.navigationController pushViewController:objAppointmentViewController animated:NO];
}

@end
