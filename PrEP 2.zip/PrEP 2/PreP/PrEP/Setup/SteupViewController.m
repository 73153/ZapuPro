//
//  SteupViewController.m
//  PrEP
//
//  Created by Bhushan on 5/1/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "SteupViewController.h"
#define IS_IPHONE5 (([[UIScreen mainScreen] bounds].size.height-568)?NO:YES)
#define MAX_LENGTH 4
#define MAX_LENGTH_Pi 2


@interface SteupViewController ()

@end

@implementation SteupViewController
@synthesize Date_view,dateFormatter,datePikrToolbar;
@synthesize pill_qua_text;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
     dbh=[[DataBase alloc]init];
    
    
     UserDateArray=[dbh selectAllUser];
    
    
    
    if ([UserDateArray count]>0)
    {//PIN,STARTDATE
        
        _name_textfield.text=[[UserDateArray objectAtIndex:0] objectForKey:@"NAME"];
        _pin_textfield.text=[[UserDateArray objectAtIndex:0] objectForKey:@"PIN"];
     
        NSString *DateStr=[[UserDateArray objectAtIndex:0] objectForKey:@"STARTDATE"];
        
          NSString *TimeStr=[[UserDateArray objectAtIndex:0] objectForKey:@"PILLTIME"];
        
        
        _start_date_text.text=[NSString stringWithFormat:@"%@ %@",DateStr,TimeStr];
        
         pill_qua_text.text=[[UserDateArray objectAtIndex:0] objectForKey:@"PILLCOUNT"];
        
        
      
        
    }
    
    
        
    //Save_button shadow set
    _save_button.layer.shadowColor = [UIColor blackColor].CGColor;
    _save_button.layer.shadowOpacity = 0.5;
    _save_button.layer.shadowRadius = 5;
    _save_button.layer.shadowOffset = CGSizeMake(3.0f,3.0f);
    _save_button.layer.cornerRadius = 5;
    
    
    
#pragma textfield layout
    
    _name_textfield.layer.cornerRadius=2.0f;
    _name_textfield.layer.masksToBounds=YES;
    _name_textfield.layer.borderColor=[[UIColor grayColor]CGColor];
    _name_textfield.layer.borderWidth= 2.5f;
    _name_textfield.backgroundColor=[UIColor clearColor];
    
    
    _start_date_text.layer.cornerRadius=2.0f;
    _start_date_text.layer.masksToBounds=YES;
    _start_date_text.layer.borderColor=[[UIColor grayColor]CGColor];
    _start_date_text.layer.borderWidth= 2.5f;
    _start_date_text.backgroundColor=[UIColor clearColor];
    
    
    _pin_textfield.layer.cornerRadius=2.0f;
    _pin_textfield.layer.masksToBounds=YES;
    _pin_textfield.layer.borderColor=[[UIColor grayColor]CGColor];
    _pin_textfield.layer.borderWidth= 2.5f;
    _pin_textfield.backgroundColor=[UIColor clearColor];
    
    
    _name_textfield.layer.cornerRadius=2.0f;
   _name_textfield.layer.masksToBounds=YES;
    _name_textfield.layer.borderColor=[[UIColor grayColor]CGColor];
    _name_textfield.layer.borderWidth= 2.5f;
  _name_textfield.backgroundColor=[UIColor clearColor];

    
    pill_qua_text.layer.cornerRadius=2.0f;
    pill_qua_text.layer.masksToBounds=YES;
    pill_qua_text.layer.borderColor=[[UIColor grayColor]CGColor];
    pill_qua_text.layer.borderWidth= 2.5f;
    pill_qua_text.backgroundColor=[UIColor clearColor];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


#pragma mark save button action in to date base..

- (IBAction)save_button_action:(id)sender
{
    
    NSString *rawString = [_name_textfield text];
    NSCharacterSet *whitespace = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed = [rawString stringByTrimmingCharactersInSet:whitespace];
    
    NSString *rawString1 = [_pin_textfield text];
    NSCharacterSet *whitespace1 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed1 = [rawString1 stringByTrimmingCharactersInSet:whitespace1];
    
    NSString *rawString2 = [_start_date_text text];
    NSCharacterSet *whitespace2 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed2 = [rawString2 stringByTrimmingCharactersInSet:whitespace2];
    
    NSString *rawString3 = [pill_qua_text text];
    NSCharacterSet *whitespace3 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed3 = [rawString3 stringByTrimmingCharactersInSet:whitespace3];
    
    
    
    if([trimmed length] == 0)
    {
        
         [appDelegate.window makeToast:@"Name Empty" duration:1.0 position:@"center"];
        
    }else if ([trimmed1 length] == 0)
    {
         [appDelegate.window makeToast:@"Pin Empty" duration:1.0 position:@"center"];
        
    }else if ([trimmed2 length]== 0)
    {
        
         [appDelegate.window makeToast:@"Start Date Empty" duration:1.0 position:@"center"];
        
    }else if ([trimmed3 length]== 0)
    {
        
        [appDelegate.window makeToast:@"Pill count Empty" duration:1.0 position:@"center"];
        
    }else
    {
        
        NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
        
        
        NSString *TimeStr = [_start_date_text.text substringFromIndex: [_start_date_text.text length] - 8];
        
        NSString *DateStr = [_start_date_text.text substringToIndex:11];
        
        [dic setObject:_name_textfield.text forKey:@"NAME"];
        
        [dic setObject:_pin_textfield.text forKey:@"PIN"];
        
        [dic setObject:DateStr forKey:@"STARTDATE"];
        
        [dic setObject:pill_qua_text.text forKey:@"PILLCOUNT"];
        
        [dic setObject:TimeStr forKey:@"PILLTIME"];
        
        
        
        
        
         NSMutableArray  *Array=[[NSMutableArray alloc]init];
        
         [Array addObject:dic];
        
        
          if ([UserDateArray count]>0)
          {
              [dbh UserUpdate:Array];
             
              [self updateDate];
              
          }
          else
          {
              [dbh insertUser:Array];
              
              [self updateDate];
              
          }
        
        
        DashBoardViewController *objDashBoardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
        
        [self.navigationController pushViewController:objDashBoardViewController animated:YES];
        
        
      //  [self.navigationController popViewControllerAnimated:YES];
        
    }
    
    
    
}


-(void)updateDate
{
    
    NSString *StaryDate=_start_date_text.text;
    
    StaryDate=[StaryDate substringToIndex:10];
    
    
    dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSDate *dateFromString = [[NSDate alloc] init];
    
    dateFromString = [dateFormatter dateFromString:StaryDate];
    
    //3 day......
    
    int daysToAdd = 3;
    NSDate *newDate1 = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd];
    
    NSString *ThreeDayStr = [dateFormatter stringFromDate:newDate1];
    
    appDelegate.update_titleName=@"3 Day Phone Call";
    
    
    [dbh UpdateDateAppo_startdate:ThreeDayStr];
    
    
    //14 day....
    
    int daysToAdd14 = 14;
    NSDate *newDate14 = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd14];
    
    NSString *Str14 = [dateFormatter stringFromDate:newDate14];
    
    appDelegate.update_titleName=@"14 Day Phone Call";
     [dbh UpdateDateAppo_startdate:Str14];
    
    // 1 month
    
    
    int daysToAdd30 = 30;
    NSDate *newDate30 = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd30];
    
    NSString *Str30 = [dateFormatter stringFromDate:newDate30];
    
    appDelegate.update_titleName=@"1 Month Visit";
     [dbh UpdateDateAppo_startdate:Str30];
    
    // 3 month
    
    
    int daysToAdd90 = 90;
    NSDate *newDate90 = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd90];
    
    NSString *Str90 = [dateFormatter stringFromDate:newDate90];
    
    appDelegate.update_titleName=@"3 Month Visit";
    [dbh UpdateDateAppo_startdate:Str90];
    
    
    
    // 6 month
    
    
    int daysToAdd6M = 180;
    NSDate *newDate6M = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd6M];
    
    NSString *Str6M = [dateFormatter stringFromDate:newDate6M];
    
    appDelegate.update_titleName=@"6 Month Visit";
     [dbh UpdateDateAppo_startdate:Str6M];
    
    // 9 month
    
    
    int daysToAdd9M = 270;
    NSDate *newDate9M = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd9M];
    
    NSString *Str9M = [dateFormatter stringFromDate:newDate9M];
    
     appDelegate.update_titleName=@"9 Month Visit";
    [dbh UpdateDateAppo_startdate:Str9M];
    // 1 yr12 Month Visit
    
    
    int daysToAdd1yr = 365;
    NSDate *newDate1yr = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd1yr];
    
     NSString *Str1yr = [dateFormatter stringFromDate:newDate1yr];
    
     appDelegate.update_titleName=@"12 Month Visit";
    [dbh UpdateDateAppo_startdate:Str1yr];
    
}

#pragma mark textViewDidBeginEditing-----------------------------------------------------

static NSInteger stepRange1[] = {
    
    0,0,90,150,150
};



static NSInteger getScrollPos21(NSInteger i) {
    
    if (i < 1 || i > 4)
        return 0 ;
    return stepRange1[i] ;
}

static NSInteger stepRange[] = {
    
    0,0,90,150,150
};



static NSInteger getScrollPos2(NSInteger i) {
    
    if (i < 1 || i > 4)
        return 0 ;
    return stepRange[i] ;
}


- (void)textViewDidBeginEditing:(UITextView *)textView
{
    
    
    _main_scroll.scrollEnabled = YES;
     CGPoint point = CGPointMake(0,700);
    [_main_scroll setContentOffset:point animated:YES] ;
    
}

- (void) textFieldDidBeginEditing:(UITextField *)textField
{
    
    if (textField.tag==4)
    {
         Date_view.hidden=NO;
        
        [textField resignFirstResponder];
        [_name_textfield resignFirstResponder];
        
        [_pin_textfield resignFirstResponder];
        [_start_date_text resignFirstResponder];
        
        [pill_qua_text resignFirstResponder];
        
        
        CGPoint point;
       
        point = CGPointMake(0, getScrollPos21(textField.tag));
        [_main_scroll setContentOffset:point animated:YES] ;
        
      
    }
    else
    {
    
    
    _main_scroll.scrollEnabled = YES;
    
    
    CGPoint point;
        
    if (IS_IPHONE5)
        point = CGPointMake(0, getScrollPos21(textField.tag));
    else
        point = CGPointMake(0, getScrollPos2(textField.tag));
    
    
    [_main_scroll setContentOffset:point animated:YES] ;
    
    }
    
    
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField.tag==4)
    {
        
        Date_view.hidden=NO;
        
        [textField resignFirstResponder];
        
        [_name_textfield resignFirstResponder];
        [_pin_textfield resignFirstResponder];
        [_start_date_text resignFirstResponder];
        [pill_qua_text resignFirstResponder];
      
        
        CGPoint point;
        
        point = CGPointMake(0, getScrollPos21(textField.tag));
        [_main_scroll setContentOffset:point animated:YES] ;
        
        return NO;
    }else
    {
    return YES;
    }
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    _main_scroll.scrollEnabled = YES;
    
    
    
    NSInteger nextTag = textField.tag + 1;
    UIResponder* nextResponder = [textField.superview viewWithTag:nextTag];
    
    if (nextResponder)
    {
        if (nextTag==4)
        {
        
            Date_view.hidden=NO;
            
            CGPoint point = CGPointMake(0, getScrollPos2(nextTag));
            [_main_scroll setContentOffset:point animated:YES];
            
            [_name_textfield resignFirstResponder];
            
            [_pin_textfield resignFirstResponder];
            [_start_date_text resignFirstResponder];
            
            [textField resignFirstResponder];
        }
        else{
        
        [nextResponder becomeFirstResponder];
        CGPoint point = CGPointMake(0, getScrollPos2(nextTag));
        [_main_scroll setContentOffset:point animated:YES];
        }
        
    }
    else
    {
        CGPoint point = CGPointMake(0,64);
        [_main_scroll setContentOffset:point animated:YES] ;
        [textField resignFirstResponder];
        
        

       
    }
    
    return YES;
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    
    if (textField.tag == 2)
    {
     
        if (textField.text.length >= MAX_LENGTH && range.length == 0)
        {
            return NO; // return NO to not change text
        }
       
    /* for backspace */
    if([string length]==0)
    {
        return YES;
    }
    
    /*  limit to only numeric characters  */
    
    NSCharacterSet *myCharSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
    for (int i = 0; i < [string length]; i++) {
        unichar c = [string characterAtIndex:i];
        if ([myCharSet characterIsMember:c]) {
            return YES;
        }
    }
    
    return NO;
    }
    else  if (textField.tag == 3)
    {
        if (textField.text.length >= MAX_LENGTH_Pi && range.length == 0)
        {
            return NO; // return NO to not change text
        }
        
        /* for backspace */
        if([string length]==0)
        {
            return YES;
        }
        
        /*  limit to only numeric characters  */
        
        NSCharacterSet *myCharSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
        for (int i = 0; i < [string length]; i++) {
            unichar c = [string characterAtIndex:i];
            if ([myCharSet characterIsMember:c]) {
                return YES;
            }
        }
        
        return NO;
    }
    
    return YES;
    
}




- (IBAction)back_button_action:(id)sender
{
     [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)Done_Pick_button:(id)sender
{
    
     NSDate *date = [_Date_picker date];
     NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
     [dateFormat setDateFormat:@"yyyy-MM-dd hh:mm:a"];
     _start_date_text.text = [dateFormat stringFromDate:date];
    
    
    
    
    Date_view.hidden=YES;
    
    CGPoint point = CGPointMake(0,0);
    [_main_scroll setContentOffset:point animated:YES] ;
   

    
}

- (IBAction)cancel_Pick_button:(id)sender
{
    _start_date_text.text=@"";
    
    
    Date_view.hidden=YES;
    
    CGPoint point = CGPointMake(0,0);
    [_main_scroll setContentOffset:point animated:YES] ;
    

}
@end
