//
//  AppointmentViewController.m
//  PrEP
//
//  Created by Bhushan on 5/7/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "AppointmentViewController.h"

#import "DashBoardViewController.h"
#import "AppointmentTableViewCell.h"
#import "AddAppointmentViewController.h"
#import "DataBase.h"
#import "AppDelegate.h"
#import "viewTaskViewController.h"
#import "SettingViewController.h"
#import "NotificationViewController.h"
#import "CalViewController.h"
#import "TimeTableViewCell.h"

#define DEGREES_TO_RADIANS(d) (d * M_PI / 180)
#define MAX_LENGTH_Pi 2

#define IS_IPHONE4 (([[UIScreen mainScreen] bounds].size.height-480)?NO:YES)

@interface AppointmentViewController ()<UIScrollViewDelegate>
{
    DataBase *dbh;
  
    
}
@end

@implementation AppointmentViewController

- (void)viewDidLoad
{
    AppDel=[[UIApplication sharedApplication] delegate];
    
    [super viewDidLoad];
   
    
    dbh=[[DataBase alloc]init];
    
    App_Date=[[NSMutableArray alloc]init];
    App_Title=[[NSMutableArray alloc]init];
    App_Comp=[[NSMutableArray alloc]init];
    App_Completed=[[NSMutableArray alloc]init];
    AppID=[[NSMutableArray alloc]init];
    
    TimeRecArray=[[NSMutableArray alloc]init];
    DateRecArray=[[NSMutableArray alloc]init];
    allRecArray=[[NSMutableArray alloc]init];
    

      Rota=NO;
    
    [_task_button setBackgroundImage:[UIImage imageNamed:@"task_selected"] forState:UIControlStateNormal];
    
    
     //ISCOMPLETED ISCONFORM
    
    NSArray *SlectAll=[dbh Select_All_Appointment];
    
    for (int i=0; i<[SlectAll count]; i++)
    {
       
        [App_Title addObject:[[SlectAll objectAtIndex:i]objectForKey:@"TITLE"]];
        [App_Completed addObject:[[SlectAll objectAtIndex:i]objectForKey:@"ISCOMPLETED"]];
        [App_Comp addObject:[[SlectAll objectAtIndex:i]objectForKey:@"ISCONFORM"]];
        [AppID addObject:[[SlectAll objectAtIndex:i]objectForKey:@"ID"]];
        
      //  [App_Date addObject:[[SlectAll objectAtIndex:i]objectForKey:@"DATE"]];
    }
    

    AppDel.Increment_Id_App_Str=[NSString stringWithFormat:@"%lu",(unsigned long)[App_Title count]+2];
    
    NSLog(@"%@",AppDel.Increment_Id_App_Str);
    
    
    
    [_view1.layer setCornerRadius:5.0f];
    
    // border
    [_view1.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [_view1.layer setBorderWidth:1.5f];
    
    // drop shadow
    [_view1.layer setShadowColor:[UIColor blackColor].CGColor];
    [_view1.layer setShadowOpacity:0.8];
    [_view1.layer setShadowRadius:3.0];
    [_view1.layer setShadowOffset:CGSizeMake(2.0, 2.0)];
    
    
    
    
    [_view2.layer setCornerRadius:5.0f];
    
    // border
    [_view2.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [_view2.layer setBorderWidth:1.5f];
    
    // drop shadow
    [_view2.layer setShadowColor:[UIColor blackColor].CGColor];
    [_view2.layer setShadowOpacity:0.8];
    [_view2.layer setShadowRadius:3.0];
    [_view2.layer setShadowOffset:CGSizeMake(2.0, 2.0)];
    
    
    
    [self MainUserData];
    
    
    _main_scroll_view.delegate = self;
   
    _main_scroll_view.clipsToBounds = NO;
    

    
    
    if (IS_IPHONE4)
    {
       
        [_main_scroll_view setContentSize:CGSizeMake(320,400)];
        
        
    }else
    {
        
       
       // [_main_scroll_view setContentSize:CGSizeMake(320,500)];
      
        
    }
    
    
    
    
    
    [self selectTimeReq];
    
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)time_save_button_action:(id)sender
{
    
    _time_view.hidden=YES;
    
    

    
    NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
    
    [dic setObject:nameStr forKey:@"NAME"];
    
    [dic setObject:pinStr forKey:@"PIN"];
    
    [dic setObject:AppDel.Pill_countStr forKey:@"PILLCOUNT"];
    
    [dic setObject:DateStr forKey:@"STARTDATE"];
    
    
    [dic setObject:_select_time.text forKey:@"PILLTIME"];
    
    NSMutableArray  *Array=[[NSMutableArray alloc]init];
    
    [Array addObject:dic];
    
    
    
    [dbh UserUpdate:Array];    
    
    
    [self MainUserData];
    
}

- (IBAction)back_button_action:(id)sender
{
    
    [self.navigationController popViewControllerAnimated:NO];
}

- (IBAction)dash_button_action:(id)sender
{
    DashBoardViewController *objDashBoardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    
    
    [self.navigationController pushViewController:objDashBoardViewController animated:NO];
}

- (IBAction)add_appointments_button_action:(id)sender
{
     AddAppointmentViewController*objAddAppointmentViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"AddAppointmentViewController"];
    
    
    [self.navigationController pushViewController:objAddAppointmentViewController animated:NO];
}

- (IBAction)noti_tab_button_action:(id)sender
{
    NotificationViewController *objNotificationViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"NotificationViewController"];
    
    [self.navigationController pushViewController:objNotificationViewController animated:YES];
}

- (IBAction)cal_tab_button_action:(id)sender
{
    
    CalViewController *objCalViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"CalViewController"];
    
    [self.navigationController pushViewController:objCalViewController animated:YES];
}

- (IBAction)setting_tab_button_action:(id)sender
{
    SettingViewController *objSettingViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"SettingViewController"];
    
    [self.navigationController pushViewController:objSettingViewController animated:YES];
    
}

- (IBAction)pill_count_button_action:(id)sender {
    
    [self PillInsertReq];
    
    if (Rota==YES)
    {
        
        if (MedInt<1)
        {
            
        }else{
            
            MedInt--;
            
            
            NSString *MeStr=[NSString stringWithFormat:@"%d",MedInt];
            
            AppDel.Pill_countStr=[NSString stringWithFormat:@"%@",MeStr];
            
            [dbh Update_pillCount:nameStr];
            
            
            
            [_med_label_cont setTitle:MeStr forState: UIControlStateNormal];
            
            [_med_label_cont setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];
            
            [UIView animateWithDuration:0.80 animations:^{
                _pill_button.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(180));
                
            }];
            [UIView animateWithDuration:0.80 animations:^{
                _pill_button.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(360));
                
            }];
            Rota=NO;
        }
    }
    else
    {
        if (MedInt<1)
        {
            
        }else{
            
            MedInt--;
            
            NSString *MeStr=[NSString stringWithFormat:@"%d",MedInt];
            
            AppDel.Pill_countStr=[NSString stringWithFormat:@"%@",MeStr];
            
            [dbh Update_pillCount:nameStr];
            
            [_med_label_cont setTitle:MeStr forState: UIControlStateNormal];
            
            [_med_label_cont setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];
            
            
            
            
            [UIView animateWithDuration:0.80 animations:^{
                _pill_button.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(180));
                
            }];
            [UIView animateWithDuration:0.80 animations:^{
                _pill_button.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(360));
                
            }];
            
            
            Rota=YES;
        }
    }
    
    
    
}

- (IBAction)Inventory_count_button_action:(id)sender
{
    
}

- (IBAction)change_date_time_action:(id)sender
{
    _time_view.hidden=NO;
}

- (IBAction)pill_save_button_action:(id)sender
{
    
    
    
    
    NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
    
    [dic setObject:nameStr forKey:@"NAME"];
    
    [dic setObject:pinStr forKey:@"PIN"];
    
    [dic setObject:DateStr forKey:@"STARTDATE"];
    
    [dic setObject:_pill_quan_text.text forKey:@"PILLCOUNT"];
    
    
    
    NSMutableArray  *Array=[[NSMutableArray alloc]init];
    
    [Array addObject:dic];
    
    
    
        [dbh UserUpdate:Array];
    
    _pill_view.hidden=YES;
    
    [self MainUserData];

    
    
}

- (IBAction)pill_back_button_action:(id)sender
{
    _pill_view.hidden=YES;
}

- (IBAction)inventory_button_action:(id)sender
{
    _pill_view.hidden=NO;
}


#pragma mark UITableViewDelegate Protocol Methods-----------------------------------



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    NSLog(@"%lu",(unsigned long)[DateRecArray count]);
    
   
        return [DateRecArray count];
        
  
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath

{
    
    return 40;
    
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath

{
    
    
    static NSString *simpleTableIdentifier = @"TimeTableViewCell";
    
    TimeTableViewCell *cell = (TimeTableViewCell *)[_appointment_tableview dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"TimeTableViewCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }

    
    

       int Inder=indexPath.row+1;
    
        cell.date_label.text=[DateRecArray objectAtIndex:indexPath.row];
    
        cell.index_label.text=[NSString stringWithFormat:@"%d",Inder];
    
        cell.time_label.text=[TimeRecArray objectAtIndex:indexPath.row];;

        
        
        
       return cell;
    
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
         AppDel.Sele_ID_viewApp_Str=[AppID objectAtIndex:indexPath.row];
         AppDel.ViewTask_Date=[App_Comp objectAtIndex:indexPath.row];
    
           NSLog(@"%@", AppDel.ViewTask_Date);
          AppDel.ViewTask_tital=[App_Title objectAtIndex:indexPath.row];
    
    
         viewTaskViewController *objviewTaskViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"viewTaskViewController"];
        
        
        [self.navigationController pushViewController:objviewTaskViewController animated:NO];
}
-(void)MainUserData
{
    NSMutableArray *UserDateArray=[[NSMutableArray alloc]init];
    
    UserDateArray=[dbh selectAllUser];
    
    
    if ([UserDateArray count]>0)
    {//PIN,STARTDATE
        
        nameStr=[[UserDateArray objectAtIndex:0] objectForKey:@"NAME"];
        AppDel.Pill_countStr=[[UserDateArray objectAtIndex:0] objectForKey:@"PILLCOUNT"];
        pinStr=[[UserDateArray objectAtIndex:0] objectForKey:@"PIN"];
        DateStr=[[UserDateArray objectAtIndex:0] objectForKey:@"STARTDATE"];
        PillTimeStr=[[UserDateArray objectAtIndex:0] objectForKey:@"PILLTIME"];
        
    }
    
    
    [_med_label_cont setTitle: AppDel.Pill_countStr forState: UIControlStateNormal];
    
    NSString *MedStr=[NSString stringWithFormat:@"%@",_med_label_cont.titleLabel.text];
    
    
    MedInt=[MedStr intValue];
    
    _time_of_change_label.text=[NSString stringWithFormat:@"Time of Day to Take : %@",PillTimeStr];
    
    _select_time.text=[NSString stringWithFormat:@"%@",PillTimeStr];
    
    
}

- (IBAction)chageTime_back:(id)sender
{
    _time_view.hidden=YES;
}

- (IBAction)time_Done_button_action:(id)sender
{
    
     NSDate *date = [_time_picker date];
     NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"hh:mm:a"];
    _select_time.text = [dateFormat stringFromDate:date];
    
    
    NSLog(@"%@",_select_time.text);
    
    // _time_view.hidden=YES;
    
}

- (IBAction)time_cancel_button_action:(id)sender
{
    _time_view.hidden=YES;
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    
   
    
    if (textField.tag == 0)
    {
        if (textField.text.length >= MAX_LENGTH_Pi && range.length == 0)
        {
            return NO; // return NO to not change text
        }
        
        /* for backspace */
        if([string length]==0)
        {
            return YES;
        }
        
        /*  limit to only numeric characters  */
        
        NSCharacterSet *myCharSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
        for (int i = 0; i < [string length]; i++) {
            unichar c = [string characterAtIndex:i];
            if ([myCharSet characterIsMember:c]) {
                return YES;
            }
        }
        
        return NO;
    }
    
    return YES;
    
}


-(void)selectTimeReq
{
    TimeRecArray=[[NSMutableArray alloc]init];
    DateRecArray=[[NSMutableArray alloc]init];
    allRecArray=[[NSMutableArray alloc]init];
    
    allRecArray=[dbh selectMEDICAL_RECORD];
    
    if ([allRecArray count]>0)
    {
        for (int i=0; i<[allRecArray count]; i++)
        {
            [DateRecArray addObject:[[allRecArray objectAtIndex:i] objectForKey:@"START_DATE"]];
            
            [TimeRecArray addObject:[[allRecArray objectAtIndex:i] objectForKey:@"MED_TIME"]];
        }
        
    }else
    {
        
        
        
        
        
        
    }
  
    [_appointment_tableview reloadData];
    
}


-(void)PillInsertReq
{
    
    NSDate *currentDateInLocal = [NSDate date];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    NSDateFormatter *dateFormat1 = [[NSDateFormatter alloc] init];
    
    [dateFormat setDateFormat:@"yyyy-MM-dd"];
    NSString *DateStr1 = [dateFormat stringFromDate:currentDateInLocal];
    
    [dateFormat1 setDateFormat:@"HH:mm:ss"];
    
    NSString* timeStr=[dateFormat1 stringFromDate:currentDateInLocal];
    
    NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
    
    
    [dic setObject:@"1" forKey:@"USER_ID"];
    [dic setObject:@"Medicine 1" forKey:@"MED_NAME"];
    [dic setObject:DateStr1 forKey:@"START_DATE"];
    [dic setObject:@"0" forKey:@"MED_TAKEN"];
    [dic setObject:@"1" forKey:@"MED_QUNTITY"];
    [dic setObject:timeStr forKey:@"MED_TIME"];
    
    
    
    NSMutableArray *dealArray=[[NSMutableArray alloc]init];
    
    [dealArray addObject:dic];
    
    [dbh insertMEDICAL_RECORD:dealArray];
    
    [self selectTimeReq];
    
    
}


@end
