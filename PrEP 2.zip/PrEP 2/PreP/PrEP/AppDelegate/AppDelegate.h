//
//  AppDelegate.h
//  PrEP
//
//  Created by Bhushan on 5/1/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    NSString *dbPath;
    NSString *deviceToken;
    
       NSMutableData *xmldata;
    
    
}

@property (strong, nonatomic) UIWindow *window;

@property (retain, nonatomic)NSString *dbpath;
@property (retain, nonatomic)NSString *AltertStr;
@property (retain, nonatomic)NSString *Title_App_Str;
@property (retain, nonatomic)NSString *CompSel_App_Str;
@property (retain, nonatomic)NSString *Increment_Id_App_Str;
@property (retain, nonatomic)NSString *Sele_ID_viewApp_Str;
@property (retain, nonatomic)NSString *ViewTask_tital;
@property (retain, nonatomic)NSString *ViewTask_Date;

@property (retain, nonatomic)NSString *Edit_Date_Appstr;
@property (retain, nonatomic)NSString *update_titleName;

@property (retain, nonatomic)NSString *Cal_dateStr;
@property (retain, nonatomic)NSString *Cal_TitleStr;
@property (retain, nonatomic)NSString *Cal_DescStr;
@property (retain, nonatomic)NSString *Pill_countStr;


-(void)PostdeviceToken;

-(void)onTick:(NSTimer *)timer;
-(void)db;


@end

