//
//  DashBoardViewController.h
//  PrEP
//
//  Created by Bhushan on 5/6/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DashBoardViewController : UIViewController

{
    
    NSMutableArray *Iscomp_DateArray,*Iscomp_Tital;
    NSMutableArray *UpComming_DateArray,*UpComming_Tital;
    NSMutableArray *Over_DateArray,*Over_Tital;
    
    BOOL OverShow;
    BOOL upcomingShow;
    BOOL Rota;
    BOOL CompShow;
    int MedInt;
    NSString *nameStr;
    
  
    
}

@property (strong, nonatomic) IBOutlet UITableView *overdue_tableview;

@property (strong, nonatomic) IBOutlet UITableView *upcoming_tableview;

@property (strong, nonatomic) IBOutlet UITableView *completed_tableview;

@property (strong, nonatomic) IBOutlet UIView *view1;

@property (strong, nonatomic) IBOutlet UIView *view2;

@property (strong, nonatomic) IBOutlet UIView *view3;

@property (strong, nonatomic) IBOutlet UIView *view4;

@property (strong, nonatomic) IBOutlet UIButton *dashborad_button;

@property (strong, nonatomic) IBOutlet UIButton *overdue_button;
@property (strong, nonatomic) IBOutlet UIButton *upcoming_button;

@property (strong, nonatomic) IBOutlet UIButton *completed_button;

@property (strong, nonatomic) IBOutlet UIScrollView *main_scroll;
@property (strong, nonatomic) IBOutlet UIButton *pill_button;

@property (strong, nonatomic) IBOutlet UIButton *med_label_cont;



- (IBAction)back_button_action:(id)sender;
- (IBAction)task_button_action:(id)sender;

- (IBAction)Appintment_button_action:(id)sender;

- (IBAction)medical_alerts_button_action:(id)sender;

- (IBAction)normal_alerts_button_action:(id)sender;

- (IBAction)notification_Tab_button_action:(id)sender;

- (IBAction)cal_tab_button_action:(id)sender;

- (IBAction)setting_tab_button_action:(id)sender;

- (IBAction)overdue_button_action:(id)sender;

- (IBAction)upcoming_button_action:(id)sender;

- (IBAction)completed_button_action:(id)sender;

- (IBAction)pill_button_action:(id)sender;

-(void)PillInsertReq;
-(void)selectTimeReq;


@end
