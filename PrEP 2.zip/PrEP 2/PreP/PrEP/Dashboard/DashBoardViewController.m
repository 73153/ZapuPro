//
//  DashBoardViewController.m
//  PrEP
//
//  Created by Bhushan on 5/6/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "DashBoardViewController.h"
#define DEGREES_TO_RADIANS(d) (d * M_PI / 180)
@interface DashBoardViewController ()<UIScrollViewDelegate>
{
    DataBase *dbh;
}

@end

@implementation DashBoardViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    OverShow=NO;
    upcomingShow=NO;
    CompShow=NO;
    
    Rota=NO;
    
    dbh=[[DataBase alloc]init];
    Iscomp_DateArray=[[NSMutableArray alloc]init];
    Iscomp_Tital=[[NSMutableArray alloc]init];
    
    UpComming_DateArray=[[NSMutableArray alloc]init];
    UpComming_Tital=[[NSMutableArray alloc]init];;
    Over_DateArray=[[NSMutableArray alloc]init];
    Over_Tital=[[NSMutableArray alloc]init];;

    
    
    _main_scroll.delegate = self;
    [_main_scroll setCanCancelContentTouches:NO];
    _main_scroll.clipsToBounds = NO;
    _main_scroll.scrollEnabled = NO;

    
    NSMutableArray *UserDateArray=[[NSMutableArray alloc]init];
    
    UserDateArray=[dbh selectAllUser];
    
    
    if ([UserDateArray count]>0)
    {//PIN,STARTDATE
        
        nameStr=[[UserDateArray objectAtIndex:0] objectForKey:@"NAME"];
        
        appDelegate.Pill_countStr=[[UserDateArray objectAtIndex:0] objectForKey:@"PILLCOUNT"];
        
    }
    else
    {
        appDelegate.Pill_countStr = 0;
    }
    
   
    [_med_label_cont setTitle: appDelegate.Pill_countStr forState: UIControlStateNormal];
    
    NSString *MedStr=[NSString stringWithFormat:@"%@",_med_label_cont.titleLabel.text];
    
    
    MedInt=[MedStr intValue];
    
    
    
    
    
    NSArray *SlectIsComp=[dbh Select_All_Appointment];;
    
    for (int i=0; i<[SlectIsComp count]; i++)
    {
        [Iscomp_DateArray addObject:[[SlectIsComp objectAtIndex:i]objectForKey:@"DATE"]];
        [Iscomp_Tital addObject:[[SlectIsComp objectAtIndex:i]objectForKey:@"TITLE"]];
        
    }
    
    
//-------------------------------------------------------------------------------------------------
    
    NSArray *UpComming=[dbh AppointmentSelect_upcomming];
    
    
    for (int i=0; i<[UpComming count]; i++)
    {
        [UpComming_DateArray addObject:[[UpComming objectAtIndex:i]objectForKey:@"DATE"]];
        [UpComming_Tital addObject:[[UpComming objectAtIndex:i]objectForKey:@"TITLE"]];
        
    }
    
    
    
//-------------------------------------------------------------------------------------------------
    
    
    NSArray *Over=[dbh AppointmentSelect_overdue];
    
    for (int i=0; i<[Over count]; i++)
    {
        [Over_DateArray addObject:[[Over objectAtIndex:i]objectForKey:@"DATE"]];
        [Over_Tital addObject:[[Over objectAtIndex:i]objectForKey:@"TITLE"]];
        
    }
    
    
    
    //completed shadow set
    _completed_button.layer.shadowColor = [UIColor blackColor].CGColor;
    _completed_button.layer.shadowOpacity = 0.5;
    _completed_button.layer.shadowRadius = 5;
    _completed_button.layer.shadowOffset = CGSizeMake(3.0f,3.0f);
    _completed_button.layer.cornerRadius = 5;
    
    
    
    _upcoming_button.layer.shadowColor = [UIColor blackColor].CGColor;
    _upcoming_button.layer.shadowOpacity = 0.5;
    _upcoming_button.layer.shadowRadius = 5;
    _upcoming_button.layer.shadowOffset = CGSizeMake(3.0f,3.0f);
    _upcoming_button.layer.cornerRadius = 5;
    
    
    _overdue_button.layer.shadowColor = [UIColor blackColor].CGColor;
    _overdue_button.layer.shadowOpacity = 0.5;
    _overdue_button.layer.shadowRadius = 5;
    _overdue_button.layer.shadowOffset = CGSizeMake(3.0f,3.0f);
    _overdue_button.layer.cornerRadius = 5;
    
    
   
  
    
   
    
    
    
    

   
    
  
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated
{
    
    NSLog(@"viewWillAppear");
    
    
    
}

-(void)DisaplayAllData
{
    
}


- (IBAction)back_button_action:(id)sender
{
    
    


    ViewController *objViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
    
    
   
    
    
    NSArray *viewControllers = [[self navigationController] viewControllers];
    
    
    NSLog(@"%@",viewControllers);
    NSLog( @"%@",viewControllers);
    for( int i=0;i<[viewControllers count];i++)
    {
        id obj=[viewControllers objectAtIndex:i];
        if([obj isKindOfClass:[objViewController class]])
        {
            [[self navigationController] popToViewController:obj animated:NO];
            return;
        }
    }

    
    
    
}

- (IBAction)task_button_action:(id)sender
{
    
    
    AppointmentViewController *objAppointmentViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"AppointmentViewController"];
    
    
    [self.navigationController pushViewController:objAppointmentViewController animated:NO];
    
}

#pragma mark Alerts button Action...

- (IBAction)Appintment_button_action:(id)sender
{
    appDelegate.AltertStr=@"Alerts Set By User";
    
    AlertsViewController *objAlertsViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"AlertsViewController"];
    
    
    [self.navigationController pushViewController:objAlertsViewController animated:NO];
}

- (IBAction)medical_alerts_button_action:(id)sender
{
    appDelegate.AltertStr=@"Medical Alerts";
    
    AlertsViewController *objAlertsViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"AlertsViewController"];
    
    
    [self.navigationController pushViewController:objAlertsViewController animated:NO];
}

- (IBAction)normal_alerts_button_action:(id)sender
{
    
     appDelegate.AltertStr=@"Normal Alerts";
    
    AlertsViewController *objAlertsViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"AlertsViewController"];
    
    
    [self.navigationController pushViewController:objAlertsViewController animated:NO];
}

- (IBAction)notification_Tab_button_action:(id)sender
{
    
    
    NotificationViewController *objNotificationViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"NotificationViewController"];
    
    
    [self.navigationController pushViewController:objNotificationViewController animated:NO];
}

- (IBAction)cal_tab_button_action:(id)sender
{
    CalViewController *objCalViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"CalViewController"];
    [self.navigationController pushViewController:objCalViewController animated:NO];
}

- (IBAction)setting_tab_button_action:(id)sender
{
    SettingViewController *objSettingViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"SettingViewController"];
    [self.navigationController pushViewController:objSettingViewController animated:NO];
}

#pragma mark OverDue Button Action.....

- (IBAction)overdue_button_action:(id)sender
{
    
    if (OverShow == NO)
    {
      
        upcomingShow=NO;
        CompShow=NO;
        
        _view1.hidden=NO;
        _view2.hidden=YES;
        _view3.hidden=YES;
        
        
        if (IS_IPHONE4)
        {
            _view1.frame =  CGRectMake(25,311,270,0);
            [_main_scroll setContentSize:CGSizeMake(320,442)];
            _upcoming_button.frame=CGRectMake(20, 325, 280, 35);
            _completed_button.frame=CGRectMake(20, 372, 280, 35);
            
        }else
        {
            
            _view1.frame =  CGRectMake(25,399,270,0);
            [_main_scroll setContentSize:CGSizeMake(320,500)];
            _upcoming_button.frame=CGRectMake(20, 415, 280, 35);
            _completed_button.frame=CGRectMake(20, 462, 280, 35);
            
        }

        
        
        [UIView animateWithDuration:0.50 animations:^{
           if (IS_IPHONE4)
           {
               
               
               _main_scroll.scrollEnabled = YES;
               _view1.frame =  CGRectMake(25,311,270,150);
               
               [_main_scroll setContentSize:CGSizeMake(320,560)];
               
               
               
               _upcoming_button.frame=CGRectMake(20, 458, 280, 35);
               _completed_button.frame=CGRectMake(20, 507, 280, 35);
               
               
               

                
           }else
           {
               
               
               
               _main_scroll.scrollEnabled = YES;
               _view1.frame =  CGRectMake(25,399,270,150);
               
               [_main_scroll setContentSize:CGSizeMake(320,660)];
               
               _upcoming_button.frame=CGRectMake(20, 542, 280, 35);
               _completed_button.frame=CGRectMake(20, 585, 280, 35);
           }
            
            
        }];
        
        OverShow=YES;
    }
    else
    {
        
        _main_scroll.scrollEnabled = NO;
        [UIView animateWithDuration:0.50 animations:^{
           if (IS_IPHONE4)
           {
          
             
               _view1.frame =  CGRectMake(25,311,270,0);
               
               [_main_scroll setContentSize:CGSizeMake(320,442)];
               _upcoming_button.frame=CGRectMake(20, 325, 280, 35);
               _completed_button.frame=CGRectMake(20, 372, 280, 35);

                
           }else
           {
              
               _view1.frame =  CGRectMake(25,399,270,0);
               [_main_scroll setContentSize:CGSizeMake(320,510)];
               _upcoming_button.frame=CGRectMake(20, 415, 280, 35);
               _completed_button.frame=CGRectMake(20, 462, 280, 35);
               
           }
            
        }];
        
        OverShow=NO;
    }
    
    
}

- (IBAction)upcoming_button_action:(id)sender
{
   
    
    if (upcomingShow == NO)
    {
        _view1.hidden=YES;
        _view2.hidden=NO;
        _view3.hidden=YES;
        
        OverShow =NO;
        CompShow=NO;
        
        
        if (IS_IPHONE4)
        {
            _view2.frame =  CGRectMake(25,353,270,0);
            [_main_scroll setContentSize:CGSizeMake(320,450)];
            _upcoming_button.frame=CGRectMake(20, 325, 280, 35);
            _completed_button.frame=CGRectMake(20, 372, 280, 35);

            
        }else
        {
            
            _view2.frame =  CGRectMake(25,441,270,0);
            [_main_scroll setContentSize:CGSizeMake(320,540)];
            _upcoming_button.frame=CGRectMake(20, 415, 280, 35);
            _completed_button.frame=CGRectMake(20, 462, 280, 35);
            
        }

        
        
        [UIView animateWithDuration:0.50 animations:^{
            if (IS_IPHONE4)
            {
               
                
                _main_scroll.scrollEnabled = YES;
                _view2.frame =  CGRectMake(25,353,270,150);
                
                [_main_scroll setContentSize:CGSizeMake(320,590)];
                _completed_button.frame=CGRectMake(20, 500, 280, 35);
                
            }else
            {
                 _completed_button.frame=CGRectMake(20, 460, 280, 35);
               
                
                _main_scroll.scrollEnabled = YES;
                
                _view2.frame =  CGRectMake(25,441,270,150);
                
                [_main_scroll setContentSize:CGSizeMake(320,646)];
                _completed_button.frame=CGRectMake(20, 584, 280, 35);
               
            }
            
            
        }];
        
        upcomingShow=YES;
    }
    else
    {
        
        _main_scroll.scrollEnabled = NO;
        
        [UIView animateWithDuration:0.50 animations:^{
            if (IS_IPHONE4)
            {
                
                _view2.frame =  CGRectMake(25,353,270,0);
                
                [_main_scroll setContentSize:CGSizeMake(320,450)];
                
                _upcoming_button.frame=CGRectMake(20, 325, 280, 35);
                _completed_button.frame=CGRectMake(20, 372, 280, 35);

              
                
                
            }else
            {
                _view2.frame =  CGRectMake(25,441,270,0);                
                
                [_main_scroll setContentSize:CGSizeMake(320,540)];
                _upcoming_button.frame=CGRectMake(20, 415, 280, 35);
                _completed_button.frame=CGRectMake(20, 462, 280, 35);
              
                
            }
            
        }];
        
        upcomingShow=NO;
    }
    
    
}

- (IBAction)completed_button_action:(id)sender
{
    
    
    if (CompShow == NO)
    {
        _view1.hidden=YES;
        _view2.hidden=YES;
        _view3.hidden=NO;
        OverShow =NO;
        upcomingShow=NO;
        
        if (IS_IPHONE4)
        {
            _view3.frame =  CGRectMake(25,400,270,0);
            [_main_scroll setContentSize:CGSizeMake(320,450)];
            
        }else
        {
            _view3.frame =  CGRectMake(25,488,270,0);            
            [_main_scroll setContentSize:CGSizeMake(320,540)];
            _completed_button.frame=CGRectMake(20, 460, 280, 35);
        }

        
        
        
        [UIView animateWithDuration:0.50 animations:^{
            if (IS_IPHONE4)
            {
                _main_scroll.scrollEnabled = YES;
                _view3.frame =  CGRectMake(25,400,270,150);
                [_main_scroll setContentSize:CGSizeMake(320,590)];
                
                
                //
                
                _upcoming_button.frame=CGRectMake(20, 325, 280, 35);
                _completed_button.frame=CGRectMake(20, 372, 280, 35);
                
               
                
            }else
            {
                _main_scroll.scrollEnabled = YES;
                _view3.frame =  CGRectMake(25,488,270,150);
                [_main_scroll setContentSize:CGSizeMake(320,660)];
                
                //
                _upcoming_button.frame=CGRectMake(20, 415, 280, 35);
                _completed_button.frame=CGRectMake(20, 462, 280, 35);
                
                
                
            }
            
            
        }];
        
        CompShow=YES;
    }
    else
    {
        
        _main_scroll.scrollEnabled = NO;
        
        [UIView animateWithDuration:0.50 animations:^{
            if (IS_IPHONE4)
            {
                  _main_scroll.scrollEnabled = NO;
                
                _view3.frame =  CGRectMake(25,400,270,0);
                [_main_scroll setContentSize:CGSizeMake(320,450)];
                
                
                
            }else
            {
              
                _view3.frame =  CGRectMake(25,488,270,0);
                
                [_main_scroll setContentSize:CGSizeMake(320,540)];
                _completed_button.frame=CGRectMake(20, 460, 280, 35);
                
            }
            
        }];
        
        CompShow=NO;
    }
    
    
}

- (IBAction)pill_button_action:(id)sender
{
    [self PillInsertReq];
    
    
    
    
    
    if (Rota==YES)
    {
        
        if (MedInt<1)
        {
            
        }else{
        
        MedInt--;
        
        
        NSString *MeStr=[NSString stringWithFormat:@"%d",MedInt];
            
        appDelegate.Pill_countStr=[NSString stringWithFormat:@"%@",MeStr];
            
            [dbh Update_pillCount:nameStr];
            
            
        
        [_med_label_cont setTitle:MeStr forState: UIControlStateNormal];
        
        [_med_label_cont setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];

        [UIView animateWithDuration:0.80 animations:^{
            _pill_button.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(180));
            
        }];
        [UIView animateWithDuration:0.80 animations:^{
            _pill_button.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(360));
            
        }];
        Rota=NO;
        }
    }
    else
    {
        if (MedInt<1)
        {
            
        }else{
        
        MedInt--;
 
        NSString *MeStr=[NSString stringWithFormat:@"%d",MedInt];
            
            appDelegate.Pill_countStr=[NSString stringWithFormat:@"%@",MeStr];
        
        [dbh Update_pillCount:nameStr];
            
        [_med_label_cont setTitle:MeStr forState: UIControlStateNormal];
        
            [_med_label_cont setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];
        
        
        
        
        [UIView animateWithDuration:0.80 animations:^{
            _pill_button.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(180));
            
        }];
        [UIView animateWithDuration:0.80 animations:^{
            _pill_button.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(360));
            
        }];

        
        Rota=YES;
        }
    }
    
    
   
}


#pragma mark UITableViewDelegate Protocol Methods-----------------------------------



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    if(tableView.tag==0)
    {
        return [Over_DateArray count];
        
    }
    if (tableView.tag==1)
    {
         return [UpComming_DateArray count];
        
        
    }
    if(tableView.tag==2)
    {
         return [Iscomp_Tital count];
        
    }
    
   
    
    return 0;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath

{
    
    return 30;
    
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath

{
    
    if (tableView.tag==0)
    {
        
        static NSString *simpleTableIdentifier = @"DashboardCustomCellTableViewCell";
        
        DashboardCustomCellTableViewCell *cell = (DashboardCustomCellTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"DashboardCustomCellTableViewCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
        
        cell.tital_label.text=[Over_Tital objectAtIndex:indexPath.row];
        cell.date_label.text=[Over_DateArray objectAtIndex:indexPath.row];
        
        int Ins=indexPath.row+1;
        
        cell.index_label.text=[NSString stringWithFormat:@"%d",Ins];
        
        
        return cell;
    }
    
    
    if (tableView.tag==1)
    {
        static NSString *simpleTableIdentifier = @"DashboardCustomCellTableViewCell";
        
        DashboardCustomCellTableViewCell *cell = (DashboardCustomCellTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"DashboardCustomCellTableViewCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
        
        cell.tital_label.text=[UpComming_Tital objectAtIndex:indexPath.row];
        cell.date_label.text=[UpComming_DateArray objectAtIndex:indexPath.row];
        
           int Ins=indexPath.row+1;
        cell.index_label.text=[NSString stringWithFormat:@"%d",Ins];
        
        
         return cell;
        
    } if(tableView.tag==2)
    {
        
        static NSString *simpleTableIdentifier = @"DashboardCustomCellTableViewCell";
        
        DashboardCustomCellTableViewCell *cell = (DashboardCustomCellTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"DashboardCustomCellTableViewCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
        }
        
        
        cell.tital_label.text=[Iscomp_Tital objectAtIndex:indexPath.row];
        cell.date_label.text=[Iscomp_DateArray objectAtIndex:indexPath.row];
        
         int Ins=indexPath.row+1;
        cell.index_label.text=[NSString stringWithFormat:@"%d",Ins];
        
        
        return cell;
        
        
    }
  
    
    return 0;
   


}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    if (tableView.tag==0)
    {
        
        appDelegate.Title_App_Str=[Over_Tital objectAtIndex:indexPath.row];
        
        EditAppointmentViewViewController *objEditAppointmentViewViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"EditAppointmentViewViewController"];
        
        
        [self.navigationController pushViewController:objEditAppointmentViewViewController animated:NO];
        
    }
    
    if (tableView.tag==1)
    {
         appDelegate.Title_App_Str=[UpComming_Tital objectAtIndex:indexPath.row];
        
        
        EditAppointmentViewViewController *objEditAppointmentViewViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"EditAppointmentViewViewController"];
        
        
        [self.navigationController pushViewController:objEditAppointmentViewViewController animated:NO];
    }

    if (tableView.tag==2)
    {
         appDelegate.CompSel_App_Str=@"1";
        
         appDelegate.Title_App_Str=[Iscomp_Tital objectAtIndex:indexPath.row];
        
        EditAppointmentViewViewController *objEditAppointmentViewViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"EditAppointmentViewViewController"];
        
        
        [self.navigationController pushViewController:objEditAppointmentViewViewController animated:NO];
        
    }
    
    
}

-(void)PillInsertReq
{
    
    NSDate *currentDateInLocal = [NSDate date];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    NSDateFormatter *dateFormat1 = [[NSDateFormatter alloc] init];
    
    [dateFormat setDateFormat:@"yyyy-MM-dd"];
    NSString *DateStr = [dateFormat stringFromDate:currentDateInLocal];
    
    [dateFormat1 setDateFormat:@"HH:mm:ss"];
    
    NSString* timeStr=[dateFormat1 stringFromDate:currentDateInLocal];
    
    NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
    
    
     [dic setObject:@"1" forKey:@"USER_ID"];
     [dic setObject:@"Medicine 1" forKey:@"MED_NAME"];
     [dic setObject:DateStr forKey:@"START_DATE"];
     [dic setObject:@"0" forKey:@"MED_TAKEN"];
     [dic setObject:@"1" forKey:@"MED_QUNTITY"];
     [dic setObject:timeStr forKey:@"MED_TIME"];
    
    
    
    NSMutableArray *dealArray=[[NSMutableArray alloc]init];
    
    [dealArray addObject:dic];
    
    [dbh insertMEDICAL_RECORD:dealArray];
    
   
    
    
}


@end
