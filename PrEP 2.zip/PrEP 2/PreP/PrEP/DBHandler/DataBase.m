//
//  DataBase.m
//  PrEP
//
//  Created by Bhushan on 5/5/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "DataBase.h"

@implementation DataBase

#pragma mark Select user Details.....

-(NSMutableArray *)selectAllUser
{
   
    
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
        
        query=@"select * from USER_INFO ";
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                dict=[[NSMutableDictionary alloc]init];
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 0)] forKey:@"NAME"];
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 1)] forKey:@"PIN"];
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 3)] forKey:@"STARTDATE"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 2)] forKey:@"PILLCOUNT"];
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 4)] forKey:@"PILLTIME"];
                
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
    
    
    
    
    
    
}


#pragma mark Insert user Details.....

-(BOOL)insertUser:(NSArray *)dealArray
{
    
    NSLog(@"%@",dealArray);
    
    BOOL isok=NO;
    
    sqlite3_stmt    *statement5;
    
    
    
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        for (int i = 0; i<[dealArray count];i++)
        {
            
           query = [NSString stringWithFormat: @"INSERT INTO USER_INFO (NAME,PIN,PILLCOUNT,STARTDATE,PILLTIME) VALUES ('%@','%@','%@','%@','%@')",[[dealArray objectAtIndex:i]objectForKey:@"NAME"],[[dealArray objectAtIndex:i]objectForKey:@"PIN"],[[dealArray objectAtIndex:i]objectForKey:@"PILLCOUNT"],[[dealArray objectAtIndex:i]objectForKey:@"STARTDATE"],[[dealArray objectAtIndex:i]objectForKey:@"PILLTIME"]];
            
            const char *insert_stmt = [query UTF8String];
            
            sqlite3_prepare_v2(db, insert_stmt, -1, &statement5, NULL);
            if (sqlite3_step(statement5) == SQLITE_DONE)
            {
                NSLog(@"Data Deals---->");
                
            } else {
                
            }
            sqlite3_finalize(statement5);
        }
        sqlite3_close(db);
    }
    return isok;
    
    
}

#pragma mark Update user

-(BOOL)UserUpdate:(NSArray*)Array
{
    BOOL isok=NO;
    
    NSLog(@"%@",Array);
    
    
     NSString *NameStr=[[Array objectAtIndex:0] objectForKey:@"NAME"];
     NSString *PinStr=[[Array objectAtIndex:0] objectForKey:@"PIN"];
     NSString *StartDateStr=[[Array objectAtIndex:0] objectForKey:@"STARTDATE"];
     NSString *PILLCOUNTStr=[[Array objectAtIndex:0] objectForKey:@"PILLCOUNT"];
     NSString *PILLTIMEStr=[[Array objectAtIndex:0] objectForKey:@"PILLTIME"];
    
    
    query=[NSString stringWithFormat:@"UPDATE USER_INFO SET PIN='%@',STARTDATE='%@',PILLCOUNT='%@',PILLTIME='%@' WHERE NAME ='%@'",PinStr,StartDateStr,PILLCOUNTStr,PILLTIMEStr,NameStr];
    
    NSLog(@"%@",query);
    
    if(sqlite3_open([appDelegate.dbpath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            
        }
        sqlite3_finalize(stm);
    }
    
    if (isok==YES)
    {
         [appDelegate.window makeToast:@"Successfully updated" duration:1.0 position:@"center"];
        
    }else
    {
        //Update user not in datebase then insert new user
        
        [self insertUser:Array];
    }
    
    sqlite3_close(db);
    
    return isok;

   
}

#pragma mark Slect All Appintment.....

//-(NSMutableArray*)AppointmentSelect_IsCompleted{
//    
//    
//    NSMutableArray *data=[[NSMutableArray alloc]init];
//    NSMutableDictionary *dict;
//    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
//    {
//        
//        query=@"select * from APPOITMENTS WHERE ISCOMPLETED='0' ORDER BY DATE DESC";
//        
//        
//        sqlite3_stmt *stm;
//        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
//        {
//            
//            while(sqlite3_step(stm)==SQLITE_ROW)
//            {
//                
//                
//                dict=[[NSMutableDictionary alloc]init];
//                
//                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 0)] forKey:@"DATE"];
//                
//                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 3)] forKey:@"TITLE"];
//                
//               
//                
//                
//                [data addObject:dict];
//                NSLog(@"%@",data);
//                
//                
//            }
//            sqlite3_finalize(stm);
//        }
//        // }
//        sqlite3_close(db);
//    }
//    
//    return data;
//    
//    
//    
//    
//    
//    
//}

#pragma mark Upconning Appointment...

-(NSMutableArray*)AppointmentSelect_upcomming
{
    
    NSDateFormatter *DateFormatter=[[NSDateFormatter alloc] init];
    [DateFormatter setDateFormat:@"yyyy-MM-dd"];
     NSString *DateStr=[DateFormatter stringFromDate:[NSDate date]];
    
    
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
        query=[NSString stringWithFormat:@"select * from APPOITMENTS WHERE  DATE >= '%@' ORDER BY DATE DESC",DateStr];
        
        
        NSLog(@"%@",query);
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                dict=[[NSMutableDictionary alloc]init];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 1)] forKey:@"DATE"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 4)] forKey:@"TITLE"];
                
                
                
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
    
    
    
    
    
    
}

#pragma mark Overdue Appointment...

-(NSMutableArray*)AppointmentSelect_overdue
{
    
    NSDateFormatter *DateFormatter=[[NSDateFormatter alloc] init];
    [DateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSString *DateStr=[DateFormatter stringFromDate:[NSDate date]];
    
    
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
        query=[NSString stringWithFormat:@"select * from APPOITMENTS WHERE  DATE < '%@' AND ISCOMPLETED='1' ORDER BY DATE DESC",DateStr];
        
        
        NSLog(@"%@",query);
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                dict=[[NSMutableDictionary alloc]init];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 1)] forKey:@"DATE"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 4)] forKey:@"TITLE"];
                
                
                
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
    
    
    
    
    
    
}


#pragma mark Slect all Appointment......

-(NSMutableArray*)Select_All_Appointment
{
    
    //ISCOMPLETED ISCONFORM
    
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
        query=[NSString stringWithFormat:@"select * from APPOITMENTS "];
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                dict=[[NSMutableDictionary alloc]init];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 2)] forKey:@"ISCOMPLETED"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 4)] forKey:@"TITLE"];
                
                
                
                 [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 0)] forKey:@"ID"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 7)] forKey:@"ISCONFORM"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 1)] forKey:@"DATE"];
                
                
                
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
    
        
    
    
}

#pragma mark Slect All Alets.......

-(NSMutableArray*)Select_All_Alerts:(NSString *)Str
{
    
    //ISCOMPLETED ISCONFORM
    
    NSLog(@"%@",Str);
    
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
        query=[NSString stringWithFormat:@"select * from ALERT WHERE ALERTTYPE=%@",Str];
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                dict=[[NSMutableDictionary alloc]init];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 2)] forKey:@"ALERTMSG"];
                
                
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
    
    
    
    
}

#pragma mark.. Edit Appointment.........

-(NSMutableArray*)EditAppointment:(NSString *)Str;{
    
    NSLog(@"%@",Str);
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
         query=[NSString stringWithFormat:@"select * from APPOITMENTS WHERE TITLE='%@'",Str];
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                dict=[[NSMutableDictionary alloc]init];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 1)] forKey:@"DATE"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 4)] forKey:@"TITLE"];
                
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 5)] forKey:@"DESC"];
                
                
                
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
    
    
    
    
    
    
}
-(BOOL)AppointmentUpdate:(NSArray*)Array
{
    BOOL isok=NO;
    
    NSLog(@"%@",Array);
    
    NSString *NameStr=[[Array objectAtIndex:0] objectForKey:@"TITLE"];
    NSString *PinStr=[[Array objectAtIndex:0] objectForKey:@"DESC"];
    NSString *StartDateStr=[[Array objectAtIndex:0] objectForKey:@"DATE"];
    
    
    query=[NSString stringWithFormat:@"UPDATE APPOITMENTS SET DESC='%@',DATE='%@',TITLE='%@' WHERE TITLE ='%@'",PinStr,StartDateStr,NameStr,appDelegate.Title_App_Str];
    
    NSLog(@"%@",query);
    
    if(sqlite3_open([appDelegate.dbpath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            
        }
        sqlite3_finalize(stm);
    }
    
    if (isok==YES)
    {
        [appDelegate.window makeToast:@"Successfully updated" duration:1.0 position:@"center"];
        
    }else
    {
        //Update user not in datebase then insert new user
        
       
    }
    
    sqlite3_close(db);
    
    return isok;
    
    
}
-(BOOL)AddAppointment:(NSArray*)dealArray
{
    
    NSLog(@"%@",dealArray);
    
    BOOL isok=NO;
    
    sqlite3_stmt    *statement5;
    
    
    
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        for (int i = 0; i<[dealArray count];i++)
        {
            
            query = [NSString stringWithFormat: @"INSERT INTO APPOITMENTS (DATE,ISCOMPLETED,USERID,TITLE,DESC,ID,TIME,ISCONFORM) VALUES ('%@','%@','%@','%@','%@','%@','%@','%@')",[[dealArray objectAtIndex:i]objectForKey:@"DATE"],[[dealArray objectAtIndex:i]objectForKey:@"ISCOMPLETED"],[[dealArray objectAtIndex:i]objectForKey:@"USERID"],[[dealArray objectAtIndex:i]objectForKey:@"TITLE"],[[dealArray objectAtIndex:i]objectForKey:@"DESC"],[[dealArray objectAtIndex:i]objectForKey:@"ID"],[[dealArray objectAtIndex:i]objectForKey:@"TIME"],[[dealArray objectAtIndex:i]objectForKey:@"ISCONFORM"]];
            
            const char *insert_stmt = [query UTF8String];
            
            sqlite3_prepare_v2(db, insert_stmt, -1, &statement5, NULL);
            if (sqlite3_step(statement5) == SQLITE_DONE)
            {
               
                 [appDelegate.window makeToast:@"Successfully Add Appointment" duration:1.0 position:@"center"];
            }
            else
            {
                
            }
            sqlite3_finalize(statement5);
        }
        sqlite3_close(db);
    }
    return isok;
    
    
}

-(NSMutableArray*)AllTask:(NSString *)Str
{
    
    NSLog(@"%@",Str);
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
        query=[NSString stringWithFormat:@"select * from TASK_LIST WHERE APPOITMENT_ID='%@'",Str];
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                dict=[[NSMutableDictionary alloc]init];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 0)] forKey:@"TASK_NAME"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 6)] forKey:@"ISCOMPLETED"];
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
    
    
    
    
    
    
}


-(BOOL)insertTask:(NSArray*)dealArray
{
    
    NSLog(@"%@",dealArray);
    
    BOOL isok=NO;
    
    sqlite3_stmt    *statement5;
    
    
    
    
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        for (int i = 0; i<[dealArray count];i++)
        {
            
            query = [NSString stringWithFormat: @"INSERT INTO TASK_LIST (TASK_NAME,TASK_DESCRIPTION,APPOITMENT_ID,USER_ID,TASK_DATE,TIME,ISCOMPLETED) VALUES ('%@','%@','%@','%@','%@','%@','%@')",[[dealArray objectAtIndex:i]objectForKey:@"TASK_NAME"],[[dealArray objectAtIndex:i]objectForKey:@"TASK_DESCRIPTION"],[[dealArray objectAtIndex:i]objectForKey:@"APPOITMENT_ID"],[[dealArray objectAtIndex:i]objectForKey:@"USER_ID"],[[dealArray objectAtIndex:i]objectForKey:@"TASK_DATE"],[[dealArray objectAtIndex:i]objectForKey:@"TIME"],[[dealArray objectAtIndex:i]objectForKey:@"ISCOMPLETED"]];
            
            const char *insert_stmt = [query UTF8String];
            
            sqlite3_prepare_v2(db, insert_stmt, -1, &statement5, NULL);
            if (sqlite3_step(statement5) == SQLITE_DONE)
            {
                
                [appDelegate.window makeToast:@"Successfully Add Task" duration:1.0 position:@"center"];
            }
            else
            {
                
            }
            sqlite3_finalize(statement5);
        }
        sqlite3_close(db);
    }
    return isok;
    
    
}

-(BOOL)UpdateAppointDate:(NSString *)Str
{
    BOOL isok=NO;
    
    query=[NSString stringWithFormat:@"UPDATE APPOITMENTS SET ISCONFORM='%@'WHERE ID ='%@'",Str,appDelegate.Sele_ID_viewApp_Str];
    
    NSLog(@"%@",query);
    
    if(sqlite3_open([appDelegate.dbpath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            
        }
        sqlite3_finalize(stm);
    }
    
    if (isok==YES)
    {
        if ([Str isEqualToString:@"1"])
        {
              [appDelegate.window makeToast:@"Date Confirmed" duration:1.0 position:@"center"];
        }else
        {
             [appDelegate.window makeToast:@"Date Not Confirmed" duration:1.0 position:@"center"];
        }
      
        
    }
    
    sqlite3_close(db);
    
    return isok;
    
    
}

-(BOOL)TaskUpdateCompleted:(NSString *)Str
{
    
    BOOL isok=NO;
    
    query=[NSString stringWithFormat:@"UPDATE TASK_LIST SET ISCOMPLETED='1'WHERE APPOITMENT_ID ='%@' AND TASK_NAME='%@'",appDelegate.Sele_ID_viewApp_Str,Str];
    
    
    NSLog(@"%@",query);
    
    if(sqlite3_open([appDelegate.dbpath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            
        }
        sqlite3_finalize(stm);
    }
    
    if (isok==YES)
    {
        
        
    }
    
    sqlite3_close(db);
    
   
     return isok;
    
    
}

-(BOOL)UpdateDateAppo_startdate:(NSString *)Str;

{
    
    BOOL isok=NO;
    
   query=[NSString stringWithFormat:@"UPDATE APPOITMENTS SET DATE='%@',ISCONFORM='0'WHERE TITLE ='%@'",Str,appDelegate.update_titleName];
    
    
    NSLog(@"%@",query);
    
    if(sqlite3_open([appDelegate.dbpath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            
        }
        sqlite3_finalize(stm);
    }
    
    if (isok==YES)
    {
        
        
    }
    
    sqlite3_close(db);
    
    
    return isok;
    
    
}


-(NSMutableArray*)AppointmentSelect_Inconform
{
    
    //BHUSHAN
    
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
        //query=[NSString stringWithFormat:@"select * from APPOITMENTS WHERE  ISCONFORM='1' ORDER BY DATE DESC"];
        
        query=[NSString stringWithFormat:@"select * from APPOITMENTS WHERE ISCOMPLETED ='1' ORDER BY DATE DESC"];
        

        NSLog(@"%@",query);
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                dict=[[NSMutableDictionary alloc]init];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 1)] forKey:@"DATE"];
                
                               
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
  
    
    
    
}
-(NSMutableArray*)Appointment_cal_info:(NSString *)Str
{
    
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
        query=[NSString stringWithFormat:@"SELECT * FROM APPOITMENTS WHERE DATE='%@'",Str];
        
        
        NSLog(@"%@",query);
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                 dict=[[NSMutableDictionary alloc]init];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 1)] forKey:@"DATE"];
                
                 [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 4)] forKey:@"TITLE"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 5)] forKey:@"DESC"];
                
                
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
    
    
    
    
}


-(BOOL)insertnotifications:(NSArray*)dealArray
{
    
    //CREATE TABLE "NOTIFICATION" ("MSG" VARCHAR, "DATE" VARCHAR, "ID" VARCHAR, "READCHECK" INTEGER)
    
    
    BOOL isok=NO;
    
    sqlite3_stmt    *statement5;
    
    
    
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        for (int i = 0; i<[dealArray count];i++)
        {
            
            query = [NSString stringWithFormat: @"INSERT INTO NOTIFICATION (MSG,DATE,ID,READCHECK) VALUES ('%@','%@','%@','%@')",[[dealArray objectAtIndex:i]objectForKey:@"MSG"],[[dealArray objectAtIndex:i]objectForKey:@"DATE"],[[dealArray objectAtIndex:i]objectForKey:@"ID"],[[dealArray objectAtIndex:i]objectForKey:@"READCHECK"]];
            
            const char *insert_stmt = [query UTF8String];
            
            sqlite3_prepare_v2(db, insert_stmt, -1, &statement5, NULL);
            if (sqlite3_step(statement5) == SQLITE_DONE)
            {
                NSLog(@"Data Notification---->");
                
            } else
            {
                
            }
            sqlite3_finalize(statement5);
        }
        sqlite3_close(db);
    }
    return isok;
    
    
}

-(NSMutableArray*)Selection_All_notification
{
    //CREATE TABLE "NOTIFICATION" ("MSG" VARCHAR, "DATE" VARCHAR, "ID" VARCHAR, "READCHECK" INTEGER)
    
    
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
        query=[NSString stringWithFormat:@"SELECT * FROM NOTIFICATION"];
        
        
        NSLog(@"%@",query);
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                dict=[[NSMutableDictionary alloc]init];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 0)] forKey:@"MSG"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 1)] forKey:@"DATE"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 2)] forKey:@"ID"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 3)] forKey:@"READCHECK"];
                
                
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
    
    
    
    
}

-(BOOL)Update_pillCount:(NSString *)Str
{
    
    BOOL isok=NO;
    
    query=[NSString stringWithFormat:@"UPDATE USER_INFO SET PILLCOUNT='%@'WHERE NAME ='%@'",appDelegate.Pill_countStr,Str];
    
    
    NSLog(@"%@",query);
    
    if(sqlite3_open([appDelegate.dbpath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            
        }
        sqlite3_finalize(stm);
    }
    
    if (isok==YES)
    {
        
        
    }
    
    sqlite3_close(db);
    
    
    return isok;
    
    
}


-(BOOL)insertMEDICAL_RECORD:(NSArray*)dealArray
{
    
    NSLog(@"%@",dealArray);
    
    BOOL isok=NO;
    
    sqlite3_stmt    *statement5;
    
    
    
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        for (int i = 0; i<[dealArray count];i++)
        {
            
            query = [NSString stringWithFormat: @"INSERT INTO MEDICAL_RECORD (USER_ID,MED_NAME,START_DATE,MED_TAKEN,MED_QUNTITY,MED_TIME) VALUES ('%@','%@','%@','%@','%@','%@')",[[dealArray objectAtIndex:i]objectForKey:@"USER_ID"],[[dealArray objectAtIndex:i]objectForKey:@"MED_NAME"],[[dealArray objectAtIndex:i]objectForKey:@"START_DATE"],[[dealArray objectAtIndex:i]objectForKey:@"MED_TAKEN"],[[dealArray objectAtIndex:i]objectForKey:@"MED_QUNTITY"],[[dealArray objectAtIndex:i]objectForKey:@"MED_TIME"]];
            
            const char *insert_stmt = [query UTF8String];
            
            sqlite3_prepare_v2(db, insert_stmt, -1, &statement5, NULL);
            if (sqlite3_step(statement5) == SQLITE_DONE)
            {
                NSLog(@"Data Deals---->");
                
            } else {
                
            }
            sqlite3_finalize(statement5);
        }
        sqlite3_close(db);
    }
    return isok;
    
    
}
-(NSMutableArray *)selectMEDICAL_RECORD
{
    
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
        query=[NSString stringWithFormat:@"select * from MEDICAL_RECORD"];
        
        
        NSLog(@"%@",query);
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                dict=[[NSMutableDictionary alloc]init];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 3)] forKey:@"START_DATE"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 6)] forKey:@"MED_TIME"];
                
                
                
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
    
    
    
    
    
    
}


-(BOOL)Comp_task:(NSString *)Str
{
    BOOL isok=NO;
    
   
    
    
    query=[NSString stringWithFormat:@"UPDATE APPOITMENTS SET ISCOMPLETED='0' WHERE TITLE ='%@'",Str];
    
    NSLog(@"%@",query);
    
    if(sqlite3_open([appDelegate.dbpath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            
        }
        sqlite3_finalize(stm);
    }
    
    if (isok==YES)
    {
        [appDelegate.window makeToast:@"Successfully updated" duration:1.0 position:@"center"];
        
    }else
    {
        //Update user not in datebase then insert new user
        
        
    }
    
    sqlite3_close(db);
    
    return isok;
    
    
}

@end
