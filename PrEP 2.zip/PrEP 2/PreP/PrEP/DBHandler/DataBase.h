//
//  DataBase.h
//  PrEP
//
//  Created by Bhushan on 5/5/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>
@interface DataBase : NSObject
{
    NSString *dataPath;
    sqlite3 *db;
    NSString *query;
}

-(NSMutableArray *)selectAllUser;

-(BOOL)insertUser:(NSArray *)dealArray;

-(BOOL)UserUpdate:(NSArray*)Array;

-(NSMutableArray*)AppointmentSelect_IsCompleted;

-(NSMutableArray*)AppointmentSelect_upcomming;

-(NSMutableArray*)AppointmentSelect_overdue;

-(NSMutableArray*)Select_All_Appointment;

-(NSMutableArray*)Select_All_Alerts:(NSString *)Str;

-(NSMutableArray*)EditAppointment:(NSString *)Str;

-(BOOL)AppointmentUpdate:(NSArray*)Array;

-(BOOL)AddAppointment:(NSArray*)Array;

-(NSMutableArray*)AllTask:(NSString *)Str;

-(BOOL)insertTask:(NSArray*)Array;

-(BOOL)UpdateAppointDate:(NSString *)Str;

-(BOOL)TaskUpdateCompleted:(NSString *)Str;

-(BOOL)UpdateDateAppo_startdate:(NSString *)Str;

-(NSMutableArray*)AppointmentSelect_Inconform;

-(NSMutableArray*)Appointment_cal_info:(NSString *)Str;

-(BOOL)insertnotifications:(NSArray*)Array;

-(NSMutableArray*)Selection_All_notification;

-(BOOL)Update_pillCount:(NSString *)Str;

-(BOOL)insertMEDICAL_RECORD:(NSArray*)dealArray;

-(NSMutableArray *)selectMEDICAL_RECORD;

-(BOOL)Comp_task:(NSString *)Str;
@end
