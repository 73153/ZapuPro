//
//  AddApoinmentCell.h
//  PrEP
//
//  Created by pradip.r on 7/16/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddApoinmentCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *addApoinmentTitleLable;


@end
