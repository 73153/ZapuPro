//
//  AppointmentTableViewCell.h
//  PrEP
//
//  Created by Bhushan on 5/7/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppointmentTableViewCell : UITableViewCell
{
    
}

@property (strong, nonatomic) IBOutlet UILabel *index_lable;

@property (strong, nonatomic) IBOutlet UILabel *tital_label;

@end
