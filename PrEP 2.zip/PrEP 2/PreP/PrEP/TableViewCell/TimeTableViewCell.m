//
//  TimeTableViewCell.m
//  PrEP
//
//  Created by Bhushan on 7/15/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "TimeTableViewCell.h"

@implementation TimeTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
