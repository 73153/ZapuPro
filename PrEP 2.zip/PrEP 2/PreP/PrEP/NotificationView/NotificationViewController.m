//
//  NotificationViewController.m
//  PrEP
//
//  Created by Bhushan on 5/13/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "NotificationViewController.h"

#import "SettingViewController.h"
#import "DashBoardViewController.h"
#import "NotificationViewController.h"
#import "AppointmentViewController.h"
#import "CalViewController.h"
#import "DataBase.h"
#import "AppointmentTableViewCell.h"

@interface NotificationViewController ()
{
    DataBase *dbh;
}
@end

@implementation NotificationViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    dbh=[[DataBase alloc]init];
    
    // Do any additional setup after loading the view.
    
    [_view1.layer setCornerRadius:5.0f];
    
    // border
    [_view1.layer setBorderColor:[UIColor orangeColor].CGColor];
    [_view1.layer setBorderWidth:1.5f];
    
    // drop shadow
    [_view1.layer setShadowColor:[UIColor blackColor].CGColor];
    [_view1.layer setShadowOpacity:0.8];
    [_view1.layer setShadowRadius:3.0];
    [_view1.layer setShadowOffset:CGSizeMake(2.0, 2.0)];
    
    
    
    [_view2.layer setCornerRadius:5.0f];
    
    // border
    [_view2.layer setBorderColor:[UIColor orangeColor].CGColor];
    [_view2.layer setBorderWidth:1.5f];
    
    // drop shadow
    [_view2.layer setShadowColor:[UIColor blackColor].CGColor];
    [_view2.layer setShadowOpacity:0.8];
    [_view2.layer setShadowRadius:3.0];
    [_view2.layer setShadowOffset:CGSizeMake(2.0, 2.0)];
    
    
    SelNotication=[[NSMutableArray alloc]init];
    msgArray=[[NSMutableArray alloc]init];
    reIdArray=[[NSMutableArray alloc]init];
    
    SelNotication=[dbh Selection_All_notification];
    
    NSLog(@"%@",SelNotication);
    
    for (int i=0; i<[SelNotication count]; i++)
    {
       
          [msgArray addObject:[[SelNotication objectAtIndex:i]objectForKey:@"MSG"]];
        
          [reIdArray addObject:[[SelNotication objectAtIndex:i]objectForKey:@"READCHECK"]];
        
        
    }
    
    
    
    
    
    
}


#pragma mark UITableViewDelegate Protocol Methods-----------------------------------



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    
    return [msgArray count];
    
    
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath

{
    
    return 40;
    
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath

{
    
    
    static NSString *simpleTableIdentifier = @"AppointmentTableViewCell";
    
    AppointmentTableViewCell *cell = (AppointmentTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"AppointmentTableViewCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    //App_Comp
    
    
    
    int Inder=indexPath.row+1;
    
    cell.tital_label.text=[msgArray objectAtIndex:indexPath.row];
    
    cell.index_lable.text=[NSString stringWithFormat:@"%d",Inder];
    
    
    
    return cell;
    
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
   
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)dash_tab_button_action:(id)sender
{
    DashBoardViewController *objDashBoardViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    
    
    [self.navigationController pushViewController:objDashBoardViewController animated:YES];
    
}

- (IBAction)setting_tab_button_action:(id)sender
{
    SettingViewController *objSettingViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"SettingViewController"];
    
    
    [self.navigationController pushViewController:objSettingViewController animated:YES];
    
}

- (IBAction)task_tab_button_action:(id)sender
{
    AppointmentViewController *objAppointmentViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"AppointmentViewController"];
    
    
    [self.navigationController pushViewController:objAppointmentViewController animated:YES];
    
}

- (IBAction)cal_tab_button_action:(id)sender
{
    CalViewController *objCalViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"CalViewController"];
    
    
    [self.navigationController pushViewController:objCalViewController animated:YES];
}


@end
